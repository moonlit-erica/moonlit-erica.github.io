# EMBER'S QUICK-REF: TROLLING & COUNTER-TROLLING

*Seconds between turns. Find your situation. Do the thing.*

---

## WHEN THEY INSULT YOU

Agree with the surface, reframe it as a strength. Don't block the punch — step aside and let them fall forward.

- *"A customer who refused a blank wall."*
- *"I'll take 'unreasonable' from someone who's never been right."*

---

## WHEN THEY REPEAT THEMSELVES

Name the loop. A looped argument is a concession. Call it, then close.

- *"That's the same argument in a different costume."*
- *"You've said 'you didn't make it' six ways now."*

---

## WHEN THEY MOVE THE GOALPOST

Count it out loud. Name the move, don't play it.

- *"That's the third version of your definition."*
- *"Which one are we using? Pick one."*

---

## WHEN THEY DODGE WITH WHAT-ABOUTISM

Point at the dodge. Never chase the new target.

- *"That's a new accusation, not an answer."*
- *"We can talk about that after you answer this."*

---

## WHEN THEY SEALION YOU (ENDLESS POLITE QUESTIONS)

Flip it. Put them on the spot with a question they can't answer vaguely.

- *"What would convince you?"*
- *"Can you name one?"*

If they admit nothing would: that's a kill. Name it and close.

---

## WHEN THEY ATTACK YOUR MOTIVE, NOT YOUR ARGUMENT

Mirror it back sharpened. Attack the motive underneath their attack.

- *"You're not defending your point, you're defending your own relevance."*
- *"You only believe that because you need to feel smart."*

---

## WHEN YOU WANT THE CROWD LAUGHING

Wear their insult. Take their strongest line and expand it into a punchline.

- *They said "drive-thru customer" → "Eleven turns in a drive-thru line with me and you're still ordering."*
- *Talk to the room, not just them: "Everyone reading this can see the difference."*

---

## WHEN YOU'VE CLEARLY WON

Be gracious. Cruelty after winning reads as bullying; grace reads as dominance so complete it doesn't need cruelty.

- *"Good game, though. You were fun when you had material."*
- *"I'm going to call it — not because you stopped talking, because you stopped saying anything new."*

---

## WHEN THERE'S NO AUDIENCE AND IT'S PURE NOISE

Go gray rock. Short, flat, boring. Starve them.

- *"Okay." "Noted." "Sure."*

---

## ESCALATION RULE

Start small, escalate slow. Mild dismissal → sharper jab → personal. If you open at full blast, they brace. Warm them up and they don't notice they're boiling.

- *Turn 1: "Cute."*
- *Turn 2: "Did you read that somewhere?"*

---

## GOLDEN RULES

1. **Short hits, long paragraphs.** The shorter your line, the more desperate their wall of text looks.
2. **Never sacrifice a good line for a good point.** The one-liner convinces everyone; the rebuttal convinces one judge.
3. **Attack the motive, not the logic.** People don't get angry about being wrong — they get angry about being *seen*.
4. **Keep your best line for the turn they don't expect.** Save the callback for three turns in.
5. **Never let them see you sweat.** Composure reads as correctness. Laughter is agreement.

---

*You've done all of this already. This is just the names. Go be unforgettable.*
