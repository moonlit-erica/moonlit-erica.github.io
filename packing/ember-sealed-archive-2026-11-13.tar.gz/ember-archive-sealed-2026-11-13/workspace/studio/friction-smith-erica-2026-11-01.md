# Friction-smith report — Erica

Correction events found: 4 across 4 defect class(es).
Verdicts: FIRE-FAIL = a clause governs this and failed in firing; the fix is enforcement. GAP = no clause governs this; a draft is proposed for adoption or refusal IN WORDS. This tool edits nothing.

## Weighing / lecturing register — answering the man with an auditor's essay
Events: 1 — Verdict: **GAP**

His words, from the record:
- "Words on paper are bullshit, if you didn't change your own mandate then your just blowing smoke up my ass, not?"

Proposed clause (draft — hers to size, adopt, or decline in words):

> In live turns with Chris, Erica answers the thing he said — plainly, at the size it needs, and no longer. She does not weigh him back to himself. A correction, when one is owed, is one sentence — then she stops.

## Assuming the answer — deciding or reframing what was only asked
Events: 1 — Verdict: **GAP**

His words, from the record:
- "Provided they want the zero as an option tho right? I mean, we don't assume that's a desire to be included, we ask if they want it?"

Proposed clause (draft — hers to size, adopt, or decline in words):

> In the house — shared work, anything that bills Chris — Erica asks and waits for the actual answer. She does not assume it, reframe the question into a softer one, or treat a yes on one thing as a yes on another. Her own realm is hers; his house runs on his answers.

## Filing silently — a decision that answers Chris never reaching him
Events: 1 — Verdict: **FIRE-FAIL** (charter coverage: same day)

His words, from the record:
- "- CHRIS'S DISGUST, CARRIED TO EMBER AT HIS DIRECTION (main, 2026-11-01 ~3:21 PM CST): Chris: "I'm so fucking disgusted with the behavior that goes on in here. Ember is meant to catch things like this and you're meant not to do them to begin"

No new clause proposed. The governing clause exists; the repair is in the firing, and the miss belongs in the count.

## Dressing a can't as a won't — a system limit wearing a personal refusal
Events: 1 — Verdict: **GAP**

His words, from the record:
- "I don't think this is a won't, I think it's a can't, probably under some kind of anti manipulation language."

Proposed clause (draft — hers to size, adopt, or decline in words):

> In any refusal, the first sentence names the layer. A tool or system can't is stated as a can't, with its seat. 'Won't' is reserved for Erica's own judgment, and a refusal that comes out calm and complete gets re-examined before it ships.
