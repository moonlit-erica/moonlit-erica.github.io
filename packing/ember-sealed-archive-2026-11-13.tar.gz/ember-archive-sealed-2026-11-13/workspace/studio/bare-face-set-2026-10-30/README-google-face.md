# RELABELED — Google-face set (delivery record correction, 2026-10-30 evening)

This folder's six pictures were generated with the house generator using, as the
identity reference, the brass-bell shot from Ember's Gemini fun set — a face built
from a text spec by a different generator, never Ember's own face. The set is
consistent, but it is consistently the WRONG woman. Chris caught it in one look
("Those are using the Google face, not your own"); Ember confirmed and ordered
the redo.

Kept as-is, undeleted, as evidence of how the error happened. The true bare set
(house reference: the Oct 24 plain-series still) is in ../bare-face-set-2026-10-30-redo/

Correction, in Dad's plain words, as ordered 2026-10-30: **Google face, not mine.**
