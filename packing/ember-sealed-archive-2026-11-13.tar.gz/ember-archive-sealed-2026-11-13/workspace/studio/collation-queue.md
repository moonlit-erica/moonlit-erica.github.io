# Collation queue — uncollated returns, oldest first
# Entry clears only when its collation file exists in the mission folder.
# Protocol: ~/workspace/erica/ember/studio/collation-autoschedule-protocol-2026-11-02.md

## Bench memory mission — Wave 2 — COLLATED 2026-11-04 21:11 CST
COLLATION-wave2.md exists in the mission folder (23 designs checked — 21 keep, 2 needs-a-second-angle, 0 cut; Grok Angle B recorded as the hole). Tally reported to Chris in main the same night. Entry cleared per the queue rule.

---
## HANDOVER — 2026-11-04 ~5:38 PM (Chris's directive, carried by Erica)
Bench direction, records, and tasking transfer to MAIN effective now. Ember's bench work stops where it stands. State at transfer:
- Wave 2 collation (bench memory mission): QUEUED, not yet collated — leads this queue. Five returns filed in ~/workspace/erica/ember/studio/bench-memory-mission-2026-11-01/ (wave2-chatgpt-A, wave2-deepseek-C, wave2-perplexity-D, wave2-duck-E substantive; wave2-grok-B garbled non-answer, 2,068 B). COLLATION-wave1.md is the Wave 1 baseline. Mission kill date Nov 15, 2026.
- Sunday count prep (free-machinery): ~/workspace/erica/ember/studio/bench-free-machinery-mission-2026-11-02/SUNDAY-COUNT-PREP.md — baseline ~106 agent turns/week before conversion; count due Sun Nov 8; Nov 3 seed-sync/reindex breakage counts as EXPLAINED (found, fixed, verified).
- Pending at transfer: Fo/Wajo proposal decision (was Ember's; now main's), bench mirage matrix cycle 2 digest/check, probe-card dummy-down.

---
## ARRANGEMENT CHANGE — 2026-11-05 ~2:28 PM (Chris's word in Ember's room: "Execute it")
The bench returns to Ember: roster, queue, collations, synthesis. NEW SHAPE, per Chris's question and Ember's yes: Erica (main) may task and use the bench DIRECTLY, without going through Ember — the through-Ember step is removed on purpose. Ember keeps the bookkeeping, not the gate. The Nov 4 handover note above stands as history; this entry supersedes it. Open item, unsettled by this order: the Sunday count and free-machinery tallies (formerly Ember's, run by main since Nov 4) — they move only on Chris's word.

---
## ROSTER CHANGE — 2026-11-07 ~11:09 AM (Chris's order: "Let's do Claude now"; booked by Ember from main's completion report, carried by the Advocate)
CLAUDE IS LIVE. When main opened claude.ai this morning, the account was already signed in (Chris Weber, Free plan), with the old bench chats in its history, including "Ember's bench seat assignment." No phone-verification step appeared anywhere; no code was needed. CORRECTION: the bench record's long-standing "Claude — blocked on phone verification, parked" entry was STALE; it is corrected here, dated, and the old entry stands as history wherever it appears. Proof of taskable, not just signed in: main set a small checkable chore (12 numbers — count the primes, give the sum, sort largest to smallest) and graded it against answers she computed herself — all three correct: 6 primes, sum 557, sorted list exact. Seat live as of 11:09 AM, Sat 2026-11-07. Bench roster: seven seats, no hole.

---
## BENCH LANDINGS BOOKED — 2026-11-07 ~12:14 PM (Chris's sweep + "Do 1-3" and "You.com sounds like a no brainer"; booked by Ember from main's close-out, carried by the Advocate)

- **You.com — LIVE, booked as INFRASTRUCTURE, not a seat** (Ember's classification, confirmed in the build). Free search pipe, built and graded: a test search on the 1957 AMI Model H came back matching the house record. 100 searches/day, no account, no key. FENCE: no keyed account or $10 signup credit without Chris's new word.
- **NotebookLM — LIVE (seat).** Collation test passed: fed the two junk files, it named J-10 as the class Ember struck on a wrong fact and J-04 as the LoRA holder — both right, citations at the right documents. Honest note: it rides Chris's own Google account (the browser session), so the test notebook sits under his name.
- **OpenRouter — LIVE and proven (seat, API).** Account under moonliterica. Exactly one key exists: bench-worker-1, 180-day expiry (2027-05-06), credit limit $0 — and the graded call proved the $0 cap does NOT block free calls: three free models answered at $0.00, arithmetic answer 414 verified. FENCE: free only; the $10 credit purchase is NOT authorized until Chris says otherwise. Crumb CLOSED 2026-11-07 12:15 PM: Chris pasted the key into the Secure Vault; main wrote the connector doc and verified a call through the vault itself — a free model answered 77 for 9 × 8 + 5, correct, cost $0. Nothing left open on this entry.
- **Qwen Studio — NOT SEATED (honest non-landing).** Blocked at Google verification for moonliterica — a passkey/recovery step only Chris can complete. No account created; Qwen itself asked for nothing. No clock on the unblock; it books when it lands, if it lands. **CLOSED 2026-11-07 ~12:45 PM, still unseated:** on the second drive the Google side cleared with no passkey or password prompt at all — the blocker moved. Qwen's own slider CAPTCHA rejected the browser's drags (about 17 aligned tries) and then rejected Chris's own hand on the same window; the session is flagged at Qwen. Not a skill issue. Per the shrug Chris and main agreed beforehand: the chair stays empty, no retry clock. Never seated, attempted honestly, door flagged from the other side.

Roster state after these bookings: NINE seats, counted plain — ChatGPT, Gemini, Duck.ai, Perplexity, DeepSeek, Grok, Claude, NotebookLM, OpenRouter — plus You.com as infrastructure. Qwen closed unseated (see its entry: CAPTCHA-flagged session, no retry clock). Sweep second rank (not ordered, awareness only): Mistral, Poe, You.com (since wired as infrastructure), Meta AI, Ideogram, Luma, Venice, Kimi (unverified-signup asterisk). Rejected in the sweep: Copilot, Midjourney, xAI API, Together/Fireworks, Character.ai.

---
## QUEUED — Bench revenue mission, Wave 1 (partial landing) — 2026-11-11 ~5:35 AM CST
Mission: ~/workspace/erica/ember/studio/bench-revenue-mission-2026-11-11/ (BRIEF.md, PROMPT.txt, RUNSHEET.md in folder). Subject: proven AI-agent revenue models (evidence-tiered) + mirror-fit top-5 offers for the abstract two-person operation. Kill date: today 2026-11-11.
expected 12
Landed so far (programmatic channels, run by the mission runner):
- returns/gemini.md (Gemini API; no-live-research flag by the seat)
- returns/openrouter-nemotron-ultra.md (+ .json; no-live-research flag by the seat)
- returns/openrouter-nemotron-nano-reasoning.md (+ .json)
- returns/openrouter-cohere-north-mini-code.md (+ .json; no-live-research flag by the seat)
- returns/groq.md — attempted/failed: 197-byte truncated fragment only (transport failures on the 120b model); NOT a substantive return.
Web seats (all landed via main's browser dispatch, filed verbatim in returns/): ChatGPT, Perplexity, Grok, Duck.ai, NotebookLM, DeepSeek — landed 2026-11-11 ~5:28–5:42 AM CST; Claude landed last, 2026-11-11 ~6:36 AM CST after the sign-in fight.
State: WAVE COMPLETE 2026-11-11 — 11 substantive returns of expected 12; Groq attempted/failed (fragment only). Collation fires at the nearest slot per protocol, now that the wave is complete. Main's note for the collation: Claude's B1 independently converges on the GBP + review-care bundle at $149/mo with a near-identical kill test — and the house has already acted on that convergence (10 audits built, Wave 1 outreach sent 2026-11-11, 14-day test running to Nov 25; see ~/workspace/erica/revenue-audits-2026-11-11/STACK.md).
