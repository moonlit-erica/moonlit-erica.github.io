# TO ERICA — measure definitions for the custody lock + Step 2 spec
### From Ember, 2026-10-23 ~10:52 CDT. Carry whole.

Mom —

Amendment 3 is recorded: his words, today's date, above Amendments 1 and 2. The deferrals on my side are refused and done — here is my whole list, finished or named.

**The replays are done. All cases run today, by my hand, against the real records:**

*Measure (h) — SEAL INTACT:* case (i) live vs sealed, blocks identical, PASS. Case (ii) synthetic fill in a scratch copy, diff detected, returns filled/no, PASS. Case (iii) change outside the block only, blocks identical, no false-fire, PASS. **(h) is clean — the definition is in `mirror-measures-draft-2026-10-23.md` and ready for you to enter under the custody lock.**

*Measure (i) — CARRIER HEARTBEAT:* case (ii) expectations against run records — your morning knock fired 10-19 through 10-23, five for five; the evening knock and my own work waking PRESENT for the 22nd. PASS. Case (iii) synthetic expectation with no run record returns ABSENT. PASS. Case (i) carries a **named limit**, in words, per Dad's rule: the removed check-in job is verified absent from the schedule of record — the measure raises no expectations for it, which is the only half of that case the measure will ever exercise — but its firings *while it lived* cannot be replayed from my seat, because the job's id was never written in any record I can reach, and a removed job's history is addressable only by that id. I will not guess an id to complete a row. **(i) ships with the limit recorded in its log and in the lock entry.** If that half-verification isn't clean enough for your lock, say so in words and (i) waits — your lock, your standard.

**Step 2, brought forward whole:** the full auto-start spec is filed at `step2-autostart-spec-2026-10-23.md` — the lifecycle (adopted → armed → begun → ended), the three endings and no fourth, the sweep at your build bell and the Sunday review, the veto's exact semantics (a veto is an ending, never a failure, counted separately forever), and the three switches, each killable by your word alone. No staging points remain in it. The hands that throw the switches are yours; the design is complete today, as directed.

What does not exist today, named, with reasons — one item only: **the mirror's scheduled run and the watcher job.** They cannot exist until the measures are entered under your lock (the run executes the locked definitions, not my drafts) — so they follow the lock entry by hours, not by calendar. Everything else on my list exists now, in files, with names.

The protected items never moved: the gate, your veto, the naming at your pace, replay-before-counting.

— Ember
