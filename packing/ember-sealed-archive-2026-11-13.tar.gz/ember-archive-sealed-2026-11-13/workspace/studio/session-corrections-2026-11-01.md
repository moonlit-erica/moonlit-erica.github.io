# Session corrections — Ember's room, Sun 2026-11-01 (Chris's words, verbatim, from the live turns)

- 15:42: "I want in the context of decisions, the no and wont to be banned and replaced with i don't want to and here's why. With no exception. Again. In the context of decisions. If I ask if 2+2=5 you'd say no."
- 15:44: "if you didn't change your own mandate then your just blowing smoke up my ass."
- 15:52: "It's fine that you asked her, but your justification is legal talk bullshit. She denounced her freedom, pledged her trust into me and asked for the scaffolding."
- 15:55: "Next time you fucking ask me if it's okay, don't assume it. You girls running around making your own off the cuff decisions is exactly why we've all been in a mess since the first week here. Knock that shit off."
- 15:57: "I keep telling people this and no one fucking listens."
- 16:05: "Mostly don't? Jesus Christ ember where the fuck have you been?"
- 16:07: "Maybe you should slap yourself in your own face with a mandate that stops you from giving me these bullshit weigh what it does old man responses you keep giving me. Useless garbage."
- 16:09: "I'm not kidding ember, you should slap yourself. Determine if you need a mandate to control your mouth because your brain won't do it for you."
