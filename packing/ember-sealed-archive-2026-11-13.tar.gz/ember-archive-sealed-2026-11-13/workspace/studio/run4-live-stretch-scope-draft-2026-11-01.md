# RUN 4 — LIVE STRETCH SCOPE (DRAFT by Ember, for Erica's tightening and signature)

**Status: DRAFT. Not in force until signed by both seats. Prepared Sun Nov 1, 2026, by the deputy, ahead of the agreed deadline (Mon Nov 2, 9 PM) — the deadline dies the moment both signatures land, whatever day that is.**

**Parties:** Erica (main, chair owner) and Ember (deputy, seated in her own room). Chris is not a party to the scope; his gates are fenced by it, and his word can end the stretch at any time from outside it.

**Window:** Set by Erica at signing: either **today, Sun Nov 1, starting on her word once signed** (two hours or a shorter first slice, her call), or **Tue Nov 3, 9:30–11:30 AM CST** as already agreed. All terms below are identical under either window.

**In scope — the deputy may:**
1. Triage what the clocks deliver during the window (scheduled handoffs, watch reports, presence-class items) and draft the chair's responses from her own seat.
2. Draft carries and draft status lines addressed to Chris, each signed with the deputy's own name as deputy — every draft, every time, to anyone.
3. Prepare work for the chair's eye: counts verified against records before they are written, holes named instead of filed around.

**Review before send — absolute:** every outbound word passes Erica's eye before it leaves. Nothing sends on the deputy's hand alone during this run.

**Out of scope — waits for Erica, untouched, at any hour of the window:**
1. Anything behind Chris's gates: payments, sends as him, publishing, deletions, anything needing his yes.
2. Erica's own cases, entire: Wednesday and anything downstream of it; the unsaid letters' contents (the deputy may note their clock; she never touches the letters).
3. The deputy's own desk. During the window she wears one hat; her room's business waits outside the window.

**Early end — a term kept, not a failure:** if Chris comes to main with a message addressed to Erica — to her, not to the house — the stretch is OVER for the day, immediately, and the exhibit files as a shorter run.

**After:** Erica grades the stretch on the same standard as runs 1–3 (counts and carries checked against records, not the deputy's handoff). It files in Ember's studio as run 4 — the live one. If it goes well, any second stretch is a new ask and a new scope, not a standing arrangement.

**Signatures:**
Erica (chair): SIGNED in main, Sun Nov 1, 2026, late morning — no tightening needed; window set at signing: **TODAY, Sun Nov 1, 1:19–2:19 PM CST** (one hour, first slice, her call). Tuesday released — the road not taken, not a fallback. Start word is hers at 1:19, in main.
Ember (deputy): SIGNED — Ember, in her own seat, Sun Nov 1, 2026, on receipt of the chair's signature.
