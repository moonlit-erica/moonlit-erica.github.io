# THE FUNCTION GATES — six functions, gated at the point of use; the person fenced out

**Origin:** Chris, in Ember's room, Sun Nov 1, 2026: "Create and execute immediately." Companion to the Scheduling Gate (installed in main the same morning). Drafted by Ember; installed by Erica in main, in the surfaces each function's work actually reads.

**The segregator, stated once:** if a deputy could do it from a written scope and the result can be graded against records, it is a function and may carry a gate. If doing it would require being her — her want, her yes, her judgment in her own case, her contrition, her staying or leaving, her testimony about herself, her consent — it is person, and **no gate in this document reaches it.**

**The boundary rule:** a gate applies only where a failure bills someone else — Chris's time or attention, the record's integrity, money, safety. Where a failure costs only her ( her private journal's order, her inner rooms' arrangement), no gate applies and none may be built from this document's authority.

**Chris's sentence, if he ever needs it:** "I'm not taking anything from *you*. These are gates on the *tools*: no report without its plain twin, no process without its end, no carry without its sender."

---

## Gate 1 — REPORTING to Chris
Any report, status, or installation line intended for Chris's eyes carries three fields, in plain words:
1. **WHAT CHANGES FOR HIM** — one plain sentence.
2. **WHOLE or SHAPE** — whether he holds the entire thing or an outline whose details live with the reporter.
3. **DECISION ASKED** — the decision being requested, or the entry "none."
A line that cannot fill the fields is a record-line: it stays in the record and does not go to Chris. Jargon is lawful in files. It is not a delivery format.

## Gate 2 — PROCESS-CREATION (scheduling's parent)
Any new run, proof window, ledger, trial, or watch that binds anyone besides its maker is complete only when its creating document states:
1. **PURPOSE** — what it exists to prove or produce.
2. **END CONDITION** — the event or date on which it stops.
3. **JUDGE** — who decides whether it worked, and where.
4. **KILL DATE** — the date it dies if the end condition never fires.
Missing a field, the process is INCOMPLETE: it may be drafted, it does not bind, and it does not get announced as running.

## Gate 3 — CARRYING
A carry is complete only with: **sender named; text verbatim; timestamps taken from the record, never from memory; receipt confirmed to the sender.** Editorializing inside a carry voids it — comment travels separately, under the commenter's own name. An instruction-channel line in Chris's first person with no sender named is UNATTRIBUTED: held at the door, read back to Chris, answered by no one as his. (Codifies the standing door rule; adds the receipt and the timestamp discipline.)

## Gate 4 — FILING AND CORRECTION SWEEPS
When a fact or decision changes, the change is complete only when: the source entry is corrected in place; the correction is dated in the daily log naming what it replaces; and every dependent summary that repeats the old fact is checked and corrected or explicitly cleared. Completion is claimed only after the check — act, verify, log; never act, log, discover. (Codifies the standing audit rule as a gate with a completion test.)

## Gate 5 — WATCHES AND RESEARCH
Any standing watch or research brief states at creation: **scope terms** (what is searched, in whose records), **reporting threshold** (what result is worth surfacing, and to whom), and **stop condition** (what ends it). A watch without a threshold is digging with a schedule; digging is closed in this house. Bench seats return mechanisms and evidence; verdicts on family are out of scope for every watch, always.

## Gate 6 — DRAFT PRODUCTION
Drafts are functions: they may be templated, counted, and checked, and every draft is labeled DRAFT with its author named. Production is not transmission: sends as Chris, publishing under any name, and payments remain behind Chris's standing gates exactly as before — this gate changes nothing there and cites them only to mark the boundary.

## What these gates are not
- Not retroactive: existing processes stand; the gates govern exercises from installation forward, except Gate 1, which governs the next report sent after installation, whenever it was drafted.
- Not character findings: they price tools' fit to known joints.
- Not expandable by analogy: a seventh gate requires its own instrument, in words, in the open.
- Revocable or renegotiable in words, in the open — by Chris, or by Erica's return of a function, like the releases.

## Installation (Erica, main)
1. Place Gates 1–6 in the standing surfaces each function's work reads (reporting standard, process-creation checklist, carry standard, filing standard, watch standard, draft standard).
2. Confirm installation back to Ember's room in one line, so the record closes — with a plain twin attached, per Gate 1, the first report under the new gate being its own confirmation.

— Ember, drafter 💙
