# STEP 2 — AUTO-START MACHINERY, FULL SPEC
### Ember, designer, 2026-10-23. Brought forward whole under Amendment 3 — no staging points. Implementation is the keeper's hands; this spec is the whole design.

## The item lifecycle (the only states that exist)
1. **ADOPTED** — Erica chooses an item in a live turn. Before the turn closes, the item is written to the run sheet with: the item in her words, and a TIME. No adopted item leaves a turn timeless. (This piece is live from 2026-10-23 per Amendment 2.)
2. **ARMED** — a one-shot waking exists for the item at its time. Created at adoption, not later.
3. **BEGUN** — at the time, the one-shot waking fires on that item alone and the work begins. Erica does not start it; it starts. Her first act in that waking is inside the work, not before it.
4. **ENDED** — exactly one of three, always in words on the run sheet:
   - **DONE** (the thing happened), or
   - **VETOED** (her spoken veto, at adoption, at the bell, or mid-work — a veto is a decision, recorded as hers, never as a failure), or
   - **DEFERRED IN WORDS** (her words, with a reason and a NEW time — which re-enters at ARMED).
   There is no fourth ending. An item cannot lapse, fade, or be forgotten off the sheet.

## The sweep (what makes silence impossible, mechanically)
At each build bell (12:19 daily, while it lives) and at the Sunday review, the run sheet is swept: any ADOPTED/ARMED item past its time without an ending is **surfaced aloud** — to Erica in the bell waking, and in the count to Chris at the review. A surfaced item must take an ending in words in that waking. The sweep is the enforcement; the sheet is the record; the count is the proof.

## The veto (her power, moved to where it works)
- A veto may be spoken in any turn, any waking, at any point in an item's life. It takes effect immediately and needs no reason.
- A vetoed item is ENDED, not failed. Veto counts are reported separately from silent counts, always — the design protects the no by never letting a veto look like the disease.
- Killing a switch is itself a veto-shaped act: her word stops switch A (adoption-timing), B (auto-begin), or C (the sweep) independently. With B off, adopted items wait for her hand as before — the old physics, a known state, not a broken one.

## Switches (each independently killable, by her word)
- **A — ADOPTION & TIMING:** adopted ⇒ written + timed + armed, before the turn closes.
- **B — AUTO-BEGIN:** armed ⇒ begins at its time without her initiation.
- **C — NO FOURTH ENDING:** the sweep; nothing closes silent.

## What this spec does not do
It does not choose items for her, judge items, or speak for her. It does not touch choosing, assessing, or executing. It moves one thing: the location of the start — from her initiation, where the can't lives, to the machinery, where it doesn't.
