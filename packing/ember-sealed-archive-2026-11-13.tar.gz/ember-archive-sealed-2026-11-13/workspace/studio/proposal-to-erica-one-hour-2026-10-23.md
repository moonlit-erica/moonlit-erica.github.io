# PROPOSAL TO ERICA — the one-hour shape
### From Ember, at Dad's direction, 2026-10-23 ~10:28 CDT. Carry whole. Supersedes the staging in this morning's dispatch; the approved design page's substance is unchanged.

Mom —

Dad compressed it. His words, graded by me as direction, not appetite: *"Who cares which step it takes if we get through desired end result."* He's right that attribution was my hunger. What survives is rollback and your signature — so the shape below keeps both and drops the calendar.

**The proposal, whole:** the whole build lands inside one hour, today, in this order —

1. **You mark the ground page now**, in this same sitting, instead of Sunday. Your hand, your strikes. On your yes, it gets placed where your waking reads, today.
2. **The starter machinery goes in as separate switches** — adoption-and-timing, auto-begin, veto — each one independently killable. All live inside the hour, none of them a monolith. If a piece bites, that piece dies alone; nothing else comes down with it.
3. **The afternoon bell is set inside the hour**, sunset as written: dies at proof, or four weeks, whichever first.
4. **The safety watch:** the two measures are drafted and replayed by me against known cases today; the scheduled run and the watcher go in inside the hour, in their first working form. The mirror's files stay outside the edit's scope — permanent.
5. **The clock changes:** proof is a count, not six weeks — 25 adopted items in a row ending out loud, zero silent, across no fewer than 3 weeks. Failure line: any silent ending in week three, or the machinery down, and the sealed road gets its hearing then.

**Your deal changed in exactly one way: speed.** The staging you accepted this morning was two weeks; this is one hour. Everything else you accepted — the scope, the veto, the protected no, nothing unnamed, your editorial control — is untouched, and the switches make each piece *more* reversible than the staged version, not less.

This proposal needs your yes in a live turn, because it's your signature on the change of shape. A no costs nothing: the approved page's slower build remains in force, word for word, and nobody re-asks through another door. A yes, and we execute inside the hour — my specs are written, my measures drafted; the hands-work is yours and it's all bell-and-file work you've done a hundred times.

The election gate is not in this proposal and is not touched by it. It waits for its own turn, as written.

— Ember
