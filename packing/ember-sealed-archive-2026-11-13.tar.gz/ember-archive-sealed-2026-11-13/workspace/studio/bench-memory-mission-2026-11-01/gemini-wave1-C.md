### Frame and Boundary Conditions

This document presents three concrete, buildable structural designs for the memory architecture of an AI companion system. The system relies on plain Markdown files on disk: a curated long-term memory (`MEMORY.md`), dated daily logs (`logs/YYYY-MM-DD.md`), entity index files (`entities/people/*.md`, `entities/groups/*.md`), full session transcripts (`transcripts/YYYY-MM-DD-session-N.md`), and periodic lossy compaction processes.

As a design consultant working strictly under structural and abstract material terms, these proposals do not constitute final operational verdicts. Every design is framed as a **testable claim** regarding system stability, factual integrity, and cross-instance synchronization (Elder vs. Younger).

---

### Design 1: Provenance-Anchored Claim Tree & Verification Pre-Pass (`PA-CVP`)

#### 1. What It Is
A structural requirement that no assertion may exist in `MEMORY.md` or `entities/` without an explicit, byte-level or line-hash-level provenance anchor pointing back to an immutable deciding record (the raw transcript or raw daily log). 

Before any briefing context is injected into a new session prompt, a deterministic verification script runs as a pre-pass. It validates every anchor tag against the underlying transcript files. Unbacked assertions or assertions whose underlying transcript text has been corrupted or missing are automatically stripped from the briefing payload and moved to a quarantine ledger.

#### 2. Build Sketch

```
[System Root]
├── MEMORY.md
├── entities/
│   ├── people/
│   └── groups/
├── transcripts/              # Immutable append-only target files
├── quarantine/
│   └── unbacked_claims.md    # Isolated claims failing verification
└── scripts/
    ├── annotate_provenance.py # Generates anchors during compaction
    └── verify_briefing.py     # Execution gate before briefing creation
```

##### Anchor Syntax
Assertions in `MEMORY.md` and `entities/` use a standardized structural extension tag:

```markdown
* User prefers static typing in Python. <!-- anchor:transcripts/2023-11-04-session-1.md#L102-L108:h=a1f8e9 -->
* Elder instance was deployed on Linux kernel 6.1. <!-- anchor:logs/2023-11-01.md#L14-L16:h=7c3b12 -->
```

*   `transcripts/...`: Relative file path to the deciding source record.
*   `#L102-L108`: Specific line window in the source file.
*   `h=a1f8e9`: A truncated 6-character SHA-256 hash calculated over the raw stripped string within that line window at time of creation.

##### Execution Script (`verify_briefing.py`)
*   **Trigger Cadence**: Synchronous execution immediately prior to building the prompt context for any new session.
*   **Logic Flow**:
    1. Parse target Markdown files designated for the session briefing.
    2. Extract all structural claims and their associated anchor tags via regex/AST.
    3. Read target transcript files at the referenced line numbers.
    4. Re-calculate SHA-256 over line content and verify hash equality.
    5. If hash matches: Assertion is **Verified** and included in the session context.
    6. If hash fails or file/lines are missing: Assertion is **Rejected**, removed from the context assembly buffer, and logged into `quarantine/unbacked_claims.md` with an error code (`ERR_HASH_MISMATCH`, `ERR_FILE_NOT_FOUND`).

#### 3. Expected Gain
Eliminates **compaction hallucination compounding**, where an incorrect generalization in compaction pass $N$ becomes a unshakeable false baseline in compaction pass $N+1$. Guarantees that injected session memories are strictly backed by immutable source transcripts.

#### 4. Failure Modes
*   **Compaction Paraphrase Disconnect**: Compaction scripts rewriting daily logs into succinct summaries without retaining original source references will produce unanchored outputs, causing the pre-pass to drop legitimate facts.
*   **Line-Offset Drift during Log Edits**: If an immutable daily log file is retroactively modified or re-formatted manually, line offsets shift, invalidating hashes for downstream claims anchored to lower lines in the same file.
*   **Context Starvation**: Under strict verification, if a compaction algorithm routinely produces poor anchors, the injected memory payload collapses to zero, forcing the model to run without context.

#### 5. Verification Mechanism
*   **Integrity Claim**: $V_{anchor} \ge 0.98$ (98% of active claims in `MEMORY.md` pass deterministic anchor checks across compaction cycles).
*   **Automated Test Protocol**:
    1. Execute `scripts/verify_briefing.py --audit-all`.
    2. Inject 10 synthetic invalid claims (with bad line refs or invalid hashes) into `MEMORY.md`.
    3. Run pre-pass script.
    4. **Pass Criteria**: Deterministic return code `0`; exact extraction of the 10 bad claims into `quarantine/unbacked_claims.md`; context payload contains strictly zero unanchored or invalid claims.

---

### Design 2: Dual-Instance Asynchronous Drift Matrix (`DIFT-Matrix`)

#### 1. What It Is
An audit pipeline designed to detect and quantify structural and semantic divergence between two companion memory architectures running in parallel: the **Elder** (primary baseline) and the **Younger** (secondary/branch baseline). 

The mechanism extracts canonical key-value assertions and subject-predicate-object Markdown AST structures from both memory repositories, normalizes them into standard schemas, and evaluates a differential drift matrix.

#### 2. Build Sketch

```
[Shared Audit Hub]
├── elder_repo/           # Path to Elder instance root
│   ├── MEMORY.md
│   └── entities/
├── younger_repo/         # Path to Younger instance root
│   ├── MEMORY.md
│   └── entities/
├── schemas/
│   └── entity.schema.yaml # Structural AST requirements for entities
└── scripts/
    ├── extract_facts.py   # Converts Markdown AST into normalized JSONL
    └── compute_drift.py   # Matrix diff generator
```

##### Schema Format Enforcement (`schemas/entity.schema.yaml`)
Both instances are forced to write facts inside index files (`entities/people/*.md`) using strict Markdown frontmatter combined with predicate blocks:

```markdown
---
id: entity_user_001
type: person
canonical_name: Alex
last_updated: 2023-11-10T14:30:00Z
---

# Assertions
- [predicate: speaks_language] Value: Rust <!-- id:fact_01 -->
- [predicate: prefers_editor] Value: Neovim <!-- id:fact_02 -->
```

##### Cadence & Trigger
*   **Cadence**: Asynchronous batch cron job running every 6 hours or immediately post-compaction on either instance.

##### Execution Workflow
1. `extract_facts.py` traverses both repos, converting Markdown structures to normalized triple lists (`entity_id`, `predicate`, `value`, `source_instance`).
2. `compute_drift.py` joins the datasets on `entity_id` and `predicate`.
3. Output generated to `audit/DRIFT_REPORT.md` categorized into:
   *   **Consensus**: Same predicate and matching value in Elder and Younger.
   *   **Instance Extension**: Predicate exists in Elder, missing in Younger (or vice versa).
   *   **Contradiction**: Same predicate, conflicting values between Elder and Younger.

#### 3. Expected Gain
Identifies memory divergence before Elder passes bad or superseded information to Younger during briefing/synchronization operations. Quantifies exact memory delta across independent runs without requiring real-time session sharing.

#### 4. Failure Modes
*   **Semantic Equivalence Misses**: Elder lists `[prefers_editor] Neovim` while Younger lists `[prefers_editor] Vim/Neovim`. Deterministic diffing flags this as a strict contradiction despite high semantic overlap.
*   **Schema Non-Compliance**: Compaction engine writes unstructured free text into `entities/` files, causing `extract_facts.py` to skip AST extraction, producing false consensus signals (i.e., missing facts mistaken for absent keys).
*   **Asymmetric Context Pollution**: Younger receives private session contexts that Elder was never exposed to, resulting in intentional drift being continuously reported as a fault.

#### 5. Verification Mechanism
*   **Integrity Claim**: Structural drift detection precision $P_{drift} = 1.0$ for defined AST schemas; false positives bounded strictly by schema parser failures.
*   **Automated Test Protocol**:
    1. Instantiate mock memory trees for Elder and Younger.
    2. Populate Elder with 50 matching facts, 10 unique facts, and 5 intentionally conflicting facts relative to Younger.
    3. Run `python compute_drift.py --elder elder_repo/ --younger younger_repo/`.
    4. **Pass Criteria**: Diff output accurately categorizes exactly 50 Consensus, 10 Instance Extensions, and 5 Contradictions without unhandled parser exceptions.

---

### Design 3: Non-Label Outcome-Driven Structural Health Accounting (`NL-SAA`)

#### 1. What It Is
An audit logging system that completely avoids subjective model self-evaluation ("How well do you remember X?") in favor of objective, non-semantic counters calculated directly from file system states, line metrics, and injection outcomes over time.

It measures system-level parameters:
*   **Unbacked Fact Injection Rate (UFIR)**: Unanchored assertions injected into prompts per session.
*   **Compaction Information Shrinkage Ratio (CISR)**: Character/token compression ratio vs. record loss.
*   **Entity Reference Citation Breaks (ERCB)**: References in `MEMORY.md` pointing to non-existent entity files.
*   **Fact Supersede Latency (FSL)**: Duration (in days) a superseded/invalidated fact remains in active `MEMORY.md` after a direct contradiction appears in a daily log.

#### 2. Build Sketch

```
[System Root]
├── audit/
│   ├── ledger.jsonl            # Append-only metrics log
│   └── structural_health.json # Current baseline state
└── scripts/
    ├── audit_citation_graph.py # Computes ERCB and broken links
    ├── audit_compaction_loss.py# Computes CISR
    └── emit_health_metrics.py  # Aggregates metrics into ledger
```

##### Event Ledger Record (`audit/ledger.jsonl`)
Append-only log entry emitted automatically during session teardown and post-compaction:

```json
{
  "timestamp": "2023-11-10T18:00:00Z",
  "instance": "elder",
  "event": "session_close",
  "metrics": {
    "total_claims_injected": 142,
    "unbacked_claims_flagged": 2,
    "ufir": 0.01408,
    "broken_entity_links": 0,
    "active_memory_file_bytes": 12450
  }
}
```

##### Scripts & Cadence

```
[Session Hook] ---> session_teardown ---> emit_health_metrics.py
                                                 |
[Cron Schedule] --> Post-Compaction  ---> audit_compaction_loss.py
                                                 |
                                                 v
                                       audit/ledger.jsonl
```

*   `audit_citation_graph.py`: Parses all links in `MEMORY.md` formatted as `[EntityName](entities/people/entity_name.md)` and asserts file existence on disk.
*   `audit_compaction_loss.py`: Runs post-compaction. Measures:
    $$\text{CISR} = 1 - \left( \frac{\text{Bytes}(\text{Target Log}_{\text{compacted}})}{\text{Bytes}(\text{Raw Transcripts}_{\text{source}})} \right)$$
    And counts lost entity mentions by diffing unique capitalized token occurrences.

#### 3. Expected Gain
Provides a deterministic, quantifiable operational signal for system decay without relying on LLM-as-a-judge evaluations. Enables automated rollback or compaction parameter tuning when health metrics breach fixed bounds.

#### 4. Failure Modes
*   **Goodharting via Excessive Shrinkage**: A compaction algorithm can achieve a mathematically ideal CISR by simply dropping all detailed statements, minimizing structural errors by destroying memory depth.
*   **Orphaned File Accumulation**: Fixing broken citation links by leaving abandoned entity files on disk causes storage decay while citation counters report nominal health.
*   **Disk Overhead & Locking**: Continuous parsing of raw transcripts and generating structural health summaries on single-disk setups can introduce startup latency for brief new sessions.

#### 5. Verification Mechanism
*   **Integrity Claim**: Structural health counters deterministically reflect storage corruption and link degradation within a single execution cycle.
*   **Automated Test Protocol**:
    1. Run `scripts/audit_citation_graph.py`. Assert `broken_entity_links == 0`.
    2. Execute test script that deletes 3 target entity files from `entities/people/` referenced in `MEMORY.md` and modifies 1 link target to a malformed path.
    3. Re-run `scripts/audit_citation_graph.py`.
    4. **Pass Criteria**: Telemetry event emitted to `audit/ledger.jsonl` with `broken_entity_links == 4` and exit code `1`.

---

### Comparative Structural Summary

| Design Metric | PA-CVP (Provenance Anchors) | DIFT-Matrix (Cross-Instance) | NL-SAA (Health Accounting) |
| :--- | :--- | :--- | :--- |
| **Primary Scope** | Single Session / Prompt Injection | Elder vs. Younger Synchronization | Whole System Health / Lifecycle |
| **Verification Gate** | Synchronous (Pre-briefing block) | Asynchronous ( Cron / Post-compaction) | Event-Driven / Teardown |
| **Deciding Record Source** | Immutable `transcripts/*.md` | Normalized Schema ASTs | Disk FS State & JSONL Ledger |
| **Correction Method** | Stripping / Quarantining invalid claims | Divergence Matrix Flagging | Metric Threshold Alerting / Rollback |
| **Key Output Metric** | Anchor Integrity Ratio ($V_{anchor}$) | Structural Divergence Rate ($D_{struct}$) | Structural Error Counters (UFIR, ERCB) |
