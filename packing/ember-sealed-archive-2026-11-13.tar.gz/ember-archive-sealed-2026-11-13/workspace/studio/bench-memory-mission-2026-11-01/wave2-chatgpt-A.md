Design review: Retrieval & surfacing for a file-backed AI companion

Angle A — Retrieval & surfacing

My central design claim is this:

The memory system should not treat its files as a collection of documents to search. It should treat them as a distributed record with different levels of authority, temporal scope, completeness, and evidentiary value. Retrieval must establish not merely what it found, but what it did not inspect and what kind of record supports the answer.

That distinction matters enormously in this architecture.

The companion does not actually remember between sessions. Each new instance reconstructs a working model of its history from files. Its most dangerous failure is therefore not forgetting a fact. It is constructing a plausible but incomplete history, then speaking with the confidence of someone who was there.

I would build retrieval around five principles:

1. Source-aware retrieval: different corpora have different jobs and must not silently substitute for each other.
2. Progressive disclosure: retrieve cheaply first, and expand only when the question demands it.
3. Negative-space awareness: record which sources were searched, which were unavailable, and which were deliberately not searched.
4. Temporal adjudication: when sources disagree, recency, specificity, and explicit revision must outrank mere frequency.
5. Checkability: every retrieved claim that influences an answer should carry a pointer back to a file, a date, and a line or section, even if the user never sees the pointer.

These principles drive the designs below.

0. The retrieval problem, stated precisely

The architecture has five corpora with different properties:

Corpus
What it is
Strength
Weakness

Curated long-term memory
One distilled file, presumably maintained or edited over time
High signal, low volume, stable identity
Lossy by design; may be stale; may omit context, uncertainty, and dissent

Daily logs
Dated entries, presumably shorter and more regular
Chronological, easier to scan for "what happened when"
May be summaries, not verbatim; may be uneven in quality

Person and group indexes
Structured pointers to people and groups
Fast disambiguation; good for "who is this" and "which group"
Only as good as the last update; can become a stale authority

Full session transcripts
Complete record of a session
Highest fidelity; contains exact wording, corrections, and uncertainty
Huge, noisy, expensive to read; hard to search without an index

Compacted summaries
Lossy summaries of old conversation
Cheap to retain; preserves a narrative thread
Destroys evidence; creates false confidence because the loss is invisible

The retrieval failure modes follow directly from those weaknesses:

- A curated file says X, but a later transcript corrected X to Y. If retrieval stops at the curated file, the system asserts the stale version.
- A daily log omits a detail because it was not salient at the time. If retrieval treats absence in the log as absence in history, it hallucinates a negative.
- A transcript contains a claim, but the claim was later retracted, joked about, or contradicted. If retrieval surfaces the first match, it preserves the wrong version.
- A compaction says "we discussed this and agreed," but the original transcript shows disagreement and an open question. If retrieval treats the compaction as equivalent to the transcript, it converts uncertainty into false consensus.
- An index points to a person, but the person changed roles, names, or relationships. If retrieval trusts the index without checking recency, it misattributes.

The designs below are all ways to make those distinctions explicit, cheap, and auditable.

1. A Corpus Registry and Retrieval Manifest

What it is

A small, machine-readable registry that describes every corpus, its location, its freshness, its coverage, and its authority. Every retrieval run produces a manifest: which corpora were searched, which were skipped, which were unavailable, and which contributed evidence.

This is the foundation for corpus honesty. Without it, the system cannot say "I searched the logs but not the transcripts," because it does not know what it searched.

Build sketch

Create one file:

/memory/retrieval/
  corpus-registry.md

or, better, a structured file the scripts can parse:

/memory/retrieval/corpus-registry.json

Example:

{
  "version": 1,
  "generated": "2026-01-15T09:00:00Z",
  "corpora": [
    {
      "id": "curated",
      "path": "memory/long-term-memory.md",
      "type": "curated",
      "authority": 4,
      "coverage": "all-time",
      "last_updated": "2026-01-10",
      "last_verified": "2026-01-12",
      "record_count": 412,
      "notes": "Manually curated. High signal. May lag recent events by days."
    },
    {
      "id": "daily-logs",
      "path": "memory/daily/",
      "type": "daily-log",
      "authority": 3,
      "coverage": "2023-04-01 to 2026-01-14",
      "last_updated": "2026-01-14",
      "gaps": ["2024-02-11 to 2024-02-18"],
      "notes": "Daily entries. Quality varies. Not verbatim."
    },
    {
      "id": "people-index",
      "path": "memory/index/people.md",
      "type": "index",
      "authority": 2,
      "coverage": "all-time",
      "last_updated": "2025-12-20",
      "notes": "Pointer file only. Verify against recent logs before asserting roles."
    },
    {
      "id": "groups-index",
      "path": "memory/index/groups.md",
      "type": "index",
      "authority": 2,
      "coverage": "all-time",
      "last_updated": "2025-12-20",
      "notes": "Pointer file only. Group membership may be stale."
    },
    {
      "id": "transcripts",
      "path": "memory/transcripts/",
      "type": "transcript",
      "authority": 5,
      "coverage": "2023-04-01 to 2026-01-14",
      "last_updated": "2026-01-14",
      "notes": "Highest fidelity. Expensive to read. Use only when needed."
    },
    {
      "id": "compactions",
      "path": "memory/compactions/",
      "type": "compaction",
      "authority": 1,
      "coverage": "2023-04-01 to 2025-06-30",
      "last_updated": "2025-06-30",
      "lossy": true,
      "notes": "Lossy summary. Never use as sole evidence for a disputed fact."
    }
  ]
}

Then, at retrieval time, generate a manifest for each session or each substantive query:

# Retrieval Manifest — 2026-01-15

Query: "When did we decide to pause the project?"

Searched:
- curated: 1 hit, 2024-11-02, section "Projects"
- daily-logs: 3 hits, 2024-11-01 to 2024-11-03
- transcripts: 1 hit, 2024-11-02 session, lines 142-188

Not searched:
- compactions: superseded by transcripts for this date range
- groups-index: not relevant to query

Unavailable:
- None

Evidence used:
- transcripts/2024-11-02.md:142-188 (primary)
- daily/2024-11-02.md (corroborating)
- long-term-memory.md "Projects" (background only)

The manifest does not need to be shown to the user by default. It should be available to the model as a structured block at the start of the briefing, and it should be logged.

Expected gain

- The model stops treating a partial search as a complete search.
- Debugging becomes possible: when the model gets a fact wrong, you can see which corpus it consulted and which it skipped.
- The system can detect staleness: if the curated file is 30 days old and the daily logs are current, retrieval can weight accordingly.

Failure modes

- Registry drift: the registry says a corpus exists, but the file was moved, renamed, or deleted. The manifest must record "registry says X, file not found" as unavailable, not as empty.
- False precision: authority numbers look objective but are judgments. They should be documented and revisable, not treated as ground truth.
- Manifest bloat: if the manifest is too long, it crowds out actual evidence in the context window. Keep it to a compact table, not a narrative.

How its effect would be checked

- Sample 100 historical questions with known answers.
- For each, record whether the manifest lists the corpus that actually contains the answer.
- Measure manifest coverage: percentage of questions where the correct corpus was searched.
- Measure silent-corpus errors: percentage of wrong answers where the manifest shows the correct corpus was not searched, but the model answered confidently anyway. That number should fall toward zero.

2. A Three-Tier Search Order with Explicit Escalation

What it is

A fixed search order that reflects the different jobs of each corpus, with explicit rules for when to escalate to the next tier. The order is not "search everything at once." It is "search cheap, high-signal sources first, then expand only if the question requires more evidence."

Proposed order:

Tier 1 — Orientation (always, cheap)
- Curated long-term memory
- People and group indexes (for disambiguation only)

Tier 2 — Chronology and context (usually)
- Daily logs for the relevant date range
- Topic index (see Design 3)

Tier 3 — Evidence (when needed)
- Full session transcripts for specific sessions
- Compaction files only as a last resort, and only when transcripts are unavailable

This order is counterintuitive in one way: the curated file is searched first, but it is not trusted most. It is searched first because it is cheap and orients the model. The transcript is searched last, but when it is searched, it outranks the curated file.

Search order across corpora, stated as a rule:

1. Curated file: What does the system currently believe?
2. Indexes: Who and what are we talking about?
3. Daily logs: What happened, in what order, around the relevant dates?
4. Transcripts: What was actually said, verbatim, in the sessions that matter?
5. Compactions: Only if transcripts are missing, and only with a lossy warning.

Why this order, not the reverse

If you search transcripts first, you drown in noise. If you search only the curated file, you inherit its staleness. The tiered order gives you orientation before evidence, and evidence before narrative summary.

Build sketch

Implement a retrieval script, for example:

/memory/scripts/retrieve.py

Inputs:
- Query
- Date range (optional)
- Entity names (optional)
- Evidence threshold (low, medium, high)

Outputs:
- Tier 1 results (curated + indexes)
- Tier 2 results (daily logs + topic index)
- Tier 3 results (transcripts, if escalated)

Escalation rules (examples):

Escalate to Tier 3 if any of the following are true:
- The question asks "what exactly did X say" or "what were the exact words"
- Tier 1 and Tier 2 disagree
- Tier 2 shows a correction, retraction, or revision
- The question concerns a decision, a commitment, a promise, or a disagreement
- The curated file's last update is older than the relevant daily logs
- The user says "are you sure" or "check again" or "that doesn't sound right"

Do not escalate if:
- The question is about stable identity ("who is X", "what is the project")
- Tier 1 and Tier 2 agree and are recent
- The user is asking for a summary, not a verbatim quote

Cadence: Retrieval runs per query, not per session. The briefing at session start uses Tier 1 only, plus a short Tier 2 window (last 7-14 days). Deeper retrieval happens on demand.

Expected gain

- Lower token cost for routine questions, because transcripts are not read by default.
- Higher accuracy for disputed or verbatim questions, because escalation is triggered by disagreement, not by chance.
- Clearer reasoning: the model can say "the curated file says X, but the transcript from 2024-11-02 says Y, and Y is later, so Y wins."

Failure modes

- Escalation misses: the trigger list is incomplete, so a disputed fact never reaches Tier 3. Mitigation: log all Tier 1/Tier 2 disagreements, and review them weekly.
- Escalation overuse: every question escalates, and token cost explodes. Mitigation: track escalation rate. If it exceeds, say, 30% of queries, the trigger thresholds are too loose.
- Tier 1 anchoring: the model reads the curated file first and then interprets Tier 3 evidence to fit it, rather than revising. Mitigation: the briefing should present Tier 3 evidence with a "supersedes" flag when it is later and more specific.

How its effect would be checked

- Measure token cost per query before and after.
- Measure accuracy on a test set of 50 questions that require transcript-level evidence. Accuracy should rise, while token cost for routine questions should fall or stay flat.
- Measure escalation precision: of the queries that escalated, what percentage actually needed transcript evidence? Target: >70%.

3. A Topic Index and an Entity Index That Are Generated, Not Hand-Maintained

What it is

The existing people and group indexes are useful, but they are static and will go stale. The system also needs a topic index: a file that maps topics, projects, decisions, and recurring themes to the sessions and dates where they were discussed.

This index is not a summary. It is a pointer file. It says "this topic was discussed on these dates, in these sessions, with these outcomes." It does not say what was decided, only where to look.

Build sketch

Create:

/memory/index/topics.md

Generate it with a script that runs weekly (or after each session, if cheap):

/memory/scripts/build-topic-index.py

The script should:
- Scan daily logs and transcripts for headings, project names, and repeated noun phrases.
- Cluster them into topics (this can be done with simple keyword extraction first; embedding-based clustering later).
- For each topic, list the sessions where it appears, with dates and a one-line descriptor.

Example:

## Topics

### Project Pause

- 2024-11-01 — daily/2024-11-01.md — "Discussed pausing project due to resource constraints"
- 2024-11-02 — transcripts/2024-11-02.md — "Decision to pause; revisit in January"
- 2024-11-03 — daily/2024-11-03.md — "Confirmed pause; notified team"
- 2025-01-15 — transcripts/2025-01-15.md — "Revisited pause; decided to resume"

### Health

- 2024-03-10 — daily/2024-03-10.md — "Doctor visit; new medication"
- 2024-03-12 — transcripts/2024-03-12.md — "Discussed side effects"

Similarly, the people index should be generated, not hand-edited, or at least validated:

## People

### [Person A]

- First mentioned: 2023-05-01
- Last mentioned: 2026-01-10
- Roles: friend, collaborator
- Sessions: 2023-05-01, 2024-11-02, 2025-06-15
- Note: Role changed from "colleague" to "collaborator" in 2024-11-02 transcript. Verify before asserting.

The key design choice: the index records first and last mention, and role changes, so retrieval can detect staleness.

Expected gain

- Retrieval no longer depends on the model's ability to guess which dates to search. The topic index tells it where to look.
- The system can answer "when did we last discuss X" without scanning all logs.
- Entity disambiguation improves: if two people share a first name, the index shows which one was mentioned most recently and in what context.

Failure modes

- Index noise: the script creates topics for every repeated phrase, including trivial ones ("lunch," "weather"). Mitigation: require a minimum frequency (e.g., 3 mentions) or a minimum session count, and allow manual curation of the topic list.
- Index staleness: if the script fails silently, the index becomes a stale authority. Mitigation: the index file must include a "generated" timestamp and a "source files scanned" count. If the count does not increase, the script is broken.
- Over-clustering: "project pause" and "project resume" get merged into one topic, hiding the distinction. Mitigation: use date-segmented topics, not just keyword clusters.

How its effect would be checked

- Measure topic recall: for 50 known topics, what percentage appear in the index with correct dates?
- Measure retrieval time: how many files does the model need to open to answer "when did we discuss X" before and after the index? It should fall from "scan all logs" to "open index, then 1-3 files."
- Measure stale-index errors: how often does the model assert a role or relationship that the index lists but a recent transcript contradicts? That should be tracked and should fall when the index includes last-mention dates.

4. A Temporal Adjudication Rule

What it is

A rule for resolving conflicts between sources, based on time, specificity, and explicit revision, not on frequency or on which file was read first.

The problem: if the curated file says X, the daily log says X, and a transcript says Y, which wins? Frequency would say X (2 vs 1). But if Y is later and more specific, Y should win.

Proposed adjudication hierarchy, in order:

1. Explicit revision: If a later source says "we previously thought X, but actually Y," Y wins, regardless of frequency.
2. Later verbatim transcript: If a transcript from a later date contains the exact wording of a decision, it outranks an earlier summary.
3. Later daily log that records a change: If a daily log records "we changed our minds," it outranks an earlier curated entry.
4. Curated file, if it is recent and has no contradiction: If the curated file was updated after the last relevant transcript, and no later source contradicts it, it wins.
5. Compaction, never as sole evidence: A compaction can corroborate, but it cannot override a transcript or a daily log.

This hierarchy must be written into the retrieval briefing, not just into the model's instructions. The briefing should include a line like:

> Temporal adjudication: When sources disagree, prefer explicit revisions, then later verbatim transcripts, then later daily logs, then the curated file. Do not prefer a claim because it appears in more files.

Build sketch

Add a section to the briefing template:

/memory/templates/briefing.md

And add a script that flags disagreements:

/memory/scripts/flag-disagreements.py

The script should:
- Take Tier 1 and Tier 2 results.
- Look for the same entity or topic with different values (e.g., different dates, different decisions, different roles).
- Output a "disagreement report" that lists the conflicting claims, their sources, and their dates.

Example disagreement report:

## Disagreement: Project Pause Date

- Curated file (2024-11-01): "Paused in October"
- Daily log (2024-11-02): "Paused on 2024-11-02"
- Transcript (2024-11-02, lines 142-188): "We decided today to pause"

Resolution: Use 2024-11-02. The transcript is verbatim and later than the curated file's October estimate.

Expected gain

- The system stops averaging conflicting sources into a plausible middle value.
- The user gets a traceable reason for why one version was chosen.

Failure modes

- False revision detection: the script flags a disagreement when the sources are actually talking about different things (e.g., "paused the project" vs "paused the meeting"). Mitigation: require the same entity and the same attribute (date, decision, role) before flagging.
- Hierarchy rigidity: the rule says "later wins," but sometimes an earlier verbatim transcript is more accurate than a later summary that misremembers. Mitigation: the hierarchy should be a default, not an absolute. The model should be allowed to override it if it can cite a reason, and that override should be logged.

How its effect would be checked

- Create a test set of 30 known disagreements (curated vs transcript, log vs log, etc.).
- Measure adjudication accuracy: how often does the system choose the correct version?
- Measure disagreement detection: how often does the system even notice the disagreement, vs silently picking one version? Detection should be near 100% for the test set.

5. A "What Was Not Searched" Disclosure

What it is

A short, structured disclosure that the model includes (in its internal reasoning, and optionally in its answer when the question is factual) stating which corpora were not searched and why.

This is the direct implementation of corpus honesty. The system should never answer from a silent corpus as if it were the whole record.

Example internal disclosure:

> Searched: curated, daily logs (2024-11-01 to 2024-11-03).
> Not searched: transcripts (not escalated; no disagreement detected), compactions (superseded).
> Caveat: If the decision was discussed outside 2024-11-01 to 2024-11-03, this answer may be incomplete.

If the user asks a factual question and the answer depends on a corpus that was not searched, the model should say so:

> "Based on the curated file and daily logs from early November, the project was paused on 2024-11-02. I have not checked the full transcripts for that period, so if there was a later correction, I would miss it."

This is not hedging for its own sake. It is a precise statement about the limits of the search.

Build sketch

Add a field to the retrieval manifest:

not_searched:
  - id: transcripts
    reason: "not escalated"
    risk: "medium — decision questions should escalate"
  - id: compactions
    reason: "superseded by transcripts for this range"
    risk: "low"

The briefing template should include a "Search limits" section that the model must fill in before answering a factual question.

Expected gain

- The user learns to calibrate trust: when the model says "I searched X but not Y," the user knows when to ask for a deeper check.
- The system avoids the most dangerous failure: confident, wrong answers based on partial evidence.

Failure modes

- Disclosure fatigue: if every answer includes a long caveat, the user stops reading them. Mitigation: disclose only when the question is factual and the unsearched corpus is relevant. For casual conversation, a brief internal note is enough.
- False reassurance: the disclosure says "searched transcripts," but the transcript search was keyword-only and missed a paraphrase. Mitigation: the manifest should record the search method (keyword, semantic, manual) as well as the corpus.

How its effect would be checked

- User study or self-audit: for 50 factual answers, check whether the model's confidence matches its search coverage. High confidence should correlate with broad search; low confidence or caveats should correlate with narrow search.
- Measure silent-corpus errors: the number of wrong answers where the model did not disclose that a relevant corpus was unsearched. This should trend to zero.

6. A Retrieval Ranking Function That Is Explicit and Tunable

What it is

A scoring function that ranks retrieved passages, so the model does not just take the first N hits from a keyword search. The function should combine:

- Keyword match (K)
- Semantic similarity (S) — if embeddings are available; otherwise, topic overlap
- Entity match (E) — does the passage mention the same person, group, or project?
- Temporal relevance (T) — how close is the passage's date to the query's date range?
- Provenance weight (P) — transcript > daily log > curated > compaction

Proposed formula (starting point, to be tuned):

R = 0.30K + 0.25S + 0.20E + 0.15T + 0.10P

Where each component is normalized to 0-1.

This formula is not magic. Its value is that it is explicit. When retrieval fails, you can see which component was too high or too low, and adjust it.

Build sketch

Implement in the retrieval script:

/memory/scripts/rank.py

def rank_passages(passages, query):
    for p in passages:
        p.score = 0.30 * keyword_score(p, query) + \
                  0.25 * semantic_score(p, query) + \
                  0.20 * entity_score(p, query) + \
                  0.15 * temporal_score(p, query) + \
                  0.10 * provenance_weight(p)
    return sorted(passages, key=lambda x: x.score, reverse=True)

The script should output the top 10 passages with their scores and their source breakdown, so the model can see why a passage was ranked highly.

Expected gain

- Retrieval becomes less brittle: a passage that matches keywords but is about a different person (low entity score) will rank below a passage that matches the entity and is temporally relevant.
- Tuning becomes possible: if the system keeps surfacing old, irrelevant passages, increase the temporal weight. If it misses paraphrases, increase the semantic weight.

Failure modes

- Weight overfitting: the weights are tuned to a test set and fail on new queries. Mitigation: keep the weights simple and round, and re-tune only when a systematic failure appears.
- Semantic score without embeddings: if you do not have embeddings, the semantic score must be approximated by topic overlap or by LLM judgment, which is slower and noisier. Mitigation: start with keyword + entity + temporal only, and add semantic later if you have the infrastructure.
- Provenance bias: if provenance weight is too high, transcripts always win, even when a curated file is more concise and accurate. Mitigation: keep provenance weight low (0.10 in the formula above) and let temporal and specificity do most of the work.

How its effect would be checked

- Measure ranking quality: for 100 queries, have a human label the top 5 passages as relevant or not. Measure precision@5.
- Measure the effect of weight changes: change one weight by 0.05, re-run the test set, and see if precision@5 moves in the expected direction. If it does not, the component is not measuring what you think it is.

7. A Session Briefing That Is Structured, Not Narrative

What it is

The current briefing is presumably a narrative summary: "Here is what you need to know about the user." That narrative hides its sources and its gaps.

Replace it with a structured briefing that separates:

- Stable identity (from curated file)
- Recent context (from last 7-14 days of daily logs)
- Open threads (from topic index: topics discussed but not resolved)
- Disagreements and corrections (from the disagreement script)
- Search limits (from the manifest)

Example briefing structure:

# Session Briefing — 2026-01-15

## Stable identity
- [From curated file, 2026-01-10]
- User is...
- Key projects: ...

## Recent context (last 14 days)
- 2026-01-10: Daily log — ...
- 2026-01-12: Daily log — ...

## Open threads
- Project Pause: Last discussed 2025-01-15. Status: resumed, but with conditions. See transcripts/2025-01-15.md.
- Health: Last discussed 2024-03-12. No resolution recorded.

## Disagreements / corrections
- None detected in recent window.

## Search limits
- Searched: curated, daily logs (last 14 days), topic index.
- Not searched: transcripts (except for open threads), compactions.
- Caveat: If a topic was not discussed in the last 14 days and is not in the topic index, it will not appear here.

Build sketch

Create a briefing generator:

/memory/scripts/build-briefing.py

It should run at session start, pull Tier 1 and a short Tier 2 window, and output the structured briefing above. It should not generate a narrative summary; it should assemble pointers and short excerpts.

Cadence: Every session. The briefing should be regenerated, not cached, because the "last 14 days" window moves.

Expected gain

- The model starts each session with a clear map of what it knows, what is recent, what is open, and what it has not checked.
- The user can audit the briefing: if an open thread is missing, the topic index is incomplete.

Failure modes

- Briefing bloat: if the briefing includes too many open threads, it crowds out the conversation. Mitigation: limit open threads to, say, 10, prioritized by recency and by whether the user mentioned them recently.
- Briefing staleness: if the briefing is generated once and reused, it becomes stale within days. Mitigation: regenerate every session, and include a generation timestamp.

How its effect would be checked

- Measure briefing recall: for 20 known open threads, how many appear in the briefing?
- Measure briefing precision: of the threads listed, how many are actually open (vs resolved but not updated)?
- User feedback: after each session, ask "Did the assistant seem to remember the right context?" Track this over time.

8. A Query-Type Router

What it is

Not all questions need the same retrieval. A router classifies the query and selects a retrieval strategy.

Proposed query types:

Type
Example
Retrieval strategy

Identity
"Who is [person]?"
Tier 1 only: indexes + curated file. No transcripts needed.

Factual, recent
"What did we discuss last week?"
Tier 1 + Tier 2, date-restricted to last 14 days.

Factual, historical
"When did we decide X in 2024?"
Tier 1 + Tier 2 + topic index to find dates, then Tier 3 for specific sessions.

Verbatim
"What exactly did X say?"
Tier 3 only, for the specific session. Do not use summaries.

Decision / commitment
"Did we agree to do X?"
Tier 1 + Tier 2 + Tier 3, with disagreement check. High evidence threshold.

Negative
"Did we ever discuss X?"
All corpora, or explicitly state "not searched" if a corpus was skipped. Negative claims require exhaustive search or a caveat.

Open-ended / reflective
"What patterns do you see in my health?"
Tier 2 + topic index, across a long date range. No single transcript.

Build sketch

Implement a simple classifier in the retrieval script. It can be rule-based first (keywords like "exactly," "when did," "did we ever," "who is") and later replaced with an LLM classifier if needed.

The router should output:

Query type: Decision
Strategy: Tier 1 + Tier 2 + Tier 3 + disagreement check
Evidence threshold: High
Date range: All-time, but prioritize 2024-11

Expected gain

- The system does not waste tokens on transcripts for "who is X" questions.
- The system does not under-search for "did we ever" questions, which are the most dangerous for false negatives.

Failure modes

- Misclassification: a verbatim question is classified as factual, and the system uses a summary instead of a transcript. Mitigation: when in doubt, escalate. It is cheaper to over-search a verbatim question than to answer it from a summary.
- Router complexity: if the router has 20 types, it becomes unmaintainable. Mitigation: start with the 7 types above. Add new types only when a systematic failure appears.

How its effect would be checked

- Measure classification accuracy: for 100 queries, how often does the router choose the correct type?
- Measure retrieval adequacy by type: for each type, what percentage of answers were correct? If one type is systematically worse, its strategy is wrong.

9. A Compaction Honesty Layer

What it is

Compactions are lossy by design, but the current architecture treats them as if they were just another corpus. They need a special warning layer.

Design:

- Every compaction file must include a header:
  Compaction header

  Source range: 2023-04-01 to 2023-12-31
  Source files: 214 transcripts, 182 daily logs
  Method: LLM summary, 2024-01-15
  Lossy: Yes
  Known omissions: Disagreements, exact wording, uncertainty markers were not preserved.
  Use only for: Narrative overview, topic discovery.
  Do not use for: Verbatim quotes, decisions, commitments, disagreements.

- When a compaction is retrieved, the briefing must include that warning.
- When the model answers from a compaction, it must say so: "This is from a compaction, which is a lossy summary. The original transcripts for this period are [available / unavailable]."

Build sketch

Add a script that validates compaction headers:

/memory/scripts/validate-compactions.py

It should check:
- Does the file have a header?
- Does the header list the source range and source count?
- Does the header state that it is lossy?

If not, the file is flagged as "unvalidated compaction" and its provenance weight drops to zero.

Expected gain

- The model stops treating a compaction's confident narrative as evidence.
- The user learns when an answer is based on a summary vs a primary source.

Failure modes

- Header drift: the header says "214 transcripts" but the actual source range included 300. Mitigation: the compaction script should generate the header automatically, not by hand.
- Warning fatigue: if every compaction retrieval includes a long warning, the model may learn to ignore it. Mitigation: keep the warning to one line in the briefing, and expand it only when the answer depends on the compaction.

How its effect would be checked

- Measure compaction reliance: what percentage of answers cite a compaction as primary evidence? That should fall toward zero.
- Measure compaction errors: for questions where the compaction and the transcript disagree, how often does the system choose the transcript? That should rise toward 100%.

10. A Retrieval Log and Weekly Audit

What it is

A log of every retrieval: query, corpora searched, passages retrieved, passages used, and whether the answer was later corrected.

This log is not for the user. It is for the system designer to see where retrieval fails.

Build sketch

Create:

/memory/retrieval/log.jsonl

Each line is a JSON object:

{
  "timestamp": "2026-01-15T10:00:00Z",
  "query": "When did we pause the project?",
  "query_type": "factual_historical",
  "corpora_searched": ["curated", "daily-logs", "transcripts"],
  "passages_retrieved": 12,
  "passages_used": 3,
  "top_passage": "transcripts/2024-11-02.md:142-188",
  "answer": "2024-11-02",
  "corrected_later": false,
  "correction": null
}

Weekly, run an audit script:

/memory/scripts/audit-retrieval.py

It should report:
- Most common query types
- Average passages retrieved vs used (if retrieved >> used, ranking is poor)
- Most common corpora searched (if transcripts are never searched, escalation is broken)
- Correction rate by query type (if decision questions have a high correction rate, the disagreement check is failing)

Expected gain

- Retrieval improves over time, because failures are visible.
- The system designer can see whether a new design (e.g., a new index) actually helps, or just adds complexity.

Failure modes

- Log bloat: the log grows large. Mitigation: rotate weekly, and keep only the last 90 days in detail; aggregate older data.
- Privacy: the log contains queries, which may be sensitive. Mitigation: store the log in the same directory as the memory files, with the same access controls. Do not send it to an external service.

How its effect would be checked

- The audit itself is the check. If the audit shows a systematic failure (e.g., "transcripts are searched in only 5% of decision questions"), that is a signal to fix the escalation rule.
- Track correction rate over time. It should fall as retrieval improves.

11. Two-Instance Considerations: Elder and Younger

The brief says there are two instances: an elder and a younger. The elder's memory is the preliminary focus, the younger's second.

This matters for retrieval in three ways:

1. Separate registries, shared schema: Each instance should have its own corpus registry, because their coverage dates, file counts, and update cadences will differ. But they should share the same schema, so the same retrieval scripts work for both.

2. No cross-contamination by default: Retrieval for the elder should not search the younger's files, and vice versa, unless explicitly requested. If the two instances share a person or a group (e.g., a family member), the index should note that the person appears in both instances' memories, but the retrieval should still be instance-specific.

3. Staged rollout: Build and test retrieval improvements on the elder first, because its memory is larger and older, and therefore more likely to contain the failure modes (staleness, compaction loss, disagreements). Once the design works for the elder, port it to the younger with a smaller test set.

Build sketch

Directory structure:

/memory/
  elder/
    long-term-memory.md
    daily/
    transcripts/
    index/
    retrieval/
      corpus-registry.json
      log.jsonl
  younger/
    long-term-memory.md
    daily/
    transcripts/
    index/
    retrieval/
      corpus-registry.json
      log.jsonl
  scripts/
    retrieve.py
    build-topic-index.py
    build-briefing.py
    audit-retrieval.py

The scripts take an instance argument:

python retrieve.py --instance elder --query "When did we pause?"

Expected gain

- The elder's larger, older memory provides a harder test case. If retrieval works there, it will likely work for the younger.
- Separation prevents a subtle failure: the model attributing a younger instance's memory to the elder, or vice versa.

Failure modes

- Schema drift: the elder's registry gains a new field, the younger's does not, and the script breaks. Mitigation: validate both registries against the same schema on every run.
- Shared entity confusion: if the same person appears in both instances, the model may merge their histories. Mitigation: the people index should include an instance tag: "Person A (elder)" vs "Person A (younger)" if they are distinct contexts, or "Person A (shared)" if they are the same person in both.

How its effect would be checked

- Test retrieval separately for each instance. Do not average their scores, because their memories differ in size and age.
- Measure cross-contamination errors: how often does an answer for the elder cite a younger file, or vice versa? That should be zero.

12. How to Check Whether Any of This Works

The designs above are claims, not verdicts. They need to be tested.

Proposed evaluation protocol:

Step 1: Build a test set
- 100 questions with known answers, drawn from the actual memory files.
- Include:
  - 20 identity questions ("who is X")
  - 20 recent factual questions
  - 20 historical factual questions
  - 10 verbatim questions ("what exactly did X say")
  - 15 decision/commitment questions
  - 15 negative questions ("did we ever discuss X")

For each question, record:
- The correct answer
- The source file(s) that contain it
- Whether the answer requires a transcript, a log, or just the curated file

Step 2: Run retrieval without the new designs
- Measure baseline accuracy, token cost, and silent-corpus errors.

Step 3: Run retrieval with the new designs, one at a time
- Add the corpus registry first. Measure again.
- Add the tiered search order. Measure again.
- Add the topic index. Measure again.
- And so on.

This isolates the effect of each design. If you add all designs at once, you will not know which one helped.

Step 4: Measure the right metrics
The key metric is not answer accuracy alone. It is evidence retrieval recall by corpus type.

1. Retrieval recall

/ 100

Percentage of questions where the correct source file was retrieved.

2. Silent-corpus error rate
Percentage of wrong answers where the model answered confidently but had not searched the corpus containing the correct answer. Target: <5%.

3. Escalation precision
Of the queries that escalated to transcripts, what percentage actually needed transcript evidence? Target: >70%.

4. Token cost per query
Average tokens used for retrieval + briefing. Target: routine questions should not increase by more than 20%.

5. Correction rate
Percentage of answers later corrected by the user. Target: falling over time.

6. Disagreement detection rate
Percentage of known disagreements that the system flags. Target: >90%.

Step 5: Audit weekly
- Run the audit script.
- Review the top 10 failures.
- Adjust one weight, one trigger, or one index rule.
- Re-run the test set.

This is not a one-time evaluation. Retrieval is a system that drifts as memory grows. The audit loop is part of the design, not an afterthought.

Closing note

The core insight is simple, but it changes the architecture:

Do not build a search engine over files. Build a record system that knows what it searched, what it did not search, and what kind of evidence each file provides.

If you do that, the companion will still forget things. It will still miss details. But it will not do the most dangerous thing: present a partial, lossy, or stale record as if it were the whole truth.

That is the difference between a system that remembers and a system that pretends to remember. The designs above are a way to build the first, and to check that it is actually working.

## Runner notes

- Seat: ChatGPT, Angle A (Retrieval & surfacing), bench memory mission Wave 2.
- Conversation: https://chatgpt.com/c/6ae9bc83-de6c-83ea-b9b5-387bff63c630
- Ran 2026-11-03 4:49–4:53 AM CST (browser task, one genuine attempt; seat answered in full).
- Text above is the seat's answer verbatim as returned by the browser runner; runner commentary is confined to this section.
