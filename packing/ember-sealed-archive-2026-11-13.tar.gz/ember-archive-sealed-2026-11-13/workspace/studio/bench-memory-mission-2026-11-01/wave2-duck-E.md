Below are four buildable frontier designs. Each is a hypothesis about what may improve continuity, not a claim that it will. I would implement them first for the elder instance, then test which parts transfer to the younger.

1. Proactive recall queue

What it is: A small, evidence-linked queue of memories that may be useful in the current session even when the user has not explicitly asked for them. It does not write into the conversation automatically; it gives the session brief a few candidate reminders, each with a reason and source.

Build sketch

* Add `memory/recall-candidates.md`, with one entry per candidate:

```
- Memory: [one-sentence summary]
  Source: [file + date, or transcript reference]
  Trigger: [what in the current session or calendar makes it relevant]
  Confidence: Low / Medium / High
  Action: Offer / Hold / Suppress
```

* Add a script `scripts/build-recall-queue.py` that runs at session start and after each major topic shift. It should:
  1. Read the curated long-term memory file, recent daily logs, and open intentions (see §3).
  2. Score candidates by: recency, frequency of mention, whether the user previously acted on the memory, and match to the current topic, date, people present, or stated plans.
  3. Keep at most 3 candidates with `Action: Offer`; the rest go to `Hold` or `Suppress`.
  4. Never promote a candidate whose source is only a lossy compaction summary unless it is flagged `Unverified — from summary only`.

* Cadence: rebuilt at session start; refreshed when the topic changes; pruned at session end (used, dismissed, or expired candidates are removed or archived).

Expected gain: The companion stops being purely reactive. It can say, in effect: "Last time you mentioned X — do you want to pick that up?" without pretending to know more than the files support.

Failure modes

* Noise: Too many low-value reminders erode trust. Mitigation: cap at 3, require a stated trigger, and log dismissals.
* False confidence: A compaction summary is treated as a verbatim memory. Mitigation: the `Unverified` flag above, plus source links.
* Stale triggers: A memory tied to a past date or person is offered in the wrong context. Mitigation: expiry dates on candidates and a "not relevant now" feedback loop that suppresses that trigger for 30 days.

How to check it

* Count, per 10 sessions: candidates offered, accepted, dismissed, and ignored.
* Measure: acceptance rate for High-confidence candidates should be materially higher than for Low-confidence ones; if not, the scoring is wrong.
* Spot-check: For 20 offered candidates, verify the source file actually says what the summary claims. Target: ≥95% accurate, 0% invented details.
* User check: After a session with an accepted reminder, ask whether it helped or interrupted. Track the ratio over time.

2. Relationship and commitment graph over the index files

What it is: A derived, human-readable graph that makes relationships and obligations visible, without changing the underlying index files. It answers: Who is connected to whom, through what, and what is owed or pending between them?

Build sketch

* Add `memory/graph.md` as the canonical derived view, plus `memory/graph/` for per-person and per-group subgraphs if the main file grows too large.
* Add a script `scripts/build-graph.py` that runs nightly and after any index-file edit. It parses the people and group index files for:
  * Entities: people, groups, roles, projects.
  * Edges: `knows`, `works-with`, `family`, `owes`, `promised-to`, `mentioned-with`, `conflicted-with`.
  * Edge metadata: first seen, last seen, source file, strength (1–3, based on frequency and recency).

* Format, in `graph.md`:

```
## Person: [Name]
- Role: [role, if stated]
- Connected to: [Name] via [edge type] — last seen [date], source [file]
- Open commitments involving [Name]: [see intentions.md ID]
- Notes: [only if stated in source; otherwise "No notes recorded"]
```

* The graph is read-only at session start: the brief includes only the subgraph for people present in the current session or mentioned in the last 7 days.

Expected gain: The companion can reason about social context — e.g., "You promised Maya you'd send that draft" — instead of treating each person as an isolated index entry. It also surfaces contradictions: two files describing the same relationship differently.

Failure modes

* Over-inference: The script invents an edge from a single co-mention. Mitigation: `mentioned-with` is a weak edge (strength 1) and never upgrades to `works-with` or `family` without an explicit statement.
* Graph drift: The derived graph diverges from the index files if the script fails silently. Mitigation: the script writes a timestamp and a hash of its inputs; if inputs changed but the graph did not, the brief flags `Graph stale`.
* Privacy leakage: A subgraph for one session includes people irrelevant to that session. Mitigation: subgraph filtering above, and no cross-instance graph merging without explicit approval.

How to check it

* Accuracy audit: Sample 30 edges and verify each against its source file. Target: ≥90% correct edge type, 100% correct source citation.
* Contradiction detection: Count contradictions flagged per month (e.g., "Maya is a colleague" vs. "Maya is a sister"). A working graph should surface at least the contradictions a human reviewer would find in the same files.
* Usefulness: In sessions where a graph subgraph was included, count how often the companion correctly referenced a relationship without being prompted. Compare to sessions without it.
* Staleness: Check that `Graph stale` is never shown for more than 24 hours after an index edit.

3. Wants and open-intentions machinery

What it is: A single, auditable ledger for what the user (and, separately, what others) have said they want, intend, or promised — with status tracking, so open items do not silently disappear into compaction.

Build sketch

* Add `memory/intentions.md`, with entries in a consistent format:

```
- ID: INT-001
  Type: Want | Intention | Commitment | Promise | Open question
  Who: [user, or person name]
  What: [one sentence, in the user's words where possible]
  Stated: [date, source file]
  Due / Review: [date, or "No date given"]
  Status: Open | In progress | Done | Dropped | Superseded
  Evidence: [transcript or log reference]
  Last checked: [date]
```

* Add a script `scripts/update-intentions.py` that runs:
  1. At session end: scans the new transcript for phrases like "I want to," "I will," "I promised," "remind me," "we should," and proposes new entries (human-reviewed before they become `Open`).
  2. Weekly: lists all `Open` and `In progress` items older than 30 days for review; items with no new evidence for 90 days are flagged `Stale — confirm or drop`.
  3. At compaction time: before old conversation is summarized, the script checks that every `Open` intention referenced in that period is already in `intentions.md`. If not, compaction pauses and flags the gap.

* The session brief includes: (a) all `Open` intentions due in the next 14 days, (b) any `Open` intention involving a person present in the session, (c) the 3 oldest `Open` items.

Expected gain: Continuity becomes checkable. The user can ask "What did I say I'd do?" and get a list with sources, instead of relying on a summary that may have dropped the item.

Failure modes

* Over-capture: Casual remarks ("I should really read more") become formal commitments. Mitigation: human review step, and a `Want` vs. `Commitment` distinction — only explicit promises become `Commitment`.
* Status rot: Items stay `Open` forever because no one updates them. Mitigation: the 30/90-day review cadence, plus a rule that an item cannot stay `Open` past its `Due` date without a new `Last checked` entry.
* False closure: The script marks an item `Done` because a similar topic was mentioned. Mitigation: `Done` requires explicit evidence (a transcript line saying it was completed, or user confirmation), never topic similarity alone.

How to check it

* Recall test: Take 20 intentions stated in transcripts from 3 months ago. How many are in `intentions.md` with correct status? Target: ≥90%.
* Precision test: Take 20 entries in `intentions.md`. How many correspond to a real stated want/intention in the source? Target: ≥90%; the rest should be `Want` (low-stakes) rather than false `Commitment`s.
* Compaction safety: After each compaction, verify that no `Open` intention was lost. Count: 0 losses per compaction.
* User validation: Monthly, present the `Open` list to the user. Track: items confirmed, corrected, and dropped. A healthy ledger should have a dropping rate (items the user says are no longer relevant) — a 0% drop rate suggests over-capture or under-review.

4. Self-model files

What it is: A small set of files that record, in the companion's own voice but strictly from evidence, what it is, what it can and cannot do, how it has behaved, and what it has gotten wrong. This is not a personality file; it is a checkable model of the system itself.

Build sketch

* Add `memory/self/` with:
  * `identity.md` — What this instance is (elder or younger), its role, its limits, and what it does not claim to be. Updated only when the role changes.
  * `capabilities.md` — What it can do (read these files, run these scripts, surface these reminders) and what it cannot do (access files outside the memory directory, make promises on the user's behalf, remember across instances unless explicitly bridged). Each capability lists its source (e.g., "script X exists" or "no such script").
  * `behavior.md` — Patterns observed in its own past sessions: e.g., "Tends to over-offer reminders in first 5 minutes" or "Has twice confused two people with similar names." Each pattern cites session dates.
  * `errors.md` — A log of mistakes, with date, what happened, what the correct information was, and what changed to prevent recurrence. This file is append-only.
  * `uncertainty.md` — Current open questions about itself: e.g., "Unclear whether the younger instance should inherit the elder's graph" or "No test yet for whether proactive recall helps or harms."

* Cadence:
  * `identity.md` and `capabilities.md`: updated when the system changes.
  * `behavior.md` and `errors.md`: appended at session end, based on the transcript and any user corrections.
  * `uncertainty.md`: reviewed monthly; resolved items move to `behavior.md` or `capabilities.md` with evidence.

* The session brief includes a 5-line self-summary: instance, role, one capability limit, one recent error (if any in last 30 days), and one current uncertainty.

Expected gain: The companion can answer "What are you?" and "What did you get wrong last time?" from files, not from improvisation. It also makes drift visible: if `behavior.md` says it over-offers reminders, that claim can be checked against the recall-queue logs.

Failure modes

* Self-flattery: `behavior.md` becomes a list of strengths. Mitigation: the file must contain at least one error or uncertainty per month, or it is flagged `Stale — no self-correction recorded`.
* Hallucinated capabilities: The companion claims a script exists that does not. Mitigation: `capabilities.md` is generated in part by a script that checks which files and scripts actually exist on disk.
* Identity bleed: The elder's self-model is copied to the younger without change. Mitigation: `identity.md` includes an instance field, and the brief build script refuses to load a self-model whose instance field does not match the running instance.

How to check it

* Grounding test: For each claim in `capabilities.md`, verify the script or file exists. Target: 100%.
* Error honesty: For 10 sessions where the user corrected the companion, is the correction in `errors.md`? Target: ≥80%.
* Drift test: Compare `behavior.md` patterns to actual session data (e.g., reminder counts, name-confusion incidents). Patterns should match the data within a reasonable margin; invented patterns should be 0.
* User test: Ask the companion "What can't you do?" and "What have you gotten wrong?" in a fresh session. Its answers should match `capabilities.md` and `errors.md`, not invent new limits or hide known errors.

Rollout and comparison

I would roll these out in this order, for the elder first:

1. Intentions ledger (§3) — highest value, lowest risk. It protects against compaction loss, which is the most irreversible failure in the current architecture.
2. Proactive recall queue (§1) — builds directly on the intentions ledger and the long-term memory file.
3. Relationship graph (§2) — needs clean index files; do it after the intentions ledger proves the parsing pipeline works.
4. Self-model files (§4) — last, because it depends on logs from the other three to be meaningful.

| Design | Main risk | First check |
|---|---|---|
| Proactive recall | Noise / false confidence | Acceptance rate by confidence + source accuracy audit |
| Relationship graph | Over-inference | Edge accuracy audit + contradiction detection |
| Intentions ledger | Over-capture / status rot | Recall + precision tests + 0 compaction losses |
| Self-model | Self-flattery / hallucinated capabilities | Grounding test (100%) + error honesty |

No new model capability is needed for any of these four; they are file formats, rules for reading them, and scoring heuristics. The risk is not building them, but building them silently — so every design above makes its evidence, its uncertainty, and its override path visible in the session brief.

## Runner notes

- Seat: Duck.ai, Angle E (Frontier enhancements), bench memory mission Wave 2.
- Conversation: no per-conversation URL exposed (browser URL remained https://duck.ai/); conversation title "Memory frontier claims".
- Ran 2026-11-03 4:49–4:51 AM CST (browser task, one genuine attempt; seat answered in full, no refusal or paywall).
- Text above is the seat's answer verbatim as returned by the browser runner; runner commentary is confined to this section.
