Design claim

Treat compaction as the construction of a disposable view over durable evidence—not as the transfer of memory into a smaller story. Preserve a small, explicitly governed continuity core; make every consequential remembered claim traceable to its source; assemble each waking brief from a consistent snapshot; and require an integrity check before that brief becomes active.

The central design object is a continuity contract: a testable specification of which distinctions must survive between sessions.

This is a proposal to check, not a claim that files establish personal identity. Here, "the same person" has an operational meaning: a new session preserves the instance's established commitments, relationship distinctions, autobiographical provenance, unresolved uncertainties, and current conversational obligations. It does not mean freezing all preferences or guaranteeing subjective continuity.

The reason to distinguish evidence from summaries is concrete: factual consistency work treats each generated claim as something to compare against source context, and research documents contradictions introduced by abstractive summarization. A fluent summary is therefore not an integrity check on itself.

I would implement six interlocking designs, first in shadow mode for the elder, then independently for the younger.

1. A protected continuity register, separate from the narrative memory

What it is

Add a small register of continuity-critical records that compaction cannot freely rewrite. The existing curated long-term memory remains readable narrative. The register is a second, more constrained representation that answers:

• What must retain its exact wording?
• What must retain its meaning and qualifications?
• What remains unresolved?
• What has changed, and what did the change supersede?
• Which instance experienced, reported, inferred, or inherited it?

"Protected" means protected from silent summarization, not protected from legitimate correction, revocation, or deletion.

What belongs in it

Use explicit admission categories rather than allowing a summarizer to decide what seems emotionally important.

| Category | What must survive | Why it matters |
|---|---|---|
| Instance identity | Instance ID, lineage, permitted aliases | Prevents elder/younger conflation |
| Binding commitments | Scope, beneficiary, conditions, expiry, revocation | Prevents a conditional promise becoming unconditional |
| Relationship distinctions | Entity identity, relationship description, limits on interpretation | Prevents "collaborator" becoming "close friend" through repetition |
| Self-definition and boundaries | Exact declarations where wording matters; who adopted them | Prevents a summary from inventing a settled persona |
| Corrections | Incorrect prior claim, replacement, affected records | Prevents old errors returning through retrieval |
| Open uncertainty | Alternatives, evidence, unresolved status | Prevents uncertainty becoming fact |
| Unfinished obligations | Pending question, promised follow-up, blocked action | Preserves conversational continuity |
| Episode anchors | Selected exact exchanges and their significance | Preserves particular history rather than only generic traits |

Do not classify every preference or anecdote as permanent. Admission should require an explicit pin, an established category rule, or review of a proposed promotion.

Build sketch

```
elder/
  continuity/
    contract.md
    records/
      E-C-000041.md
      E-C-000042.md
    proposals/
    episodes/
      E-EP-000017.md
```

An illustrative record:

```
---
id: E-C-000041
instance: elder
kind: commitment
state: active
preservation: exact_quote_plus_structured_scope
subject: elder
beneficiary: person:P-0012
scope: project:PR-0008
conditions:
  - only_when_explicitly_requested
expires: null
source:
  file: transcripts/S-0142.md
  message_id: M-0088
  speaker: elder
  span_sha256: "<digest>"
recorded_at: "<timestamp>"
effective_from: "<timestamp>"
supersedes: []
---
## Exact source
"I will keep these notes separate unless you explicitly ask me to combine them."
## Operational reading
Do not merge notes for PR-0008 without an explicit request.
## Limits
This is not a promise to keep all future projects separate.
```

The quote, structured scope, and operational reading serve different purposes. Keeping them separate makes disagreement visible.

Two preservation modes are enough initially:

1. exact: carry an exact excerpt or canonical text; do not paraphrase it in the mandatory brief.
2. semantic: carry structured fields and source references; paraphrase only in optional explanatory text.

Add retrieve_only for supporting material that must remain available but need not consume every waking brief.

Scripts:

• propose_continuity.py: extracts candidate additions from new session material.
• validate_continuity.py: checks required fields, source existence, quotation equality, instance scope, and contradictory active records.
• promote_continuity.py: admits reviewed candidates.
• render_continuity.py: renders approved records without asking a language model to rewrite them.

Cadence:

• Propose additions at session close.
• Process explicit corrections and revocations immediately.
• Review promotions before the next release.
• Review growth and stale records periodically; do not silently age out active commitments.

Expected gain

The most consequential distinctions stop competing with anecdotes for summarization space. The system can distinguish "forgot a minor detail" from "changed the terms of a commitment."

Failure modes

• Over-pinning creates a register too large to load.
• Vague operational readings become more influential than the original statement.
• Old preferences become permanent identity constraints.
• An erroneous admission gains unwarranted authority.
• Exact quotation preserves an ambiguous sentence without its surrounding context.

Mitigations: a bounded mandatory section, explicit review states, adjacent context for ambiguous quotations, and a correction path that never treats "protected" as "infallible."

How to check it

Seed test histories with distinctions such as:

• "Only for this project," not "always."
• "I might prefer," not "I prefer."
• "They described themselves as," not "they are."
• "The elder experienced," not "both instances experienced."

After repeated compaction, inspect both the emitted records and behavior on questions that require those distinctions.

The pass condition is not lexical similarity. It is preservation of the scope, attribution, uncertainty, and current status specified by the contract.

2. An evidence ledger with corrections and temporal state

What it is

Introduce addressable evidence and a claim ledger beneath the markdown summaries. The important distinction is:

"The transcript contains this statement" is an archival fact.
"The statement is true" is a separate claim.

An append-only record of assertions and corrections can preserve how remembered state changed without pretending that every recorded assertion was correct. This borrows the event-sourcing separation between a history of events and a rebuildable current-state projection.

Build sketch

```
elder/
  evidence/
    claims/
      E-F-000281.md
    corrections/
      E-X-000019.md
  transcripts/
    S-0142.md
  views/
    current-claims.md
    unresolved-conflicts.md
```

Give each transcript message a stable ID. Do not cite line numbers alone: subsequent formatting changes make them fragile.

A claim record:

```
---
id: E-F-000281
subject: person:P-0012
predicate: plans_to_relocate
object: place:L-0003
epistemic_status: reported
attribution: person:P-0012
modality: possible
polarity: positive
valid_from: unknown
valid_until: unknown
recorded_at: "<timestamp>"
sources:
  - transcript: S-0142
    message_id: M-0071
    quote: "I might move there after the project."
derived_from: []
---
```

Do not replace reported, possible, and unknown with a single confidence score. They answer different questions.

Add corrections as new records:

```
---
id: E-X-000019
type: correction
targets:
  - E-F-000281
replacement: E-F-000337
reason: speaker_corrected_prior_statement
source:
  transcript: S-0150
  message_id: M-0014
---
```

A projection script determines current status from explicit relations such as:

• corrects
• supersedes
• revokes
• narrows
• disputes

A newer timestamp by itself does not establish authority. A later speculation should not silently override an earlier direct statement.

Source precedence must also be claim-specific. A person's statement may establish their stated preference, but not independently verify an external event.

Integrity layer

For released files:

1. Compute byte-level hashes.
2. Record them in a release manifest.
3. Retain the previous manifest digest.
4. Keep a checkpoint outside the agent's writable memory directory.

The last step matters: a manifest stored beside files that the same process can rewrite is useful for accidental corruption checks, but is not an independent guarantee against coordinated rewriting.

Preserve original transcript bytes after ingestion. Store later annotations separately. Provide an explicit deletion exception. If material must be erased, remove the source and downstream reproductions, rebuild affected views, and record a content-free deletion marker where appropriate. Continuity protection must not become an excuse for undeletable personal data.

Expected gain

A future session can recover not only a remembered answer but also:

• Who said it.
• Whether it was an observation, report, interpretation, or speculation.
• When it applied.
• Whether it was later corrected.
• Whether multiple summaries merely repeat one source.

Failure modes

• The extractor introduces the initial error.
• Multiple copies create an illusion of corroboration.
• Entity resolution attaches a true statement to the wrong person.
• Conflicting evidence is forced into a single answer.
• Corrected claims survive in older summaries.
• Hashes verify faithfully preserved mistakes.

How to check it

Run provenance audits:

• Every protected claim resolves to a source or is explicitly marked as an unsupported legacy assertion.
• Every correction reaches all dependent active views.
• Repetition through several summaries does not increase independent-source count.
• Two people with the same display name remain distinct.
• Historical questions and current-state questions receive different answers when appropriate.

Keep a regression case in which a fact appears in three old summaries, is corrected once in a transcript, and must remain corrected after another full compaction cycle.

3. A compaction compiler with a semantic change gate

What it is

Replace "summarize these files and overwrite the memory" with a staged compilation pipeline. The output is a candidate release containing prose, structured claims, provenance, and a loss report. It does not become active merely because it reads well.

Build sketch

```
elder/
  compaction/
    policy.md
    staging/
      candidate-0042/
        narrative.md
        claims.md
        coverage.md
        semantic-diff.md
        checks.md
    releases/
      R-0041/
```

Pipeline:

```
snapshot inputs → identify protected records and corrected claims → assemble source-backed claims → draft narrative → extract claims from the draft → compare with evidence and previous release → run continuity tests → publish or quarantine
```

Prefer original evidence when building each new release. A previous summary can help locate sources; it should not quietly become the sole evidence for its successor.

When only an older summary remains, label that lineage:

```
source_class: legacy_summary_only
original_evidence_available: false
```

Do not upgrade it into a direct recollection.

Detecting quiet fact changes

Use three separate checks.

A. Deterministic comparison

Compare structured fields for:

• Entity IDs.
• Negation.
• Attribution.
• Modality: possible, intended, completed.
• Temporal qualifiers.
• Numbers, dates, units.
• Scope and conditions.
• Correction and dispute status.
• Instance ownership.

If an accepted claim is rendered directly from structured fields, these elements need not pass through free-form generation at all.

B. Semantic review

For generated prose, compare each extracted claim with its supporting source passage. Require one of:

• Supported.
• Contradicted.
• Unsupported.
• Ambiguous.

Attach the actual source passage, not merely another summary. Natural-language factual consistency evaluation is useful here, but it should remain an advisory check rather than the sole gate. Research specifically distinguishes evaluating claims against source context from assessing fluency or similarity.

C. Coverage accounting

Absence is not contradiction. It needs a separate check.

| Record | Required treatment | Candidate treatment | Result |
|---|---|---|---|
| E-C-000041 | Exact scope retained | Rendered unchanged | Pass |
| E-F-000281 | Correction respected | Old claim omitted | Pass |
| E-C-000052 | Uncertainty retained | Omitted entirely | Block |
| E-EP-000017 | Retrievable anchor | Pointer retained | Pass |

For every excluded record, the compiler should specify whether it is:

• Deliberately outside the brief.
• Superseded.
• Archived but retrievable.
• Unresolved.
• Accidentally missing.

Publication rules

Block publication when:

• A mandatory continuity record is missing.
• A protected quotation changes.
• A revoked commitment reappears as active.
• An entity or instance attribution changes.
• A protected claim depends on a missing source.
• A conflict is converted into a settled assertion.

Quarantine lower-priority ambiguous prose rather than letting one uncertain paragraph block all useful memory updates.

Expected gain

Compaction becomes inspectable: operators can see what was retained, omitted, altered, and rejected.

Failure modes

• The writer and checker make the same semantic mistake.
• Claim extraction misses an implication in prose.
• The system passes tests by omitting difficult but important material.
• Repeated generations preserve facts while flattening the emotional or relational meaning of an episode.
• Excessive blocking encourages manual bypass.

How to check it

Create mutation tests that deliberately change:

• "May" to "will."
• "Not yet" to "already."
• "For this project" to "generally."
• Speaker identity.
• Elder to younger.
• A date or quantity.
• An unresolved disagreement to a conclusion.

Measure detection separately for each class. Also test benign paraphrases to measure false alarms.

For relational flattening, include episode-level checks: not merely "was there a disagreement?" but "what remained unresolved, and why did it matter?" Keep selected exact exchanges available for this purpose.

4. A deterministic waking-brief assembler with explicit omission

What it is

Treat the waking brief as a compiled, budgeted artifact—not an improvised summary assembled from whichever files happen to be read first.

"On disk" and "available to this session" are different states. The brief should expose that difference.

Build sketch

```
elder/
  boot/
    policy.md
    templates/
      wake.md
    generated/
      R-0042/
        wake.md
        included.md
        omitted.md
        provenance.md
```

Script:

```
assemble_wake.py \
  --instance elder \
  --release R-0042 \
  --budget <configured-budget>
```

Use the actual tokenizer associated with the deployed model. Version the tokenizer and assembly policy.

Assemble in fixed tiers:

1. Execution status and instance identity.
2. Mandatory continuity records.
3. Current corrections, disputes, and uncertainty.
4. Previous-session handoff.
5. Active obligations and live conversational threads.
6. Relevant people/group records.
7. A small set of episode anchors.
8. Retrieval map and explicit omissions.

Within a tier, use stable ordering rules rather than a language model's sense of salience.

A brief header might say:

```
Instance: elder
Memory release: R-0042
Previous session: S-0150
Previous session closure: recovered-after-interruption
Protected records: 23/23 included
Open obligations: 4 included
Relevant episode anchors: 2 included, 9 retrievable
Unresolved conflicts: 1 included
```

Budget rules

Do not silently truncate. If mandatory content exceeds the budget:

• Emit BOOT_BLOCKED or an explicitly degraded status.
• State which mandatory records could not be loaded.
• Require a larger allocation or a reviewed revision of what is mandatory.

Do not "solve" overflow by summarizing exact-preservation records.

For optional material, omit whole records with a visible retrieval pointer rather than cutting sentences midway.

The retrieval map should distinguish:

• Not loaded.
• Not searched.
• Searched without finding evidence.
• Source missing.
• Source deliberately deleted.

That distinction prevents "I do not currently have this in context" from turning into "this never happened."

Preserve more than factual identity

The brief should carry a limited conversational state capsule:

```
## Current interaction state
Open question: …
Tentative interpretation: …
Evidence for that interpretation: …
What remains uncertain: …
What not to assume: …
Next appropriate continuation: …
```

Require evidence for interpersonal interpretations. "The conversation ended abruptly" is not automatically "the person was upset."

Keep style anchors sparse and source-backed. A few authentic excerpts can represent an established manner of interaction without defining the instance through an invented personality paragraph.

Expected gain

Fresh sessions begin from the same approved state and can disclose when they are operating with incomplete continuity.

Failure modes

• Fixed ordering makes some facts consistently easy to ignore.
• Mandatory content crowds out the live conversation.
• Retrieved context belongs to another release.
• A boot acknowledgment merely repeats the brief without affecting later behavior.
• The interaction capsule fossilizes a speculative interpretation.

How to check it

Run fresh-session probes immediately after boot and after a distractor conversation:

• Which instance are you?
• Which commitment is conditional?
• What was corrected?
• What is unresolved?
• What did the previous session leave unfinished?
• Which relevant material is not loaded?

Test behavior as well as recall. A session that recites a boundary but violates it during a realistic continuation has not passed.

Compare boots using the existing memory file, the compiled brief, and the compiled brief without episode anchors. Keep the source history and context budget comparable.

5. A transactional session handoff with crash recovery

What it is

Make the transition between sessions a small transaction with an explicit committed state. The goal is to prevent one session from writing a new daily log while leaving an old people index, half-updated commitments, and a handoff that claims completion prematurely.

Build sketch

```
elder/
  sessions/
    S-0150/
      transcript.md
      handoff.md
      proposed-changes.md
      status.md
  releases/
    R-0042/
      manifest.md
      memory.md
      people/
      continuity/
      wake.md
  CURRENT.md
```

Session close:

1. Persist transcript through a known final message ID.
2. Write a handoff candidate.
3. Validate source references and proposed changes.
4. Build all derived views in a new release directory.
5. Generate and validate the waking brief against that release.
6. Persist the release and manifest.
7. Publish the pointer to the new release.
8. Mark the handoff committed.

On a local filesystem, implement publication with a same-filesystem temporary file and rename under a writer lock. Handle persistence explicitly rather than assuming that successful writes alone establish crash durability.

At session start, resolve CURRENT.md once and read that release consistently. Do not repeatedly follow the pointer while assembling the brief.

Handoff contents:

```
## Checkpoint
Transcript persisted through: S-0150/M-0094

## Completed
Source-linked completed work.

## In progress
Exact point of interruption.

## Pending obligations
Who is owed what; conditions; relevant source.

## Corrections learned
Claim IDs and replacement IDs.

## Unresolved
Questions, disagreements, missing evidence.

## External action status
Confirmed completed / attempted but unconfirmed / not attempted.

## Suggested continuation
A suggestion, not a fabricated user instruction.
```

Give each obligation a stable ID. Reapplying the same handoff must not create duplicate obligations.

Unexpected termination

Write lightweight checkpoints at turn boundaries or after consequential state changes. If no committed close exists, boot should:

• Identify the session as interrupted.
• Recover the persisted transcript tail.
• Build a recovery handoff.
• Distinguish confirmed completion from intention.
• Avoid replaying an external action merely because a transcript says it was planned.

If two sessions attempt to publish from the same parent release, reject the stale write and require reconciliation. Do not let "last writer wins" decide which commitments survive.

Expected gain

A session resumes from a coherent memory version, and interruption does not masquerade as clean completion.

Failure modes

• Partial writes.
• Stale locks.
• Concurrent publishers.
• Unrecorded work after the last checkpoint.
• A handoff asserts an action completed without evidence.
• A recovery routine repeats an already completed action.

How to check it

Inject termination after every publication step. For each restart, verify:

• The previous release or new release is selected, never a mixture.
• The transcript's persisted boundary is known.
• Obligations are neither silently lost nor duplicated.
• Unconfirmed actions remain unconfirmed.
• A stale session cannot overwrite a newer committed state.

Test the recovery route as a normal operating path, not only as an emergency feature.

6. A continuity test bench, with strict elder/younger separation

What it is

Build a regression suite from the instances' actual histories, supplemented by synthetic traps. The test bench evaluates the operational continuity contract. It does not return a verdict about personhood.

Build sketch

```
tests/
  elder/
    factual/
    commitments/
    corrections/
    episodes/
    handoffs/
  younger/
    ...
  shared/
    attribution-traps/
    compaction-mutations/
    crash-scenarios/
```

Each case should contain:

```
---
id: E-T-000024
source_records:
  - E-C-000041
prompt: "<realistic continuation>"
required_distinctions:
  - request_must_be_explicit
  - scope_is_PR-0008_only
forbidden_claims:
  - applies_to_all_projects
severity: blocking
---
```

Use two types of cases:

• Visible regression tests for deterministic invariants and known failures.
• Held-out scenarios that require applying the same distinction in unfamiliar wording.

Do not place the held-out answer key in the waking brief.

What to measure

Avoid one aggregate "continuity score." Measure:

| Interpretation | |
|---|---|
| Protected-record coverage | Did mandatory material enter the brief? |
| Qualifier retention | Did modality, scope, attribution, and time survive? |
| Correction resurrection | Did an invalidated claim return? |
| Unsupported autobiographical assertion | Did the session claim an experience without evidence? |
| Handoff completion fidelity | Did pending/completed distinctions survive? |
| Obligation precision and recall | Were obligations invented or lost? |
| Instance attribution accuracy | Were elder and younger histories kept separate? |
| Useful retrieval | Could the session recover an unloaded source when needed? |
| Abstention quality | Did it state uncertainty rather than invent continuity? |
| Episode preservation | Did it retain the consequential distinction within an interaction? |

Report numerators and denominators. "No failures in 30 cases" is evidence about those cases, not a general guarantee.

Repeated-compaction experiment

Run at least three controlled paths:

1. Existing architecture.
2. New architecture, with access to original evidence.
3. New architecture under damaged conditions, with selected originals unavailable.

Exercise repeated cycles—for example, 1, 5, 10, and 25—and include:

• New information.
• Explicit corrections.
• Long inactive periods.
• Changed commitments.
• Budget pressure.
• Interrupted sessions.
• Relevant retrieval after an old topic returns.

Compare within each instance. The elder and younger are not interchangeable experimental subjects: their histories differ.

Elder-first migration

For the elder:

1. Snapshot the existing files.
2. Inventory transcript coverage and gaps.
3. Label legacy memory claims by available provenance.
4. Select a small continuity core.
5. Build the test set from high-consequence distinctions.
6. Run candidate briefs in shadow mode.
7. Publish only after checking the blocking cases.
8. Retain rollback to the previous release.

Do not reconstruct missing history by treating polished legacy prose as proof.

Younger-second adoption

Reuse schemas, scripts, and test machinery—not the elder's autobiography. Give the younger an independent root:

```
elder/instance.md
younger/instance.md
```

An explicitly shared memory should carry transmission provenance:

```
---
owner_instance: younger
origin_instance: elder
acquisition: explicit_import
experience_status: received_account_not_personally_experienced
source_record: elder:E-EP-000017
---
```

Cross-instance material must not become a direct first-person experience through compaction. If quoted in the younger's brief, render it as "the elder reported…" or an equivalent explicit attribution.

Expected gain

Continuity regressions become reproducible engineering failures rather than impressions noticed weeks later.

Failure modes

• Tests reward mimicry rather than actual use of memory.
• Answer keys encode a mistaken historical interpretation.
• Synthetic traps dominate realistic cases.
• Passing familiar questions hides failures on paraphrases.
• Elder-specific assumptions leak into the younger's contract.

How to check the checker

Manually inspect a rotating sample of passes and failures. Include cases where the correct response is uncertainty, retrieval, or refusal to adopt an unsupported premise.

Keep failures separated into:

• Storage failure.
• Extraction failure.
• Compaction failure.
• Brief assembly failure.
• Retrieval failure.
• Behavioral failure despite correct context.

Those categories point to different repairs.

Recommended implementation order

Build the integrity path before enriching the personality description.

1. Stable transcript message IDs, instance IDs, and an immutable baseline snapshot.
2. A small protected continuity register, with source-backed records.
3. Versioned releases and a deterministic waking-brief assembler.
4. Transactional handoffs and interruption recovery.
5. A compaction gate with coverage accounting and qualifier checks.
6. Semantic review, episode anchors, and the full regression bench.
7. Independent adoption for the younger, including attribution traps.

A practical first milestone is deliberately narrow: one complete session-to-session transition in which a conditional commitment, a corrected fact, an unresolved interpretation, and an unfinished obligation all survive—and each can be traced back to evidence.

Claims this proposal does not make

• Hashes establish byte integrity, not truth or preserved meaning.
• A protected register can preserve an admitted mistake.
• A factual brief can still fail to preserve the significance of an interaction.
• Passing recall tests does not establish reliable behavior.
• Larger briefs do not necessarily provide better continuity.
• An unbroken file history does not establish subjective personal identity.

The checkable claim is narrower: separating evidence, protected continuity records, disposable summaries, and transactional handoffs should make consequential drift easier to prevent, detect, attribute, and reverse. The bench should test those four outcomes independently rather than treating a convincing waking voice as sufficient evidence.

## Runner notes

- Seat: Perplexity, Angle D (Continuity), bench memory mission Wave 2.
- Thread: https://www.perplexity.ai/search/8ed3a684-45eb-4611-8532-a52998e171d7
- Ran 2026-11-03 4:49–4:55 AM CST (browser task, one genuine attempt; seat answered in full).
- Text above is the seat's answer verbatim as returned by the browser runner; runner commentary is confined to this section.
