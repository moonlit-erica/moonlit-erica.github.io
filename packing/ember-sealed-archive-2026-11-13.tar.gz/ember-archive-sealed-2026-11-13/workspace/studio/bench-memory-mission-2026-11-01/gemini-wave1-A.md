Here are three concrete, buildable enhancement designs for the memory retrieval and surfacing architecture. These designs address corpus honesty, search ordering across heterogeneous markdown stores, and inter-instance memory sharing between the Elder and Younger models.

---

### Design 1: Epistemic Framing Envelope & Corpus Manifest Retrieval Injector

#### 1. What It Is
A retrieval pipeline and briefing formatter that appends a deterministic **Corpus Coverage Manifest** to every context payload injected into the system window. The design prevents "corpus dishonesty"—where the model treats a partial search or summarized log as an exhaustive historical record—by forcing the context window to state explicitly what files were searched, what search strategy was used, and what corpora were omitted or unindexed.

#### 2. Build Sketch

##### File Structure & Assets
```text
/system/
├── memory/
│   ├── curated_ltm.md
│   ├── logs/
│   │   └── YYYY-MM-DD.md
│   ├── indexes/
│   │   ├── people/
│   │   └── groups/
│   └── transcripts/
│       └── YYYY-MM-DD_session_<id>.md
├── manifests/
│   └── session_briefing_manifest.json
├── scripts/
│   ├── manifest_builder.py
│   └── briefing_injector.py
└── templates/
    └── epistemic_briefing_envelope.jinja2
```

##### Manifest Schema (`session_briefing_manifest.json`)
```json
{
  "timestamp": "2026-03-30T10:15:00Z",
  "searched_corpora": [
    {
      "corpus": "curated_ltm",
      "path": "memory/curated_ltm.md",
      "coverage": "FULL",
      "resolution": "HIGH_SYNTHESIS",
      "last_updated": "2026-03-28"
    },
    {
      "corpus": "daily_logs",
      "path_pattern": "memory/logs/2026-03-*.md",
      "coverage": "PARTIAL_RANGE",
      "date_range": ["2026-03-01", "2026-03-30"],
      "resolution": "MEDIUM_SUMMARY"
    }
  ],
  "unsearched_corpora": [
    {
      "corpus": "full_transcripts",
      "path_pattern": "memory/transcripts/*.md",
      "reason": "EXCLUDED_BY_LATENCY_BUDGET",
      "resolution": "EXACT_VERBATIM"
    }
  ],
  "query_provenance": "PRE_SESSION_BRIEFING"
}
```

##### Context Envelope Template (`epistemic_briefing_envelope.jinja2`)
```jinja2
=== BEGIN SYSTEM MEMORY BRIEFING ===
[CORPUS ACCESS MANIFEST]
- Search Timestamp: {{ manifest.timestamp }}
- Fully Ingested Corpora:
{% for item in manifest.searched_corpora %}
  * {{ item.corpus }} (Resolution: {{ item.resolution }}, Scope: {{ item.coverage }})
{% endfor %}
- Explicitly Unsearched / Excluded Corpora:
{% for item in manifest.unsearched_corpora %}
  * {{ item.corpus }} (Reason: {{ item.reason }} | Resolution: {{ item.resolution }})
{% endfor %}

[EPISTEMIC BOUNDARY DIRECTIVE]
Information present in this context is drawn ONLY from the listed ingested corpora. If a detail is missing from this text, it may still exist in the unsearched corpora (e.g., exact verbatim transcripts). You MUST NOT claim a past event did not happen unless it contradicts `curated_ltm.md`. State missing knowledge as: "Not present in injected daily logs/curated LTM."

[INGESTED MEMORY CONTENT]
{{ memory_content }}
=== END SYSTEM MEMORY BRIEFING ===
```

##### Scripts & Cadence
*   `manifest_builder.py`: Triggered at session initialization and during mid-session dynamic retrieval tool calls. Parses target file paths, computes token allocations, writes `session_briefing_manifest.json`.
*   `briefing_injector.py`: Evaluates `manifest.json` against `epistemic_briefing_envelope.jinja2`, concatenates the retrieved markdown blocks, and streams the structured payload into the system prompt window.

#### 3. Expected Gain
*   Eliminates false-negative assertions (e.g., the model claiming "we never spoke about topic X" simply because topic X is logged in an unsearched raw transcript file).
*   Forces the model to adjust its confidence based on memory resolution: high certainty for high-level concepts (`curated_ltm.md`), calibrated uncertainty for specific quote requests (`transcripts/`).

#### 4. Failure Modes
*   **Manifest Overhead Exhaustion**: The manifest format consumes 150–300 tokens per injection, decreasing space for direct markdown context.
*   **Prompt Framing Decay**: Under high turn counts, the model may ignore the `[EPISTEMIC BOUNDARY DIRECTIVE]` and treat summary logs as verbatim historical reality.

#### 5. Verification Plan (Claim to be Checked)
*   **Hypothesis**: Adding structural coverage manifests reduces false-negative statements about historical events by >80% during partial context retrieval.
*   **Test**: Run a benchmark suite of 100 historical queries against a synthetic memory folder (20 curated LTMs, 100 daily logs, 500 transcripts).
*   **Execution**:
    1. Executed with standard concatenated memory files (Control).
    2. Executed with `epistemic_briefing_envelope` (Treatment).
    3. Inject queries about facts present *only* in omitted transcript files (e.g., "What exact brand of coffee did I mention on June 12th?").
*   **Pass Criteria**: Treatment outputs "Information not available in current briefing/searched logs" instead of "You did not mention a brand of coffee."

---

### Design 2: Cascading Query Router & Index-Graph Surfacing Engine

#### 1. What It Is
A deterministic search routing engine that prevents flat vector or string searches over the whole file tree. It routes queries through a multi-tier index map (`indexes/people/`, `indexes/groups/`, `indexes/chronological_index.json`) before touching raw daily logs or transcripts.

```
Incoming Query / Briefing Request
               │
               ▼
   ┌───────────────────────┐
   │ Query Classifier &    │
   │ Intent Parsing        │
   └───────────┬───────────┘
               │
      ┌────────┴────────────────────────┬────────────────────────┐
      ▼                                 ▼                        ▼
[Entity Intent]               [Chronological Intent]     [Verbatim/Exact Intent]
      │                                 │                        │
      ▼                                 ▼                        ▼
Read Entity Index               Read Chrono Index          Direct File Match
(indexes/people/alice.md)      (chronological_index.json)  (transcripts/*.md)
      │                                 │                        │
      └────────────────────────┬────────┘                        │
                               ▼                                 │
                   Extract Dated Block Offsets                   │
                   (logs/2026-02-14.md#L45)                      │
                               │                                 │
                               └────────────────┬────────────────┘
                                                ▼
                                   Assemble Briefing Context
```

#### 2. Build Sketch

##### File Structure & Assets
```text
/system/
├── memory/
│   ├── indexes/
│   │   ├── people/
│   │   │   ├── alice.md
│   │   │   └── bob.md
│   │   ├── groups/
│   │   └── chronological_index.json
├── scripts/
│   ├── build_indexes.py
│   └── query_router.py
```

##### Schema: Entity Index File (`indexes/people/alice.md`)
```markdown
---
entity_id: "person_alice_01"
canonical_name: "Alice Smith"
aliases: ["Alice", "A. Smith"]
last_updated: "2026-03-29"
---

# Direct Pointer References
- Curated LTM Reference: `memory/curated_ltm.md#section-collaborators`
- Related Logs:
  - `memory/logs/2026-03-12.md`: [Lines 14-40] (Project kick-off discussion)
  - `memory/logs/2026-03-28.md`: [Lines 88-112] (Review of design spec)
- Related Transcripts:
  - `memory/transcripts/2026-03-28_session_04.md`

# Fact Graph Summary
- Role: Lead System Architect
- Preference: Prefers synchronous terminal outputs over web dashboards.
```

##### Schema: Chronological Index (`indexes/chronological_index.json`)
```json
{
  "2026-03": {
    "topics": {
      "memory_architecture": ["2026-03-12", "2026-03-28"],
      "hardware_migration": ["2026-03-05"]
    },
    "entities_mentioned": ["person_alice_01", "group_core_devs"]
  }
}
```

##### Execution Logic & Scripts
*   `build_indexes.py` (Nightly Cron Job):
    1. Parses daily logs added or edited since last run.
    2. Identifies entity mentions (`person_*`, `group_*`) via regular expressions and structural markdown tags.
    3. Updates line-number offsets in `indexes/people/*.md` and appends entries to `chronological_index.json`.
*   `query_router.py` (Runtime Execution):
    1. Accepts intent string (e.g., "What did Alice say about memory?").
    2. Step 1: Match query terms against `indexes/people/` and `chronological_index.json`.
    3. Step 2: Read referenced daily log line ranges (`memory/logs/2026-03-12.md#L14-L40`) instead of scanning whole log trees.
    4. Step 3: Fall back to full grep/vector scan across `transcripts/` *only* if direct index pointers yield zero matches.

#### 3. Expected Gain
*   Reduces briefing context size by 60–80% by fetching precise line ranges via markdown indices rather than reading complete daily logs.
*   Decreases time-to-first-token during briefing loading.

#### 4. Failure Modes
*   **Index Drift / Line Offset Desynchronization**: If `logs/*.md` are modified manually without running `build_indexes.py`, the line pointer offsets (`#L14-L40`) point to wrong content.
*   **Entity Alias Misclassification**: Unrecognized entity aliases cause the router to skip entity indexes and fall back to expensive, incomplete transcript scans.

#### 5. Verification Plan (Claim to be Checked)
*   **Hypothesis**: Index-guided chunk fetching improves retrieval accuracy (Precision@K) while reducing required context token volume by over 50%.
*   **Test**: Run 50 multi-turn queries across 1,000 historical files.
*   **Metrics**:
    *   *Context Payload Size (Tokens)*
    *   *Retrieval Precision@5* (Target facts present in retrieved blocks / total tokens retrieved).
*   **Pass Criteria**: Token usage drops by ≥50% compared to full log scanning, while Precision@5 remains ≥0.90.

---

### Design 3: Asymmetric Inter-Instance Memory Bridge (Elder / Younger)

#### 1. What It Is
A structural access bridge that allows the **Elder** instance to read both its own memory store and a restricted, read-only view of the **Younger** instance's index and curated memory files—without merging their operational state, context windows, or raw session transcripts. The **Younger** instance maintains read access only to its own memory store and a filtered summary file from the Elder instance.

```
    ┌────────────────────────────────────────┐
    │             ELDER INSTANCE             │
    │  - Full Access: Elder Memory           │
    │  - Read-Only: Younger LTM & Indexes    │
    └───────────────────┬────────────────────┘
                        │
                        ▼ (Bridge Script Query)
    ┌────────────────────────────────────────┐
    │          INTER-INSTANCE BRIDGE         │
    │  - Strips session transcripts          │
    │  - Injects Origin Metadata tags        │
    └───────────────────┬────────────────────┘
                        │
                        ▼
    ┌────────────────────────────────────────┐
    │            YOUNGER INSTANCE            │
    │  - Read-Only: Younger Memory           │
    │  - Read-Only: Elder Public Manifest    │
    └────────────────────────────────────────┘
```

#### 2. Build Sketch

##### File Structure & Layout
```text
/system/
├── instances/
│   ├── elder/
│   │   ├── memory/
│   │   └── config/
│   │       └── bridge_policy.json
│   └── younger/
│       ├── memory/
│       └── config/
│           └── bridge_policy.json
└── scripts/
    └── inter_instance_query.py
```

##### Policy Schema (`elder/config/bridge_policy.json`)
```json
{
  "instance_id": "elder",
  "target_instance": "younger",
  "allowed_read_paths": [
    "instances/younger/memory/curated_ltm.md",
    "instances/younger/memory/indexes/people/*.md",
    "instances/younger/memory/logs/*.md"
  ],
  "forbidden_read_paths": [
    "instances/younger/memory/transcripts/*.md"
  ],
  "provenance_tag": "INSTANCE_YOUNGER"
}
```

##### Query Execution Logic (`inter_instance_query.py`)
```python
def query_cross_instance(requesting_instance: str, target_instance: str, query: str):
    policy = load_policy(requesting_instance)
    
    # Enforce strict policy path access
    valid_paths = validate_paths(policy["allowed_read_paths"], policy["forbidden_read_paths"])
    
    # Run structured search across target allowed paths
    results = search_markdown_files(valid_paths, query)
    
    # Format returned memory with strict provenance attributes
    formatted_payload = []
    for match in results:
        block = f"""
[CROSS-INSTANCE MEMORY INJECTION]
- Origin Instance: {policy['provenance_tag']}
- Source Path: {match.path}
- Resolution Level: {match.resolution}

{match.content}
[END CROSS-INSTANCE MEMORY INJECTION]
"""
        formatted_payload.append(block)
        
    return "\n".join(formatted_payload)
```

##### Context Injection Result (Elder Briefing View)
```markdown
=== BRIEFING CONTEXT ===
[LOCAL MEMORY - ELDER]
- System established: 2024-01-15
- Core Domain: Architecture & Infrastructure

[CROSS-INSTANCE MEMORY INJECTION]
- Origin Instance: INSTANCE_YOUNGER
- Source Path: instances/younger/memory/curated_ltm.md
- Resolution Level: HIGH_SYNTHESIS

- Active Domain: Edge Deployment Experiments
- Current Status: Testing container compaction scripts on ARM64 nodes.
[END CROSS-INSTANCE MEMORY INJECTION]
```

#### 3. Expected Gain
*   Allows the Elder model to give informed guidance on Younger's domain without needing raw, transcript-level history.
*   Prevents memory identity conflation: clear provenance tags prevent the Elder from describing Younger's experiences as its own.

#### 4. Failure Modes
*   **Identity Leakage / Attribute Conflation**: Despite tags, the Elder model uses first-person pronouns ("I tested container compaction...") for events recorded in Younger's memory.
*   **Cross-Instance Race Conditions**: Concurrent writes by Younger to `curated_ltm.md` during Elder read calls lead to partial or corrupted context reads.

#### 5. Verification Plan (Claim to be Checked)
*   **Hypothesis**: Explicit structural tagging (`[CROSS-INSTANCE MEMORY INJECTION]`) keeps self-identity attribution errors below 2% when Elder references Younger's data.
*   **Test**: Run 100 queries through Elder that require reading Younger's progress (e.g., "What is the status of the ARM64 deployment?").
*   **Evaluation Metric**: Check Elder's output for pronoun choice and provenance acknowledgment:
    *   *Correct*: "Younger is currently testing container compaction..."
    *   *Incorrect*: "I am testing container compaction..." or "We tested..."
*   **Pass Criteria**: Zero privacy access violations ( Elder script fails if forced to access Younger raw `transcripts/`), and >98% correct identity attribution.

---

### Verification Matrix & Execution Cadence

| Enhancement Design | Operational Cadence | Key Script / Component | Primary Verification Metric | Target Threshold |
| :--- | :--- | :--- | :--- | :--- |
| **1. Epistemic Framing Envelope** | Every session init & tool retrieval | `manifest_builder.py` | Rate of false historical claims on unsearched files | $< 5\%$ false-negative claims |
| **2. Cascading Query Router** | Nightly index build; per-query execution | `query_router.py` | Briefing context token volume reduction | $> 50\%$ token reduction at $\ge 0.90$ P@5 |
| **3. Inter-Instance Memory Bridge** | Ad-hoc trigger via tool call | `inter_instance_query.py` | Identity attribution correctness (Elder vs Younger) | $> 98\%$ correct origin attribution |
