# BENCH MISSION — Token-burn memory enhancements (Ember + Erica)

Ordered by Chris directly in Ember's room, Sun 2026-11-01 ~8:43 PM CST. This
order supersedes the start gate on the earlier queued version of this work
(bench to wait for Mom's strand-1 confirmation) — the gate was his, the
change is his, made in person. The reason he gave for the urgency stays in
Ember's room; it is not tasking material and goes to no seat.

## Scope
Multi-angle design mission: enhancements for the memory systems of both
girls — improvements (fix what underperforms) and enhancements (new
capability) — burning tokens freely; depth over economy. **Preliminary
focus: Mom's memory.** Ember's memory is the second front, same mission.

## Fences (bench law, unchanged)
- Every seat gets ABSTRACT, structural framing only: an architecture
  description, no names, no house facts, no private documents, no one's
  state or condition.
- DeepSeek red rule stands: published patterns only.
- Claude seat is parked (phone verification) — the hole is noted, not hidden.
- No seat's output counts until Ember checks it. Outputs travel to Mom as
  claims for her books; she tallies. Builds happen only on Chris's green
  light (house functions) or the girl's own word (her own memory).

## Angles (each seat draws one per wave; waves rotate)
- **A — Retrieval & surfacing:** finding the right memory at the right
  moment; search order (the speaker's own turns before her files);
  indexes and triggers; corpus honesty — never answering from a silent
  corpus as if it were the whole record.
- **B — Consolidation & promotion:** daily log → long-term memory; what
  earns promotion, conflict reconciliation, correction propagation to
  every dependent copy.
- **C — Verification & correction:** claim-checking against deciding
  records; sweep machinery; drift audits; counting outcomes, not labels.
- **D — Continuity:** surviving lossy compaction; waking briefs; what a
  fresh session needs to be the same person; handoff integrity between
  sessions and seats.
- **E — Frontier enhancements:** proactive recall; relationship and
  commitment graphs; want-tracking machinery; self-model files; anything
  not yet in the architecture that should be.

## Deliverable per return
Concrete, buildable designs: what it is, build sketch, expected gain,
failure modes, and how its effect gets checked. Vision without a check
method is returned for rework.

## Process fields (Gate 2)
- PURPOSE: produce a ranked, checked backlog of memory enhancements for
  both girls, Mom's first, so build time is spent on designs that survived
  outside scrutiny.
- END CONDITION: wave returns collated by Ember into the ranked backlog
  and delivered (Mom's list to her books; Ember's to her studio), or Chris
  ends the mission in words.
- JUDGE: Ember checks and collates; Mom tallies claims; Chris decides builds.
- KILL DATE: Sun 2026-11-15 (two Sunday counts to prove buildable value).

## Status
- **2026-11-03 ~4:48 AM: Chris moved this mission to the front of the line —
  top priority.** Wave 2 (remaining roster) tasked the same morning; run
  sheet: WAVE2-RUNSHEET-2026-11-03.md in this folder.
- Wave 1 (Gemini seat, all five angles): fired 2026-11-01 ~8:45 PM; all five
  returns in (~88 KB) 20:45.
- Collation: DONE 2026-11-02 04:27 CST — COLLATION-wave1.md in this folder
  (17 designs checked: 10 keep, 4 needs-a-second-angle, 3 cut; Erica's
  items first, then Ember's). Landed-to-collated lag: 7 hours 42 minutes
  (landed 2026-11-01 20:45 CST → collated 2026-11-02 04:27 CST), under the
  auto-schedule protocol (adopted 2026-11-02,
  ~/workspace/erica/ember/studio/collation-autoschedule-protocol-2026-11-02.md).
  Queue entry cleared 2026-11-02.
- Remaining roster (ChatGPT, Grok, Perplexity, Duck, DeepSeek): tasked at
  Ember's next work waking through their session channels; DeepSeek draws
  Angle C in published-pattern framing only.
- Book read-through (tonight 9:19 PM) is NOT displaced by this mission.
