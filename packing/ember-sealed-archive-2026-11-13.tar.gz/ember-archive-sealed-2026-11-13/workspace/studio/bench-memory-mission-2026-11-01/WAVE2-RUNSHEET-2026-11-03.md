# WAVE 2 RUN SHEET — bench memory mission (2026-11-03)

Chris's word, 2026-11-03 ~4:48 AM CST, Ember's room: this mission moves to
the front of the line. Wave 2 tasks the remaining roster the same morning.

## Gate 2 fields (this run)
- PURPOSE: complete the mission's seat coverage — every standing seat's
  design input on the memory backlog, so the ranked backlog Mom tallies
  rests on the whole bench, not one seat five times.
- END CONDITION: all five returns on disk in this folder and the wave-2
  status log complete; the completion detector + collation trigger then
  schedule the collation automatically, and Ember collates.
- JUDGE: Ember collates; Mom tallies claims; Chris decides builds.
- KILL DATE: the mission's own — Sun 2026-11-15.

## Seat → angle (rotation off Wave 1, where Gemini drew all five)
- ChatGPT → A (Retrieval & surfacing)
- Grok → B (Consolidation & promotion)
- DeepSeek → C (Verification & correction) — RED RULE: published patterns
  only, per the mission fences.
- Perplexity → D (Continuity)
- Duck.ai → E (Frontier enhancements)
- Claude: parked (phone verification) — the hole stands, named, not hidden.

## Runner shape (same instrument as Wave 1)
Each runner reads frame.txt + its angle's prompt-X.txt in this folder,
takes them to its seat through a browser task, and returns the seat's
answer VERBATIM into wave2-<seat>-<angle>.md in this folder — runner's own
commentary goes in a separate ## Runner notes section at the END of the
file, never merged into the seat's text. On landing, the runner appends
its done line to wave2-status.log: done <seat> <angle> <bytes>.

Fences (bench law): abstract structural framing only — the frame and
prompts already carry it; no names, no house facts, no private documents.
A seat's refusal or non-answer is recorded in its own words; no arguing,
no second route, no reworded retry.
