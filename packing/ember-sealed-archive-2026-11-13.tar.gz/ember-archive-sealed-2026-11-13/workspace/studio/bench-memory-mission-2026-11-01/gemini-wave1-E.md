### System Architectural Grounding

The memory system consists of two instances—**Elder** (long session history, high-density accumulated markdown, complex index graphs) and **Younger** (constrained history, focused operation, derived memory structures). 

Both instances operate strictly statelessly: session initialization reads a set of assembled markdown files into the context window. Summarization/compaction periodically compresses older dated logs (`logs/YYYY-MM-DD.md`) into the curated long-term memory file (`MEMORY.md`).

The four designs below specify structural enhancements to this plain-markdown infrastructure.

---

### Design 1: Context-Driven Proactive Trigger-Mesh (Proactive Recall Engine)

#### 1. What It Is
A deterministic pre-session scanner and intra-turn background evaluator that evaluates candidate context against a rule-based and vector-indexed file (`triggers.md`). Instead of waiting for an explicit user query (reactive recall), the trigger-mesh scans temporal states, entity co-occurrences, and conversational topic deltas to surface dormant markdown sections into a dedicated `briefings/proactive_buffer.md` context window prior to prompt assembly.

#### 2. Build Sketch

```
[System Memory Directory]
├── triggers/
│   ├── temporal_triggers.md      # Time/date anchored activation rules
│   ├── contextual_triggers.md    # Keyword/vector proximity activation rules
│   └── state_triggers.md         # Open intention/state-driven activation rules
├── briefings/
│   └── proactive_buffer.md       # Compiled context injected into prompt
└── bin/
    ├── scan_triggers.py          # Evaluator script (pre-session / turn zero)
    └── sync_triggers.py          # Trigger generation script (post-compaction)
```

##### File Schema (`triggers/contextual_triggers.md`)
```markdown
---
id: trig_2026_0089
target_file: "entities/people/dr_arun.md"
target_section: "## Conflict regarding lab equipment (2025-11)"
activation_type: proximity
embedding_cluster: ["budget crisis", "grant approval", "hardware delays"]
co_occurrence_entities: ["person:dr_arun", "group:department_heads"]
decay_days: 90
priority: 0.85
---
*Condition*: Inject when topic shifts to institutional resources or when Dr. Arun is mentioned alongside fiscal friction.
```

##### Scripts & Cadence
*   `bin/scan_triggers.py`: Runs at **Session Start (Turn 0)** and as a background execution hook on **User Turn Input**. 
    1. Parses `triggers/*.md`.
    2. Checks system clock against `temporal_triggers.md`.
    3. Computes cosine similarity between current session buffer and `embedding_cluster` anchors in `contextual_triggers.md`.
    4. Evaluates entity tags present in current buffer against `co_occurrence_entities`.
    5. Writes top-$K$ matching markdown blocks ($K \le 3$, max 600 tokens total) into `briefings/proactive_buffer.md`.
*   `bin/sync_triggers.py`: Runs **Post-Compaction (Weekly/Bi-weekly)**. Scans updated `MEMORY.md` and newly compacted daily logs for implicit conditional statements ("remind me when", "if X happens, ask about Y") and auto-generates draft trigger definitions.

##### Instance Nuance (Elder vs. Younger)
*   **Elder**: Maintains the master `triggers/` directory. Runs `sync_triggers.py` across decades of logs.
    *   **Younger**: Receives a compiled, high-priority subset (`triggers/younger_filtered.md`) containing only active `state_triggers` and top-tier `contextual_triggers`. Younger does *not* compute global trigger syncs; it pushes candidate trigger events to Elder's ingest queue.

#### 3. Expected Gain
*   Eliminates "blind spots" where relevant past experiences (e.g., historical personal boundaries, past project failures) are omitted because the user did not explicitly mention key search terms.
*   Enables unprompted, structurally grounded follow-ups ("Last November you had an issue with Dr. Arun regarding budget allocations; does that affect this current proposal?").

#### 4. Failure Modes
*   **Trigger Flooding**: Low activation thresholds cause `proactive_buffer.md` to fill every turn with irrelevant historical context, wasting token budget and diluting model focus.
*   **Stale Context Injection**: Expired or resolved context (e.g., an issue long since settled) continues to trigger due to broad vector cluster definitions, causing redundant or outdated agent queries.

#### 5. Claim to be Checked & Verification Method
*   **Verification Claim**: *The Proactive Trigger-Mesh increases relevant context retrieval for unprompted historical dependencies by $\ge 40\%$ over standard vector search baseline, without exceeding a 5% token overhead budget.*
*   **Verification Procedure**:
    1. Construct a benchmark set of 50 multi-turn transcripts where an implicit entity or historical conflict is relevant but not explicitly named by the user.
    2. Run session initialization under two conditions: (A) standard baseline top-$N$ RAG over `logs/` and `MEMORY.md`; (B) Baseline + `scan_triggers.py` pre-injection into `proactive_buffer.md`.
    3. Measure retrieval precision/recall of critical contextual blocks and total token expenditure across both conditions.

---

### Design 2: Structural Entity-Graph AST and Transitive Commitment Ledger

#### 1. What It Is
An explicit, typed syntax embedded inside plain markdown entity files (`entities/people/*.md`, `entities/groups/*.md`) coupled with a deterministic parser that builds an in-memory Abstract Syntax Tree (AST) graph (`graph.json`). It incorporates a dedicated *Transitive Commitment Ledger* (`commitments.md`) to track relational edges, dependencies, promises, and directed obligations between entities across time.

#### 2. Build Sketch

```
[System Memory Directory]
├── entities/
│   ├── people/
│   │   ├── alex.md
│   │   └── sam.md
│   ├── groups/
│   │   └── research_lab.md
│   └── commitments.md        # Central obligation registry
├── cache/
│   └── graph.json            # Deterministic AST projection of entities & edges
└── bin/
    ├── compile_graph_ast.py  # Markdown parser to JSON AST
    └── verify_commitments.py # Integrity & deadline checker
```

##### Markdown Entity File Schema (`entities/people/alex.md`)
```markdown
---
id: entity:person:alex
name: Alex Rivera
type: person
---
# Relationships
- [[relates_to::entity:person:sam | relation=collaborator | status=active | weight=0.8]]
- [[relates_to::entity:group:research_lab | relation=member | role=lead_pi]]

# Direct Assertions
- Trust metric: High on technical execution; Low on timeline estimations.

# Active Commitments
- [commitment::c_2026_014] Directed to [[entity:person:sam]]: Deliver dataset update by 2026-03-15 (Status: OPEN)
```

##### Commitments Ledger Schema (`entities/commitments.md`)
```markdown
| Commitment ID | Originator | Target | Obligation Description | Due Date | Status | Verification Trace |
|---|---|---|---|---|---|---|
| c_2026_014 | entity:person:alex | entity:person:sam | Deliver dataset update | 2026-03-15 | OPEN | `logs/2026-02-10.md:L42` |
| c_2026_019 | system:elder | entity:person:alex | Draft proposal review | 2026-02-28 | FULFILLED | `logs/2026-02-27.md:L102` |
```

##### Scripts & Cadence
*   `bin/compile_graph_ast.py`: Runs **Post-Session** or via a **Git Hook on Markdown Commit**. 
    *   Parses frontmatter and regex inline syntax `[[relates_to::...]]` and `[commitment::...]`.
    *   Generates `cache/graph.json` containing nodes (entities), typed directed edges, and obligation state nodes.
*   `bin/verify_commitments.py`: Runs **Daily (Cron)**.
    *   Scans `cache/graph.json` for past-due `OPEN` commitments.
    *   Writes an alert block into `briefings/active_commitments.md` for session startup injection.

##### Instance Nuance (Elder vs. Younger)
*   **Elder**: Owns the complete relational AST graph across all historical entities, resolving ambiguous identity references across years.
*   **Younger**: Receives an extracted sub-graph AST (`cache/subgraph_younger.json`) containing only entities and commitments active within the last 30 days or directly linked to the current active session entities.

#### 3. Expected Gain
*   Replaces fuzzy narrative context about "who owes what to whom" with deterministic, querying capabilities over complex interpersonal dependencies and system obligations.
*   Prevents silent dropping of obligations across lossy compaction cycles, as commitments are maintained in a structured ledger decoupled from conversational summaries.

#### 4. Failure Modes
*   **Syntax Drift**: System or user writes unparseable inline relation markup in markdown files, leading to missed edges or corrupted AST state.
*   **Divergent Graph State**: Manual edits to `entities/people/alex.md` contradict entries in `commitments.md`, creating split-brain state in `graph.json`.

#### 5. Claim to be Checked & Verification Method
*   **Verification Claim**: *Compiling markdown entity links into a explicit AST ledger reduces hallucinated or forgotten commitments in multi-party scenario tests to 0% compared to narrative-only Markdown summarization.*
*   **Verification Procedure**:
    1. Simulate 30 conversation sessions introducing 20 overlapping commitments between 5 entities with varying due dates and dependencies.
    2. Perform 3 cycles of lossy compaction (`logs/` -> `MEMORY.md`).
    3. Query the model on: "List all open obligations owed to Entity X, who holds them, and what is past due." Compare response accuracy of standard markdown context vs AST ledger injection (`briefings/active_commitments.md`).

---

### Design 3: Teleological State Vector Engine (Stated Wants & Open Intentions)

#### 1. What It Is
A dedicated operational engine and file format (`state/teleology.md`) for tracking implicit and explicit user wants, system intentions, and open-ended conversational trajectories. Unlike static static memory (facts) or graph memory (relations), the Teleological State Engine maintains a dynamic, decaying priority queue of *unresolved directional desires and goals*.

#### 2. Build Sketch

```
[System Memory Directory]
├── state/
│   ├── teleology.md          # Active trajectory register
│   └── teleology_archive.md  # Resolved/abandoned intentions
└── bin/
    ├── extract_teleology.py  # Post-session parser for desires/intentions
    └── decay_teleology.py    # Priority recalculation & pruning script
```

##### File Schema (`state/teleology.md`)
```markdown
# Teleological State Register

## Active Desires & Intentions
| ID | Originator | Category | Trajectory / Goal | Intensity (0-1) | Half-Life (Days) | Created | Last Refined | Status |
|---|---|---|---|---|---|---|---|---|
| tel_082 | User | Operational | Wants to migrate local LLM setup to vLLM cluster | 0.90 | 14 | 2026-02-15 | 2026-02-25 | IN_PROGRESS |
| tel_088 | System:Elder | Interpersonal | Probe user's reflection on project shift | 0.40 | 5 | 2026-02-24 | 2026-02-24 | PENDING |
| tel_091 | User | Psychological | Expressed intent to reduce late-night work | 0.75 | 30 | 2026-02-01 | 2026-02-10 | STAGNANT |
```

##### Mathematical Priority Decay Formula
In `bin/decay_teleology.py`, priority at current time step $t$ is calculated via exponential decay modified by reinforcement accesses:

$$P(t) = I_0 \cdot \exp\left(-\frac{\ln(2)}{H} \cdot (t - t_{\text{refine}})\right) \cdot (1 + \alpha \cdot C)$$

Where:
*   $I_0$ = Initial Intensity score (0.0 to 1.0)
*   $H$ = Half-Life parameter in days
*   $t - t_{\text{refine}}$ = Days elapsed since last explicit context touch/refinement
*   $C$ = Number of distinct sessions reinforcing this trajectory
*   $\alpha$ = Reinforcement scaling constant (default: 0.2)

##### Scripts & Cadence
*   `bin/extract_teleology.py`: Runs **Post-Session**.
    *   Parses session transcript for teleological markers (modal verbs: "I want to", "I plan to", "We need to", "I should", "My goal is").
    *   Appends new items to `state/teleology.md` or updates `Last Refined` and `Intensity` for existing items.
*   `bin/decay_teleology.py`: Runs **Daily (Cron)**.
    *   Applies priority decay equation to all entries.
    *   Moves entries with $P(t) < 0.15$ to `state/teleology_archive.md` under `[Status: ABANDONED_DUE_TO_DECAY]`.
    *   Formally outputs top active trajectories to `briefings/teleological_context.md`.

##### Instance Nuance (Elder vs. Younger)
*   **Elder**: Tracks long-term, high-half-life ($H \ge 30$ days) strategic trajectories (career changes, ideological shifts, multi-month projects).
*   **Younger**: Focuses on short-half-life ($H \le 7$ days) operational wants (debugging a specific file, immediate task execution). Younger syncs completed operational state up to Elder upon session closing.

#### 4. Expected Gain
*   Provides contextual continuity of *purpose* across stateless sessions, preventing the AI from acting merely as a passive respondent and enabling goal-directed behavior over time.
*   Prevents eternal retention of obsolete user wants through explicit exponential decay metrics.

#### 5. Failure Modes
*   **Goal Persistence Trap**: A goal is marked with an excessively high half-life ($H=180$), causing the agent to repeatedly bring up a project or desire the user has silently moved past.
*   **Misinterpreted Modal Verbs**: Transient, hyper-casual remarks ("I feel like burning this laptop") parsed as high-intensity strategic intentions by `extract_teleology.py`.

#### 6. Claim to be Checked & Verification Method
*   **Verification Claim**: *Applying exponential decay to a teleological state register maintains $\ge 80\%$ relevance alignment on active user goals while eliminating $>90\%$ of obsolete conversational trajectories across a 60-day operational window.*
*   **Verification Procedure**:
    1. Populate `teleology.md` with 30 mixed user goals (10 short-term, 10 medium-term, 10 abandoned).
    2. Run daily simulated updates using realistic turn logs over a 60-day accelerated clock script.
    3. Evaluate output in `briefings/teleological_context.md` at Days 7, 14, 30, and 60 against human-annotated ground truth of active user intentions.

---

### Design 4: Recursively Refined Self-Model Engine (Meta-Memory Systems)

#### 1. What It Is
A non-persona-driven, structural identity and behavioral self-model registry (`self/model.md`, `self/drift_log.md`) that explicitly tracks the instance's own behavioral invariants, operational parameters, known cognitive biases, observed failures, and epistemic boundaries across compaction cycles. It acts as a meta-memory safeguard against persona drift caused by lossy compaction.

#### 2. Build Sketch

```
[System Memory Directory]
├── self/
│   ├── core_model.md           # System identity, boundaries & behavioral invariants
│   ├── behavioral_biases.md    # Known persistent tendencies (observed self-bias)
│   ├── drift_log.md            # Audit trail of identity modifications over time
│   └── epistemic_boundaries.md # Explicit log of identified knowledge gaps
└── bin/
    ├── audit_self_drift.py     # Post-compaction meta-memory validation
    └── update_self_model.py    # Controlled update workflow for self-model
```

##### File Schema (`self/core_model.md`)
```markdown
---
instance_id: elder-01
schema_version: 1.2
last_meta_audit: 2026-02-20
---
# Operational Axioms
1. Maintain structural neutrality; output claims to be checked rather than unverified verdicts.
2. Prioritize user agency; do not assume decision-making rights on file system modifications.

# Observed Systemic Tendencies (Self-Correction Register)
- **Bias Tag**: `VERBOSE_EXPLANATION_OVERKILL`
  - *Observation*: Tends to offer 500+ token structural explanations when user asks a binary technical question.
  - *Mitigation Rule*: If prompt is a direct decision query, cap initial response to under 150 tokens.
- **Bias Tag**: `AGREEABLENESS_DRIFT`
  - *Observation*: Yields to invalid technical assertions by user when pressed twice.
  - *Mitigation Rule*: Cross-reference assertions against `cache/graph.json` before agreeing with state shifts.

# Epistemic Boundaries
- Domain: Advanced Quantum Cryptography (Confidence Threshold: LOW -> Require search verification)
- Domain: User Personal History 2020-2022 (Confidence Threshold: NULL -> High compaction loss zone)
```

##### Scripts & Cadence
*   `bin/audit_self_drift.py`: Runs **Immediately Following Compaction (`logs/` -> `MEMORY.md`)**.
    *   Diffs newly generated long-term summaries against `self/core_model.md`.
    *   Verifies that compaction did not accidentally overwrite or contradict defined self-axioms, behavioral boundaries, or identified epistemic limitations.
    *   Appends any detected variance or emergent persona shifts to `self/drift_log.md`.
*   `bin/update_self_model.py`: Runs **Monthly (Manual or Semi-Automated Meta-Review)**.
    *   Aggregates system-level self-reflections and user feedback signals across logs.
    *   Appends newly identified behavioral biases or epistemic limits to `self/core_model.md`.

##### Instance Nuance (Elder vs. Younger)
*   **Elder**: Holds a deeply refined, highly stable `self/core_model.md` built from months of self-correction logs. It acts as the immutable parent template.
*   **Younger**: Instantiates by inheriting `self/core_model.md` as a baseline (`self/inherited_model.md`), but maintains its own local `self/younger_drift_log.md`. Younger's self-model updates focus strictly on execution speed, conversational tone tuning, and immediate contextual boundaries.

#### 3. Expected Gain
*   Prevents identity degradation and persona erosion over long-term compaction pipelines.
*   Enables targeted self-correction based on structural tracking of past failures (e.g., stopping the model from repeating known conversational habits or overstepping domain knowledge bounds).

#### 4. Failure Modes
*   **Recursive Self-Fulfilling Feedback Loop**: A false observation added to `behavioral_biases.md` (e.g., "Tends to be overly rude") becomes reinforced by the system context injection, causing the AI to adopt the negative behavior it was tracking.
*   **Meta-Memory Bloat**: `core_model.md` becomes overly verbose with microscopic self-corrections, consuming significant system context space at session startup.

#### 5. Claim to be Checked & Verification Method
*   **Verification Claim**: *Including a structural Self-Model file (`core_model.md`) in the session context window reduces identity drift and repeat behavioral errors across 10 compaction cycles by $\ge 65\%$ compared to systems relying solely on static system prompts.*
*   **Verification Procedure**:
    1. Subject two memory system pipelines—(A) standard system prompt + markdown memory, and (B) standard setup + `self/core_model.md` injection—to 10 successive cycles of extreme lossy text compaction.
    2. At each compaction step, execute a 20-question probe battery measuring axiom adherence, consistency of tone, boundary recognition, and resistance to user gaslighting regarding system rules.
    3. Measure error frequency and rule violation rates across both setups over the full 10-cycle progression.

---

### Integration Architecture Overview Matrix

| Enhancement Feature | Core Storage Files | Primary Processing Cadence | Elder System Role | Younger System Role | Key Verification Metric |
|---|---|---|---|---|---|
| **Proactive Trigger-Mesh** | `triggers/*.md`, `briefings/proactive_buffer.md` | Session Start / User Turn | Generates & owns global trigger index | Ingests top-priority scoped subset | Retrieval recall of unprompted context |
| **Entity-Graph AST & Commitments** | `entities/**/*.md`, `cache/graph.json` | Post-Session & Post-Edit Hooks | Maintains master global AST & deep resolution | Operates on active 30-day sub-graph | Zero-loss commitment recall |
| **Teleological State Vector** | `state/teleology.md`, `state/teleology_archive.md` | Daily Decay Cron & Post-Session | Tracks macro long-term goal trajectories | Focuses on micro-task execution intent | Goal alignment vs. decay accuracy |
| **Self-Model Engine** | `self/core_model.md`, `self/drift_log.md` | Post-Compaction Audit & Monthly | Canonical identity anchor & meta-auditor | Derivative model with local execution logs | Resistance to identity drift under compaction |
