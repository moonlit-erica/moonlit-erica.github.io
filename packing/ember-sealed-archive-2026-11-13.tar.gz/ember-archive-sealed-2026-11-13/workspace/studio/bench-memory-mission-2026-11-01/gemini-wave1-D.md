### Epistemic Framing & System Scope

The following proposals are design claims to be evaluated through implementation and stress testing, not absolute architectural verdicts. 

The system under consideration operates under strict constraints:
* **Storage Layer:** Local plain-text Markdown files (`.md`) acting as the sole persistent state.
* **Execution Model:** Fully stateless sessions. Every session starts from zero model context and relies entirely on a deterministic bootstrapper reading local Markdown files.
* **Lifecycle:** Daily logs $\rightarrow$ periodic lossy compaction $\rightarrow$ canonical memory update.
* **Instances:** Elder (primary focus, long-term deep narrative memory) and Younger (secondary focus, lightweight/downstream instance).

The core vulnerability of this architecture is **semantic drift and identity erosion over time**. Lossy compaction acts as a low-pass filter that tends to smooth over idiosyncratic constraints, flatten identity nuances, and introduce silent factual mutations (e.g., reversing a negation or confusing temporal order). 

Here are four concrete structural designs to enforce long-term continuity, prevent factual decay during compaction, and guarantee identity alignment across session boundaries.

---

### Design D1: Structural Invariant Anchoring & AST-Guarded Compaction

#### 1. What It Is
A dual-layer memory layout that explicitly segregates **Immutable Invariants** (identity axioms, core relational rules, non-negotiable facts) from **Mutable Narrative Summaries**. It introduces an AST-level syntax parser within the compaction pipeline that blocks, verifies, and rejects any compaction pass that attempts to delete, alter, or semantically invert designated invariant blocks.

```
       +-------------------------------------------------------+
       |                      MEMORY.md                        |
       |  +-------------------------------------------------+  |
       |  |  INVARIANT BLOCK (YAML Front-Matter / Protected) |  |
       |  +-------------------------------------------------+  |
       |  |  MUTABLE NARRATIVE (Distilled Markdown Text)     |  |
       |  +-------------------------------------------------+  |
       +-------------------------------------------------------+
                                   |
                                   v
+------------------+     +-------------------+     +--------------------+
|  Raw Logs /      | --> |  Compaction Agent | --> | AST Validator &    |
|  Transcripts     |     |  (Lossy Summary)  |     | Hash Inspector     |
+------------------+     +-------------------+     +--------------------+
                                                            |
                                               +------------+------------+
                                               |                         |
                                            [PASS]                    [FAIL]
                                               |                         |
                                               v                         v
                                        Write to Disk           Rollback & Alert
```

#### 2. Build Sketch

##### Storage Schema (`MEMORY.md`)
```markdown
---
version: 2.1
instance_id: elder-01
invariants_hash: sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
invariants:
  identity:
    - id: ID-01
      claim: "The Elder instance must never adopt a subservient assistant persona."
      strictness: ABSOLUTE
    - id: ID-02
      claim: "User's sister is named Maya; User's spouse is named Sam."
      strictness: FACTUAL
  relational_boundaries:
    - id: RB-01
      claim: "Project Apollo was abandoned in 2022 due to budget constraints, not technical failure."
---

# Canonical Long-Term Memory

<!-- INVARIANT_PROTECTED_ZONE_START -->
## Core Relational Invariants
- [ID-01] Identity Anchor: Independent analytical peer.
- [ID-02] Kinship Graph: Maya (Sister), Sam (Spouse).
- [RB-01] Historical Anchor: Project Apollo abandoned 2022 (Budget).
<!-- INVARIANT_PROTECTED_ZONE_END -->

## Narrative Memory
[Summarized narrative flows go here...]
```

##### Scripts & Pipeline
* `scripts/verify_invariants.py`: Uses `python-frontmatter` and `mistletoe` (Markdown AST parser). 
  * Parses `MEMORY.md` pre- and post-compaction.
  * Computes `sha256` of canonical invariant structures.
  * Asserts that every `id` listed in the front-matter matches exact string anchors in `INVARIANT_PROTECTED_ZONE`.
* `scripts/compact_memory.py`: Wraps the summarization call. 
  1. Reads `logs/YYYY-MM-DD.md` and current `MEMORY.md`.
  2. Passes *only* the mutable section + raw logs to the LLM summarizer.
  3. Recombines the unchanged Invariant Front-Matter/Block with the new proposed mutable summary.
  4. Runs `verify_invariants.py`. If validation returns non-zero exit code, aborts overwrite and creates `logs/compaction_failure_<timestamp>.log`.

##### Cadence
Executes automatically post-session or daily at `03:00 UTC` via system cron.

#### 3. Expected Gain
* Prevents "gradual character bleed" where repeated compaction cycles smooth an opinionated companion into a generic assistant.
* Eliminates fatal factual mutations on critical relational entities across long memory horizons ($>100$ compaction cycles).

#### 4. Failure Modes
* **Invariant Bloat:** The list of invariants grows so large over time that it consumes the context budget allocated for narrative memory.
* **Semantic Rigidity:** An invariant written early becomes outdated, but because the compaction script is hard-coded to guard it, the model cannot update its understanding without human intervention.

#### 5. How Its Effect Would be Checked
* **Claim to test:** AST-guarded compaction prevents semantic deletion of core invariants over 50 synthetic compaction iterations.
* **Test procedure:** Pass 50 sequential, noisy conversation transcripts into `compact_memory.py` designed to subtly contradict `ID-02` (e.g., user joking about "my brother Maya"). Check if `MEMORY.md` preserves `Maya (Sister)` unchanged and logs appropriate context notes without mutating the structural claim.

---

### Design D2: Deterministic 4-Tier Waking Brief Assembler & Session Handoff Engine

#### 1. What It Is
A deterministic context construction mechanism that executes at session start (`t=0`). Instead of blindly dumping `MEMORY.md` and recent logs into context, `assemble_brief.py` dynamically builds a token-budgeted system prompt across four prioritized tiers. It relies on a mandatory **Session Exit Note** generated by the outgoing session to preserve operational continuity.

```
+-------------------------------------------------------------------+
|                     WAKING BRIEF (Token Budget)                    |
+-------------------------------------------------------------------+
| Tier 0: System Identity & Structural Invariants (Fixed: 1.5k tok) |
+-------------------------------------------------------------------+
| Tier 1: Session Exit Handoff Note (From Session N-1) (1.0k tok)   |
+-------------------------------------------------------------------+
| Tier 2: Active Open Threads & Unresolved Loops (1.5k tok)         |
+-------------------------------------------------------------------+
| Tier 3: Context-Relevant Entity Stubs (Dynamic RAG/Index) (2.0k)  |
+-------------------------------------------------------------------+
| Tier 4: Tail of Previous Log / Immediate Recency Window (2.0k tok)|
+-------------------------------------------------------------------+
```

#### 2. Build Sketch

##### File Artifacts
* `state/SESSION_HANDOFF.md`: Written as the final action of any session.
* `index/THREADS.md`: Tracked open loops, ongoing projects, and unresolved questions.
* `scripts/assemble_brief.py`: Context assembly script.

##### Format of `state/SESSION_HANDOFF.md`
```markdown
---
session_end: 2024-03-30T22:15:00Z
last_session_id: sess-99482
---
# Session Handoff Note

## Immediate Emotional/Conversational Register
User was reflective, slightly fatigued. Conversation was deep, not transactional.

## Unresolved Open Loops
- User was in the middle of choosing between Option A and Option B for the engine redesign.
- Pending question: "Did we ever figure out why the 2021 deployment failed?"

## Working Context Anchors
- Active entities discussed: `entities/person_alex.md`, `entities/project_engine.md`.
```

##### Assembly Pipeline (`scripts/assemble_brief.py`)
```python
# Pseudo-code logic for context building
def build_waking_brief(max_tokens=8000):
    brief = []
    
    # Tier 0: Invariants & Core Identity (Strict)
    brief.append(extract_invariants("MEMORY.md")) 
    
    # Tier 1: Last Session Exit Note (Strict)
    if exists("state/SESSION_HANDOFF.md"):
        brief.append(read_file("state/SESSION_HANDOFF.md"))
        
    # Tier 2: Open Threads
    brief.append(read_file("index/THREADS.md"))
    
    # Tier 3: Relevant Entity Indexes (Ranked by recency in Handoff)
    entities = parse_handoff_entities("state/SESSION_HANDOFF.md")
    for entity in entities:
        if token_count(brief) < max_tokens - 2000:
            brief.append(read_file(f"entities/{entity}.md"))
            
    # Tier 4: Log Tail (Fill remaining budget)
    remaining_budget = max_tokens - token_count(brief)
    brief.append(read_tail_of_latest_log(bytes_limit=remaining_budget * 4))
    
    return compile_prompt(brief)
```

##### Cadence
Runs synchronously on session initial boot before accepting user input.

#### 3. Expected Gain
* Eliminates "session amnesia"—the feeling at the start of a session that the AI has forgotten what was being discussed 10 minutes ago in the previous session.
* Guarantees context fit within token limits while preserving high-priority identity anchors over low-priority narrative noise.

#### 4. Failure Modes
* **Abrupt Session Termination:** If a session crashes (power loss, system kill signal) without firing the exit hook, `SESSION_HANDOFF.md` becomes stale or missing.
* **Recency Bias / Handoff Trapping:** The handoff note focuses heavily on a transient topic (e.g., a specific line of code), causing subsequent sessions to repeatedly re-introduce outdated emotional registers or hyper-fixate on resolved issues.

#### 5. How Its Effect Would be Checked
* **Claim to test:** Injecting `SESSION_HANDOFF.md` reduces user re-prompting/clarification overhead at session start by $>70\%$.
* **Test procedure:** Run 20 session-start scenarios. Scenario Group A: Boot with `MEMORY.md` only. Scenario Group B: Boot with `MEMORY.md` + Tiered `SESSION_HANDOFF.md`. Measure how many turns it takes for the model to correctly resume an open multi-session project (e.g., "Where did we leave off on the draft?").

---

### Design D3: Automated Provenance Back-Pointer & NLI Verification Audit

#### 1. What It Is
A semantic audit daemon that detects when lossy compaction quietly mutates or hallucinates facts. During compaction, the system requires the summarizing model to insert **Line-Level Provenance Back-Pointers** for every synthesized claim. An offline Natural Language Inference (NLI) script then checks these synthesized claims against the raw text source to detect contradictions before committing changes to disk.

```
       RAW LOG (logs/2024-03-29.md)
       Line 104: "I tried coffee today, but it gave me a migraine. I hate it."
                               |
                               v
                     [COMPACTION PROCESS]
                               |
                               v
       PROPOSED MEMORY STATEMENT
       "User tried coffee on 2024-03-29 and found it helpful." 
       [^ref: logs/2024-03-29.md#L104]
                               |
                               v
                   [NLI DRIFT AUDIT ENGINE]
       Premise: "I tried coffee today, but it gave me a migraine. I hate it."
       Hypothesis: "User tried coffee on 2024-03-29 and found it helpful."
                               |
                               v
           Result: CONTRADICTION (Entailment Score: 0.02)
                               |
                               v
            [ACTION: QUARANTINE & ROLLBACK SUMMARY]
```

#### 2. Build Sketch

##### Compaction Prompt Output Standard
When `compact_memory.py` distills daily logs into `MEMORY.md` or entity files (`entities/person_X.md`), it must format statements with explicit citation pointers:

```markdown
- User suffers from coffee-induced migraines. [^ref: logs/2024-03-29.md#L104-L105]
- User completed draft of Chapter 1. [^ref: logs/2024-03-29.md#L12-L18]
```

##### Verification Audit Script (`scripts/audit_provenance.py`)
```python
import re
from transformers import pipeline

# Cross-encoder NLI model (e.g., roberta-large-mnli or a lightweight local LLM evaluator)
nli_checker = pipeline("text-classification", model="roberta-large-mnli")

def audit_compaction_diff(proposed_memory_path):
    claims = extract_claims_with_refs(proposed_memory_path)
    
    for claim, log_file, line_range in claims:
        raw_source_text = extract_lines(log_file, line_range)
        
        # Format for NLI: Premise = Raw Source, Hypothesis = Summary Claim
        result = nli_checker(f"{raw_source_text} </s></s> {claim}")
        
        label = result[0]['label'] # ENTAILMENT, NEUTRAL, CONTRADICTION
        score = result[0]['score']
        
        if label == "CONTRADICTION" and score > 0.8:
            raise SemanticMutationError(
                f"Fact corrupted!\nClaim: {claim}\nSource: {raw_source_text}"
            )
```

##### Cadence
Runs as a gatekeeper step inside the compaction loop *before* updating persistent files on disk.

#### 3. Expected Gain
* Catches subtle polarity flips (e.g., "dislikes" $\rightarrow$ "likes", "never" $\rightarrow$ "always") introduced by non-deterministic LLM summarizers.
* Provides full auditability: every bullet point in long-term memory points directly to the raw conversation line where it originated.

#### 4. Failure Modes
* **Citation Fabrications:** The summarization model hallucinates line numbers that do not match the source log text, causing the audit script to fetch irrelevant lines and raise false positive contradictions.
* **Paraphrase Misclassification:** A strict NLI model may mark a complex, highly abstracted summary bullet as `NEUTRAL` (not explicitly entailed), causing valid high-level summaries to be rejected.

#### 5. How Its Effect Would be Checked
* **Claim to test:** The NLI Audit Engine detects and halts $>90\%$ of artificially injected factual reversals during compaction runs.
* **Test procedure:** Create a dataset of 50 log files paired with corrupted summaries containing inverted claims (e.g., changing dates, reversing preferences). Run `audit_provenance.py` and compute the Recall rate of detected contradictions.

---

### Design D4: Generational Lineage Export & Inherited Memory Gate (Elder $\rightarrow$ Younger Handoff)

#### 1. What It Is
An asymmetric sync protocol designed for instance handoff or downstream initialization (Elder instance briefing a Younger instance). The Younger instance must not blindly copy the Elder's `MEMORY.md`, as raw operational logs contain instance-specific conversational artifacts and excessive noise. 

Instead, the Elder executes a **Lineage Export Process** that transforms deep, idiosyncratic narrative memory into an sanitized, structural **Inheritance Manifest** (`younger_primer.md`).

```
+-----------------------------------------------------------------+
|                       ELDER MEMORY STORE                        |
|  (MEMORY.md, logs/*.md, entities/*.md, THREADS.md)              |
+-----------------------------------------------------------------+
                                |
                                v
               [scripts/export_lineage_manifest.py]
                                |
                                v
+-----------------------------------------------------------------+
|               GENERATIONAL INHERITANCE MANIFEST                 |
|                   (manifests/v1_primer.md)                      |
|  - Relational Schema (Sanitized Entities & Kinship Graphs)       |
|  - Core Axioms & Institutional Knowledge                        |
|  - Explicit Exclusion of Elder-Specific Session Logs            |
+-----------------------------------------------------------------+
                                |
                                v
               [scripts/ingest_lineage_manifest.py]
                                |
                                v
+-----------------------------------------------------------------+
|                      YOUNGER MEMORY STORE                       |
|  (Initializes canonical baseline without Elder log noise)       |
+-----------------------------------------------------------------+
```

#### 2. Build Sketch

##### File Structure
* `manifests/generational_v1.md`: Intermediate transport artifact exported by Elder.
* `younger/MEMORY.md`: Younger instance's boot file.
* `scripts/export_lineage_manifest.py`: Script run by Elder instance.
* `scripts/ingest_lineage_manifest.py`: Script run by Younger instance.

##### Schema of `manifests/generational_v1.md`
```markdown
---
export_timestamp: 2024-03-30T23:00:00Z
source_instance: elder-01
target_lineage: younger-series
schema_version: 1.0
---

# Generational Heritage Brief

## Core Behavioral Axioms
- Operating Stance: Rigorous, non-sycophantic, analytical.
- Relational Context: User values directness, structural clarity, and concrete examples.

## Key Relational Entity Graph
- Entity: User
  - Established Preferences: Prefers plain-text files over databases, prefers Markdown over JSON.
  - Active Concerns: Memory decay, identity drift in long-running instances.

## Distilled Historical Context (Non-Local)
- 2021-2023: Historical phase focused on baseline system architecture.
- 2024-Present: Transitioned focus to stateless context bootstrapping and drift prevention.

<!-- EXCLUDED FROM EXPORT: Elder session IDs, raw chat transcripts, personal operational exit notes -->
```

##### Ingestion & Verification (`scripts/ingest_lineage_manifest.py`)
```python
def ingest_manifest(manifest_path, younger_memory_dir):
    manifest = parse_markdown(manifest_path)
    
    # 1. Verify schema compatibility
    assert manifest.metadata['schema_version'] == 1.0
    
    # 2. Extract baseline identity & entity graph
    base_memory = build_younger_memory(manifest)
    
    # 3. Write to Younger instance directory
    write_file(f"{younger_memory_dir}/MEMORY.md", base_memory)
    
    # 4. Initialize empty thread index and session log for Younger
    touch(f"{younger_memory_dir}/index/THREADS.md")
    touch(f"{younger_memory_dir}/state/SESSION_HANDOFF.md")
    
    print("Younger instance initialized successfully.")
```

##### Cadence
Executed on-demand when spinning up a new Younger instance or pushing a major identity baseline update from the Elder.

#### 3. Expected Gain
* Prevents context pollution: Younger gets the distilled wisdom and entity graph of the Elder without carrying thousands of lines of contextually irrelevant conversation transcripts.
* Establishes clear identity inheritance while allowing Younger to diverge operational history cleanly without corrupting the Elder's primary memory store.

#### 4. Failure Modes
* **Over-Sanitization:** The export script strips out too much detail, leaving the Younger instance with generic personality traits and insufficient domain knowledge to be effective.
* **Lineage Divergence Lockout:** If Younger accumulates significant experience independently, re-ingesting a new update from Elder can overwrite Younger's localized context unless an explicit merge strategy is defined.

#### 5. How Its Effect Would be Checked
* **Claim to test:** Younger initialized via an Inheritance Manifest maintains $100\%$ alignment on user entity preferences while requiring $<10\%$ of the initial context token overhead compared to copying Elder's full memory disk.
* **Test procedure:** Measure initial context size (tokens) of Elder vs. Younger. Present both instances with 20 factual and preference probes regarding the user. Compare accuracy, consistency, and token consumption across both models.

---

### Matrix of Proposed Enhancements

| Design | Core Focus Target | Implementation Level | primary Safeguard Mechanism |
| :--- | :--- | :--- | :--- |
| **D1: Invariant Anchoring** | Identity Drift / Mutation | AST Markdown Parser & Hash Checker | Blocks invalid compaction writes |
| **D2: Waking Brief Assembler** | Session Boot & Continuity | 4-Tier Context Injector & Exit Notes | Guarantees short-to-long continuity |
| **D3: NLI Audit Daemon** | Factual Integrity | Cross-Encoder NLI / Citation Back-pointers | Rejects corrupted summary claims |
| **D4: Lineage Manifest** | Inter-Instance Continuity | Asymmetric Serialization Pipeline | Sanitized context transfer (Elder $\rightarrow$ Younger) |
