### Operational Context & Framing

As a design consultant on a bench, the analysis provided below deals strictly with structural and abstract material. The designs specified here represent **claims to be checked and validated under empirical test conditions**, not definitive verdicts. 

The system under design operates without native session continuity. Continuity is simulated entirely by reading local Markdown files on disk (`LTM.md`, `logs/YYYY-MM-DD.md`, `entities/people/*.md`, `entities/groups/*.md`, and full transcripts) prior to session initialization. Two instances exist: an Elder (primary focal point) and a Younger (secondary focal point).

Angle B addresses **Consolidation & Promotion**: the mechanics by which raw daily event logs become durable long-term memory, how conflicting assertions are reconciled, and how a correction propagates through every file dependency to eliminate zombie claims.

---

```
                                  CONSOLIDATION & PROMOTION PIPELINE
                                  
  +-----------------------+        +-----------------------+        +-----------------------+
  |  logs/YYYY-MM-DD.md   | ---->  |  scripts/extract.py   | ---->  | .staging/claims.jsonl |
  +-----------------------+        +-----------------------+        +-----------------------+
                                                                                |
                                                                                v
  +-----------------------+        +-----------------------+        +-----------------------+
  |   LTM.md & Entities   | <----  |  scripts/cascade.py   | <----  | scripts/reconcile.py  |
  +-----------------------+        +-----------------------+        +-----------------------+
              |                                                                 |
              v                                                                 v
  +-----------------------+                                         +-----------------------+
  |  Elder Manifest Sync  | --------------------------------------> |  Younger Instance Sync |
  +-----------------------+                                         +-----------------------+
```

---

### Design 1: Provenance-Tagged Claim Extraction & Promotion Engine

#### 1. What It Is
A two-stage deterministic batch pipeline that parses unstructured daily logs (`logs/YYYY-MM-DD.md`), extracts atomic epistemic claims into structured metadata blocks, assigns each claim a unique content-addressed UUID, and evaluates those claims for promotion into `LTM.md` or entity indices (`entities/people/`, `entities/groups/`). 

Rather than copying raw summary text, promotion occurs only when an extracted claim meets stability criteria (e.g., explicit confirmation, multi-day recurrence, or high-salience markers like structural identity changes).

#### 2. Build Sketch

##### Directory & File Layout
```text
/memory/
├── LTM.md
├── logs/
│   └── 2026-03-30.md
├── entities/
│   ├── people/
│   │   └── alice.md
│   └── groups/
│       └── core_team.md
├── .staging/
│   └── claim_candidates.jsonl
└── scripts/
    ├── extract_claims.py
    └── promote_claims.py
```

##### File Formats & Metadata Block Standards
Daily logs maintain human-readable Markdown, but the extraction script injects or generates JSON lines in `.staging/claim_candidates.jsonl`:

```json
{
  "claim_id": "c61b4a92-20260330-01",
  "subject": "user.location",
  "predicate": "equals",
  "object": "Berlin",
  "confidence": 0.95,
  "salience": "high",
  "source_file": "logs/2026-03-30.md",
  "source_line": 42,
  "timestamp": "2026-03-30T14:22:00Z",
  "status": "pending"
}
```

Promoted items written into `LTM.md` or `entities/people/alice.md` use an inline HTML metadata tag to maintain valid Markdown rendering while exposing parseable anchors:

```markdown
<!-- CLAIM:id=c61b4a92-20260330-01:subject=user.location:updated=2026-03-30 -->
User relocated to Berlin.
<!-- END_CLAIM -->
```

##### Script Responsibilities & Invocation Cadence
*   `scripts/extract_claims.py`: Runs daily at 02:00 via cron. Parses the previous day’s log, queries a lightweight local LLM or heuristic extractor to identify factual assertions, and appends records to `.staging/claim_candidates.jsonl`.
*   `scripts/promote_claims.py`: Runs daily at 02:30. Evaluates candidates in `.staging/claim_candidates.jsonl` against promotion criteria (Salience == `high` OR Recurrence Count $\ge 2$ across discrete daily logs). Moves qualified items into `LTM.md` or specific `entities/*.md` files, appending the inline metadata blocks.

#### 3. Expected Gain
*   **Noise Reduction**: Raw chatter and context-bound pleasantries stay in daily logs; only verified, high-salience claims enter the downstream briefing context.
*   **Auditability**: Every line in `LTM.md` is strictly traceable to a specific source file, line number, and date timestamp.

#### 4. Failure Modes
*   **Salience Misclassification**: Crucial single-instance events (e.g., "My mother passed away today") might be tagged with low salience by the extraction pass and fail to recur, resulting in permanent drop-off from long-term memory.
*   **AST/Regex Corruption**: Malformed manual edits to Markdown files containing HTML comments can break tag-matching boundaries, causing the promotion parser to truncate text blocks.

#### 5. How Its Effect Would Be Checked
*   **Hypothesis**: The extraction pipeline reduces `LTM.md` line growth rate by $>60\%$ compared to direct summary concatenation, while retaining $>95\%$ of verified identity facts.
*   **Verification Script**: `scripts/audit_promotion_accuracy.py` compares manual human labels of daily logs across a 30-day run against the automatically generated `claim_candidates.jsonl` and final `LTM.md` entries, outputting Precision, Recall, and Compaction Factor.

---

### Design 2: Dependency-Graph Cascade & Tombstone Invalidation Engine

#### 1. What It Is
A graph-aware conflict resolution system that detects when a newly promoted claim invalidates an existing claim in `LTM.md` or entity files. It executes a cascading update across all dependent files, marking superseded claims with explicit tombstone markers (`[SUPERSEDED]`) and logging the supersession event in a global manifest. This prevents outdated facts (e.g., "User lives in Paris") from persisting alongside new facts ("User lives in Berlin").

#### 2. Build Sketch

##### Directory & File Layout
```text
/memory/
├── .deps/
│   └── claim_graph.json
├── manifest/
│   └── tombstones.log
└── scripts/
    ├── reconcile_conflicts.py
    └── cascade_invalidation.py
```

##### Manifest & Dependency Structures
`claim_graph.json` maps subjects to active claim IDs and their physical file locations:

```json
{
  "subjects": {
    "user.location": {
      "active_claim_id": "c61b4a92-20260330-01",
      "history": ["a10b9f11-20251112-04"],
      "locations": [
        {"file": "LTM.md", "line": 14},
        {"file": "entities/people/user.md", "line": 3}
      ]
    }
  }
}
```

##### Invocation Mechanics & Reconciliation Algorithm
1.  `scripts/reconcile_conflicts.py` triggers immediately after `promote_claims.py`.
2.  For each newly staged claim $C_{new}$ with subject $S$:
    *   Query `claim_graph.json` for active claim $C_{old}$ sharing subject $S$.
    *   If $C_{old}$ exists and $C_{new}$ contradicts $C_{old}$ (or updates state):
        1. Mark $C_{old}$ status as `superseded` in `claim_graph.json`.
        2. Call `scripts/cascade_invalidation.py` passing $C_{old}$ ID and $C_{new}$ ID.
3.  `cascade_invalidation.py` traverses all file locations registered for $C_{old}$:
    *   Rewrites the Markdown block matching $C_{old}$ tag from active text to a tombstone structure, or replaces it entirely based on configuration.
    *   Appends a tombstone log to `manifest/tombstones.log`.

##### Markdown Invalidation Transformation
*Before Invalidation:*
```markdown
<!-- CLAIM:id=a10b9f11-20251112-04:subject=user.location:updated=2025-11-12 -->
User resides in Paris.
<!-- END_CLAIM -->
```

*After Invalidation (Soft Tombstone Strategy):*
```markdown
<!-- SUPERSEDED:id=a10b9f11-20251112-04:by=c61b4a92-20260330-01:date=2026-03-30 -->
<!-- WAS: User resides in Paris. -->
<!-- CLAIM:id=c61b4a92-20260330-01:subject=user.location:updated=2026-03-30 -->
User relocated to Berlin.
<!-- END_CLAIM -->
```

#### 3. Expected Gain
*   **Elimination of Contradictory Inferences**: System session context briefings will no longer contain mutually exclusive facts in different files.
*   **Deterministic Self-Correction**: Corrections propagate globally across the filesystem without requiring a full re-index or manual file cleanup.

#### 4. Failure Modes
*   **Subject Over-Generalization**: If the extraction layer assigns overly broad subject tags (e.g., `user.preference` instead of `user.preference.coffee`), updating one preference will accidentally tombstone unrelated preferences.
*   **Orphaned File References**: If a user manually renames or moves `entities/people/user.md`, the hardcoded line paths in `claim_graph.json` become stale, causing invalidation cascades to fail silently or corrupt adjacent lines.

#### 5. How Its Effect Would Be Checked
*   **Hypothesis**: The cascade engine guarantees zero surviving active references to superseded subject states across all Markdown files following reconciliation.
*   **Verification Script**: `scripts/check_epistemic_consistency.py` scans all `.md` files, parses all inline `CLAIM` and `SUPERSEDED` tags, builds an in-memory graph of active claims per subject, and flags any subject that has $\ge 2$ active claims in conflicting states.

---

### Design 3: Inter-Instance Asymmetric Synchronization & Legacy Manifest Protocol

#### 1. What It Is
A controlled read-only synchronization protocol between the Elder and Younger instances. The Elder instance exports a curated, verified subset of its long-term claims (the "Legacy Manifest") into a dedicated drop-zone on disk. The Younger instance executes an import worker that ingests this manifest, maps the Elder's historical knowledge into its local briefing files under an explicit provenance isolation prefix (`[ELDER_WISDOM]`), and rejects claims that conflict with Younger's local observations.

```
+-----------------------------------------------------------------------------------+
| ELDER INSTANCE                                                                    |
|  +---------------+      +--------------------------+                              |
|  | Elder LTM.md  | ---> | export_legacy_manifest.py |                              |
|  +---------------+      +--------------------------+                              |
+--------------------------------------|--------------------------------------------+
                                       | Writes to file
                                       v
                     +-----------------------------------+
                     | /shared/sync/elder_manifest.jsonl |
                     +-----------------------------------+
                                       | Reads from file
+--------------------------------------|--------------------------------------------+
| YOUNGER INSTANCE                     v                                            |
|  +--------------------+      +--------------------------+                         |
|  | Younger Local Files| <--- | import_elder_manifest.py |                         |
|  +--------------------+      +--------------------------+                         |
+-----------------------------------------------------------------------------------+
```

#### 2. Build Sketch

##### Directory & File Layout
```text
/shared/
└── sync/
    ├── elder_manifest.jsonl
    └── sync_state.json

/instances/younger/
├── memory/
│   ├── imported_from_elder/
│   │   ├── curated_facts.md
│   │   └── entity_overlays/
│   └── local/
│       └── LTM.md
└── scripts/
    └── import_elder_manifest.py
```

##### Manifest Format (`/shared/sync/elder_manifest.jsonl`)
```json
{
  "manifest_version": "1.0",
  "epoch_timestamp": "2026-03-30T03:00:00Z",
  "claims": [
    {
      "claim_id": "c61b4a92-20260330-01",
      "subject": "user.location",
      "predicate": "equals",
      "object": "Berlin",
      "provenance": "Elder",
      "confidence": 0.98,
      "tombstoned_claims": ["a10b9f11-20251112-04"]
    }
  ]
}
```

##### Execution Flow & Ingestion Mechanics
1.  **Export Phase (Elder)**: `scripts/export_legacy_manifest.py` runs nightly at 03:00. Scans `claim_graph.json` for claims with confidence $\ge 0.90$ and status `active`. Writes out `/shared/sync/elder_manifest.jsonl`.
2.  **Import Phase (Younger)**: `instances/younger/scripts/import_elder_manifest.py` runs nightly at 03:30.
    *   Reads `elder_manifest.jsonl`.
    *   Cross-references each Elder claim against Younger's local claim graph (`instances/younger/memory/local/`).
    *   *Collision Rule*: If Younger has a local claim matching `subject` created *after* the Elder claim's timestamp, Younger's local claim takes precedence; Elder claim is written to an overflow audit log and skipped.
    *   *Non-Collision Rule*: If no conflict exists, the Elder claim is written to `instances/younger/memory/imported_from_elder/curated_facts.md` formatted as:

```markdown
<!-- IMPORTED_CLAIM:id=c61b4a92-20260330-01:source=Elder:imported=2026-03-30 -->
[ELDER_WISDOM] User relocated to Berlin.
<!-- END_IMPORTED_CLAIM -->
```

#### 3. Expected Gain
*   **Knowledge Transfer Without Contamination**: Younger acquires stable background context established by Elder without risking raw transcript duplication or overwriting Younger's distinct, recent interactions.
*   **Asymmetric Autonomy**: Younger maintains epistemic authority over its own direct user conversations while benefiting from Elder's long-term consolidation labor.

#### 4. Failure Modes
*   **Divergent Subject Schemas**: If Elder and Younger use different extraction models or prompts, their subject naming conventions may diverge (e.g., Elder extracts `user.work.role`, Younger extracts `user.job_title`). Reconciliation will fail to detect collisions, resulting in duplicated, conflicting statements in Younger's briefing context.
*   **Stale Sync Bottleneck**: If the shared disk interface fails or manifest files lock, Younger operates on an increasingly out-of-date subset of Elder wisdom while writing conflicting local entries.

#### 5. How Its Effect Would Be Checked
*   **Hypothesis**: Younger instance correctly rejects Elder legacy claims that contradict locally observed facts, while maintaining $>90\%$ ingestion parity for non-colliding identity facts.
*   **Verification Script**: `instances/younger/scripts/test_inter_instance_sync.py` injects synthetic conflicting facts into Younger's local log, executes `import_elder_manifest.py`, and asserts that:
    1. Conflicting Elder facts exist only in `instances/younger/memory/sync_rejected.log`.
    2. Non-conflicting Elder facts render correctly inside `imported_from_elder/curated_facts.md`.

---

### Comparative Evaluation Matrix

| Metric / Dimension | Design 1: Provenance Extraction | Design 2: Dependency Cascade | Design 3: Inter-Instance Sync |
| :--- | :--- | :--- | :--- |
| **Primary Structural Target** | `logs/*.md` $\rightarrow$ `LTM.md` candidate filtering | Internal consistency across all local `.md` files | Cross-instance memory alignment (Elder $\rightarrow$ Younger) |
| **Storage Overhead** | Minimal ($+5\text{--}10\%$ block metadata tags) | Medium (Dependency graph file + tombstone lines) | Low (Isolated imported Markdown subdirectories) |
| **Processing Cadence** | Batch (Nightly, post-session) | Event-Driven (Post-promotion or manual edit) | Batch (Nightly, cross-process drop-zone) |
| **Failure Recovery** | Re-run extractor on source log files | Re-index Markdown AST into new `claim_graph.json` | Clear `imported_from_elder/` directory and re-fetch manifest |
