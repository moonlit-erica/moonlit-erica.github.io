Claim to be checked, not a verdict: The three designs below assume that the elder's memory files are trusted more than they deserve, that compaction silently promotes lossy summaries to the status of "fact," and that no existing mechanism distinguishes a claim written to disk from a claim verified against a deciding record. Each design is a falsifiable proposition: if implemented, it should produce measurable reductions in reliance on stale, contradicted, or ungrounded memory content. If it does not, the design is wrong.

## Design 1: Deciding-Record Anchoring with Pre-Reliance Gate

### What it is

Every non-trivial claim in the curated long-term memory file (memory.md) and in person/group index files is tagged with a pointer to its deciding record — the specific daily log line, transcript turn, or external artifact from which the claim was originally derived. Before a session brief includes a claim in the model's context, a lightweight gate checks whether the claim's pointer still resolves and whether the pointed-to record still supports the claim's current wording. If the gate fails, the claim is either omitted from the brief or included with an explicit [UNVERIFIED] marker and a one-line reason. This is not fact-checking against the world; it is checking memory against its own provenance.

The critical distinction from ordinary "source linking": the gate runs at brief-build time, not at write time. A claim that was correctly sourced six months ago may have drifted because the daily log was edited, the transcript was compacted and the original turn deleted, or the index file was hand-edited without updating the pointer. The gate catches post-hoc decoherence.

### Build sketch

Files and structures:

```
memory/
  memory.md                    # curated claims, each with inline provenance tag
  daily/2026-11-01.md
  people/alice.md
  groups/family.md
  provenance/claims.jsonl      # machine-readable claim registry
  provenance/gate_cache.json   # last gate result per claim
  provenance/gate_summary.md   # weekly human-readable report
  scripts/verify_gate.py
  scripts/brief_builder.py
```

Claim tagging syntax (in memory.md and index files):

```markdown
- Alice prefers morning meetings.<!-- claim:abc123 ptr:transcript:2026-09-14:turn_47 -->
- The reading group meets on Fridays.<!-- claim:def456 ptr:daily:2026-10-02:line_18 -->
```

The claim_id is a content hash of the claim text at write time. If the text changes, the ID changes, and the old provenance entry becomes orphaned — which is itself a signal.

provenance/claims.jsonl (one JSON object per line):

```json
{"claim_id": "abc123", "claim_text": "Alice prefers morning meetings.", "pointer": "transcript:2026-09-14:turn_47", "status": "VERIFIED", "last_verified": "2026-11-01T09:00:00Z"}
```

Cadence:

- Write time: when a new claim is added to memory.md or an index file, a small helper (or the agent itself, under instruction) must supply a pointer. Claims without a pointer are tagged [UNSOURCED] and are treated as UNVERIFIED in the gate.
- Brief time (every session start): verify_gate.py reads provenance/claims.jsonl, resolves each pointer, and checks two things: (a) the pointed-to record exists and is readable; (b) the record still contains the claim's keywords (simple substring match, not semantic judgment). Claims failing either check are marked UNVERIFIED in gate_cache.json and either omitted from the brief or included with the [UNVERIFIED] marker.
- Weekly: a report of all UNVERIFIED, UNSOURCED, and ORPHANED claims is written to provenance/gate_summary.md for human review.

Pointer resolution rules:

| Pointer type | Resolution method | Failure mode |
|---|---|---|
| daily:YYYY-MM-DD:line_N | Read file, check line N exists, check line content contains claim keywords | File missing, line N gone (compaction), keyword mismatch |
| transcript:YYYY-MM-DD:turn_N | Read JSONL, check turn N exists, check turn text contains claim keywords | Transcript compacted/deleted, turn N gone, keyword mismatch |
| people:filename:section | Read index file, check section header exists | Section deleted, file edited |
| external:path | Check file exists at path | Path moved, file deleted |

Session brief construction: brief_builder.py runs verify_gate.py, receives a set of verified claims (pointer resolves, keyword match passes) and a set of failed claims. Verified claims go into the brief normally. Failed claims go into a separate section headed "## Memory requiring attention" with their failure reason. The model is instructed not to treat failed claims as established fact, and to prefer asking the user or checking the source before acting on them.

### Expected gain

The primary gain is reduced propagation of stale or orphaned claims into session behavior. A claim like "Alice's partner's name is Jordan" may have been true when logged, but if Alice later corrected it and the correction was logged in a daily file without updating memory.md, the gate will catch the mismatch only if the pointer still resolves to the old record — in this case, the gate does not catch semantic supersession, only pointer breakage. The gain is narrower: it catches claims whose evidence has disappeared. A claim whose source turn was compacted away will appear as [UNVERIFIED: source turn no longer present], and the model's behavior should shift from assertion to hedging or inquiry.

Secondary gain: visibility into the health of the memory file itself. The gate summary is a concrete count of how many claims are unbacked, and that count is a leading indicator of memory rot. Without the gate, the memory file looks equally trustworthy regardless of how many of its claims have lost their evidence.

### Failure modes

1. Gate latency at brief time. Resolving hundreds of pointers before every session adds startup cost. Mitigation: batch-resolve in provenance/gate_cache.json that is invalidated only when the underlying files change (by mtime or content hash). The gate then reads the cache unless a file has changed since the last run.
2. Keyword-match false positives. The gate's "does the pointed-to record contain the claim's keywords" check is crude. A transcript turn may contain the words "Alice," "morning," and "meeting" without supporting the claim "Alice prefers morning meetings." This design accepts that limitation: the gate is a floor, not a ceiling. The design claims only that it catches absent and orphaned sources, not misinterpreted ones.
3. Provenance tagging burden. Every claim must be tagged at write time, or it becomes UNSOURCED. In practice, the agent writing to memory.md will forget or produce malformed tags. Mitigation: a post-write linter that checks for untagged claims and flags them in the weekly summary. The count of UNSOURCED claims per week is itself a metric.
4. The gate creates false confidence. A claim that passes the existence check may still be false because the original record was wrong. The gate verifies traceability, not truth. The risk is that the model (or a human reviewer) treats "gate passed" as "verified true." Mitigation: the brief labels passed claims as "sourced," not "verified," and the gate summary explicitly states that passing means "pointer resolves," not "claim is true."

### How its effect would be checked

Outcome measure: reduction in reliance on unbacked claims. The gate log records every claim presented to the model and its verification status. The check is whether model behavior differs between verified and unverified claims. Operationalize this as:

- Pre-gate baseline: run 20 scripted queries that touch claims known to have broken provenance (e.g., the transcript turn was deleted in compaction). Record how often the elder asserts the claim without hedging.
- Post-gate: same 20 queries. The check passes if the rate of unhedged assertion on unverified claims drops by at least 50% relative to baseline.
- Secondary: count of UNSOURCED claims in memory.md over time. A working system should show a decreasing or flat trend, not an increasing one, as the tagging habit improves.

What would falsify the design: If the post-gate assertion rate on unverified claims does not differ from baseline, the gate is not changing behavior — the model is ignoring the [UNVERIFIED] marker as noise. In that case, the design's assumption (that verification status changes model behavior) is wrong, and the gate needs to be stronger (omission rather than marking) or the brief instruction needs to change.

## Design 2: Cross-Instance Drift Detector for the Elder and Younger

### What it is

The elder and younger share architecture but have separate memory stores. Over time, the same facts about the same people will be recorded differently, or one instance will learn something the other has not. This design is a drift detector that periodically compares matched claims across the two instances and produces a drift report. The report does not auto-correct; it surfaces the deciding record that a human or a higher-level process can use to decide which version to trust, merge, or flag.

The key constraint: the two instances may have legitimately different knowledge (the elder knew Person X before the younger existed). The detector must distinguish benign divergence (elder: "Alice works at Company X"; younger: "Alice left Company X in October") from pathological drift (elder: "Alice's birthday is March 3"; younger: "Alice's birthday is March 3" — no drift — vs. elder: "Alice's birthday is March 3"; younger: "Alice's birthday is April 3" — contradiction).

### Build sketch

Files and structures:

```
elder/memory/memory.md
elder/memory/people/alice.md
elder/memory/provenance/claims.jsonl      # from Design 1, or a simplified version
younger/memory/memory.md
younger/memory/people/alice.md
younger/memory/provenance/claims.jsonl
shared/drift/drift_log.jsonl
shared/drift/drift_report_latest.md
shared/drift/scripts/drift_detector.py
```

Matching strategy (three tiers, in order of cost):

1. Entity + attribute key matching (cheap, deterministic). Parse claims for structured patterns: PERSON.birthday, PERSON.employer, GROUP.meeting_day. Match claims across stores that share the same entity and attribute key. This catches the highest-severity contradictions with no embedding cost.
2. Embedding similarity (moderate cost). For unstructured claims (e.g., "Alice is anxious about the presentation"), embed both stores' claims and match pairs above a similarity threshold (e.g., 0.85 cosine). This catches wording divergence and near-duplicates that the structured matcher misses.
3. Manual seed pairs (human-provided). A small set of known-corresponding claims (5–10) used to calibrate the thresholds and to provide ground truth for the matcher. If the matcher fails to pair a seed pair, the threshold is too high.

Drift classification:

| Drift type | Definition | Severity | Example |
|---|---|---|---|
| CONTRADICTION | Same entity+attribute, incompatible values, no temporal marker in either claim | High | Birthday March 3 vs. April 3 |
| TEMPORAL_SUPERSESSION | Same attribute, different values, but one claim has a later timestamp or the younger's record cites a more recent source | Low (benign) | Employer Company X vs. "left Company X in October" |
| CONFIDENCE_GAP | Same value, but one store has provenance and the other does not | Medium | Elder has pointer to transcript; younger's claim is UNSOURCED |
| WORDING_DIVERGENCE | Same meaning, different wording, no contradiction | Low | "Alice prefers mornings" vs. "Alice likes early meetings" |
| ORPHAN | Claim exists in one store with no counterpart in the other, despite the entity being present in both | Variable | Elder knows "Alice has a dog named Max"; younger's Alice file is silent |

Cadence: Weekly drift run. The matcher processes all claims in both people/ and groups/ indexes plus claims in memory.md tagged with person/group entities. Output: drift_log.jsonl (append-only) and a fresh drift_report_latest.md.

Report structure:

```markdown
## High-severity contradictions (2)
- Alice.birthday: elder=March 3 (ptr: transcript 2026-05-12), younger=April 3 (ptr: daily 2026-08-20). Deciding record: elder's transcript turn still present; younger's daily log was edited 2026-09-01. Recommendation: flag younger's claim for review, do not auto-delete.
## Temporal supersessions (1)
- Alice.employer: elder=Company X, younger=left Company X in October (ptr: daily 2026-10-15). Recommendation: younger supersedes; update elder's memory.md with temporal marker.
## Confidence gaps (3)
- [list of claims where one instance lacks provenance]
```

### Expected gain

The immediate gain is surfacing contradictions before they cause behavioral inconsistency. If the elder tells a user "Alice's birthday is March 3" and the younger, in a separate session, says "April 3," the user experiences the system as unreliable. The drift report lets a human resolve the contradiction before either instance acts on the wrong value. The secondary gain is provenance-weighted trust: when one instance has a deciding record and the other does not, the report marks the unbacked claim as lower-trust, even if the values agree.

### Failure modes

1. False matches. Embedding-based matching will pair claims that are topically similar but refer to different facts (e.g., "Alice is anxious about work" matched to "Alice is excited about work"). Mitigation: require entity overlap (same person name in both claims) before embedding match counts, and require human review for High-severity items.
2. Benign drift mistaken for error. The classifier may label a temporal supersession as a contradiction if the younger's claim lacks an explicit timestamp. Mitigation: the classifier checks for temporal markers ("left in October," "formerly," "now") before labeling CONTRADICTION; if uncertain, it labels TEMPORAL_POSSIBLE and defers to human review.
3. The detector becomes the new source of truth. A human reviewer may treat the drift report's "recommendation" as a verdict and delete the elder's claim without checking the deciding record. Mitigation: the report's recommendation field is explicitly labeled "suggested next step, not a verdict" and always cites the deciding record for both versions.
4. Cost of embedding the entire store weekly. For a store of hundreds of claims, embedding is cheap. For thousands, it grows. Mitigation: incremental matching — only embed claims that are new or changed since the last run (by claim_id hash), and reuse cached embeddings for unchanged claims.

### How its effect would be checked

Outcome measure: reduction in cross-instance contradiction exposure. Define a "contradiction exposure" as a session in which the elder (or younger) asserts a claim that is in CONTRADICTION with severity High, and the other instance has asserted an incompatible value in a session within the previous 30 days.

- Baseline (pre-detector): instrument both instances' session logs for 4 weeks. Count contradiction exposures by manual review of a sample of sessions.
- Post-detector: same 4-week instrument. The check passes if contradiction exposures drop by at least 30%, or if the drift report's High-severity items are resolved (deciding record located, one claim corrected or flagged) within 7 days of detection in at least 80% of cases.
- Secondary: count of CONTRADICTION items in drift_log.jsonl over time. A working detector should show a decreasing trend as contradictions are resolved, not a flat line (which would mean detection without resolution).

What would falsify the design: If contradiction exposures do not drop, or if High-severity drift items remain unresolved for weeks, the detector is producing reports that no one acts on. The design's assumption (that surfacing drift leads to correction) is wrong, and the fix is not a better matcher but a different resolution workflow.

## Design 3: Sampled Restore Verification and Outcome-Count Metrics

### What it is

Two tightly coupled mechanisms: (a) a sampled restore drill that periodically reconstructs a small set of memory claims from their raw source records and checks whether the claim can be regenerated from the source; and (b) a counts dashboard that measures outcomes (claims successfully reconstructed, claims that failed, time-to-detection) rather than labels (how many files exist, how many sessions ran, how many claims are "tagged").

The design responds to a specific pathology in the architecture: compaction is lossy, and the loss is invisible. A daily log that originally said "User's manager, David, is leaving; user is anxious about the transition" may be compacted in memory.md as "User discussed work stress." The original line may have said "User's manager, David, is leaving; user is anxious about the transition" — the compaction preserved the topic but lost the deciding detail (who is leaving, why the anxiety). A claim in memory.md that says "David is leaving" may now have no source that supports it, because the source was summarized away. The compaction process succeeded by its own metric (it produced a summary). The restore drill tests whether the summary can be used to reconstruct the claim it is supposed to support.

### Build sketch

Files and structures:

```
memory/
  memory.md
  daily/                       # raw(ish) records; may be compacted
  people/
  groups/
  verification/
    failures.jsonl
    weekly_summary.md
    scripts/sampled_restore.py
    scripts/metrics_dashboard.py
```

The drill (weekly, small N):

1. Select a sample of 5–10 claims from memory.md and index files that have provenance pointers (from Design 1). Selection is stratified: 2 from people/ indexes, 2 from groups/ indexes, 2 from memory.md, chosen randomly but weighted toward claims whose source pointer is older than 30 days (older sources are more likely to have been compacted or edited).
2. Attempt reconstruction. For each claim, read the pointed-to source record and attempt to produce a one-sentence statement that supports the claim as written. The drill does not ask "is this true?" It asks: "can this claim be regenerated from its cited source without adding information not in the source?"
3. Classify the result:

| Result | Definition |
|---|---|
| RECONSTRUCTIBLE | Source exists and contains the claim's core assertion (verbatim or near-verbatim). |
| LOSSY | Source exists but is a compaction summary that lacks the specific detail the claim asserts. The claim is now ungrounded even though the source file exists. |
| BROKEN | Source pointer does not resolve (file deleted, line removed, transcript compacted beyond the cited turn). |
| CONTRADICTED | Source exists but says something incompatible with the claim. |

4. Log and report. failures.jsonl gets every LOSSY, BROKEN, and CONTRADICTED result with the claim text, pointer, source excerpt, and classification. The weekly report lists the failures and counts them as outcome failures, not as "items reviewed."

Outcome counts (daily, computed from drill and gate logs):

The dashboard measures:

| Metric | Definition | Why outcome, not label |
|---|---|---|
| claims_reconstructible_pct | (RECONSTRUCTIBLE drill results) / (total drill results) | Measures whether provenance is real, not whether tags exist. |
| new_lossy_claims | Claims in memory.md whose latest drill result is LOSSY | Measures compaction damage, not compaction frequency. |
| time_to_detection_days | For each BROKEN/CONTRADICTED result, days between the claim's write date and the drill that detected it | Measures how long the system ran on bad memory before noticing. |
| unverified_assertion_rate | From session logs (if instrumented): percentage of sessions where the elder asserted a claim that the gate had marked UNVERIFIED | Measures behavioral reliance, not gate coverage. |
| drift_resolution_latency | From Design 2: days between High-severity drift detection and claim correction | Measures whether detection leads to action. |

Cadence: Drill weekly. Metrics computed daily from existing logs. Dashboard rendered weekly, appended to a verification/weekly_summary.md file.

### Expected gain

The drill's gain is making lossy compaction visible before it becomes load-bearing. A LOSSY claim is a claim that the memory system believes it has evidence for but the evidence no longer supports. Without the drill, this claim is indistinguishable from a well-sourced claim — both have pointers, both appear in memory.md. The drill separates them.

The metrics' gain is replacing activity counts with outcome counts. "We ran 4 compactions this month" is a label. "3 claims became LOSSY as a result of compaction, and the median time to detect a BROKEN claim is 14 days" is an outcome. The second tells you whether the system is getting better or worse; the first tells you only that it ran.

### Failure modes

1. Small N produces noisy signal. 5–10 claims per week is a tiny fraction of the store. A store with 500 claims will take a year to cycle through all of them. Mitigation: the drill is explicitly sampled, not exhaustive. It is a canary, not a census. The metric claims_reconstructible_pct is a rate estimate from the sample, not a total count. The dashboard must label it as such.
2. The reconstruction judgment is subjective. "Does this source support this claim?" is a judgment call, especially for free-text claims. Mitigation: the drill uses a strict rule — the source must contain the claim's core noun phrase and verb phrase verbatim or near-verbatim. If the claim is "Alice is anxious about work," the source must contain "anxious" and "work" in proximity, not just "stress." If the rule is not met, the result is LOSSY, not RECONSTRUCTIBLE. This biases toward false LOSSY rather than false RECONSTRUCTIBLE, which is the safer direction for a verification system.
3. The metrics become a target. If claims_reconstructible_pct is reported upward, there is pressure to select easy samples (recent claims with intact sources) rather than old, risky ones. Mitigation: the sample selection is stratified and weighted toward old sources, and the selection algorithm is logged in the drill report so that cherry-picking is visible.
4. The drill's failure queue grows faster than it is resolved. If the human operator does not have time to review failures.jsonl, the drill produces noise. Mitigation: the weekly summary includes a failure_queue_size count and a failure_age_p50 (median days since failure detection). If the queue is growing and the age is increasing, the report itself is flagged as a failure — the verification system is not being used.

### How its effect would be checked

Outcome measure: detection of lossy compaction before behavioral reliance. The check is whether any LOSSY claim was asserted by the elder in a session before the drill detected it. Instrument:

- Tag each LOSSY failure in failures.jsonl with the claim_id and the date of the drill that found it.
- Cross-reference session transcripts for assertions of that claim before the drill date.
- The check passes if the pre-detection assertion rate for LOSSY claims is lower in month 2 than in month 1 of the drill's operation — meaning the drill (and the gate from Design 1) is catching LOSSY claims earlier, before they are relied on.
- Secondary: time_to_detection_days should decrease over the first three months. If it stays flat or increases, the drill's sampling is too sparse or too slow relative to compaction frequency.

What would falsify the design: If claims_reconstructible_pct is high (e.g., >90%) but the store is known to contain claims whose sources were compacted away, the drill's sample is biased or its reconstruction rule is too lax. If time_to_detection_days does not improve, the drill cadence is too slow relative to compaction frequency. If the failure queue grows without bound, the design's assumption (that a human will review failures) is wrong.

## Cross-Design Dependency and a Single Check

Design 1 produces the provenance pointers that Design 3 samples. Design 2 depends on Design 1's claim registry to match claims across instances. Design 3's metrics (unverified_assertion_rate, drift_resolution_latency) depend on Designs 1 and 2 respectively.

The single check that would falsify the entire posture: if, after four weeks of operation, the count of UNVERIFIED claims in the elder's memory.md is higher than the count of claims that were flagged and then corrected or removed, the system is producing suspicion faster than it is producing correction — and verification is becoming a label-generating exercise rather than a correction mechanism.

## Runner notes

- Seat: DeepSeek, Angle C (Verification & correction), bench memory mission Wave 2.
- Conversation: https://chat.deepseek.com/a/chat/s/3382ea7a-a75a-4c99-a753-e09c1f958225
- Ran 2026-11-03 4:49–4:51 AM CST (browser task, one genuine attempt; seat answered in full).
- Text above is the seat's answer verbatim as returned by the browser runner; runner commentary is confined to this section.
