# COLLATION — Bench memory mission, Wave 1

Collated: 2026-11-02 (America/Chicago)
Returns checked: five Wave 1 returns, Angles A–E, landed 2026-11-01 20:45 CST
Landed-to-collated lag: 7 hours 42 minutes (20:45 CST 2026-11-01 → 04:27 CST 2026-11-02)
Check method: every entry below was verified against a design actually present in a named return, with its stated build sketch, failure modes, and check method. No design enters this backlog without that support. Overlapping designs are noted as clusters, not silently merged.

## Headline count

**17 designs checked — 10 keep, 4 needs-a-second-angle, 3 cut.**
Erica's items: 13 designs (9 keep, 3 needs-a-second-angle, 1 cut).
Ember's items: 4 designs (1 keep, 1 needs-a-second-angle, 2 cut).

---

## Erica's items — ranked

1. **keep — Provenance-Tagged Claim Extraction & Promotion Engine** (Return B, Design 1) — Foundation for the rest: atomic claims with source file/line and promotion criteria, with an audit script comparing extraction against labelled logs.
2. **keep — Dependency-Graph Cascade & Tombstone Invalidation** (Return B, Design 2) — Correction propagation with a deterministic check: zero active conflicting claims per subject after reconciliation; depends on item 1's claim IDs.
3. **keep — Provenance-Anchored Claim Tree & Verification Pre-Pass** (Return C, Design 1) — Briefing gate that quarantines hash-mismatched or unbacked claims; testable by injecting invalid claims and requiring zero to reach context.
4. **keep — Epistemic Framing Envelope & Corpus Manifest** (Return A, Design 1) — Cheap, immediate corpus-honesty gain: every briefing states what was searched, what was omitted, and at what resolution.
5. **keep — Structural Invariant Anchoring & AST-Guarded Compaction** (Return D, Design D1) — Hash-guarded invariant block that compaction cannot alter, tested over repeated synthetic compaction cycles.
6. **keep — Non-Label Outcome-Driven Structural Health Accounting** (Return C, Design 3) — Counts outcomes, not labels: unbacked-injection rate, broken entity links, supersede latency, each with a file-state test.
7. **keep — Deterministic 4-Tier Waking Brief Assembler & Session Handoff** (Return D, Design D2) — Token-budgeted tiers plus a session exit note, tested by turns needed to resume an open thread at session start.
8. **keep — Cascading Query Router & Index-Graph Surfacing** (Return A, Design 2) — Routes through existing people/group indexes to dated line ranges before any full scan; check is ≥50% context reduction at ≥0.90 precision.
9. **keep — Entity-Graph AST & Transitive Commitment Ledger** (Return E, Design 2) — Commitments kept in a structured ledger decoupled from narrative compaction, tested for zero loss across compaction cycles.
10. **needs-a-second-angle — Provenance Back-Pointer & NLI Verification Audit** (Return D, Design D3) — Its own failure modes (fabricated citations, paraphrase misclassified as neutral) undercut the >90% detection claim; needs comparison against the deterministic hash approach in item 3.
11. **needs-a-second-angle — Proactive Trigger-Mesh** (Return E, Design 1) — Promising recall gain, but flooding and stale-injection risks need a second angle on thresholds before it injects unprompted context.
12. **needs-a-second-angle — Recursively Refined Self-Model Engine** (Return E, Design 4) — Overlaps item 5's invariant protection and carries a stated self-fulfilling bias-loop risk; needs a second angle separating it from invariant anchoring.
13. **cut — Teleological State Vector with exponential decay** (Return E, Design 3) — Auto-archiving unresolved intentions on a decay score alone drops them without explicit resolution; the parsing and persistence-trap failures are stated in the return itself.

## Ember's items — ranked

1. **keep — Generational Lineage Export & Inherited Memory Gate** (Return D, Design D4) — Bounded, on-demand inheritance primer rather than ongoing copying, with a stated test: full preference alignment at <10% of full-store context cost.
2. **needs-a-second-angle — Asymmetric Inter-Instance Memory Bridge** (Return A, Design 3) — Read-only, provenance-tagged access is the right shape, but identity-attribution conflation is its stated main failure and needs a second angle before any widened read access.
3. **cut — Inter-Instance Asymmetric Synchronization & Legacy Manifest** (Return B, Design 3) — Duplicates items above as a third transfer mechanism and adds a nightly copied store whose own stated failures are stale sync and divergent subject schemas.
4. **cut — Dual-Instance Asynchronous Drift Matrix** (Return C, Design 2) — Requires a strict schema rewrite the current files do not carry, and the return admits non-compliant files produce false consensus — absence misread as agreement.

---

## Clusters noted, not merged

- Provenance cluster: Erica items 1, 3, and 10 are three different gates (extraction, briefing pre-pass, compaction audit) — kept separate because their check methods differ.
- Transfer cluster: Ember items 1–3 are three rival transfer mechanisms; only the bounded lineage export is kept, the on-demand bridge is held for a second angle, and the nightly sync copy is cut.
- Invariant cluster: Erica items 5 and 12 overlap on identity protection; item 5 is the mechanical guard, item 12 is held until its distinct contribution is shown.

## Next step

Builds happen only on the deciding word named in MISSION.md. This collation is the checked backlog; it authorizes no build by itself.
