# BUILD RUN SHEET — free-machinery builds under Erica's GO WITH CONDITIONS
Filed: Mon 2026-11-02, ~15:33 CST, Ember's room. Source verdict: Erica, main seat, checker review of Ember's suggested build order, under Chris's word "if she says go then go." Synthesis: SYNTHESIS.md in this folder.

## Gate 2 fields
- PURPOSE: convert the synthesis's top builds into working token-free machinery, fence first, so the house can get quieter without getting less safe.
- END CONDITION: all four build blocks below landed and verified, or the kill date arrives — whichever first.
- JUDGE: Erica checks (checker seat); Chris is the deciding word above her; Ember builds and supplies counts.
- KILL DATE: 2026-11-15. Work not landed by then stops and needs a fresh word. No roll-over. (Erica condition 1.)

## Scope of the go — exactly this
1. Fence first: watcher-health register, dead-man switch (ONE level only), census, synthetic test wires.
2. De-wrapper in small batches: fixed-text posters first, then script-runners; silent on success, raw failure posted immediately.
3. Completion detector for the bench and collation pipeline.
4. Headroom, Stage 0 only: DUMMY-01 (Harrow Corpus v1) and GRADE-01 (Clerk Grading Suite v1) built; grading suite run per the settled second-account dummy route.

## NOT covered
Backlog items 2 and 5 held until a clean Sunday count AND measured savings; items 6–15 untouched; clerk Stage 1/2 not authorised; out-of-band leg stays named undesigned; nothing here calls the net a safety net.

## Erica's conditions (binding)
1. Every new clock under this go carries REASON / TIME-WHY / CONSTRAINT / REVIEW in its body; a clock binding Chris's attention does not fire until complete. Kill date above binds.
2. De-wrapper conversions re-verify each job's body at conversion time. Inventory classification alone converts nothing. A body showing judgment content is a mismatch reported back, not converted. Checker jobs (chain-verify, review-internal checks) are NOT de-wrapper candidates in this go.
3. Register alarms land where they will be seen: critical wires (journal vault seal, mirror safety) alarm the same day; the rest surface in the Sunday count at the latest.
4. "Clean Sunday count" defined before the fact: every converted job fired per the register, zero unexplained silences, every failure surfaced raw. The gate to items 2 and 5 also needs measured wrapper-turn counts before/after, taken from the register and tallied by Erica. Estimates do not open that gate.
5. DUMMY-01/GRADE-01: dummy content never crosses into any live tree — one-way valve, numbers only. The dummy run changes nothing about the fork account's seeding state beyond the reset-to-blank Chris already accepted.

## Build order and acceptance
- Block 1 (register): every registered wire touches a heartbeat on completion regardless of outcome; register logs positive/negative/error; dead-man check compares heartbeat age to per-wire max staleness with a deliberate-pause state; synthetic fixture fires on schedule per wire; acceptance = a deliberately killed test wire is detected and alarmed, a paused wire is not.
- Block 2 (de-wrapper): batch list written before each batch, each body re-read at conversion; acceptance = converted jobs fire per register with zero unexplained silences through the Sunday count.
- Block 3 (completion detector): expected-N manifest rule (learned from the Wave 4 early-fire), stable size/checksum + sanity checks, atomic pending flag, hard timeout with partial-completion escalation; acceptance = subset landing does not fire, full set fires once, dropped item escalates at timeout.
- Block 4 (dummy): corpus ≥200 units, ≥5 persons, ≥8 topics, ≥30 days, planted traps, ground-truth manifest held outside the clerk's reach, all units watermarked synthetic, fully separate tree/index; grading thresholds per SYNTHESIS.md E1 (50/50, 20/20 with 0 fabrications, 30/30 exact sets, 100% provenance, 0 orphans).

REVIEW: weekly Sunday count, with the mission.
