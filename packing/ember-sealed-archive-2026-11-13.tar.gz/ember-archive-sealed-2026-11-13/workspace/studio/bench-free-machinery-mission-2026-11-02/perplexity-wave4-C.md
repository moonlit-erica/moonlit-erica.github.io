Main angle: make attention scarce, not observation

The upside is not merely cheaper monitoring. It is a change in what the household can afford to notice: continuously watch a broad surface, preserve what changes, and spend model tokens only when something deserves interpretation.

The resulting asymmetry is powerful: thousands of uneventful checks can feed a handful of well-timed judgments. A household no longer needs to choose between “pay an agent to keep looking” and “discover it tomorrow.”

“Free” here means zero model tokens, not zero operating cost. Scripts still consume compute, endpoint quotas, storage, and maintenance. More importantly, cheap detection can create expensive noise unless waking an agent is separately budgeted. The opportunities below are architectural proposals for the supplied setup, not measured savings.

What becomes possible

Opportunity | Mechanical layer | Agent work reserved for | New capability
Continuous completion watches | Track expected return IDs, completion markers, versions, and existing collations | Synthesis and interpretation | Work starts when dependencies are ready, rather than at the next nightly session
Wide opportunity coverage | Watch many endpoints or local signals; filter by explicit thresholds and changes | Decide whether an opportunity is worthwhile | Maintain many low-probability watches that would not justify individual agent patrols
Durable short-lived observations | Save timestamped snapshots when a condition changes | Interpret the captured state later | An opportunity or fault need not remain visible until the agent wakes
Delta-only reading | Track hashes, IDs, timestamps, and changed sections | Read changed material and relevant dependencies | A growing corpus need not require a growing rediscovery prompt
Universal mechanical preflight | Check schemas, required files, references, counts, and declared constraints | Evaluate truth, reasoning, usefulness, and tone | Every deliverable gets a first pass, including low-priority work
Dependency-driven chains | Release the next task when a defined prerequisite commits | Handle each genuinely judgment-bearing stage | Multi-step work progresses unattended without waiting for recurring schedules
Exception-based administration | Compute counts, compare catalogs, track deadlines, and detect missing artifacts | Explain anomalies and choose responses | Routine bookkeeping becomes a persistent background service
Continuous operational proof | Check run receipts and exercise an end-to-end canary | Diagnose failures that survive mechanical recovery | Failures can be noticed before someone needs the system

A useful distinction: a script can establish “all expected artifacts have valid completion receipts,” not “the research is intellectually complete.” Likewise, a deliverable can pass every structural check and still be wrong.

For the audio canary, record exactly what it proves. “The renderer exited successfully,” “an output file appeared,” and “recognizable audio reached the intended endpoint” are different coverage levels. Google’s monitoring guidance distinguishes internal, white-box checks from black-box tests of externally visible behavior; combining them catches failures that either alone can miss. sre

Where the economics compound

A simple planning model is:

Agent-patrol tokens ≈ N × P × D
Mechanically gated tokens ≈ E × J + A

Here:

N: watched subjects.
P: agent patrols per subject.
D: average tokens per discovery session.
E: meaningful events after deduplication and batching.
J: average tokens per event-driven judgment.
A: tokens spent on audits, reconciliation, and escalations.

This is a budgeting model, not a claim that every mechanical check replaces an actual agent session.

The savings compound in several places:

Frequency: increasing mechanical checks from daily to every few minutes does not multiply model usage.

Coverage: adding another watch mainly adds configuration and operational load, rather than another recurring discovery prompt.

Context reuse: immutable manifests and change records let the agent reopen the relevant evidence instead of reconstructing the entire situation.

Fan-in: twenty arrivals can create one “batch ready” wake rather than twenty separate interruptions.

Pipeline depth: each downstream stage can receive a prepared input bundle instead of rediscovering what its predecessor produced.

Error containment: catching a missing file before synthesis avoids both the failed session and the later repair session.

These effects reinforce one another, but they are not independent percentages to multiply together. One avoided session cannot be counted again as avoided polling, avoided discovery, and avoided repair.

The genuinely unfair-looking advantages

1. Broad vigilance without broad attention

A household can maintain a large portfolio of narrow, low-yield watches. Most watches never fire; that is acceptable when silence does not consume model tokens.

The advantage comes from coverage plus selectivity, not from checking everything as fast as possible. Public endpoint limits and access rules still apply.

2. Capture now, decide later

A script can preserve the exact state that triggered a watch, including an expiring offer, transient failure, changed response, or newly completed artifact. The agent then judges a durable evidence package rather than chasing a condition that may have disappeared.

This separates the deadline for observation from the deadline for deliberation.

3. Follow-through without someone remembering

The bench-return example is especially valuable because it closes an administrative gap:

returns committed → batch verified → task durably queued → agent collates → output checked → completion recorded

The important improvement is not simply waking sooner. It is removing “someone must remember the next step” as a dependency.

4. Universal cheap checks, selective expensive review

Run mechanical preflight on every deliverable. Reserve deeper review for consequential work, failed checks, unfamiliar cases, and a sample of apparent successes.

That makes a quality floor affordable without pretending that structural validation establishes correctness.

5. Attention arbitrage

Spend the recovered budget on work that was previously crowded out: competing interpretations, evidence verification, unresolved contradictions, and occasional audits of the automation itself.

The strongest version of this architecture does not eliminate judgment. It buys more judgment per unit of routine work.

1. Proposal engine: can 300 tokens support real approval?

Yes, the saving can be real—but only if the proposal preserves the evidence needed for the particular decision. An agent cannot meaningfully approve an evidence-dependent conclusion from an unsupported summary.

A 300-token payload instead of a 10,000-token discovery prompt represents a 97% reduction in those input tokens, or roughly 33 times less input. It does not establish a 97% reduction in total cost: evidence retrieval, output, retries, audits, and different billing categories still matter.

Separate three kinds of approval

Decision | Can a compact proposal suffice?
“The declared batch is complete; schedule collation” | Often, if completion follows a trustworthy manifest and deterministic checks
“This source supports the proposed conclusion” | Only if the relevant evidence is actually included or retrieved
“This recommendation is sound despite conflicting evidence” | Usually requires broader context; the proposal should be a navigation aid, not a substitute

A hash proves which bytes are being referenced, not whether those bytes support the recommendation.

Make the proposal evidence-carrying

A useful packet contains:

Proposed action and exact target.
Triggering predicate and observed values.
Evidence timestamps, source versions, and immutable references.
Decision-relevant excerpts, with provenance.
Known omissions, failed checks, and conflicting observations.
Expiry and invalidation conditions.
A route to retrieve more evidence or escalate.

If those fields cannot fit honestly into 300 tokens, exceed the target. The token cap must not become an evidence cap.

Fences that prevent rubber-stamping

The following are suggested policies, not universal operating values:

Fence | Practical rule
Rate limits | One pending proposal per task/version; per-agent wake cap; global daily token budget
Duplicate suppression | Repeated detection updates the existing proposal rather than generating another approval
Staleness | Set freshness windows by decision type; a price observation and a static document need different treatment
Version binding | Bind approval to exact evidence versions, target, and action
Execution recheck | Immediately before acting, verify that prerequisites and target state still match; changed material facts invalidate approval
Pruning boundary | Preserve contradictions, uncertainty, provenance, and decision dependencies even when dropping unrelated history
Escalation | Missing evidence, unfamiliar schema, or failed checks permit “retrieve more” or “abstain,” not forced yes/no
Audit | Inspect a sample of accepted and rejected proposals against full underlying records

Keep untrusted source text separate from instructions. A document being summarized should not be able to redefine the approval policy.

This design fails outright when the script cannot reliably identify relevant evidence, the decision depends on omitted relationships, the source is adversarial, or consequences demand a level of verification unavailable in the packet. In those cases, preassembly can still organize discovery; it cannot replace it.

2. Event-driven cascades: absence still requires a clock

You cannot reliably detect “an expected event never happened” with an event graph that has no time source or independent observer.

A timeout is itself a time-generated event. Replace unnecessary agent schedules, not clocks.

Use events for progress and timers for obligations

When a task becomes expected, persist:

Task ID and input version.
Expected producer and output.
Start time and completion deadline.
Last progress heartbeat, where appropriate.
Retry budget and escalation destination.

Then allow either:

completion receipt → advance

or:

deadline expires without valid receipt → investigate or escalate

Heartbeat timeouts and overall deadlines serve different purposes: a heartbeat detects a worker that stops reporting progress; an overall timeout bounds a task that remains alive but never finishes. Published durable-workflow guidance explicitly uses heartbeat timeouts for missing check-ins. aws.amazon

Cover silently failed upstream nodes

A downstream watcher cannot notice work it never learned should exist. Maintain a durable registry of expected obligations, not merely a stream of successful events.

Use three safety nets:

Local deadline checks for known tasks.
A periodic reconciliation sweep comparing expected state, queue state, receipts, and actual artifacts.
An independently checked watchdog receipt or end-to-end canary.

A watchdog on the same stopped host cannot report its own silence. Detection of whole-host failure requires something outside that failure domain; otherwise, accept that failures will only be discovered after the host returns.

Bound event storms before they reach agents

Deduplicate by task, input version, and transition.
Make task creation and completion idempotent.
Coalesce related changes into one pending wake.
Bound queue length, concurrency, fan-out, and cascade depth.
Apply cooldowns or hysteresis to oscillating thresholds.
Retry transient failures with backoff and jitter.
Stop after a bounded number of retries; park failed work for inspection.
Enforce per-workflow and household-wide wake/token budgets.

AWS’s retry guidance emphasizes both idempotency and bounded backoff: retries can otherwise corrupt state or amplify overload. Event-processing guidance also recommends durable queues and dead-letter handling for repeated failures. aws.amazon +1

Finally, “scheduled” is not “finished.” Track separate receipts for queued, started, output committed, and validated. The two-minute delay in the example is a debounce or scheduling choice, not proof of eventual execution.

3. Token accounting: fix the counterfactual before claiming savings

For a small household, start with labeled estimates plus actual usage records. A detailed counterfactual ledger is worthwhile only when it changes decisions enough to repay its maintenance.

The central honesty rule: compare against what the household would credibly have done, not against assigning an agent every operation the script performs.

Keep three accounts separate

Account | Meaning | Appropriate claim
Displaced work | Agent sessions that previously occurred and are now avoided | Estimated avoided usage, grounded in observed history
Expanded service | New monitoring or checking that previously was not performed | Added coverage or capability, not historical cash savings
Improved outcomes | Faster completion, fewer forgotten tasks, fewer faults escaping | Report latency and quality separately from token savings

If a price was previously checked once per day, checking it mechanically 720 times per day does not mean 720 agent checks were saved. At most, the old daily check was displaced; the remaining checks are new coverage.

Pin an honest baseline

Before substantial changes:

Record representative existing session costs and frequencies.
Define a realistic alternative: nightly batch, manual review, agent patrol, or no service.
Freeze that baseline for a reporting period.
Record actual new agent usage, including escalations and audits.
Report assumptions and uncertainty ranges.
Revisit the baseline when workflow or model economics change.

For operational accounting, also distinguish submitted input, cached input where applicable, output, and billed cost rather than treating every token as financially interchangeable.

Do not let an ROI score reward brittle automation. Include maintenance time, missed detections, repair work, false wakes, and consequences of errors. Keep time and money separate unless an explicit conversion assumption is useful.

A sufficient household report

A short weekly or monthly report could contain:

Actual agent usage.
Estimated displaced sessions, with baseline label.
Additional watches and checks now affordable.
False wakes and missed-event incidents.
Median and worst-case completion delay.
Maintenance and recovery time.
Confidence level for savings estimates.

Build a richer ledger only if multiple workflows compete for a meaningful budget, estimates repeatedly mislead, or trustworthy receipts already make accounting nearly automatic. Otherwise, instrument actual work and label counterfactual estimates clearly.

The decision criterion is not “which script claims the most avoided tokens?” It is “which arrangement provides useful, reliable outcomes at acceptable total cost?”

4. Script copying, routing, and carrying: policy decides; machinery executes

The line is between applying an explicit, authorized rule to verified inputs and inventing a meaning-dependent rule.

A script may execute a mechanical move even when an agent made the preceding decision. Conversely, a file operation is not safe merely because it is syntactically simple.

Which moves belong where?

Operation | Safe mechanical scope | Judgment or additional authorization needed
Copy | Copy an immutable artifact to a preauthorized location using verified task metadata | Decide whether sensitive content should reach a new recipient
Route | Select destination from a trusted manifest or fixed mapping | Infer ownership or audience from ambiguous prose
Archive | Create a reversible archive copy, or archive under an established retention rule | Decide that a record has no continuing significance
Rename | Apply a specified naming scheme while preserving identity and references | Invent names that imply conclusions, priority, or status
Deduplicate | Detect byte-identical artifacts; remove redundant disposable copies under policy | Merge similar-but-not-identical records or choose the “authoritative” account
Delete | Remove allowlisted temporary files or regenerable derivatives under retention policy | Destroy primary records or decide that evidence is no longer needed
Update memory | Append receipts or place candidates in a review inbox | Promote a claim into curated memory or replace an established conclusion

Routing metadata must itself be trustworthy. A downloaded file should not be able to declare an arbitrary destination path and have the household obey it.

For primary records, the default should be preservation: no automatic destructive operations, including overwrites disguised as ordinary copies. An agent’s preference alone is not necessarily sufficient authorization for permanent deletion.

Safeguards on the mechanical side

Stage before publishing. Write into a temporary destination, verify completeness and integrity, then expose the final artifact.

Use atomic publication within the supported filesystem boundary. On Linux, rename provides atomic namespace replacement, but it does not work across different mount points. For cross-filesystem transfers, copy into a temporary file on the destination filesystem and publish there after verification. man7

Distinguish visibility from durability. Atomic rename does not by itself establish crash durability. Where durability matters, flush file data and the relevant directory metadata according to platform semantics; Linux documentation explicitly notes that flushing a file does not necessarily flush its directory entry. man7

Prevent overwrite by default. Use unique versioned names or no-replace operations. A collision should produce a visible exception.

Constrain paths and permissions. Restrict source and destination roots, reject traversal, and handle symlinks explicitly. Do not build shell commands by concatenating untrusted filenames.

Verify identity and completeness. Check expected IDs, byte counts, and hashes where appropriate. A hash verifies content identity, not intellectual quality.

Require committed inputs. A file’s existence does not mean its producer finished writing it. Prefer explicit producer commit markers or atomic publication.

Preserve recoverability. Keep primary sources intact until destination verification and any authorized retention transition are complete.

Reconcile orphans. Detect abandoned staging files, destination files lacking receipts, receipts lacking files, and tasks stranded between copy and publication. Recover from current state rather than assuming the last operation completed.

Record minimal provenance. Keep source, destination, task ID, version, checksum, timestamp, and outcome. Avoid copying sensitive contents into logs.

The productive boundary is broad: let scripts carry, count, stage, validate, and route under established rules. Let agents interpret evidence, resolve ambiguity, and propose policy changes. Keep consequential authority separate from both.
