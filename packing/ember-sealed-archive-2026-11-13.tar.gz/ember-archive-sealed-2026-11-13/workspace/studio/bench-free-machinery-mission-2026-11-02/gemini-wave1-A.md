## Executive Architecture: The Deterministic Boundary

In a token-metered household, every agent session ("wake") incurs a base tax: reading system prompts, context memories, recent daily logs, and local state before taking action. A minor 8,000-token context window initialized 48 times a day (every 30 minutes) to check an empty inbox or directory burns ~384,000 tokens/day on baseline context loading alone—costing real currency for zero net work.

The system architecture must enforce a strict separation between **state recognition** (free, deterministic, script-driven) and **state transformation** (metered, semantic, agent-driven).

```
┌─────────────────────────────────────────────────────────┐
│              DETERMINISTIC LAYER ($0.00)                 │
│  Cron / inotifywait / cURL / jq / grep / Regex / SHA256 │
└───────────────────────────┬─────────────────────────────┘
                            │
              Condition Fired (Shape Detected)
                            │
                            ▼
┌─────────────────────────────────────────────────────────┐
│                METERED AGENT LAYER ($$$)                 │
│         LLM Judgment / Synthesis / Ambiguity            │
└─────────────────────────────────────────────────────────┘
```

---

## Non-Mechanical Work: Where Agent Judgment Is Irreplaceable

Before pushing tasks down to the script layer, define what **cannot** be reduced to deterministic rules. The agent layer must be reserved exclusively for:

1. **Semantic Synthesis & Collation:** Merging 10 disparate research returns, resolving contradictions across sources, and summarizing themes.
2. **Ambiguous Intent Resolution:** Parsing a human memo like *"Follow up on that weird charge from Tuesday"* and mapping it to bank log entries and email threads.
3. **Qualitative Evaluation:** Assessing whether a generated output meets subjective standards of tone, clarity, persuasive logic, or strategic alignment.
4. **Unstructured Exception Recovery:** Handling failure states where the recovery path is non-deterministic (e.g., an API returns an unannounced response structure requiring adaptive fallback).

---

## Mechanical Work Audit

### 1. Polling & Arrival Watching

*   **Household Domain:** Watching email inboxes for specific vendor replies, tracking RSS/web feeds for key mentions, and monitoring a dropsFolder for arriving files.
*   **Agent Version Cost:**
    *   *Tokens:* ~10k input tokens per check (System Prompt + Tool Definitions + History). Spun up every 15 mins = 960k tokens/day.
    *   *Latency:* 5–15 seconds per execution spin-up.
    *   *Failure Mode:* Hallucinating that a critical file arrived when only a temporary system file (`.DS_Store` or `.tmp`) is present.
*   **Script Version:**
    *   *Implementation:* Linux `inotifywait` daemon or an IMAP filter script polling via `python-imaplib` every 120 seconds.
    ```bash
    # Watch directory for completed write actions, then fire schedule trigger
    inotifywait -m -e close_write --format '%w%f' ~/dropzone | while read FILE; do
      if [[ "$FILE" =~ \.pdf$ ]]; then
        systemctl start trigger-agent-ingest.service
      fi
    done
    ```
*   **What Is Lost:** Contextual inference of non-standard arrivals (e.g., an email with a typo in the subject line or an arrival dropped in an unmonitored sibling folder).

---

### 2. Completion & Readiness Checking

*   **Household Domain:** Bench research pipelines where multiple sub-tasks dump JSON/markdown outputs into a target directory before collation.
*   **Agent Version Cost:**
    *   *Tokens:* ~15k tokens per polling iteration to read directory listings, parse state JSONs, and calculate if `completed_jobs == total_expected_jobs`.
    *   *Latency:* 10–20 seconds per wake-up.
    *   *Failure Mode:* Early execution (calling collation before a slow worker finishes writing its file payload).
*   **Script Version:**
    *   *Implementation:* Bash script checking for explicit manifest criteria or output count equivalence.
    ```bash
    # Compare count of finished worker payloads against manifest
    EXPECTED=$(jq '.expected_returns' manifest.json)
    ACTUAL=$(ls -1 return_batch_*.json 2>/dev/null | wc -l)

    if [ "$ACTUAL" -ge "$EXPECTED" ]; then
      echo "Batch complete. Scheduling agent..."
      at now + 2 minutes -f ./wake_collation_agent.sh
    fi
    ```
*   **What Is Lost:** Deep validation of file contents. A script sees that 5 files exist, but cannot detect if File #3 contains an internal application stack trace instead of valid research data.

---

### 3. Counting & Aggregation

*   **Household Domain:** Weekly habit compliance tracking (tallying completed workouts, water intake entries, or reading logs from daily markdown files).
*   **Agent Version Cost:**
    *   *Tokens:* Loading 7 full daily markdown logs (~20k tokens total) into context and asking the model to perform simple addition.
    *   *Latency:* 8–12 seconds.
    *   *Failure Mode:* Non-deterministic math errors (off-by-one errors, skipping entries during long context processing).
*   **Script Version:**
    *   *Implementation:* `grep` and `awk` pipeline extracting standard frontmatter or task syntax (`- [x]`).
    ```bash
    # Tally completed checklist items across past 7 daily logs
    find ~/memory/daily -mtime -7 -name "*.md" -exec grep -h "\- \[x\] Gym" {} + | wc -l
    ```
*   **What Is Lost:** Fuzzy match interpretation. The script misses non-standard entries like `- [x] Went for a 5k run` or `Hit the gym late` unless explicitly regex matched.

---

### 4. Diffing & Drift Checking

*   **Household Domain:** Verification of disk state against curated file catalogs; tracking updates to local configuration files or remote price targets.
*   **Agent Version Cost:**
    *   *Tokens:* Passing both target state and current state arrays into prompt context (~30k tokens) for structural comparison.
    *   *Latency:* 15–30 seconds.
    *   *Failure Mode:* Inventing spurious differences or missing subtle changes in deeply nested lists.
*   **Script Version:**
    *   *Implementation:* Python script utilizing `filecmp` or computing SHA256 checksum manifests.
    ```python
    import hashlib, json, sys

    def get_manifest(directory):
        manifest = {}
        for path in directory.rglob('*'):
            if path.is_file():
                manifest[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        return manifest

    # Load baseline, compare current, output true diffs
    # If len(diff) > 0, invoke agent
    ```
*   **What Is Lost:** Semantic diffing. A deterministic diff flags a non-functional reformatting (e.g., whitespace changes, reordered JSON keys) as drift, triggering unnecessary alerts.

---

### 5. Format Checking & Schema Validation

*   **Household Domain:** Ensuring daily markdown logs adhere to required YAML frontmatter standards, or validating incoming API JSON pay-structures before agent ingestion.
*   **Agent Version Cost:**
    *   *Tokens:* ~8k input tokens to ingest text + ~1k output tokens to report syntax errors.
    *   *Latency:* 5–10 seconds.
    *   *Failure Mode:* High hallucination risk on strict syntax rules (approving trailing commas in standard JSON or invalid ISO-8601 dates).
*   **Script Version:**
    *   *Implementation:* Python script using `jsonschema` or a regex-based frontmatter parser.
    ```python
    import yaml, sys

    try:
        with open(sys.argv[1]) as f:
            docs = list(yaml.safe_load_all(f))
            frontmatter = docs[0]
            assert "date" in frontmatter and "status" in frontmatter
    except Exception as e:
        print(f"Validation failed: {e}")
        sys.exit(1)
    ```
*   **What Is Lost:** Qualitative content checking. The script verifies that the `summary` key exists and contains a string, but cannot evaluate if the summary is nonsensical or too short.

---

### 6. Threshold Watching

*   **Household Domain:** Utility price monitors, hardware temperature alerts, local token budget enforcement, and API rate-limit tracking.
*   **Agent Version Cost:**
    *   *Tokens:* Periodic ingestion of raw numeric payloads to perform simple `value > target` logic (~5k-10k tokens/check).
    *   *Latency:* 5–8 seconds.
    *   *Failure Mode:* Inconsistent alerting triggers due to floating-point representation misunderstandings or variable prompt interpretation.
*   **Script Version:**
    *   *Implementation:* `curl` fetching JSON API endpoint parsed via `jq` inside a cron task.
    ```bash
    # Alert if current spot token price crosses threshold
    CURRENT_PRICE=$(curl -s https://api.exchangerate.local/v1/metrics | jq '.cost_per_m')
    THRESHOLD=2.50

    if (( $(echo "$CURRENT_PRICE > $THRESHOLD" | bc -l) )); then
      ./trigger_agent_budget_warning.sh --price "$CURRENT_PRICE"
    fi
    ```
*   **What Is Lost:** Volatility and contextual trend evaluation (e.g., ignoring a temporary 10-second spike vs. reacting to a sustained upward price trend over 3 hours).

---

### 7. Copying, Routing, & Carrying

*   **Household Domain:** Moving processed raw notes into monthly archive directories; forwarding structured incoming notifications to push services.
*   **Agent Version Cost:**
    *   *Tokens:* ~10k input tokens + tool call generation tokens to execute a simple `fs.rename` or `HTTP POST`.
    *   *Latency:* 8–15 seconds.
    *   *Failure Mode:* Path truncation, improper string escaping in execution tools, or unintended file overwrites.
*   **Script Version:**
    *   *Implementation:* Standard `rsync`, `mv`, or `curl` execution.
    ```bash
    # Move logs older than 30 days to archive folder
    find ~/memory/daily/ -type f -name "*.md" -mtime +30 -exec mv {} ~/memory/archive/ \;
    ```
*   **What Is Lost:** Content-aware destination routing (e.g., routing a note to `~/projects/alpha` vs `~/projects/beta` based on a holistic understanding of the note's subject matter).

---

### 8. Heartbeat & Pipeline Canary Verification

*   **Household Domain:** Daily verification that the local text-to-speech (TTS) and audio pipeline (e.g., Whisper + Piper) is functioning end-to-end.
*   **Agent Version Cost:**
    *   *Tokens:* ~12k tokens for the agent to construct test sentences, call audio generation tools, listen to outputs, and evaluate pipeline readiness.
    *   *Latency:* 20–40 seconds.
    *   *Failure Mode:* Non-deterministic test variations that introduce transient false positives or confuse audio processing bugs with LLM output quirks.
*   **Script Version:**
    *   *Implementation:* Deterministic pass-through script rendering a static string, reading the audio response back, and verifying strict bitwise or STT exact-match equivalence.
    ```bash
    # Generate static audio, feed back through STT, compare string
    echo "CANARY_TEST_STRING" | tts-engine --out test.wav
    RESULT=$(stt-engine --in test.wav)

    if [ "$RESULT" != "CANARY_TEST_STRING" ]; then
      notify-send "Audio Pipeline Failure"
    fi
    ```
*   **What Is Lost:** Dynamic edge-case testing. A static script tests the operational health of the pipeline path, but fails to test novel pronunciations, complex punctuation, or edge-case audio encoding scenarios.

---

## Architecture Summary Matrix

| Task Class | Agent Token Cost (Daily Avg) | Script Equivalent | Execution Cost | Trade-Off / Edge-Case Vulnerability |
| :--- | :--- | :--- | :--- | :--- |
| **1. Polling / Watching** | 500k – 1M tokens | `inotifywait` / `imaplib` | $0.00 | Misses obscure/non-standard drop locations |
| **2. Completion Check** | 100k – 300k tokens | Manifest count / `wc -l` | $0.00 | Cannot verify internal payload integrity |
| **3. Counting / Aggregation** | 50k – 200k tokens | `grep` / `awk` / `wc` | $0.00 | Misses non-standard/unformatted text entries |
| **4. Diffing / Drift** | 200k – 500k tokens | SHA256 / `diff` | $0.00 | Flagged on superficial formatting/whitespace changes |
| **5. Format Validation** | 50k – 150k tokens | `jsonschema` / Regex | $0.00 | Validates syntax structural compliance, not qualitative value |
| **6. Threshold Watching** | 100k – 400k tokens | `curl` + `jq` + `bc` | $0.00 | Incapable of qualitative trend/context evaluation |
| **7. Copying / Routing** | 30k – 100k tokens | `mv` / `rsync` | $0.00 | Lacks semantic context to determine smart routing |
| **8. Canary Testing** | 20k – 50k tokens | Static payload round-trip | $0.00 | Fails to generate dynamic, novel edge cases |
