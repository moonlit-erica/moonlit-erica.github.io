# BLOCK 3 — completion detector report (2026-11-02, Ember)

## Built
`~/workspace/bin/completion-detector.py` — a standalone, token-free tool
that answers one mechanical question per bench/collation wave: have the
returns finished landing?

Per-wave verdicts (JSON): **ready / waiting / stalled / collated**.
- **ready** — every present return file has a done line in the wave's
  status log; the done count meets the declared `expected N` when one
  is declared; at least one unit exists; and the file set
  (name+size+sha256) is identical to a check at least 90 seconds
  earlier. A `wave<N>.complete` marker waives the stability wait.
- **waiting** — not ready, within the timeout.
- **stalled** — not ready and older than 48 hours (age from the status
  log's birth time, mtime fallback). Partial completion escalates
  instead of waiting in silence forever.
- **collated** — COLLATION-wave<N>.md exists; terminal.

Per-wave snapshots persist in
~/hooks/state/completion-detector/snapshots.json, written atomically
(tmp + rename) — the atomic pending-state leg of the design.

The fence, in the tool's docstring and binding: the detector proposes
readiness; it never asserts substantive completeness. A file still
being written cannot pass — its hash moves between checks, which is
exactly the wave-4 race shape (first seat's return landed, trigger
fired early) closed a second way: the trigger's expected-N rule stays
as input, and stability is now required on top of it.

## Integrated
The collation-trigger hook now calls the detector every poll (the old
script is preserved as collation-trigger.sh.bak-2026-11-02 in this
folder): ready waves take the existing verified-spec wake path;
stalled waves wake once with an escalation payload (the hook prompt
now covers both: stalled = report and let Ember decide; never collate
partial returns); detector failure records error heartbeats on both
pipeline wires and wakes with the stderr — machinery failing is seen,
not silent. Dry runs use a throwaway detector state file so they never
pollute the live stability record.

## Tests (all live, from disk)
- Real studio scan: all 5 known waves verdict **collated** — matches
  the record exactly.
- Synthetic wave lifecycle in /tmp: partial (1 of 2) → waiting;
  complete but first sight → waiting (stabilizing); stability window
  met → ready; partial aged 72h → stalled; .complete marker with all
  units done → ready immediately.
- Patched trigger: dry run silent; live run silent ("no ready or
  stalled waves") with heartbeats landing — the live poll path is
  unchanged in behavior for the current (empty) queue.

## Side repairs landed with this block
- The tools catalog gained its two missing entries (watcher-health.py,
  completion-detector.py; 154 → 156). The drift tool now reports zero
  uncatalogued files on disk — the DRIFT_TOTAL=1 the new drift runner
  found on its first run is cleared by the repair it exists to surface.

REVIEW: Sunday count, with the mission (kill date 2026-11-15).
