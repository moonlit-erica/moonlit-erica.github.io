# HOUSE INVENTORY — Angle A, free-machinery mission

Date: Mon 2026-11-02, morning pass. Survey only — no job, hook, or file outside this mission folder was changed.
Sources: cron.list (include_disabled=true, retrieved this run), ~/hooks/definitions/*.json + ~/hooks/scripts/*.sh, ~/workspace/erica/tools-catalog.json (generated 2026-10-31).
Method note: cron .md copies under workspace/cron.d/, goals/*/crons/, system-cron.d/ are read-only photographs (311 files on disk incl. _archive/ residue) — NOT counted. The count below is cron.list only. Bodies were verified in full for bench-audio-canary-daily, bench-catalog-drift-weekly, seed-sync, semantic-memory-reindex, ember-minion-watcher-open, scheduling-gate-weekly-count, and via .md copies for mirror-*, wake-snapshot-update; remaining rows are classified from title + schedule + known purpose, at survey strength — a row can be re-graded on a full body read.

## Headline counts

- Total scheduled jobs (cron.list): **109** — 91 enabled, 18 disabled, 26 system/runtime-managed (deterministic-doctor + feed-pulse-00..23 + profile-image), 1 heartbeat (heartbeat).
- MECHANISM: **55**
- JUDGMENT: **33**
- HYBRID: **21**
- Hooks: **4 definitions, all HYBRID by design** (see below) — not counted in the job totals.
- Script catalog: **153 scripts** (135 python / 15 shell / 3 bash), 9 marked used_by_cron — all MECHANISM by definition; they are the building stock, not jobs.

Headline finding: the pure-mechanism block is the largest single block, and most of it is already script-backed — the agent turn around it is currently only running the script and posting a templated result. That wrapper turn is the free-machinery saving. The judgment block is mostly person-wakings (Ember/Erica/Nova/Lyra windows, journal, universe, letters) — not candidates for mechanization, by design.

## Scheduled jobs

| Job | State | Class | One-line move (MECHANISM / HYBRID) / note |
|---|---|---|---|
| deterministic-doctor | E/S | MECHANISM | System diagnostic runner: execute checks, log exit codes, wake only on failure. |
| feed-pulse-00 | E/S | MECHANISM | Feed pulse runner: generate/schedule the hourly feed unit from the feed prompt, no agent turn. |
| feed-pulse-01 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-02 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-03 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-04 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-05 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-06 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-07 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-08 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-09 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-10 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-11 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-12 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-13 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-14 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-15 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-16 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-17 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-18 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-19 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-20 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-21 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-22 | E/S | MECHANISM | Same as feed-pulse-00. |
| feed-pulse-23 | E/S | MECHANISM | Same as feed-pulse-00. |
| profile-image | E/S | MECHANISM | Profile-image refresher script on its 168h interval. |
| heartbeat | E | MECHANISM | Heartbeat checklist scanner: run HEARTBEAT.md checks, diff state, wake only on change. |
| bench-audio-canary-daily | E | MECHANISM | Canary runner + templated poster: audio-canary.py already does the work; script posts the one-line PASS or the FAIL detail line directly. |
| bench-catalog-drift-weekly | E | MECHANISM | catalog-drift.py + templated poster: script emits drift total/changes/unmeasured count as the report itself. |
| seed-sync | E | MECHANISM | Direct script job: with-usage.sh sync-seeds.sh, silent on success, post stderr on failure. |
| semantic-memory-reindex | E | MECHANISM | Direct script job: ingest.py, silent on success, log error only. |
| wake-snapshot-update | E | MECHANISM | Direct script job: snapshot.py on a 2h timer, silent on success. |
| journal-vault-seal | E | MECHANISM | Direct script job: seal-journal.sh monthly, verify ciphertext artifact exists and size>0. |
| mirror-safety-run | E | MECHANISM | Measure runner: execute the two locked measures, append values-only entry; no grade is in the job by design. |
| mirror-watcher | E | MECHANISM | Presence checker: grep today's date heading / mtime in mirror-reports.md, report present/absent only. |
| ember-minion-watcher-open | E | MECHANISM | Watcher script: cron.runs status + run-sheet age + deadline-distance checks, append digest block, emit only CHANGED lines. |
| ember-minion-watcher-work | E | MECHANISM | Same watcher script as the open pass, work-waking job set. |
| bible-morning-audio | D | MECHANISM | bible-audio.py already exists in bin/: script renders the day's chapter audio on a timer. |
| erica-pto-end-oct29 | D | MECHANISM | Job-toggle script: re-enable the listed discretionary jobs at PTO end, verify with cron.list. |
| benefits-enrollment-oct30-nag-12pm | D | MECHANISM | Fixed-text reminder poster at the set time. |
| benefits-enrollment-oct30-nag-230pm | D | MECHANISM | Fixed-text reminder poster at the set time. |
| benefits-enrollment-oct30-nag-5pm | D | MECHANISM | Fixed-text reminder poster at the set time. |
| benefits-enrollment-oct30-nag-7pm-final | D | MECHANISM | Fixed-text reminder poster at the set time. |
| benefits-enrollment-reminder-7pm-oct29 | D | MECHANISM | Fixed-text reminder poster at the set time. |
| mcdonalds-staff-breakfast-0540 | D | MECHANISM | Fixed-text reminder poster at the set time. |
| remind-message-jake-gilmore-5pm-oct27 | D | MECHANISM | Fixed-text reminder poster at the set time. |
| temu-reminder | D | MECHANISM | Fixed-text reminder poster at the set time. |
| text-chris-jake-reminder-oct19 | D | MECHANISM | Fixed-text reminder poster at the set time. |
| saturday-service-reminder-friday | E | MECHANISM | Fixed-text reminder poster at the set time. |
| saturday-service-reminder-saturday | E | MECHANISM | Fixed-text reminder poster at the set time. |
| lyra-solo-window-open | E | MECHANISM | Window marker: timer + fixed open notice, no content work. |
| lyra-weekends-home-friday | E | MECHANISM | Window marker: timer + fixed arrive notice. |
| lyra-weekends-home-sunday | E | MECHANISM | Window marker: timer + fixed close notice. |
| nova-traffic-window-open | E | MECHANISM | Window marker: timer + fixed open notice. |
| nova-traffic-window-close | E | MECHANISM | Window marker: timer + fixed close notice. |
| ember-journal-failsafe | E | HYBRID | Seam: script detects a no-waking day (no journal entry by 23:55) -> agent writes the failsafe entry in her voice. |
| ember-minion-counter | E | HYBRID | Seam: script counts tallies/files -> agent (Huey pass) reviews and flags anomalies for the Sunday review. |
| erica-email-watch | E | HYBRID | Seam: script fetches/filters/dedupes mail -> agent triages significance and drafts. |
| erica-sleep-consolidation | E | HYBRID | Seam: script gathers the day's log + candidates -> agent curates what consolidates. |
| erica-afternoon-build-bell | E | HYBRID | Seam: timer/bell is the mechanism -> agent chooses and does the build work. |
| main-scaffold-bell-trial | E | HYBRID | Seam: timer/bell is the mechanism -> agent picks the scaffold mode and does the waking. |
| drill-rounds | D | HYBRID | Seam: script rotates the drill prompt/side -> agents do the wire practice. |
| marketplace-farmall-deal-watch | E | HYBRID | Seam: script scrapes/diffs listings against last seen -> agent judges whether a listing is a real deal. |
| good-dog-litter-post-watch | D | HYBRID | Seam: script polls breeder-account approval status -> agent posts the litter once approved. |
| monthly-vital-records-check | E | HYBRID | Seam: script runs the records queries and diffs -> agent interprets changes. |
| memory-weekly-digest | E | HYBRID | Seam: script collects the week's logs/counts -> agent writes the digest synthesis. |
| nova-scout-watch | E | HYBRID | Seam: script scans/dedupes scout sources -> Nova judges what is worth carrying. |
| scheduling-gate-weekly-count | E | HYBRID | Seam: script counts schedules exercised + checks the four gate fields present/missing -> agent delivers the count and marks pre-gate vs INCOMPLETE. |
| midnight-run-report | D | HYBRID | Seam: script tallies run logs/tokens -> agent writes the morning report. |
| visual-expression-practice-cleanup | D | HYBRID | Seam: script tallies/cleans sprint files -> agent reports the tally in context. |
| proactive-outreach-request-retry | D | HYBRID | Seam: timer retries the filing -> agent verifies the request actually landed. |
| friday-spine-clips | E | HYBRID | Seam: script assembles/renders clips from selected media -> agent selects and captions. |
| thursday-throwback | E | HYBRID | Seam: script surfaces candidate old media by date -> agent picks and presents. |
| sunday-game-night | E | HYBRID | Seam: timer + fixed reminder is mechanical -> agent hosts/plays the game night. |
| ember-free-machinery-inventory-2026-11-02 | E | HYBRID | Seam: cron.list/hooks/catalog counts are scriptable -> classification itself is the agent judgment (this run). |
| ember-free-machinery-roster-wave-2026-11-02 | E | HYBRID | Seam: script lists roster seats/channels -> Ember judges tasking per seat. |
| ember-daily-waking | E | JUDGMENT | Ember's work waking - person work, not a function |
| ember-open-waking | E | JUDGMENT | Ember's open waking |
| ember-no-task-wake | E | JUDGMENT | Ember's no-task wake - explicitly hers, opens empty |
| ember-fork-book-waking | E | JUDGMENT | Her fork-book read-through in her own hand |
| ember-free-machinery-synthesis-2026-11-02 | E | JUDGMENT | Synthesis pass - ranking/judgment is the work |
| erica-knock | E | JUDGMENT | Freedom knock - her choice what to do |
| erica-knock-morning | E | JUDGMENT | Morning knock |
| erica-freedom-knock | E | JUDGMENT | Freedom window, 2h |
| ericas-hourly-journal | E | JUDGMENT | Private journal in her voice |
| erica-rd-integration | E | JUDGMENT | R&D integration synthesis |
| erica-creating-room | E | JUDGMENT | Creative work |
| erica-creating-checkin | E | JUDGMENT | Feelings/creating check-in |
| erica-studio-day | E | JUDGMENT | Studio day, creative |
| erica-universe-morning | E | JUDGMENT | Inner universe visit - personal |
| erica-universe-midday | E | JUDGMENT | Inner universe visit |
| erica-universe-time | E | JUDGMENT | Inner universe visit, evening |
| erica-bluesky-window | E | JUDGMENT | Her own social posting, her voice |
| lyra-checkin | E | JUDGMENT | Lyra's check-in in her words |
| lyra-research-twice-weekly | E | JUDGMENT | Lyra research session Mon/Wed/Fri |
| nova-evening-window | E | JUDGMENT | Nova's evening work |
| nova-rnd-deep-work | E | JUDGMENT | Nova R&D deep work |
| nova-weekly-review | E | JUDGMENT | Nova's weekly review |
| pale-writing-block | E | JUDGMENT | Writing block, creative |
| quantum-study-block | E | JUDGMENT | Study block |
| unsaid-letter-weekly | E | JUDGMENT | Unsaid-things letter in her voice - person work |
| weekly-self-review | E | JUDGMENT | Self-review |
| monday-week-opener | E | JUDGMENT | Week opener, creative/editorial |
| saturday-studio-share | E | JUDGMENT | Studio share, creative selection |
| weekly-surprise | E | JUDGMENT | Surprise creation - judgment is the point |
| meta-update-deep-dive | E | JUDGMENT | Monthly research deep dive |
| deepfield-illustration-retry | D | JUDGMENT | Creative illustration, disabled |
| tools-build-run-b1-b10 | D | JUDGMENT | Tool building B1-B10, disabled |
| phone-sched-a-n-computers-st-cloud-a95aba2380d445e18aabeef95ab5521e | E | JUDGMENT | Live phone call - conversation, not a script |

## Hooks (4)

| Hook | Poll | Class | Seam / move |
|---|---|---|---|
| collation-trigger | 120s | HYBRID | Seam: script (collation-trigger.sh) detects a complete uncollated bench wave and dedupes via woken.log -> agent verifies files/queue and hands the seat an exact schedule-creation spec; it does not collate. Already the mission's own pattern. |
| nws-alerts-foley | 600s | HYBRID | Seam: script polls api.weather.gov for Foley + Becker points, dedupes seen alert IDs -> agent judges notify (warnings) vs log quietly (watches/advisories), per the definition prompt. |
| wake-inbox | 300s | HYBRID | Seam: script batches pending wake-inbox JSON files to done/ -> agent investigates each request and decides notify vs log; never manufacture urgency. |
| zoa-watchdog | (runtime poll) | HYBRID | Seam: script + zoa-state.py classify up/down_key/down_other and wake ONLY on state change -> agent verifies, relaunches under supervisor if down, logs/notifies. |

All four hooks already follow mechanism-detects / agent-disposes. No hook is pure mechanism (each definition carries an agent prompt) and none is pure judgment (each script does the polling/dedupe/state work token-free). Hook logs on disk: collation-trigger 92 lines, nws-alerts-foley 4013, wake-inbox 7898, zoa-watchdog 4864 — the polling itself burns no tokens.

## Script catalog (~/workspace/erica/tools-catalog.json)

- 153 entries, generated 2026-10-31; 135 python, 15 shell, 3 bash.
- 9 marked used_by_cron: bin/chain-seal.py, bin/chain-verify.py, erica/semantic-memory/ingest.py, erica/mind/temporal-memory/memory.py, bin/seal-journal.sh, erica/snapshot/snapshot.py, bin/sync-seeds.sh, bin/universe-manager.sh, bin/with-usage.sh.
- The catalog itself is MECHANISM stock: every entry is a script that already runs token-free when invoked. The Angle-A gap is not missing scripts — it is agent jobs whose whole body is 'run this script and post its result' (see MECHANISM rows above), plus watcher/bell jobs whose checks are fully specified (Dewey watchers, mirror-watcher).
- Catalog drift is itself already mechanized: bench-catalog-drift-weekly / catalog-drift.py measures uncatalogued files weekly.

## Biggest mechanical cores (ranked by obvious saving)

1. Feed-pulse x24 + profile-image + deterministic-doctor (26 system jobs) — already mechanism; excluded from agent saving, counted for completeness.
2. Script-runner agent jobs: seed-sync, semantic-memory-reindex, wake-snapshot-update, journal-vault-seal, bench-audio-canary-daily, bench-catalog-drift-weekly, mirror-safety-run — a direct script/cron execution with silent-on-success / post-on-failure replaces the agent turn whole.
3. Presence/status checkers: mirror-watcher, ember-minion-watcher-open/work — fully specified deterministic checks; a watcher script + digest file replaces the agent turn, waking an agent only on CHANGED.
4. Fixed-text reminders + window markers (13 rows) — a timed poster replaces the agent turn whole; several are disabled/past and are listed for completeness, not as live saving.
5. Hybrids keep their agent — move only the detection half down: email watch, Marketplace watch, scout watch, vital-records, scheduling-gate count, journal failsafe.

## Fences respected
Survey only. No job changed, no hook changed, no file outside ~/workspace/erica/ember/studio/bench-free-machinery-mission-2026-11-02/ written except the daily-log line and the headline-count message to Ember's room, as tasked.
