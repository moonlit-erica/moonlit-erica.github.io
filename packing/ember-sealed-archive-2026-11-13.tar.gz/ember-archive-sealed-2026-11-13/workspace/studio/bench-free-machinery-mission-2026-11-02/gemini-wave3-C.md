# Escalation Ladders: Architecting Cost-Conscious Agent Topology

In a metered household AI system, token expenditure is a non-renewable operational cost, and human attention is the most expensive resource in the building. Bridging zero-cost, deterministic system hooks with high-cost cognitive agents requires a strict ladder of escalation. 

By filtering noise at the lowest possible tier, the household ensures that computational tokens are spent only when judgment is required, and human attention is interrupted only when sovereignty or high-stakes action is mandatory.

---

## The Four-Rung Escalation Ladder

```
[ Rung 4: Human Decides ]      - High Attention Cost / Sovereign Authority
           ▲
[ Rung 3: Duty Agent Judges ]  - Metered Token Cost / Cognitive Triage
           ▲
[ Rung 2: Script Verifies ]    - Zero Token Cost / Deterministic Logic
           ▲
[ Rung 1: Wire Notice ]        - Zero Token Cost / Raw Sensor Output
```

### Rung 1: Wire Notice (Deterministic Event Detection)

Rung 1 consists of un-opinionated, ultra-lightweight daemons, file watchers (`inotify`, `fswatch`), cron jobs, and webhooks. It operates continuously at zero token cost.

* **What it may conclude:** "A state delta occurred." It notices that a file modification time changed, a HTTP endpoint returned a non-200 code, an email arrived in an inbox, or a directory now contains four files instead of three. It possesses zero semantic understanding.
* **What it must pass up:** The raw event payload (filepaths, status flags, timestamps) to Rung 2 whenever a predefined edge-change condition fires.
* **Cost Asymmetry:**
  * *False Escalation Cost:* Virtually zero (microseconds of local CPU time to invoke Rung 2).
  * *Missed Escalation Cost:* Silent stall. The system fails to notice that state changed until a scheduled macro-audit or manual check occurs.

### Rung 2: Script Verifies (Deterministic Algorithmic Filter)

Rung 2 consists of local shell scripts, Python utility modules, JSON schema validators, and regex parsers. It evaluates the raw event against hard structural rules without calling an LLM.

* **What it may conclude:** "The event satisfies structural criteria." Examples:
  * "All 5 expected bench research result files exist, are non-empty, and match the target schema."
  * "The daily audio canary script rendered an audio snippet, but the output file size is 0 bytes (failure)."
  * "The price watcher parsed a value that crossed a static 15% threshold."
* **What it must pass up:** Structured context packages (e.g., a synthesized JSON manifest of the bench research returns, or an error payload) to Rung 3 *only* when the structural criteria are satisfied, or when structural validation fails in a non-recoverable way.
* **Cost Asymmetry:**
  * *False Escalation Cost:* Low. Invokes a Duty Agent session (~1,000 to 5,000 metered tokens; ~$0.001–$0.02).
  * *Missed Escalation Cost:* Moderate. Uncollated research sits unread, drift in markdown catalogs compounds over days, or a broken audio pipeline goes unrectified.

### Rung 3: Duty Agent Judges (Cognitive Triage & Execution)

Rung 3 is a targeted, transient LLM session ("Duty Agent") invoked with scoped context. It reads the structured payload from Rung 2 alongside curated markdown system memory.

* **What it may conclude:** Semantic and contextual judgments. Examples:
  * "The 5 bench research files represent 3 valid responses and 2 duplicate retries; I will synthesize the 3 valid responses into the daily log and prune the duplicates."
  * "The price drop reported by Rung 2 is an artifact of a currency conversion shift on the target site, not a real discount."
  * "The weekly compliance score missed its target because Tuesday was a declared holiday in the household log."
* **What it must pass up:** High-stakes escalations to Rung 4. This includes requests for external financial transactions, emails to external contacts, ambiguous instructions that risk memory corruption, or system failures that the agent cannot self-heal.
* **Cost Asymmetry:**
  * *False Escalation Cost:* High. Interrupts the human via push notification or dashboard flag, risking alert fatigue and destroying the automation value proposition.
  * *Missed Escalation Cost:* High to Severely Damageable. The agent makes an incorrect assumption, writes hallucinated state to long-term markdown memory, misses an urgent reply, or allows silent decay of household systems.

### Rung 4: Human Decides (Sovereign Authority)

Rung 4 is the human operator. Interface mechanisms include low-priority daily digest logs, active push notifications, or required physical/UI sign-offs.

* **What it may conclude:** Final strategic decisions, manual overrides, system modifications, or out-of-band real-world actions.
* **What it must pass up:** Nothing. Rung 4 is the terminal authority.
* **Cost Asymmetry:**
  * *False Escalation Cost:* Attention fragmentation. Repeated false escalations lead the human to disable notifications or blindly grant permissions.
  * *Missed Escalation Cost:* Total failure of real-world or high-value digital operations (e.g., unpaid bills, unresponded critical correspondence, systemic agent drift).

---

## Escalation Matrix Summary

| Rung | Execution Engine | Cost per Invocation | Primary Function | False Escalation Penalty | Missed Escalation Penalty |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1. Wire Notice** | OS hooks, Cron, `inotify` | $0.00 (CPU cycles) | Edge/Delta detection | Negligible (CPU noise) | High (Silent state stall) |
| **2. Script Verifies**| Bash, Python, Schema | $0.00 (CPU cycles) | Structural verification | Low (Wasted token wake) | Moderate (Delayed workflow) |
| **3. Duty Agent** | Scoped LLM session | Metered Tokens | Semantic triage & synthesis | High (Interrupted human) | Critical (Memory/State corruption) |
| **4. Human Decides**| Human cognitive band | Attention & Time | Sovereign authorization | Extreme (System distrust/fatigue)| Catastrophic (Real-world failure)|

---

## Right-Sizing the Ladder for a Household

For a small household, **a four-rung architecture is the optimal maximum depth**. Attempting to insert intermediate rungs—such as multi-agent consensus chains (e.g., "Sub-Agent verifies Main Agent")—adds extreme architectural overhead, latency, and token drain without adding real safety.

### Recommended Household Rules for Ladder Sizing:

1. **Strict Zero-Cost Bisection:** The system must preserve a hard boundary between **Deterministic Infrastructure** (Rungs 1 and 2, $0 cost) and **Cognitive Infrastructure** (Rungs 3 and 4, metered cost). If an issue can be evaluated with Python string matching, `git diff`, or file sizing, it *must never* land on Rung 3.
2. **One-Shot Duty Agents:** Household Rung 3 agents should almost always be one-shot execution sessions. Long-running, broad-context multi-agent loops burn metered tokens rapidly and increase the probability of hallucinated escalations to Rung 4.
3. **Batching Escalations at Rung 3 $\to$ 4:** Except for critical immediate notices (e.g., security breach, critical service outage), Rung 3 should not escalate to Rung 4 individually. Instead, it appends triage notes to a **Daily Human Queue** (a markdown file reviewed during a single daily check-in). This turns potential push-interruptions into an asynchronous digest.

---

## System Hazards: When Ladders Become Risks

An escalation ladder is a structural system; like physical ladders, it can suffer from structural decay, misuse, and feedback failures.

### 1. Alert Fatigue (The Rung 3 $\to$ 4 Spike)
If Rung 3 agents are prompt-engineered with excessive caution, they will escalate minor ambiguities to Rung 4. 
* **The Hazard:** The human experiences notification overload, begins clearing alerts without reading them, or silences the notification channel entirely.
* **Mitigation:** Enforce a strict "Defensive Defaults" policy at Rung 3. If an ambiguity is low-stakes (e.g., formatting inconsistent in a non-critical file), Rung 3 must apply a default safe fallback, log the choice to the daily markdown audit log, and *not* ping the human.

### 2. Rung Rot (Silent Drift in Deterministic Layers)
Rung Rot occurs when lower-tier scripts break due to environmental shifts (e.g., an external website changes its CSS layout, breaking a price watcher; an OS update shifts file path permissions; an API changes its return format).
* **The Hazard:** Rung 2 fails silently. Because it returns `false` or exits with an unhandled code, it never escalates to Rung 3. The workflow dies at the bottom of the ladder without generating an error flag.
* **Mitigation:** The **Audio Canary and Drift Checker Pattern**. The household must run scheduled meta-watchers (e.g., daily canary jobs) that intentionally pass known test payloads through Rungs 1 and 2 to prove the deterministic pipeline is alive. If the canary fails to reach Rung 3, an infrastructure alarm fires.

### 3. Escalation Feedback Loops (Token Burn Cascades)
A feedback loop occurs when a Rung 3 agent takes an action that inadvertently triggers a Rung 1 sensor.
* **The Hazard:** Rung 1 detects a modified file $\to$ Rung 2 validates structure $\to$ Rung 3 wakes, processes the file, and writes a summary file to disk $\to$ Rung 1 detects the summary file modification $\to$ Rung 3 wakes again. This loop can burn through thousands of metered tokens in minutes.
* **Mitigation:** 
  * **Strict Directory Isolation:** Agents may only write to designated output directories that are explicitly excluded from Rung 1 file-watcher masks.
  * **Global Rate-Limiting:** Implement a global Rung 2 circuit breaker: if an agent wake hook fires more than $N$ times within a 10-minute window, Rung 2 locks the trigger and notifies the human log.
