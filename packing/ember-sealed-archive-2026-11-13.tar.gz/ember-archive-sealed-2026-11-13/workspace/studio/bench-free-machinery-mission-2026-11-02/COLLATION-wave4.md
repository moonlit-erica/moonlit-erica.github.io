# COLLATION — Bench free-machinery mission, Wave 4 (full remaining roster)

Collated: 2026-11-02 09:41 CST (America/Chicago)
Returns checked: five Wave 4 returns — ChatGPT→A (inventory), Grok→B (patterns), Perplexity→C (exploitation), DeepSeek→D (hazards, published patterns only), Duck→E (frontier) — read against COLLATION-wave1.md, COLLATION-wave2.md, and COLLATION-wave3.md in this folder.
Landed-to-collated lag: 7 minutes (wave complete 2026-11-02 09:33:41 CST → collated 09:41 CST)
Check method: every item below is supported by a named Wave 4 return as written. Overlapping designs across returns are one item with multiple sources, not counted twice. No item enters this backlog on collator invention; a design no Wave 4 return supports does not enter. Wave 3 weaving items and Wave 3 cuts that no Wave 4 return raises are not re-counted here — they stand as filed in COLLATION-wave3.md (noted at the end).
Fence applied throughout: outputs bound for Erica's books stay abstract about sources; nothing about any person's state appears in this collation.
Hole noted, not hidden: Claude seat parked (verification) — no Claude return in this wave.

## Headline count

**30 items checked — 15 keep, 7 needs-a-second-angle, 8 cut.**

Wave 2's refutation verdicts survive this wave almost intact: the blind proposal engine, zero-clock cascades, and the built accounting engine stay cut — and each is replaced in this wave by a narrower, evidence-carrying form that the roster does support (items 9, 11, 12). The copying/carrying boundary Wave 2 resolved is now confirmed by all five seats (item 10).

---

## The four second-angle verdicts (required, from Wave 1 items 12–15)

### 1. Proposal engine — blind form CUT stands; evidence-carrying form KEEP as a new design (item 11)

No seat supports approval over evidence the agent cannot inspect. All five cut the blind form: ChatGPT (Architecture B "creates an approval machine"), Grok (fails outright where verification cannot be compressed), Perplexity (an agent "cannot meaningfully approve an evidence-dependent conclusion from an unsupported summary"), DeepSeek (a payload that omits the evidence is "the removal of the judgment layer while retaining its name" — the moral-crumple-zone pattern), Duck (approving "a plausible summary while missing a contradiction, stale value, or important exception").

The evidence-carrying replacement is supported by four seats in full — ChatGPT (proposal carries ID, trigger, evidence references, timestamps, state version, exceptions, reversal plan; revalidation at commit time), Perplexity (evidence-carrying packet; "the token cap must not become an evidence cap" — exceed 300 tokens when the evidence needs it), DeepSeek (pointers not just verdicts, staleness window with regeneration, consequence-set sampling fraction, minimum evidence threshold, approval/rejection rates themselves monitored), Duck (concise proposal plus cheap targeted retrieval; approve / reject / need-more-evidence must all be available outcomes).

Grok supports in part and dissents in part: it supports the rate limit, the staleness window, and the outright-failure cases, but its context-pruning fence as written — strip all but the proposal, a policy excerpt, and a "why this matters" note, "making it impossible for the agent to dig for missing evidence inside the same session" — is the blind form under another name and is cut at item 30 below, against the other four seats.

### 2. Event-driven cascades — pure zero-clock form CUT stands, unanimously; hybrid form KEEP (item 9)

All five seats cut the wholesale replacement of clocks and all five support the same hybrid: events fire progress, a clock-driven deadline/lease watchdog detects absence, and periodic reconciliation compares the graph against actual state. ChatGPT (three layers: event, deadline, reconciliation; "you cannot eliminate all periodic checking"), Grok (expected-by deadlines in a durable graph, lease expiry, per-edge rate limits and a graph circuit breaker; "a minimal external heartbeat or lease store must remain"), Perplexity ("replace unnecessary agent schedules, not clocks"; heartbeat timeout ≠ overall deadline; out-of-band check required for whole-host failure), DeepSeek (absence-detection "is a clock function"; parent–child dependency modelling so a silent upstream produces one root-cause signal, not a storm or silence; per-node fire budgets, flap detection, inhibition edges), Duck (timeouts and periodic checks as explicit failure-detection events; a fully clockless design works only where every state change is guaranteed to emit a durable, independently detectable event).

### 3. Token accounting — built engine CUT stands, unanimously; lightweight labelled report KEEP (item 12)

All five seats cut a built counterfactual ledger/dashboard at household scale and all five support the same replacement: labelled estimates against a pinned baseline, with actual usage kept in a separate account. ChatGPT (baseline from historical samples, median not worst case, baseline versioned and fixed; quality columns — false-positive/negative, correction, escalation rates — beside the savings; a small registry, not a subsystem), Grok (baseline = the cheapest equivalent agent session that actually performed the work; one-shot script producing labelled estimates in a weekly/monthly report is sufficient), Perplexity (three accounts kept separate — displaced work, expanded service, improved outcomes; checking a price 720×/day mechanically does not mean 720 agent checks were saved), DeepSeek (baseline defined before the script is built, multiplied by the actionable rate, minus induced costs — false wakes, verification time, watcher review; a judgment-cost column and a reversibility field), Duck (measured usage, estimated counterfactual, and outcome quality as three separate quantities; formal ledger only if estimates start driving meaningful decisions or need auditability).

### 4. Script copying / routing / carrying — KEEP, boundary confirmed by all five seats (item 10)

All five support free-layer copying, staging, routing, indexing, and archiving under explicit rules, and all five cut the same other side: deciding which version is authoritative, resolving conflicting records, content-based routing, promoting a record's authority/status, and any destructive operation on a primary record. ChatGPT (authority levels 0–2 default for scripts, level 3 — destructive or authoritative change — requires explicit, specific authorization; transaction journal, staged copy-verify-commit, orphan recovery, idempotency; authority is explicit metadata, never inferred from location), Grok (pure relocation of finalized artifacts and temp-only deletes safe; anything that interprets content, merges, deduplicates, or decides retention stays at the agent layer; staging is never the primary store), Perplexity (routing metadata must itself be trustworthy — a carried file must not be able to declare its own destination; no-overwrite by default; commit markers, path constraints, orphan reconciliation), DeepSeek (safe set is non-destructive, reversible, shape-only; deletion only of a provable duplicate held elsewhere; age alone never establishes staleness), Duck (copy-then-verify over move-then-hope; quarantine unexpected files or destination conflicts instead of guessing; dry-run mode).

One genuine split survives inside this verdict and is carried as item 22: the *deletion* step for exact-hash duplicates. ChatGPT, Perplexity, DeepSeek, and Duck each permit exact-content-hash deduplication under safeguards (DeepSeek: only where a copy provably exists elsewhere); Grok lists deduplication itself among the operations that must stay at the agent layer. Copy/archive of a verified duplicate is settled (item 10); deleting the redundant copy is not.

---

## Ranked backlog — KEEP (15)

1. **keep — Tripwire polling replacement, edge-triggered** (ChatGPT A §1, Grok B Tripwires, Perplexity C wide coverage, Duck E §3) — State-transition emission against last-known state replaces agent polling wakes; the largest buy in Wave 1, reaffirmed by four seats with no new wound.
   *Hazard (DeepSeek D H1/H2): a dead tripwire is indistinguishable from a quiet world, and transient-state firings burn the saved tokens — keep only with item 8's heartbeat/fixture fence and a per-watcher wake budget whose exhaustion escalates to a human or a drift note, never to more wakes (D H2, wave-4 sharpening of the Wave 1 budget).*

2. **keep — Completion detector / arrival and batch completion** (ChatGPT A §2, Grok B Completion Detectors, Perplexity C continuous completion watches) — Manifest, presence, stable size/checksum, and completion-marker checks emit one batch-complete event and one agent wake.
   *Hazard (ChatGPT A §2, DeepSeek D H3): silence is not proof of completeness, and a shape-complete set can be substantively empty — the wake payload carries shape evidence (paths, timestamps, checksums, raw status lines), never a verdict, and "tripwire fired, condition not actually met" is a first-class agent outcome that feeds the watcher's review counter (D H3).*

3. **keep — Counting, aggregation, and pre-aggregated telemetry** (ChatGPT A §3, Perplexity C exception-based administration) — Scripts parse structured records, count, and do the arithmetic; the agent receives numbers only when interpretation is required. Unattacked in every wave.
   *Caveat (ChatGPT A §3): a script can report that a rate fell; significance, cause, and whether the measurement itself misleads stay at the agent layer.*

4. **keep — Threshold trigger with hysteresis** (ChatGPT A §6, Grok B Threshold Triggers, Perplexity C) — Scalar-versus-bound checks with an enter/clear deadband, alert-once state, debounce, and recording replace agent numeric polling.
   *Caveat: which trend operations above the raw threshold are statistics (free layer) and which are context (agent layer) is still undrawn — item 18.*

5. **keep — File-shape contract / pre-flight validation, fail-loud** (ChatGPT A §5, Grok B File-Shape Contracts, Perplexity C universal preflight) — Schema, header, filename, and required-section checks quarantine malformed inputs before any agent wake, on every deliverable, not only high-priority ones.
   *Wave-4 sharpening (DeepSeek D H4): "input present but unparseable" is a distinct shape-drift state that fires a note — it is never the same as "no input"; every parser carries a known-good fixture rendered through it on a schedule, and the contract is versioned alongside the parser. Syntactic validity is never semantic correctness (all seats).*

6. **keep — Queue-and-trigger batching, single-domain** (Grok B Queue-and-Trigger Scheduling, ChatGPT A §9) — A durable queue drains into precisely timed one-shot agent sessions at a count/time threshold, with deduplication; Wave 2's single-domain narrowing and priority bypass stand.
   *Hazard (Grok B): backlog growth if the agent layer cannot keep up, and duplicate wakes without queue deduplication — both are build-shape requirements, not objections.*

7. **keep — Canary probe, file-property form** (Grok B Canary Probes, ChatGPT A §8, Perplexity C continuous operational proof) — A known input round-tripped on a schedule, checked for exit status, presence, non-emptiness, and content hash; Wave 2's cuts of exact-string round-trip comparison and driver-code-as-hardware-proof stand.
   *Hazard (Perplexity C): coverage levels must be recorded as what they prove — "renderer exited," "output appeared," and "recognizable output reached the endpoint" are different claims; a passing canary proves the pipe, never the content carried through it (Wave 3 item 20 stands).*

8. **keep — Watchdog, dead-man switch, and watcher-health register, single level** (ChatGPT A §8, Grok B Watchdogs + Dead-Man Switches, DeepSeek D H1) — Heartbeat age and lease expiry detect absence; one health register plus one dead-man check over it, with a deliberate-pause state (Wave 2 item 9 shape stands, no recursive watcher chain).
   *Wave-4 sharpening (DeepSeek D H1): each watcher also needs its own synthetic fixture trigger on a schedule, so a dead tripwire is discovered by a controlled false event, not by the absence of a real one; the heartbeat send itself must be fire-and-forget and never break the monitored job.*

9. **keep — Hybrid event cascades: events for progress, clocks for absence, periodic reconciliation** (all five seats, Second Angle 2) — The surviving form of Wave 1 item 13 after Wave 2's cut of the wholesale form: a state graph with durable event log, idempotency keys, deadlines/leases per expected event, a cheap watchdog over outstanding obligations, and a periodic reconciliation of event records against actual files, outputs, and deadlines.
   *Build-shape fences (DeepSeek D, Grok B, Perplexity C, Duck E): parent–child dependency modelling with a stuck-node state distinct from idle; per-node and per-edge fire budgets, deduplication windows, flap detection, inhibition edges, and a graph-level circuit breaker that collapses a storm into one signal; queued / started / output-committed / validated tracked as separate receipts — "scheduled" is never "finished" (Perplexity C).*

10. **keep — Copying, routing, and carrying by script, authority levels 0–2** (all five seats, Second Angle 4) — Observe, copy/prepare, and reversible route/archive/rename under explicit rules are free-layer work, built on staging, atomic publication, checksum verification, a transaction journal, idempotent operation IDs, and orphan recovery.
    *Boundary (all five): level 3 — deleting a primary record, overwriting, deciding the authoritative version, resolving conflicts, content-based routing, promoting a record's status — requires explicit authorization or stays at the agent layer entirely; authority is carried as explicit metadata, never inferred from a file's location (ChatGPT A Q4). The deletion step for exact-hash duplicates is the one unsettled sub-case — item 22.*

11. **keep — Evidence-carrying proposal engine** — **wave-4-new** (ChatGPT A Q1 Architecture A, Perplexity C Q1, DeepSeek D Q1, Duck E Q1; Grok B Q1 in part) — A script pre-assembles a compact proposal that carries or points to its evidence — trigger, observed values, evidence references with timestamps and versions, known exceptions and conflicts, expiry — and the agent approves, rejects, or demands more evidence, with revalidation against current state immediately before execution. This is a new design, not a revival of the cut item 23: it does not inherit that item's place or its claimed saving, which must be re-proved in use.
    *Fences (as returned): per-event, per-agent, and per-category rate limits with deduplication and rejected-proposal cooldowns; staleness windows set by decision type; sampling of raw evidence at a consequence-set fraction (100% for anything touching a primary record, DeepSeek D); never prune warnings, contradictions, provenance, or decision criteria; outright failure where evidence is incomplete or contradictory, the classification itself is the disputed question, or the action is irreversible (ChatGPT A, Duck E).*

12. **keep — Lightweight token-accounting report / automation registry** — **wave-4-new** in its specified form (all five seats, Second Angle 3) — A periodic report or small registry per mechanism: pinned baseline (method and version stated), estimated displaced agent tokens with a confidence label, actual agent usage in a separate account, expanded-coverage and improved-outcome effects reported as capability and latency — never as savings — plus false-wake, missed-event, correction, and maintenance figures.
    *Reason it is keep while item 25 is cut: every seat draws this exact line — the labelled estimate informs build choices; the built engine's apparatus and false precision are what all five reject at this scale.*

13. **keep — Capture now, decide later: durable snapshots at trigger time** — **wave-4-new** (Perplexity C, supported by Duck E §1's normalizer and ChatGPT A's evidence preparation) — When a watch fires, the script preserves a timestamped snapshot of the state that triggered it — an expiring offer, a transient failure, a changed response, a newly completed artifact — so the agent later judges a durable evidence package instead of chasing a condition that may have disappeared.
    *Boundary (Perplexity C as written): the snapshot separates the deadline for observation from the deadline for deliberation; it preserves evidence, it does not interpret it.*

14. **keep — Evidence-to-decision pipeline with a deterministic policy gate** — **wave-4-new** (Duck E §1, mirrored in ChatGPT A's five-layer synthesis) — Watcher → durable event queue → normalizer gathering the smallest provenance-recorded evidence bundle → proposal builder (item 11) → agent → a deterministic policy gate that checks permissions, required evidence, and action limits before any execution → action runner → audit log, with "insufficient evidence" as an explicit, recordable outcome.
    *Hazard (Duck E §1 as written): policy checks must not depend on the agent's confidence alone, untrusted input must never be treated as an instruction, and retries must be idempotent so a repeated action cannot execute twice.*

15. **keep — Self-maintaining automation, repair-proposal form only** (Duck E §5; the surviving ticket-generation half of Wave 1 item 16 / Wave 2 item 14) — A script catalog with declared contracts, health and expected-output checks independent of the script being monitored, and a failure-generated repair proposal (the check, the logs, the recent changes) queued for an agent to diagnose and draft a patch against, with tests and an approval gate controlling deployment and prior versions preserved.
    *Boundary: the auto-overwrite half stays cut at item 26 — a checker must never be modifiable by the script it checks, and no repair deploys itself (Duck E §5).*

---

## NEEDS A SECOND ANGLE (7)

16. **needs-a-second-angle — State diffing and delta-only wakes, scope line** (ChatGPT A §4, Grok B State Diffing, Perplexity C delta-only reading; Wave 2 item 16, still open) — All three Wave 4 returns support diffing (ChatGPT adds classify-by-explicit-rule and report-first, repair only under a separate authorization policy), but none draws the line Wave 2 required: local static files and canonicalised structured sources versus live web state, and none specifies what baseline context rides with a delta so the agent is not starved into secondary reads.
    *One-line reason: support widened in this wave; the scope and baseline-payload specifications Wave 2 asked for still appear in no return.*

17. **needs-a-second-angle — Deterministic grader / post-flight linting, retry path** (Grok B Deterministic Graders, Duck E §2; Wave 2 item 17, still open) — The gate half gains one Wave 4 fence — Duck requires sampling *passing* work for human review and measuring false passes as well as caught errors — but no Wave 4 return fixes the retry cap number, the escalation target, or the auto-fix-first order Wave 2 required before build.
    *One-line reason: gate strengthened, loop still unspecified — exactly the split Wave 2 named.*

18. **needs-a-second-angle — The trend split point** (Wave 2 item 18, still open) — Wave 4 does not draw it either: ChatGPT A §6 keeps context-sensitive interpretation of a threshold crossing at the agent layer without separating statistical filtering from context, and no other return addresses trend operations directly.
    *One-line reason: the line inside "trend" between deterministic statistics and judgment remains undrawn after four waves.*

19. **needs-a-second-angle — Out-of-band watchdog for the shared substrate** (Wave 3 item 16, advanced not closed) — Wave 4 names the requirement from three sides — Perplexity C (a watchdog on the same stopped host "cannot report its own silence"; whole-host detection requires something outside that failure domain), DeepSeek D H1 (a heartbeat ping to an external healthchecks-style receiver), Duck E §3 (independently checked watchdog receipts) — but no return designs the household's external leg: what pings, from where, to whom.
    *One-line reason: the external receiver is now attested as a pattern; its concrete design for this house is still missing.*

20. **needs-a-second-angle — Human semantic audit routine** (Wave 3 item 17, still open) — Wave 4 supplies sampling for adjacent objects — proposals (DeepSeek D Q1), mechanically passing work (Duck E §2), accepted/rejected proposals against full records (Perplexity C Q1) — but still no fixed human sampling cadence and sample definition for the *content correctness* of what the net passes.
    *One-line reason: agent-layer sampling is now specified in three places; the human leg E required in Wave 3 is still not.*

21. **needs-a-second-angle — Invariant-only scoping line, per domain** (Wave 3 item 18, sharpened not drawn) — DeepSeek D H3 sharpens the vocabulary (condition coverage versus semantic adequacy: a shape-check passes the first and fails the second by construction) and Perplexity C separates canary coverage levels, but no return walks the coverage matrix domain by domain and marks which checks are true invariants and which are proxies.
    *One-line reason: proxies may trigger; until the per-domain line is drawn they cannot carry safety claims, and no return draws it.*

22. **needs-a-second-angle — Deletion of exact-hash duplicates** — **wave-4-new** conflict (ChatGPT A Q4, Perplexity C Q4, DeepSeek D Q4, Duck E Q4 against Grok B Q4) — Four seats permit exact-content-hash deduplication under safeguards; Grok places deduplication at the agent layer. Detection of byte-identical copies and reversible archiving of a verified duplicate are settled inside item 10; only the deletion of the redundant copy splits the roster.
    *One-line reason: a 4–1 split on an irreversible step is a second-angle question, not a keep.*

---

## CUT (8)

23. **cut — Proposal engine as written: 300-token blind approval** (Wave 1 item 12, Wave 2 item 11 — stands, now unanimous across four waves of returns) — Every Wave 4 seat cuts the evidence-blind form for the same structural reason Wave 2 sustained: approval without inspectable evidence is a rubber stamp, and stripping the context is the design's stated saving, so the flaw cannot be tuned away. The replacement is item 11, a new design that inherits nothing from this one.
24. **cut — Pure event-driven cascades replacing clocks wholesale** (Wave 1 item 13, Wave 2 item 12 — stands, unanimous in Wave 4) — An event that does not happen fires no trigger; absence detection is a clock function, and removing clocks removes the timeout and dead-man coverage the rest of the backlog depends on. The hybrid survives at item 9.
25. **cut — Built counterfactual token-accounting engine** (Wave 1 item 14, Wave 2 item 13 — stands, unanimous in Wave 4) — A dedicated ledger/dashboard apparatus at household scale costs more maintenance than the decisions it informs are worth, and its tabulated figures acquire false authority over the labelled estimates all five seats prefer (item 12). Counting expanded coverage as displaced savings is cut with it (Perplexity C Q3).
26. **cut — Immune-system auto-repair with auto-overwrite of production scripts** (Wave 1 item 16, Wave 2 item 14 — stands) — No Wave 4 return supports self-deploying repair; the strongest Wave 4 form (Duck E §5) requires independent monitoring, preserved prior versions, tests, and an approval gate — which is item 15, not this design.
27. **cut — Script-layer judgment** (Wave 1 item 17, Wave 2 item 15 — stands, reaffirmed by all five seats) — Pruning by content, sending external communications, resolving conflicting returns or deciding the authoritative version, scoring quality, assigning priority, content-based routing, promoting a record's authority, and cleanup by age alone: no Wave 4 return moves any of these into the free layer, and DeepSeek D's judgment table and ChatGPT A's inventory summary restate the boundary directly.
28. **cut — Semantic proxy metrics as proof of completion or correctness** (Wave 3 item 20 — stands, reinforced) — DeepSeek D H3 (shape-complete returns can be substantively empty), Perplexity C (a valid completion receipt is not intellectual completeness), and Duck E §2 ("mechanically valid" distinct from "judged correct") each restate the cut from their own angle; proxies remain triggers and structure checks only.
29. **cut — The net itself as a safety net / verification tool** (Wave 3 item 19 — stands) — No Wave 4 return revives the claim: Perplexity C frames the layer's value as attention scarcity ("make attention scarce, not observation"), Duck E §3 retains periodic sentinels precisely because the trigger layer cannot verify itself, and DeepSeek D's five hazards are a catalogue of the layer failing silently. Triggering and latency reduction, not safety.
30. **cut — Evidence-stripping context pruning as a proposal fence** — **wave-4-new** (Grok B Q1, fence (c) as written) — Stripping a proposal session down to the proposal, a policy excerpt, and a short rationale — expressly so the agent cannot look for missing evidence in that session — reproduces item 23's blind approval inside the replacement design. Cut against the other four seats, each of which requires evidence pointers, provenance, contradictions, and a route to retrieve more evidence to survive pruning (ChatGPT A Q1, Perplexity C Q1, DeepSeek D Q1, Duck E Q1).

---

## Standing from earlier waves, not re-counted here

- Wave 3's weaving keeps that Wave 4 does not re-raise (coverage matrix, dual-path verification, disagreement triage/quorum/STATE_SPLIT, the escalation ladder and its anti-fatigue fences, wire census and daily mechanical audit) stand as filed in COLLATION-wave3.md; where Wave 4 overlaps them (heartbeat, canary, completion), the Wave 4 item above governs the build shape.
- Wave 3's remaining cuts — forced git stash/rebase as automatic remediation (item 21) and unbounded wire sprawl outside census/probe/pruning (item 22) — are raised by no Wave 4 return and stand unrevived.
- Wave 1's token figures remain the returns' own estimates, not measured house numbers; Wave 4's accounting verdict (items 12/25) is precisely that no figure from any wave may be quoted as a saving without its baseline method and confidence label attached.

## Next step

Builds happen only on the deciding word named in MISSION.md. This collation is the checked backlog; it authorizes no build by itself. Items 16–22 are the second-angle queue for the next wave that takes them up.
