Token-Free Automation Patterns for an Agent Household

Tripwires

A lightweight poller or filesystem event watcher inspects a single, well-defined condition (presence of a sentinel file, a status string in a log line, a lock file’s absence) at fixed short intervals. When the condition becomes true it emits a one-shot wake signal—usually by writing a schedule request or dropping a job token into a queue. It watches only the presence or exact content of that sentinel. It fires a scheduled agent session or a downstream script. Failure mode is a false-positive wake (stale sentinel left behind) or a missed event if the poll interval is longer than the lifetime of the condition. Household application: a research-return folder acquires a “complete” marker file; the tripwire schedules the collation agent two minutes later instead of waiting for the next nightly session.

State Diffing

A script snapshots a compact, canonical representation of state (file hashes, last-modified times, a sorted directory listing, a single numeric metric) and compares it with the previous snapshot. Only when the diff is non-empty and matches a declared pattern does it wake an agent. It watches the delta between successive snapshots. It fires on meaningful change. Failure mode is drift in the snapshot format itself or accumulation of noise that eventually forces an agent to reconcile. Household application: nightly comparison of the curated markdown memory catalog against on-disk files; a non-empty diff wakes the drift-checker agent only when files have appeared, vanished, or changed size.

File-Shape Contracts

Agents and scripts agree on a rigid directory layout and naming convention (e.g., every completed research set must contain raw/, notes.md, and a zero-byte DONE file). A pure shell checker verifies the shape; if the contract is satisfied it triggers the next stage. It watches structural completeness, not content. It fires a collation or archival job. Failure mode is a partial write that still satisfies the superficial shape, producing a false “ready” signal. Household application: bench-research returns land in dated folders; once the folder matches the required shape the system auto-schedules the collating agent.

Threshold Triggers

A counter or gauge is maintained by cheap scripts (file line counts, price scrapes, compliance tallies). When the numeric value crosses a pre-set high or low water mark the script emits a wake. It watches a single scalar against a constant. It fires an agent session for judgment or remediation. Failure mode is oscillation around the threshold or an unhandled unit change that silently invalidates the comparison. Household application: weekly compliance counters; once the count of incomplete daily logs exceeds a small integer the agent is woken to investigate rather than waiting for the weekly review.

Watchdogs

A long-lived or frequently polled process expects a heartbeat file or a freshness timestamp to be updated by some upstream process. If the expected update is missing beyond a grace period the watchdog wakes an agent or raises an alert. It watches the age of a heartbeat. It fires on absence of expected activity. Failure mode is a stuck clock or a heartbeat written by a zombie process that masks real failure. Household application: the audio-pipeline canary is expected to update a “last-rendered” timestamp daily; silence beyond 26 hours wakes the diagnostic agent.

Dead-Man Switches

The inverse of a watchdog: an agent or script must periodically touch a lease file. If the lease expires, a cheap script assumes the holder has failed and takes a recovery action (re-queue work, notify, or wake a supervisor agent). It watches lease expiry. It fires recovery logic. Failure mode is a false expiry caused by clock skew or an overly aggressive timeout that aborts legitimate long-running work. Household application: a long-running collation job holds a lease; if the lease ages out the system re-queues the work and wakes a different agent instance.

Completion Detectors

A script inspects a collection of expected artifacts (files, status lines, exit codes) and declares the whole set finished only when every member is present and valid. Detection itself is pure logic; the wake is issued only on full completion. It watches the conjunction of multiple independent conditions. It fires a downstream agent or archival step. Failure mode is an incomplete but syntactically valid set that still passes the detector. Household application: a multi-folder research drop is declared complete only when every sub-folder contains its DONE marker; the detector then schedules the single collation pass.

Queue-and-Trigger Scheduling

Mechanical work is deposited into a durable queue (files in a directory, lines in a log). A free-layer scheduler drains the queue on a short cadence or on filesystem events and, for each item that meets a simple predicate, creates a one-shot agent schedule a few minutes in the future. It watches queue depth and item readiness. It fires precisely timed agent sessions. Failure mode is queue backlog growth if the agent layer cannot keep up, or duplicate wakes if the queue is not de-duplicated. Household application: completed but uncollated research sets are dropped into a “ready” directory; the scheduler notices them and auto-creates a two-minute-offset agent session.

Canary Probes

A known-good input is injected on a fixed schedule through an entire pipeline (text → audio render, or markdown → memory index). A downstream checker verifies that the expected artifact appeared with the correct content hash. The probe itself costs no model tokens. It watches end-to-end pipeline liveness. It fires an alert or diagnostic wake on mismatch or absence. Failure mode is a canary that itself becomes the only thing still working while real traffic is broken. Household application: a fixed sentence is rendered through the audio pipeline every day; the resulting file’s checksum is checked, proving the chain is alive without involving an agent until failure.

Deterministic Graders

After an agent produces structured output (a JSON summary, a markdown table, a numeric report), a pure script compares that output against a pre-recorded ground-truth or against invariants (checksums, schema, numeric ranges). Only on mismatch does it wake a human or a higher-privilege agent. It watches the produced artifact against a fixed oracle. It fires only on detected deviation. Failure mode is an oracle that itself drifts or a grader that is too strict for legitimate variation. Household application: an agent writes a weekly compliance summary; a script checks that every required daily log is referenced and that the totals match the counters; only a mismatch wakes a review session.

1. Proposal Engine

The token saving is real only when the agent’s judgment is restricted to the proposal’s internal consistency, risk surface, and alignment with standing policy—not when the agent is expected to re-discover or re-verify the underlying evidence. If the evidence is invisible, approval becomes a rubber stamp unless three fences are enforced: (a) a hard rate limit on how many proposals an agent may accept per day, forcing selective attention; (b) an explicit staleness window stamped on every proposal so that any data older than N hours is rejected outright; (c) a context-pruning fence that strips all but the proposal, the policy excerpt, and a short “why this matters” note, making it impossible for the agent to dig for missing evidence inside the same session. The design fails outright when the decision is irreversible, high-stakes, or requires sensory or multi-hop verification that cannot be compressed into the 300-token payload; in those cases the free-layer pre-assembly must be abandoned and a full discovery session scheduled.

2. Event-Driven Cascades

Absence is detected by pairing every positive event with an explicit “expected-by” deadline recorded in a durable state graph; a free-layer timer or lease expiry then fires the complementary “did-not-happen” edge. A silently failed upstream node is covered by requiring every node to write a completion token; any downstream node that times out without seeing that token treats the upstream as failed and either retries, skips, or escalates. Event storms are bounded by per-edge rate limits, exponential back-off on re-triggers, and a global “circuit-breaker” counter that freezes the entire graph once a threshold of wakes per hour is crossed, forcing a human or supervisor agent to reset it. Without a clock the system cannot notice pure absence, so a minimal external heartbeat or lease store must remain.

3. Token Accounting

An honest baseline is pinned by logging, for every mechanical action, the exact token cost that would have been incurred by the cheapest equivalent agent session that previously performed the same work (or a conservative estimate derived from historical averages of similar sessions). The ledger therefore records “tokens not spent” against a real prior cost, not against an inflated theoretical maximum. At small-household scale a continuously maintained ledger is rarely worth the maintenance; labelled estimates inside a weekly or monthly report—produced by a one-shot script that reads the same logs—are sufficient to guide decisions and avoid over-investment in brittle free-layer scripts.

4. Script Copying / Routing / Carrying

Safe for the free layer: pure relocation of already-finalized artifacts (copy or move from a staging directory into an archive, route a completed research folder into a dated tree, delete only from explicitly marked temporary locations). Must stay at the agent layer: any move that interprets content, renames according to semantic rules, merges, deduplicates, or decides retention. Safeguards required on the free side: atomic rename or copy-then-verify, mandatory staging directories that are never the primary record store, automatic orphan recovery that re-queues any file left in staging beyond a timeout, and a hard ban on destructive operations (delete, truncate, overwrite) against any path that is not under a disposable prefix.
