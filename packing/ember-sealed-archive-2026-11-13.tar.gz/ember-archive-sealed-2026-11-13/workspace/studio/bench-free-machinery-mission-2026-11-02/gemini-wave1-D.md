# Red-Teaming the Mechanical Layer: Limits, Hazards, and Boundaries

The free mechanical layer—composed of cron jobs, shell scripts, regex checks, and file watchers—is an indispensable buffer. It protects the household from burning metered LLM tokens on empty cycles. However, because it costs nothing to run, it is dangerously easy to over-trust. 

A shell script has **zero situational awareness**. It evaluates structure, not meaning; presence, not validity; syntax, not semantics. 

---

## 1. The Golden Rule: What a Script Must Never Decide

> **A mechanical script must never judge state, quality, intent, or consequence. It may only detect structural transitions.**

* **Allowed (Shape Detection):** *"File X was modified," "HTTP status is 200," "Directory contains 4 PDFs," "Regex matched a timestamp."*
* **Forbidden (Judgment):** *"The research is complete," "The reply is urgent," "The data is valid," "The file is safe to delete."*

If a decision requires understanding **context**, **implication**, or **truth**, it belongs strictly to the agent or human layer.

---

## 2. Deep-Dive Hazards & Countermeasures

### Hazard 1: Silent Rot (The Dead Tripwire)
* **How it bites:** A polling script fails silently—due to an unhandled permission error, a changed directory path, a broken dependency, or an API returning a `200 OK` with an error payload (`{"status": "error"}`). Because the script is dead, no trigger condition ever fires. The system appears calm and operating smoothly, but critical tasks (like collating land research or processing incoming mail) rot indefinitely. A dead tripwire looks identical to a quiet world.
* **Countermeasures:**
  * **Watchers for the Watchers (Mechanical Canaries):** Synthetic events generated on a schedule (e.g., a daily dummy file written to the land research incoming folder) that *must* be caught and logged by the watcher script.
  * **Dead-Man Switches:** Central monitoring script that checks script execution logs. If `check_land_research.sh` hasn't updated its timestamp log in 15 minutes, trigger an alert.
  * **Explicit Fail-Open / Fail-Log:** Scripts must log positive executions, negative evaluations, and errors to a single health register.

### Hazard 2: False-Positive Runaways (Token Drain)
* **How it bites:** A trigger fires, waking an agent to perform a task (e.g., collating research files). The agent wakes, encounters an error (e.g., a corrupt PDF), and crashes before moving or clearing the source files. Two minutes later, the polling script runs again, sees the exact same uncollated files, and schedules *another* wake. The loop repeats indefinitely, burning dollars in tokens while the household sleeps.
* **Countermeasures:**
  * **Trigger Quarantines & Lock Files:** When a script schedules an agent wake, it creates a `.processing` lock or moves the triggering files to a staging area immediately.
  * **Wake Budgets:** Hard limits enforced at the mechanical layer. A single polling script may only schedule $N$ wakes per hour/day. If exceeded, the script trips a breaker and notifies human/agent channels.
  * **Back-off Schedules:** One-shot schedules must use exponential back-off if the expected outcome (e.g., file cleared) isn't achieved after the wake session completes.

### Hazard 3: Epistemic Slip (Conflating Shape with Truth)
* **How it bites:** The research polling script checks if four files exist in `/incoming/land_research/` and assumes "research is ready to collate." In reality, one file is a 0-byte network timeout artifact, and another is an error page HTML renamed to `.pdf`. The script schedules the agent wake. The agent, trusting the mechanical layer's implicit assertion that "data is ready," blindly ingests the garbage into the curated markdown memory.
* **Countermeasures:**
  * **Agent-Side Verification Step:** The mechanical layer's wake prompt is purely a proposal: *"Script noticed 4 files in incoming. Evaluate and collate if valid."*
  * **Two-Stage Ingestion:** Agents must run explicit assertion checks (non-zero size, valid header schemas, reasonable file structures) before incorporating triggered inputs into primary memory or actions.

### Hazard 4: Brittle Contracts & Format Drift
* **How it bites:** A public price-watcher endpoint changes its JSON structure from `{"price": 100}` to `{"data": {"current_price": 100}}`. The shell script's `jq` parser fails, falling back to an empty string. Depending on the script's error handling, it either stays silent forever (Hazard 1) or continuously wakes the agent with empty state payloads (Hazard 2).
* **Countermeasures:**
  * **Drift Checkers:** Periodic mechanical assertions that run against external schemas. If an input format does not match a rigid expected pattern, drop it into an `unparsed/` queue rather than silently failing.
  * **Schema Guardrails:** If a parser output is null/empty, the script aborts immediately without scheduling an agent wake, logging a "schema mismatch" warning.

### Hazard 5: Unjudged Execution (Action Without Sight)
* **How it bites:** To save tokens, a script is given permission to *do* something rather than just *wake* an agent—such as "automatically delete research files older than 7 days" or "automatically post a confirmation HTTP request when state is done." A logic flaw causes the script to wipe the active research folder instead of the archive folder, destroying state with zero model overhead.
* **Countermeasures:**
  * **Read-Only / Schedule-Only Isolation:** The mechanical layer is strictly sandboxed. It can **Read** local paths/APIs, **Write** its own execution logs/locks, and **Schedule** agent wakes. It has **zero write/delete authority** over household memory, external communication APIs, or raw research files.
  * **Hard Kill Switches:** Global environment flag (`MAINTENANCE_MODE=true`) that immediately disables all mechanical execution and one-shot scheduling.

---

## 3. Non-Delegable Decisions: The Judgment Layer Boundary

The following decisions must **never** be automated in bash, Python scripts, or cron logic, no matter how predictable they appear:

| Task / Decision | Why Mechanics Fail | Minimum Execution Layer |
| :--- | :--- | :--- |
| **Pruning / Archiving Memory** | A script cannot tell if a markdown note is "outdated" or a "core long-term principle." | **Agent + Human Review** |
| **External Communication** | Sending emails, messaging external parties, or publishing public API posts. | **Agent (Draft) + Human (Send)** |
| **Resolving Data Conflicts** | Deciding which of two contradictory price reports or research returns is correct. | **Agent Layer** |
| **Compliance & Quality Scoring** | Deciding if weekly progress/compliance numbers meet quality standards. | **Agent Layer** |
| **Destructive File Operations** | Unlinking, overwriting, or moving primary records (outside of raw temp dumps). | **Agent Layer (with constraints)** |
| **Contextual Priority Assignment** | Deciding if a newly arrived message warrants breaking a scheduled task. | **Agent Layer** |

---

## Summary Matrix

```
[ Raw Event / File State ]
           │
           ▼
┌──────────────────────────────────────┐
│  MECHANICAL LAYER (Zero Tokens)      │
│  - Detects shape / presence          │ ──► [ Fails Schema? ] ──► Log to Error Queue (No Wake)
│  - Checks rate limit / wake budget   │ ──► [ Rate Exceeded? ] ─► Trip Kill-Switch Alert
└──────────────────────────────────────┘
           │
           ▼ (Schedules One-Shot Wake)
┌──────────────────────────────────────┐
│  JUDGMENT LAYER (Metered Tokens)     │
│  - Verifies truth and file integrity │ ──► [ Invalid Data? ] ──► Move to Quarantine (No Memory Write)
│  - Synthesizes, evaluates, acts      │
│  - Clears locks / moves processed    │
└──────────────────────────────────────┘
```
