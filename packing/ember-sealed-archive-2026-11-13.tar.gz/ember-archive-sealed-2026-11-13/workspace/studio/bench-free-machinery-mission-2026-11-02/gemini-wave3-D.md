# Angle W3-D: The Net Watching Itself

A zero-token layer of shell scripts, event hooks, and pollers provides high-frequency monitoring at zero model cost. However, deterministic tripwires decay: file paths change, public APIs update their schemas, permissions drift, and cron jobs silently fail. 

To prevent this layer from rotting silently without spending tokens to continuously check it, the monitoring infrastructure must monitor itself using the same zero-token principle.

---

## 1. The Wire Census

Every script, watcher, and polling loop in the system must be registered in a single, machine-readable manifest (`wire_census.json`). Unregistered wires are treated as rouge processes and flagged during audits.

### Census Schema
```json
{
  "wire_id": "poll_bench_research",
  "script_path": "/ops/wires/poll_bench.sh",
  "schedule": "*/2 * * * *",
  "owner_agent": "research_agent",
  "max_staleness_hours": 24,
  "last_successful_run": "2026-03-30T14:02:00Z",
  "probe_script": "/ops/canaries/probe_bench.sh"
}
```

### Key Metadata
* **Owner Agent:** The specific AI agent responsible for interpreting the outputs or fixing the script if it breaks.
* **Max Staleness Date/TTL:** The maximum allowable duration a wire can go without either executing successfully or validating its target state.
* **Probe Link:** The zero-token validation script associated with this wire.

---

## 2. Canary Probes (Known-Input Testing)

A wire cannot be assumed healthy just because its execution returned exit code `0`. A script checking an empty directory or parsing a broken HTML layout will also exit `0` while failing to do its job. 

Every wire requires a synthetic probe that injects a known input and verifies the deterministic output *without* triggering a real agent wake-up or burning tokens.

### Probe Mechanics
* **Mock Injection:** Probes write a dummy file (e.g., `.canary_sample.json`) to a isolated temp path or hit a controlled local mock endpoint.
* **Dry-Run Flags:** Scripts support a `--dry-run` or `CANARY_MODE=1` environment variable. In this mode, when the script detects the condition, it writes to a canary log or stdout instead of posting to the agent's wake queue.
* **Assertion Check:** The canary harness asserts that:
  1. The input was detected within 1 execution cycle.
  2. The generated event payload matches expected JSON/markdown schemas.
  3. No actual agent wake schedule was created.

---

## 3. Mechanical Audits & Self-Filed Tickets

A lightweight, local cron job runs once daily at midnight. It executes strictly in bash/AWK (zero tokens) to audit the entire net.

### The Mechanical Audit Process
1. **Probe Execution:** Runs every `probe_script` listed in `wire_census.json`.
2. **Staleness Check:** Compares `last_successful_run` against `max_staleness_hours`.
3. **Registry Check:** Scans active crontabs and systemd timers against `wire_census.json` to detect unlisted wires or dead registrations.

### Health Report Output
The audit generates a mechanical numerical summary stored in `/ops/reports/net_health.json` and appended to the local daily system log:

```text
=== NET HEALTH AUDIT: 2026-03-30 ===
Total Wires Tracked: 18
Healthy / Passing:   16
Stale Wires:         1 (watch_price_gpu)
Failed Probes:       1 (poll_bench_research)
Net Availability:    88.8%
====================================
```

### Self-Filed Repair Tickets
When a probe fails or a wire exceeds its staleness threshold, the audit script generates a structured markdown file in `/ops/tickets/open/`:

`TICKET-poll_bench_research-20260330.md`
```markdown
---
ticket_id: TICKET-20260330-01
wire_id: poll_bench_research
owner_agent: research_agent
failure_type: PROBE_FAILURE
detected_at: 2026-03-30T00:00:01Z
---
### Failure Details
Canary probe `/ops/canaries/probe_bench.sh` failed.
Expected trigger output on sample file `.canary_sample.json`, but received exit code 2 (Directory structure missing).
```

---

## 4. What Needs an Agent's Eyes (and How Rarely?)

The deterministic layer detects *breakage* (syntax errors, missing directories, failed probes), but it cannot detect *semantic drift* or *loss of utility*. An agent's eyes are expensive and must be reserved strictly for judgment, not monitoring.

### When the Agent is Invoked

1. **Reactive Repair (On Failure):**
   * **Trigger:** A ticket drops into `/ops/tickets/open/`.
   * **Mechanism:** The next scheduled session of the `owner_agent` checks the ticket folder. It opens the broken script, reads the failure output, rewrites the shell logic or updates paths, tests the probe, and closes the ticket.
   * **Frequency:** As needed (typically 0–2 times per month).

2. **Proactive Semantic Review (Scheduled):**
   * **Trigger:** A dedicated monthly meta-maintenance job.
   * **Task:** The agent reads the `wire_census.json` alongside the household's higher-level goal documents.
   * **Questions evaluated:**
     * *Is this wire still useful?* (e.g., "We stopped tracking GPU prices three weeks ago, but the poller is still running.")
     * *Has the environment changed fundamentally?* (e.g., "The research source moved from local folders to an API endpoint.")
     * *Are wires firing too often without agent action?*
   * **Frequency:** **Once per month**, using a strict 5-minute/token budget allocated during an existing off-peak routine session.

### Summary Balance

| Layer | Responsibility | Token Cost | Frequency |
| :--- | :--- | :--- | :--- |
| **Shell/Pollers** | State detection & canary probes | Zero | Every 2–5 minutes |
| **Mechanical Audit** | Tabulating health metrics & filing tickets | Zero | Daily |
| **Agent (Reactive)** | Fixing broken scripts & resolving tickets | Low (Metered) | Event-driven (Rare) |
| **Agent (Proactive)** | Pruning unused wires & re-aligning intent | Low (Metered) | Monthly |
