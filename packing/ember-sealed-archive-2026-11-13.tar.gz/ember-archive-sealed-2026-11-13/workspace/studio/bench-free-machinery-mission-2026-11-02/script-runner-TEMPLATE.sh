#!/usr/bin/env bash
# Script-runner: __WIRE__ (de-wrapper, Block 2 batch 2, 2026-11-02).
# Runs the wire's command directly on its due rule: silent on success
# (heartbeat recorded), __FAIL_SHAPE__ on failure.
# Fixture: a file named "force" in the state dir makes the next poll due
# (consumed by the run) — the wire's synthetic probe.
set -euo pipefail
source "$HATCH_HOOK_RUNTIME"

STATE="$HOME/hooks/state/script-runner-__WIRE__"
mkdir -p "$STATE"
LAST="$STATE/last_run"
FORCE="$STATE/force"

if [[ "${HATCH_HOOK_DRY_RUN-0}" == "1" ]]; then
  silent "dry run: no execution, no state writes"
fi

now="$(date +%s)"
last=0
[[ -f "$LAST" ]] && last="$(cat "$LAST")"

due=0
if [[ -f "$FORCE" ]]; then
  due=1
__DUE_RULE__
fi

if [[ "$due" -eq 0 ]]; then
  silent "__WIRE__ not due"
fi

out="$STATE/last-stdout.txt"
err="$STATE/last-stderr.txt"
set +e
bash -c '__CMD__' >"$out" 2>"$err"
rc=$?
set -e
echo "$now" > "$LAST"
rm -f "$FORCE"

if [[ "$rc" -eq 0 ]]; then
  "$HOME/workspace/bin/with-usage.sh" "$HOME/workspace/bin/watcher-health.py" \
    heartbeat __WIRE__ --outcome ok \
    --note "script-runner completed" >/dev/null 2>&1 || true
  silent "__WIRE__ ran ok"
fi

"$HOME/workspace/bin/with-usage.sh" "$HOME/workspace/bin/watcher-health.py" \
  heartbeat __WIRE__ --outcome error \
  --note "script-runner exit $rc; stderr in hook state" >/dev/null 2>&1 || true
__FAIL_ACTION__
