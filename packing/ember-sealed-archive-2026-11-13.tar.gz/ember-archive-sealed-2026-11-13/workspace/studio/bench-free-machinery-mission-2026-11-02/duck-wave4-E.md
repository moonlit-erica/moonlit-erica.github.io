Frontier hybrid architectures

The strongest pattern is deterministic machinery for observation, bookkeeping, and reversible operations; metered agents for interpretation, prioritization, and decisions with ambiguous consequences. Scripts should produce evidence and bounded proposals—not silently turn weak signals into consequential actions. Every handoff should be inspectable, replayable, and safe to retry.

1. Evidence-to-decision pipeline

Components: event watchers; a durable event queue; a normalizer that gathers relevant records; a proposal builder; an agent; a policy gate; an action runner; an audit log.

Data flow: A watcher detects a concrete state change and writes an event with a stable ID, timestamp, source, and observed values. The normalizer gathers the smallest relevant evidence bundle and records where each item came from. The proposal builder summarizes the task and links to the evidence. The agent recommends an action—or asks for more evidence. A deterministic policy gate checks permissions, required evidence, and action limits before execution.

What the agent still does: interpret ambiguous material, weigh competing priorities, identify missing context, and explain its decision.

What could go wrong: a watcher misses or duplicates an event; a summary omits a decisive detail; the agent treats an untrusted input as an instruction; or a retry repeats an action. Use durable queues, idempotency keys, source links, explicit “insufficient evidence” outcomes, and policy checks that do not depend on the agent’s confidence alone.

2. Mechanical pre-graders and quality gates

Components: task-specific checkers; a rubric stored as versioned rules; an agent output format; a grader report; escalation thresholds.

Data flow: The agent returns work with its claims, evidence references, and any uncertainty. Mechanical checks test properties that can be checked mechanically: required fields, valid references, counts, file presence, schema conformity, and agreement with known state. The system routes clean cases onward, requests a bounded correction, or flags a human review.

What the agent still does: produce and revise the work; interpret whether evidence supports a conclusion; handle exceptions the checks cannot express.

What could go wrong: passing the checks is mistaken for correctness; the rubric rewards easy-to-measure properties; or the agent learns to satisfy the format while missing the substance. Keep “mechanically valid” distinct from “judged correct,” sample passing work for human review, and measure false passes as well as caught errors.

3. Trigger-first household with health sentinels

Components: event-driven triggers for positive changes; a small set of periodic health checks; a durable event ledger; dependency tracking; retry and rate-limit controls; a dead-letter queue for unresolved events.

Data flow: Most work starts on an observed event, such as a completed return or changed reply status. Each event advances a named workflow state. Periodic sentinels are retained specifically to detect missing events, stalled work, and broken watchers. Failed or expired events are surfaced rather than silently discarded.

What the agent still does: resolve ambiguous cases, summarize accumulated changes, and decide what to do when a workflow is stuck or conflicting.

What could go wrong: no event arrives for something that should have happened; one noisy source creates a cascade; or a workflow waits forever on a lost dependency. Treat timeouts and periodic checks as explicit failure-detection events, not ordinary work schedules. Add per-source rate limits, deduplication, maximum retries, and a circuit breaker that pauses a noisy branch.

4. Mission-level token and outcome ledger

Components: event and action IDs; measured model usage; labeled counterfactual estimates; outcome labels; a periodic review.

Data flow: Record actual tokens and agent wakes by mission. Separately record the mechanical actions that prevented a wake, with the estimated baseline method and assumptions. Later, attach outcomes such as completed, corrected, escalated, or abandoned. Report measured usage separately from estimated avoided usage.

What the agent still does: review ambiguous mission categories, explain unusual cases, and help assess whether the automation achieved the intended outcome.

What could go wrong: the counterfactual assumes an agent would have done work that nobody would actually have requested; estimated savings are presented as measured savings; or token reduction becomes the goal even when quality falls. Keep assumptions visible, track error and escalation rates alongside savings, and do not count “avoided work” unless a comparable prior task or agreed baseline supports it.

5. Self-maintaining automation

Components: a catalog of scripts and their inputs; health checks; expected-output checks; version and dependency records; a ticket generator; a review queue.

Data flow: A checker compares the declared contract of each script with observed behavior—for example, whether expected inputs exist and outputs remain within a known schema. A failure creates a repair proposal containing the check, logs, and recent changes. An agent can diagnose and draft a patch; tests and an approval gate control deployment.

What the agent still does: interpret unfamiliar failures, propose repairs, and assess whether a contract should change.

What could go wrong: a checker is itself stale; a generated repair masks the symptom; or a script modifies its own checks to pass. Keep monitoring independent from the script being monitored, preserve prior versions, test repairs in a separate environment, and require approval for changes that expand permissions or alter data handling.

1. PROPOSAL ENGINE

A 300-token proposal can save substantially over a 10,000-token discovery prompt only when the omitted material is not needed to make the decision. If the agent cannot inspect the underlying evidence, it may approve a plausible summary while missing a contradiction, stale value, or important exception. The reliable saving is often not “hide the evidence,” but “show a concise proposal and make targeted evidence retrieval cheap.”

A sound proposal should include the requested decision, the reason it fired, the key facts, timestamps, source references, known conflicts, and a clear option to request more evidence. Keep the underlying evidence available through bounded retrieval; the agent should be able to inspect the decisive source items rather than accept the summary on trust.

Useful controls:

Rate limits: cap proposals per source and per time window; deduplicate equivalent events; pause a source after repeated failures or bursts.
Staleness checks: attach source timestamps and versions; reject or refresh evidence outside a task-specific freshness window; recheck state immediately before consequential action.
Context-pruning fences: never prune the triggering fact, its source and timestamp, relevant exceptions, unresolved conflicts, or the evidence needed for the requested decision. Record what was omitted and why.
Decision boundaries: allow “approve,” “reject,” and “need more evidence”; require a second check or human approval for irreversible or high-impact actions.

This design fails outright when the decision depends on holistic context that the proposal cannot preserve, when sources are unreliable or adversarial, or when the cost of a false approval is high and evidence cannot be independently checked. In those cases, use the proposal as an index into the evidence, not as a substitute for it.

2. EVENT-DRIVEN CASCADES

A system cannot detect that an expected event never happened using only positive triggers. Preserve a small clock-based watchdog layer for absence detection: deadlines, heartbeats, lease expiry, and periodic reconciliation. The goal is not to eliminate clocks, but to reserve them for detecting silence and drift.

Represent each workflow as a state graph with explicit expected transitions. When a node starts, record its expected completion condition and deadline. If the condition is not met by then, the watchdog emits a timeout event, marks the node stalled, and routes it to retry, escalation, or review. Also periodically reconcile upstream state with downstream expectations, so a silently lost event can be reconstructed.

Bound cascades with:

Per-event IDs and idempotent handlers.
Maximum depth, retries, and total work per workflow.
Per-source and per-branch rate limits.
Dead-letter handling for repeated failures.
Circuit breakers that pause a branch when errors or volume exceed limits.
A manual or scheduled reconciliation path for missed events.

Without a clock or some independent heartbeat, absence is unobservable. A fully clockless design can work only where every relevant state change is guaranteed to emit a durable event and delivery failures are independently detectable.

3. TOKEN ACCOUNTING

Pin the baseline before counting savings. A useful baseline is a documented, repeatable estimate of the agent work the mechanical action actually replaces: the prior workflow, a representative sample of comparable tasks, or an agreed task-specific estimate. Do not count every script action as a full agent wake if the old process would have bundled several actions into one session—or if nobody would have asked the agent to do it.

Keep three quantities separate:

Measured actual usage: agent wakes and tokens observed.
Estimated counterfactual usage: what the defined baseline predicts would have been used.
Outcome quality: completion, correction, escalation, delay, or error.

Label assumptions and uncertainty; review estimates against sampled tasks; and include maintenance, failures, and repair work in the cost picture. This discourages brittle scripts that look cheap only because their errors and upkeep are omitted.

At small-household scale, a full accounting system may cost more to maintain than it teaches. Start with a lightweight report: mission, mechanical actions, agent wakes avoided by the stated baseline, actual agent tokens, and outcome. Build a more formal ledger only if the estimates are driving meaningful decisions or need auditability.

4. SCRIPT COPYING / ROUTING / CARRYING

The free layer is appropriate when the operation is mechanical, the destination rule is explicit, and mistakes are recoverable. The agent layer is appropriate when the move depends on meaning, identity, ambiguity, or judgment about what should be retained.

Safe for scripts: copy files into a known staging area; route by stable IDs or declared metadata; add deterministic filenames; archive a verified duplicate; move a completed item into a workflow folder when a recorded state explicitly calls for it. Prefer copy-then-verify over move-then-hope.

Keep at the agent or human decision layer: deciding which of several similarly named records is authoritative; inferring an owner or topic from ambiguous content; resolving conflicting versions; deciding whether a record is obsolete; and any deletion or overwrite of a primary record based on interpretation.

Safeguards for the mechanical side:

Use atomic rename within a filesystem where possible; otherwise copy, verify size or checksum, then mark the source as handled.
Stage changes before committing them, and log source, destination, reason, timestamp, and event ID.
Make operations idempotent so retries do not create duplicate or conflicting results.
Preserve a manifest or receipt that enables orphan detection and recovery after interruption.
Never destructively modify primary records; use versioned copies, reversible archives, and explicit retention policies.
Quarantine unexpected files or destination conflicts instead of guessing.
Provide a dry-run mode and periodic reconciliation against the routing rules.

The practical line is: scripts may carry records according to explicit rules; they should not decide what the records mean or irreversibly discard the originals.
