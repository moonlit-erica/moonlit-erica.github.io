# COLLATION — Bench free-machinery mission, Wave 3 (Gemini seat) — the WEAVING pass

Collated: 2026-11-02 04:37 CST (America/Chicago)
Returns checked: five Wave 3 returns, Angles A–E, landed 2026-11-02 ~04:29 CST
Landed-to-collated lag: 8 minutes (04:29 CST → 04:37 CST 2026-11-02)
Check method: every item below is supported by a named return as written, with its stated mechanism and failure modes. Overlapping designs across returns are noted as one item with multiple sources, not counted twice. No item enters this backlog on collator invention.
Fence applied throughout: outputs bound for Erica's books stay abstract about sources; nothing about any person's state appears in this collation.

## Angle E's verdict on the safety-net thesis — at the top, whole

Thesis as put to Angle E: "enough tripwires laced together become a safety net."

**E's verdict: the thesis is neither universally true nor universally false — it holds only under concrete structural conditions, and calling the layer a safety net without them is a dangerous category error.** A network of cheap scripts is, in E's closing words, effective for *reducing agent invocation latency and saving tokens*; scripts provide *triggering mechanics*, not safety. A script can verify that a file arrived; it can never verify that the system is sane.

**Where the thesis holds (real safety) — E §4, all four conditions:**
1. **Out-of-Band Dead-Man Switches** — external heartbeats exist; if the local machine or scheduler dies, an external ping fails and raises an out-of-band alarm.
2. **Fail-Explicit Design** — failure to execute or return a result generates an immediate, noisy alert, rather than resolving to a quiet "no action required" state.
3. **Strict Isolation of Invariants** — tripwires check unambiguous, binary physical invariants (e.g. disk space, process exists) rather than inferring complex state from fragile string matches.
4. **Scheduled Human Auditing** — the operator treats tripwires strictly as *latency-reduction tools* (waking agents faster), not *verification tools* (proving work was done correctly), and maintains a fixed routine of manual sampling.

**Where it is false comfort (coverage theater) — E §§1–3 and §4, all four failure conditions:**
1. **Shared-Fate Infrastructure** — the single-substrate fallacy (E §1): twenty scripts feel independent but share one host/scheduler (all die together on a hang, panic, or power loss), one filesystem (inode exhaustion, read-only disk, permission drift stop state/lock writes), and one runtime environment (a `bash`/`curl`/`jq`/Python update breaks many paths at once). Add fail-silent behaviour — a broken script exits into an unmonitored log, and the absence of a trigger looks identical to a quiet, nominal world.
2. **Fail-Silent Script Design** — errors default to silent exits, unparsed stdout, or suppressed stderr (E §4).
3. **Semantic Proxy Drift** — script metrics (file presence, line counts, timestamp updates) are used as proxies for task completion or context health (E §4). Two named forms (E §3): the Canary Fallacy — a canary proves the pipe works, nothing about whether content carried through it was accurate, hallucinated, or missed; and the Counter Fallacy — a counter proves logs exist, nothing about whether they contain meaningful work or repeated gibberish.
4. **Unbounded Script Sprawl** — the wire count exceeds the operator's capacity to audit and maintain it (E §4), compounding E §2's complexity debt: scripts monitoring other scripts' artifacts produce phantom cascades, polling a half-written file produces race-condition wakes with corrupted context, and brittle regex/format assumptions rot while the script keeps running and returning empty.

E's psychological mechanism, kept whole because it is the reason the four failure conditions bite (E §3): coverage theater plus automation bias — a fully instrumented dashboard makes the human stop performing manual spot-checks, so mechanical status is trusted as semantic correctness long after the two have diverged.

That verdict governs the ranking below: weaving designs that assume the same host, scheduler, and filesystem can supervise themselves are marked needs-a-second-angle where E's out-of-band condition is unmet (items 16–18), and the two claims E cuts outright are cut here too (items 19–20).

## Headline count

**22 items checked — 15 keep, 3 needs-a-second-angle, 4 cut.**

---

## Ranked weaving backlog

1. **keep — Coverage matrix: primary + orthogonal secondary + deadman window per domain** (A §1) — Every monitored domain gets one primary watcher, one cross-checking watcher, and an explicit silence threshold with a named wake target; this is the map that makes gaps visible at all.
   *Hazard (E §1): the matrix maps coverage on one substrate — a full matrix is not independence; see item 16.*

2. **keep — Dual-path verification by different mechanisms** (A §2, B §4 example) — Primary uses low-latency events (filesystem/push/polling), secondary uses state reconstruction (scan/DB/hash), they share no code, state files, or execution path, and a discrepancy evaluator decides flag/wake.
   *Hazard (A §2 Ex. A): a discrepancy can mean the event watcher broke — the evaluator rewrites the queue and restarts it; the auto-remediation half is bounded by item 21's cut.*

3. **keep — Mandatory heartbeat on every run + central deadman sweeper** (A §3.1–3.2) — Every wire touches its heartbeat file on completion regardless of outcome, and a sweeper every 2 minutes compares heartbeat age against a per-wire maximum; silence itself becomes the signal.
   *Hazard (E §1): the sweeper runs on the same scheduler it watches — it detects a dead wire, not a dead scheduler; see item 16.*

4. **keep — Silence escalation: deterministic self-heal, re-check, then agent** (A §3.3) — On an expired heartbeat: restart/kill the watcher, wait 30 seconds and re-check, and only then spend tokens waking the target agent with logs, error code, and failure duration.
   *Hazard (A §3.3): self-heal is restart-only as returned — a watcher that restarts into the same broken dependency loops; the re-check, not the restart, is what stops that.*

5. **keep — Mechanical disagreement triage: freshness wins, transport failure is not dissent** (B §§1, 3; Pattern B) — A newer valid timestamp supersedes an older payload, and an empty/exit-127 output is quarantined as execution failure, not counted as a conflicting observation.
   *Hazard (B §1): freshness resolves sample latency only — two same-second valid payloads are not resolved by this rule; they fall to items 6–8.*

6. **keep — Quorum rules split by stakes: majority-with-degraded-flag to proceed, unanimous to act high-impact** (B §2; Patterns A, C) — ≥M-of-N agreement proceeds with a degraded flag logged for later review, while N-of-N is required before a high-impact auto-action and a single dissent halts it.
   *Hazard (B, escalation table §4): majority is explicitly unsafe where cost/risk is asymmetric — e.g. 2-of-3 "complete" must not start a heavy run on partial data; that case escalates under item 8.*

7. **keep — Disagreement-as-signal: the STATE_SPLIT synthetic event** (B §4) — When two healthy, synchronous watchers contradict on the same boundary, the split itself is the finding: the mechanical layer generates the event and does not guess which watcher is right.
   *Hazard (B §4): a split proves an invariant was violated, not which side holds ground truth — reconciliation is agent work under item 8.*

8. **keep — The four-condition escalation boundary for disagreement** (B, boundary table) — Disagreement goes up a layer exactly on: semantic ambiguity, irreconcilable concurrent dissent, invariant breach without a failure code, or cost/risk asymmetry; everything resolvable by timestamps, sorting, or math is resolved silently at zero cost.
   *Hazard (B summary): the agent's job on escalation is judge, not watcher-runner — escalations carry the split, not a request to re-poll.*

9. **keep — Four-rung escalation ladder with a hard zero-cost bisection** (C, ladder + rules 1–2) — Rung 1 wire notices, Rung 2 script verifies, Rung 3 one-shot duty agent judges, Rung 4 human decides; anything evaluable by string match, diff, or file size must never land on Rung 3, and four rungs is the stated maximum worth building for a small household.
   *Hazard (C, sizing): intermediate multi-agent consensus rungs add overhead, latency, and token drain without adding real safety, per C's own sizing rule.*

10. **keep — Anti-fatigue fences on the agent→human rung: batch to a daily queue + defensive defaults** (C rule 3; hazard 1) — Non-critical Rung 3→4 escalations append to a daily human queue instead of pushing, and low-stakes ambiguity gets a logged safe fallback at Rung 3 instead of a ping.
    *Hazard (C hazard 1): the exceptions are critical immediate notices (security breach, critical outage) — batching those would trade fatigue for a missed emergency.*

11. **keep — Feedback-loop fences: output-directory isolation + a global wake circuit breaker** (C hazard 3) — Agents write only to directories excluded from Rung 1 watcher masks, and if a wake hook fires more than N times in 10 minutes, Rung 2 locks the trigger and logs it.
    *Hazard (C hazard 3): without both halves, an agent's own output re-triggers its own wake and burns tokens in minutes — isolation prevents the loop, the breaker bounds it if isolation leaks.*

12. **keep — Transient one-shot scheduling with idempotency locks and execution bounds** (A §4.2–4.4) — A firing wire stages a JSON payload and registers a one-shot timer (never an inline agent call), advances tracking state before the wake (rewinding on agent failure), and runs under <200ms file-op and hard curl timeout bounds.
    *Hazard (A §4.2): the built-in delay is also the batching mechanism for rapid sequential events — shortening it for urgency re-opens duplicate wakes the lock exists to prevent.*

13. **keep — Wire census: every wire registered, owned, with a staleness TTL and a probe link** (D §1) — A single machine-readable manifest lists script path, schedule, owner agent, max staleness, last success, and probe; unregistered wires are flagged as rogue at audit.
    *Hazard (D §1): the census is a manifest, not a proof — a registered wire with a stale `last_successful_run` is exactly what item 15's audit exists to catch.*

14. **keep — Canary probe per wire: known input, dry-run, no real wake** (D §2; C hazard 2) — Each wire's probe injects a mock input under `CANARY_MODE`/dry-run and asserts detection within one cycle, a schema-correct payload, and that no actual agent wake was created.
    *Hazard (E §3, canary fallacy): a passing probe proves the wire's path, not the correctness of what real inputs carry — see item 20.*

15. **keep — Daily mechanical audit + numeric net-health report + self-filed repair tickets** (D §3–4.1) — A zero-token daily audit runs every probe, checks staleness and registry, reports totals (tracked / passing / stale / failed probes / availability %), files a structured ticket per failure, and the owner agent repairs reactively on its next session (typically 0–2 times/month per D).
    *Hazard (E §1, D §3): the audit shares the host and scheduler with the wires — its numbers are trustworthy for wire-level breakage, not for substrate failure; see item 16.*

16. **needs-a-second-angle — Out-of-band watchdog for the shared substrate** (E §4 holds-1, §1; against A §3, D §3 as written) — E's first holding condition requires an external heartbeat/alarm, but no A–D return designs one: every deadman, sweeper, and audit in this wave lives on the host it watches.
    *Reason: a second angle must design the external leg — what pings, from where, to whom — before any design in items 3 or 15 is described as covering scheduler/host death.*

17. **needs-a-second-angle — Human semantic audit routine** (E §4 holds-4, §3; against D §4.2 as written) — E requires fixed manual sampling by the operator, while D's only semantic leg is a monthly agent review on a strict 5-minute/token budget asking whether wires are still useful.
    *Reason: D's monthly review checks utility and drift of wires, not correctness of content the net passed — a second angle must state the human sampling cadence and what gets sampled before coverage is claimed as checked.*

18. **needs-a-second-angle — Invariant-only scoping line** (E §4 holds-3; against A §1, C Rung 2 as written) — E holds the thesis only for unambiguous binary invariants, while A/C as returned also weave in fragile proxy checks (parsed prices, file counts, format-dependent endpoints).
    *Reason: a second angle must draw, per domain in the coverage matrix, which checks are true invariants and which are proxies — proxies may still trigger (item 20 fences what they may prove), but they cannot carry safety claims.*

19. **cut — The net itself as a safety net / verification tool** (E, conclusion and §3) — Treating laced tripwires as proof a system is safe is the category error E names: the layer provides triggering and latency reduction, not safety or verification.
    *Reason: no return supports the stronger claim — A–D design detection, escalation, and self-watch, and E shows each of those still fails silently on a shared substrate.*

20. **cut — Semantic proxy metrics as proof of completion or correctness** (E §3, counter and canary fallacies) — File presence, counts, non-empty strings, and a passing canary pipe do not prove content was meaningful, accurate, or complete.
    *Reason: A–D's own designs use these metrics as triggers and structure checks only (A §1, C Rung 2, D §2) — promoting them to verdicts is supported by no return and cut by E directly.*

21. **cut — Forced git stash/rebase as automatic remediation on a memory cross-check failure** (A §2 Ex. B, as written) — On a disk-vs-git discrepancy the return forces a stash/rebase sequence before waking the agent.
    *Reason: that is a high-impact, state-rewriting auto-action taken on a split signal — it violates B's own unanimous-gate rule for high-impact actions (item 6) and belongs behind the item 8 escalation boundary, with the discrepancy preserved, not overwritten.*

22. **cut — Unbounded wire sprawl: adding wires without census, probe, and pruning** (E §2, §4 fails-4) — Each new script multiplies interactions with existing scripts (phantom cascades, races, rot) faster than it adds coverage.
    *Reason: D's census/probe/audit machinery (items 13–15) is the stated precondition for growth; a wire added outside it is, by D's own registry rule, a rogue wire.*

---

## Clusters noted, not merged

- Silence cluster: items 2, 3, 4, and 15 all detect absence, at different scopes — a single fact (dual-path), a single wire (heartbeat), a failed heal (escalation), and the whole net (daily audit). Kept separate because item 16's shared-fate hazard strikes the last three scopes simultaneously and only the first survives it partially.
- Disagreement cluster: items 5, 6, 7, and 8 are one pipeline — triage, quorum, split-as-event, escalation boundary — kept separate because each step has a different failure: freshness cannot resolve concurrency, quorum cannot resolve asymmetry, and a split must not be silently resolved by either.
- Self-watch cluster: items 13, 14, and 15 are D's three legs (registry, probe, audit/ticket). Item 17 is deliberately outside this cluster: it is the leg D does not supply and E requires.

## Next step

Builds happen only on the deciding word named in MISSION.md. This collation is the checked backlog; it authorizes no build by itself.
