# COLLATION — Bench free-machinery mission, Wave 2 (REFUTATION pass)

Collated: 2026-11-02 (America/Chicago)
Returns checked: five Wave 2 refutation returns (A–E), each attacking its own Wave 1 companion return; read against the five Wave 1 returns and COLLATION-wave1.md, all in this folder.
Landed-to-collated lag: 7 minutes (landed 2026-11-02 ~04:28 CST → collated 04:35 CST)
Check method: every verdict below is tied to a named Wave 2 return as written and, where the attack misstates its target, re-checked against the Wave 1 return as written. The attack is evidence, not gospel — overclaims inside the refutations are named in their own section and do not move a verdict.
Fence applied throughout: outputs bound for Erica's books stay abstract about sources; nothing about any person's state appears in this collation.

## Headline count

**18 Wave 1 backlog items re-checked after attack — 10 survived, 5 cut, 3 needs-a-second-angle.**

Wave 1 stood at 11 keep / 4 needs-a-second-angle / 3 cut. The refutation moved the backlog, it did not gut it: the core watch/gate/health patterns survive, mostly with changed build shapes; the three speculative frontier builds and the two blanket forms fall.

---

## SURVIVED (10) — with the wounds that change their build shape

1. **Tripwire polling replacement** (Wave 1 item 1) — SURVIVED, wounded. W2-A and W2-B both keep event-driven arrival detection as strictly superior to polling, but the code as returned in Wave 1 is cut with it (see Cut list): any build carries debounce, an atomic lock / pending-state flag set at fire time, `IN_CLOSE_WRITE` only, and no reliance on `inotify` over network mounts (W2-B).
   *One-line reason: the concept survives both attacks; the un-debounced, un-locked example code does not (W2-A §2, W2-B §Survives 1).*

2. **Completion detector** (Wave 1 item 2) — SURVIVED, wounded. Build shape now includes a hard timeout / TTL with partial-completion escalation (W2-B), an atomic pending flag so sequential landings do not stack duplicate one-shot wakes (W2-D §2.1, W2-C §2.3), a re-arm rule for late arrivals inside the scheduling window (W2-A §3), and script-side sanity checks (non-zero size, header, structured error field) before the wake asserts readiness (W2-A, W2-D).
   *One-line reason: W2-B keeps it by name with the timeout fix, and the race attacks specify mechanism, not a fatal flaw.*

3. **Threshold trigger** (Wave 1 item 4) — SURVIVED, expanded. W2-A's strongest hit lands in this item's favour: statistical trend filtering (moving averages, rolling windows, deviation thresholds) is deterministic work and moves down into the free layer, shrinking the agent-only "trend evaluation" loss Wave 1 Angle A claimed. Hysteresis and fire-once state stand as before (W2-B §Survives 3).
   *One-line reason: the refutation enlarges this item instead of wounding it — basic time-series statistics were never judgment work (W2-A §Overclaims 1).*

4. **Counting, aggregation, and pre-aggregated telemetry** (Wave 1 item 5) — SURVIVED, unwounded. No Wave 2 return attacks it; W2-A's surviving-classification section reaffirms deterministic recognition over standard-format entries, which is exactly this item's stated scope.
   *One-line reason: unattacked, and its Wave 1 caveat (exact only over standard-format entries) already fences the fuzzy case.*

5. **File-shape contract / pre-flight validation** (Wave 1 item 6) — SURVIVED, wounded in two places. (a) The raw-PDF/binary regex claim in Wave 1 Angle B's application is cut — compressed PDF streams do not yield to shell regex (W2-B §1); PDF checking survives only through a real text-extraction step. (b) Structural integrity checks move fully into the script layer: W2-D is right that spending agent tokens on byte-size and JSON-validity checks misallocates the metered layer, so the Wave 1 hazard note assigning those checks to the agent is reversed.
   *One-line reason: schema/header validation is reaffirmed by three returns; only the PDF-regex form and the agent-side placement of integrity checks fall (W2-B §1, W2-D §1).*

6. **Queue-and-trigger batching** (Wave 1 item 8) — SURVIVED, narrowed. W2-B's toxic-context attack is sustained: batching is single-domain only, with per-item failure isolation so one malformed item cannot drop or halt the rest of the batch; cross-domain micro-batching (unrelated replies + lists + log work in one wake) is cut. Priority bypass from Wave 1 stands.
   *One-line reason: the amortisation buy is real, but only inside one domain per wake (W2-B §3).*

7. **Canary probe** (Wave 1 item 9) — SURVIVED, narrowed to one of its three Wave 1 forms. The file-property / signal-analysis form (output size > 0, non-silent, via media tooling) survives — W2-C keeps binary canary probing by name and W2-E keeps media signal checks. Two forms are cut with the item: exact-string speech round-trip comparison (non-deterministic engines will not reproduce a static string verbatim — W2-A §1) and driver exit-code as proof of physical audio output (an accepted buffer proves nothing about amplifier, connection, or volume — W2-B §4).
   *One-line reason: the attacks kill the comparison method and the hardware claim, not the binary property check (W2-A §1, W2-B §4, W2-C §Survives 3, W2-E §Survives 2).*

8. **Watchdog for hung subprocesses** (Wave 1 item 10) — SURVIVED, wounded. W2-B's kill-without-recovery attack is sustained: no bare `SIGKILL` plus lockfile removal without atomic write discipline (temp-file + atomic move as the house write pattern), a terminate-then-kill sequence, and a post-kill state-reconciliation step; per-task-class timeouts from Wave 1 stand.
   *One-line reason: execution bounds survive; the unbacked hard-kill mechanism as returned does not (W2-B §2).*

9. **Dead-man switch and watcher-health register** (Wave 1 item 11) — SURVIVED, kept to one level. W2-B keeps the dead-man switch by name (simple timestamp-age logic). W2-D's attack on recursive watchers-for-watchers is sustained only against a recursive cascade: the build shape is one health register plus one dead-man check over it, with the deliberate-pause state from Wave 1 — no watcher chain beyond that level.
   *One-line reason: the single-level register is reaffirmed; only the recursive reading of the countermeasure falls (W2-B §Survives 4, W2-D §1).*

10. **Copying, routing, and carrying by script** (Wave 1 item 15) — SURVIVED, resolved from needs-a-second-angle. The second angle arrived in this wave: W2-D draws the line Wave 1 lacked — deterministic post-processing (atomic moves on success, log rotation, temp and lockfile cleanup) belongs in the free layer, and a blanket read-only ban wastes agent tokens on file chores; W2-A keeps routing by static path / exact filter by name. The other side of the line stands unchanged: content-aware routing and any destruction or movement of primary records stay in the agent layer, and staging moves need an orphan-recovery sweep so a crashed wake cannot strand files in a processing folder (W2-D §2.2).
    *One-line reason: the refutation supplied the exact boundary the Wave 1 collation said was missing (W2-A §Survives 2, W2-D §§1, 4).*

---

## CUT (5)

11. **Proposal engine as written — 300-token blind approval over a database queue** (Wave 1 item 12) — CUT. W2-E's circularity attack is sustained against the design as returned: an agent asked to sanity-check a proposal it cannot see the evidence for is a rubber stamp, and stripping the context is the design's stated saving, so the flaw is structural, not a tuning problem; the database queue for a household-scale spool is bloat on top. A revival would be a new design carrying its evidence payload, with its savings re-proved — it does not inherit this item's place in the backlog.
    *One-line reason: context starvation is load-bearing in the design as written, so the attack removes the design, not a detail (W2-E §1, W2-C §1B).*

12. **Pure event-driven cascades replacing clocks wholesale** (Wave 1 item 13) — CUT as a wholesale replacement. W2-E's negative-event attack is decisive: an event that does not happen fires no trigger, so absence detection requires a clock; removing clocks removes the timeout and dead-man coverage the rest of the backlog depends on. Event cascades themselves survive inside items 1–3 above as a hybrid (events fire, clocks audit absence) — what is cut is the zero-clock dogma and the "enterprise latency / service-bus equivalence" framing with it (W2-C §3).
    *One-line reason: a trigger-only system cannot detect its own silent failures, which is the hazard the whole health cluster exists to catch (W2-E §1 Arch 3).*

13. **Counterfactual token accounting engine** (Wave 1 item 14) — CUT as a built subsystem. W2-E's attack is sustained on build-worth: a dedicated ledger/database/dashboard apparatus to total hypothetical savings costs real maintenance and can spend metered tokens reviewing imaginary ones, and Wave 1 already flagged its baseline as an estimate that can mislead build choices. Informal estimates in a collation (clearly labelled estimates, as in Wave 1) are untouched by this cut; the engine is.
    *One-line reason: the measurement apparatus outgrows the thing measured at household scale (W2-E §1 Arch 4).*

14. **Immune-system auto-repair with auto-overwrite of production scripts** (Wave 1 item 16) — CUT, stands and reinforced. W2-E adds the sharpest form of the hazard: a patch that exits cleanly while silently changing what data is captured or where it goes — corruption that no sandbox pass catches. The surviving half is unchanged from Wave 1: deterministic error-ticket generation (script source, error output, recent payload packaged for review) survives by name in W2-E; repair and overwrite stay with the agent/human layer on a visible diff.
    *One-line reason: two independent waves reach the same cut, and the refutation names a failure mode (silent logical drift) the first wave missed (W2-E §1 Arch 5).*

15. **Script-layer judgment** (Wave 1 item 17) — CUT, stands, boundary refined. No Wave 2 return revives pruning memory by content, sending external communications, resolving conflicting returns, scoring quality, or assigning priority by script; W2-A and W2-E both reaffirm those as the agent layer's non-mechanical categories. The refinement is a subtraction, not a revival: deterministic cleanup and atomic file chores are not judgment and are removed from this cut's scope — they live in item 10 above.
    *One-line reason: the refutation narrows what counts as judgment; it does not move any actual judgment into the free layer (W2-A §Survives 3, W2-D §4, W2-E §3).*

---

## NEEDS A SECOND ANGLE (3)

16. **State diffing and delta-only wakes** (Wave 1 item 3) — NEEDS A SECOND ANGLE on scope. The returns conflict and each is partly right: W2-A shows canonicalisation (sorted-key JSON normalisation before hashing) deterministically removes the key-reorder/whitespace false diffs Wave 1 Angle A listed as a loss; W2-B shows raw diffing of live web pages is a false-positive machine and cuts the pattern as written for that scope; W2-C adds that delta-only payloads can starve the agent of baseline context it needs, forcing secondary reads. Local static files and canonicalised structured APIs look survivable; live web state does not — a second angle must draw that scope line and specify what baseline context rides with a delta before any build.
    *One-line reason: three attacks, three different scopes, no single verdict covers all of them as written (W2-A §Overclaims 2, W2-B §§1–2, W2-C §1B).*

17. **Deterministic grader / post-flight linting** (Wave 1 item 7) — NEEDS A SECOND ANGLE on the retry path. The gating half survives in the returns (W2-E: mechanical QC before anything is committed to long-term records prevents corruption; auto-fixable formatting should be fixed by deterministic tools for free, never by an agent micro-retry). The re-enqueue half is attacked from two sides as an uncapped token-burn loop (W2-B §5, W2-C §2.1), and Wave 1's retry cap was asserted without a number or an escalation target. A second angle must fix the cap, the escalation, the auto-fix-first order, and which checks (if any) a platform's native structured output genuinely covers — before build.
    *One-line reason: gate survives, loop does not, and the boundary between them is exactly what no return specifies (W2-B §5, W2-E §1 Arch 2).*

18. **Pushing semantic, fuzzy, and trend interpretation down to scripts** (Wave 1 item 18) — NEEDS A SECOND ANGLE, partially overturned. The trend portion of the Wave 1 cut is overturned: statistical trend work moves down (see item 3 above). The semantic and fuzzy portions stand unrevived — W2-A itself reaffirms synthesis, ambiguity resolution, and qualitative evaluation as agent work. What no return draws is the exact line inside "trend": which operations are statistics (deterministic) and which are context (judgment). That line must be drawn before the expanded threshold item is built on it.
    *One-line reason: the refutation splits this cut in half and leaves the split-point unspecified (W2-A §§Overclaims 1, Survives 3).*

---

## Where the refutation itself overclaims — attack discounted, verdict unchanged

- **W2-B, grader "obsolete" claim:** that native structured-output support in model APIs makes an external grader unnecessary overclaims — a generation schema does not check cross-file totals, link targets, or table arithmetic of the kind Wave 1 Angle B §10 specified. This overclaim is why item 17 is second-angled rather than cut on W2-B's word.
- **W2-B, web-diff "100% of the time":** the raw-diff false-positive claim is stated as a certainty; Wave 1 Angle B §2 as written already specified stripping dynamic elements and used a stable status page as its application. The attack's direction holds for arbitrary live pages; its certainty does not — hence scope second angle (item 16), not a blanket cut.
- **W2-A, stack-trace detection:** a marker search or a structured error-field check catches the traces that announce themselves in those forms; it does not deterministically catch every internal-error payload, so Wave 1 Angle A §2's "cannot detect" is narrowed, not reversed. Item 2's build shape takes the check; the collation does not take the certainty.
- **W2-A, canary "strawman":** the claim that no real architecture spends agent tokens on pipeline health is contradicted inside Wave 1 itself (Angle B §9's scheduled morning check is a stated application). The exact-match mechanism still falls on the non-determinism point; the padding charge does not land.
- **W2-D, recursive monitoring:** Wave 1 Angle D proposed one canary level plus one dead-man register, not an unbounded watcher regress; the attack hits a stronger version than the one written. Item 9's shape is capped at one level as a precaution, but the register was not cut on a regress it never proposed.
- **W2-D, wake budgets "no mechanism":** the missing-mechanism charge is fair as written — Wave 1 asserted budgets and back-off without specifying their state store. It is a specification gap (a persistent tally file is the obvious candidate), not proof the guardrail is impossible; the guardrail itself survives in W2-D's own surviving list.
- **W2-E, accounting numbers "fake":** counterfactual baselines are estimates with real error bars, not fictions; item 13 is cut on apparatus cost and incentive risk, not on the numbers being invented.

## Code and claims cut inside otherwise-surviving items (not counted separately)

- Un-debounced `inotifywait` loops and bare `at`-job scheduling as production examples (W2-A) — cut as examples wherever they appear in Wave 1; the patterns they illustrated survive in items 1–2 with the mechanisms above.
- "Enterprise latency on a micro-budget" and "action mathematically guaranteed" framings (W2-C) — cut as claims; presence/shape detection guarantees a wake condition fired, never that the data is actionable.
- Cross-domain micro-batching (W2-B) — cut inside item 6.
- Exact-string audio round-trip and driver-code-as-hardware-proof (W2-A, W2-B) — cut inside item 7.

## Next step

Builds happen only on the deciding word named in MISSION.md. This collation authorizes no build by itself. Items 16–18 are the second-angle queue for the next wave that takes them up.
