# Refutation Pass: Companion Return Attack

The companion catalog provides a clean taxonomy on paper, but it suffers from a fatal flaw common to architectural blueprints: **it treats shell scripting and Unix utilities as zero-cost, error-free primitives while ignoring the messy reality of state, web volatility, and LLM edge cases.** 

It repeatedly claims "deterministic" safety while describing mechanisms that will either deadlock, burn tokens through infinite retry loops, or fail silently.

---

## Core Attacks: Overclaims, Weak Claims, & Missing Mechanisms

### 1. Naïve Web Parsing & Binary Extraction
* **Pattern Affected**: *State Diffing* (#2) & *File-Shape Contract* (#3)
* **The Overclaim**: Claiming a shell script can run `diff`/`cmp` on raw web pages or use simple `grep`/regex on downloaded PDFs to decide whether to wake an agent.
* **The Flaw**: 
  * **Web Pages**: Modern web pages are dynamic JS bundles. A raw `curl` with standard `diff` will trigger on volatile CSRF tokens, dynamic nonce classes, tracking pixels, and timestamp footers 100% of the time. Stripping these out "via lightweight shell script" requires maintaining complex DOM-sanitization scripts that break whenever the site updates its CSS. The companion asserts this mechanism works out-of-the-box, but in practice, plain `diff` turns State Diffing into a permanent false-positive machine that **increases** token burn.
  * **PDF Inspection**: Raw PDFs store text inside compressed `/FlateDecode` streams or vector paths. Running regex on a `.pdf` file in bash without heavy dependencies (`pdftotext`, `pdfplumber`) fails silently or yields raw binary garbage. 

### 2. Death by SIGKILL (Unbacked Recovery Mechanism)
* **Pattern Affected**: *Watchdog* (#5)
* **The Flaw**: The Watchdog pattern explicitly suggests sending `SIGTERM`/`SIGKILL` to hung agent subprocesses and removing lockfiles.
* **Missing Failure Mode**: What happens to state when an agent is mid-write? An agent interrupted by `SIGKILL` leaves half-written Markdown files, corrupt state caches, or incomplete database transactions. The catalog asserts that killing the process "preserves system stability," but offers zero mechanism for rollback, transaction safety, or state reconciliation. A hard kill without atomic file-swapping (`mv temp target`) causes cascading state corruption across the rest of the household system.

### 3. Toxic Context Contamination via Micro-Batching
* **Pattern Affected**: *Queue-and-Trigger Scheduling* (#8)
* **The Flaw**: Packing non-urgent replies, shopping list additions, and log categorizations into a single agent wake to "save context tokens."
* **Missing Failure Mode**: Multi-task prompt pollution. LLMs perform worse when crammed with unrelated directives across distinct domains in a single session context. If item #2 in the queue is ambiguous or malformed, the model may hallucinate, halt execution, or drop items #3 through #8 entirely. Saving 2,000 input tokens by merging runs costs far more when the agent fails to complete 4 out of 5 tasks in the batch, forcing human re-intervention or full re-runs.

### 4. False Hardware Signals
* **Pattern Affected**: *Canary Probe* (#9)
* **The Flaw**: Claiming that checking for a non-zero exit code from an audio driver/process proves the physical audio pipeline is alive.
* **The Flaw**: Software exit codes only prove that ALSA or PulseAudio accepted the buffer. They do **not** prove that the physical amplifier is powered, the 3.5mm jack is plugged in, or the speaker volume isn't muted at the hardware level. The canary probe gives a false sense of security: the script reports `OK` (exit code 0), while the room remains completely silent.

### 5. Infinite Retry Token Drains
* **Pattern Affected**: *Deterministic Grader* (#10)
* **The Flaw**: The catalog claims that if an agent fails a deterministic evaluation (e.g., wrong Markdown format), the grader "rejects the changes, re-enqueues the raw task, and logs specific error context."
* **Missing Failure Mode**: **The Infinite Token Burn Loop.** If an agent repeatedly misunderstands a schema invariant or makes the same structural error, the deterministic grader will continuously reject the output and re-enqueue the job. Instead of saving tokens, this mechanism creates an un-capped loop that burns through metered API limits in minutes. Without an explicit, hard retry cap (e.g., `max_retries=2` -> escalate to human), this "zero-token pattern" becomes a token furnace.

---

## What to CUT (and Why)

### 1. CUT: Pattern 10 (*Deterministic Grader*)
* **Why**: Validation of model output is necessary, but calling it a "zero-token household pattern" misplaces where schema validation belongs. Modern LLM APIs support native structured output (JSON Schema / function calling) at zero extra token overhead during generation. Implementing an external, out-of-band "grader" that rejects work and triggers agent re-runs creates loop risk and duplicates capabilities already handled natively by API spec structures.

### 2. CUT: Pattern 2 as written (*State Diffing*)
* **Why**: The claim that raw state diffing on arbitrary web/external endpoints is "zero-token and lightweight" is a trap. Maintaining custom scrapers/parsers to make web state deterministic takes dozens of hours of brittle scripting per site. Unless restricted explicitly to **local static file diffs** or **clean JSON APIs**, this pattern should be removed from a catalog aimed at zero-maintenance household setups.

### 3. CUT: Audio Software assertions from Pattern 9 (*Canary Probe*)
* **Why**: Overpromises system health. Software exit codes cannot validate analog hardware states. Retain the canary concept for file systems or local APIs, but cut the claim that rendering audio via driver codes guarantees physical voice briefing delivery.

---

## What SURVIVES the Attack (and Why)

### 1. SURVIVES: Pattern 1 (*Tripwire*)
* **Why**: Event-driven execution (`inotifywait`, filesystem events) is the gold standard of zero-cost trigger mechanisms. It replaces CPU-burning polling loops with kernel-level waits.
* **Required Caveat**: Must explicitly state that `inotify` does not work reliably over network mounts (SMB/NFS) and requires `IN_CLOSE_WRITE` to prevent firing on incomplete file writes.

### 2. SURVIVES: Pattern 7 (*Completion Detector*)
* **Why**: Directly matches the concrete problem solved in the context (uncollated research returns). Checking for the presence of $N$ files or a `DONE` signal before waking a collation agent prevents premature agent wakes.
* **Required Fix**: Must enforce a **Hard Timeout**. If 5 of 6 files arrive, the system cannot hang indefinitely; it must fire a partial collation or alert a human after an explicit TTL.

### 3. SURVIVES: Pattern 4 (*Threshold Trigger*)
* **Why**: Evaluating dynamic numeric streams (electricity prices, disk space, API budgets) against absolute bounds is mathematically trivial, completely deterministic, and saves massive agent tokens.
* **Required Caveat**: State persistence and hysteresis deadbands must be explicitly modeled to avoid signal oscillation (flapping).

### 4. SURVIVES: Pattern 6 (*Dead-Man Switch*)
* **Why**: Low overhead, high reliability. Checking if `mtime` on `daily_log.md` is older than 24 hours via a simple shell check is foolproof and guarantees that broken schedules or silent agent crashes are surfaced.

---

## Summary Matrix

| Pattern | Status | Key Reason for Decision |
| :--- | :--- | :--- |
| **1. Tripwire** | **SURVIVES** | Kernels handle I/O events efficiently; perfect fit for local drop-folders. |
| **2. State Diffing** | **CUT** | HTML/Web churn breaks raw diffs; creates false-positive wake storms. |
| **3. File-Shape Contract**| **REVISE** | Keep JSON Schema validation; drop raw PDF/binary regex claims. |
| **4. Threshold Trigger** | **SURVIVES** | Simple math; highly effective provided hysteresis/state is stored. |
| **5. Watchdog** | **REVISE** | Retain execution bounds; drop raw `SIGKILL` without atomic rollback protocols. |
| **6. Dead-Man Switch** | **SURVIVES** | Unbeatable for passive health tracking; simple `mtime` logic. |
| **7. Completion Detector**| **SURVIVES** | Directly solves batch collation; requires mandatory TTL/timeout logic. |
| **8. Queue-and-Trigger** | **REVISE** | Limit to single-domain task queues; ban cross-context micro-batching. |
| **9. Canary Probe** | **REVISE** | Good for API/pipeline checks; cut hardware/audio validation claims. |
| **10. Deterministic Grader**| **CUT** | Re-enqueue loops risk runaway token burn; native API schemas render this obsolete. |
