# Refutation Pass: Deconstruction of Wave 1 Companion Return

The Companion Return suffers from classic **enterprise-architecture cosplay**. It takes a clean, pragmatic mechanism—lightweight zero-cost shell scripts triggering high-judgment LLM sessions—and smothers it under layers of unnecessary abstraction, speculative self-healing code loops, circular agent validation logic, and vanity metrics engines. 

Below is a systematic deconstruction of the weakest claims, flawed mechanisms, and missing failure modes across all five proposed architectures, followed by explicit lists of what to **CUT** and what **SURVIVES**.

---

## 1. Deconstruction by Architecture

### Architecture 1: Asynchronous Proposal Engine ("Script Proposes, Agent Disposes")
* **The Circular Logic Trap:** The proposal asserts that a deterministic script can aggregate context, synthesize a candidate action, and generate a 300-token proposal for the agent to approve with a simple `APPROVED` token. If a deterministic script has enough context and rule certainty to draft a specific, high-confidence target execution payload (`ACTION: organize_files`, `TARGETS: [a.txt, b.txt]`), **there is no reason to invoke an LLM at all.** The script should simply execute the payload.
* **Context Starvation as a Structural Flaw:** The architecture claims the agent saves tokens by receiving *only* the 300-token proposal instead of 10,000 tokens of raw context. But the agent’s *only job* in this architecture is "semantic sanity checking" and "edge handling." An LLM cannot perform semantic sanity checking on stripped context; if it doesn't see the underlying files, it is acting as a blind rubber stamp, burning tokens to validate a script's guess.
* **Overengineered Mechanism:** Introducing an "SQLite Priority Proposal Queue" for a small household environment running local file watchers is absurd infrastructure bloat. A directory of pending JSON files or a simple standard out pipeline achieves the exact same state tracking without database overhead.

### Architecture 2: Deterministic Mechanical Pre-Graders & Gating CI/CD
* **The LLM Retry Waste Hole:** When a mechanical check fails (e.g., a markdown linter catches a broken relative link or AST catches a missing import), the system triggers a "micro-retry session" waking the agent to fix it. This is anti-pattern engineering. Deterministic linters and AST tools (like `black`, `prettier`, or simple `sed`/`jq` hooks) can auto-fix formatting and structural syntax natively at zero cost. Re-invoking a metered LLM to fix a misplaced trailing comma or missing markdown header burns tokens on mechanical formatting rather than judgment.
* **Missing Failure Mode (Linter Over-Fitting):** The document misses that agents forced into tight deterministic retry loops will rapidly degrade output semantic depth to satisfy the strict structural regex/linter requirements.

### Architecture 3: Pure Event-Driven Household Cascades ("Zero-Clock Operations")
* **The "Zero-Clock" Overclaim:** Claiming to "eliminate time-based polling schedules (`cron`) entirely" is both impossible and counterproductive for a household. Household reality is fundamentally tied to human time cycles (sleep patterns, work days, evening reviews, external API rate-limit windows). 
* **The Missing Mechanism (Negative Event Handlers):** Pure event-driven architectures fail completely when an expected event *does not happen* (e.g., research returns fail to download by 5:00 PM). You cannot trigger an OS kernel `inotify` event on an event that *didn't* occur. Detecting absence requires a clock (a timeout or cron poller). Abandoning time-based triggers introduces silent systemic staleness.

### Architecture 4: Counterfactual Token Accounting Engine
* **Pure Vanity Metric / Fake Math:** This entire architecture is an operational distraction. Calculating "how much money an LLM would have cost if it polled an API 720 times a day" is logging vanity metrics. Writing an SQLite ledger, event interceptors, and shadow estimation prompts to calculate "avoided costs" consumes real disk I/O, maintenance complexity, and compute power to measure imaginary dollars.
* **Ungrounded Mechanism:** The prompt implies the agent will read this accounting ledger during weekly reviews to "suggest new deterministic scripts." Waking a metered agent to read hypothetical logs so it can write more bash scripts is spending real tokens to analyze fake token savings.

### Architecture 5: Immune-System Architecture (Self-Maintaining Scripts)
* **High-Risk Illusion of Autonomy:** Letting an LLM patch local production shell scripts based on `stderr` outputs and run them on host systems via automated sandboxes is an operational disaster. If an external API changes, an LLM guessing the new API payload without live interactive inspection will frequently generate plausible-looking broken code that exits with code `0` while silently dropping or mutating data.
* **Catastrophic Feedback Loops:** The listed failure mode acknowledges "Recursive Auto-Repair Cascades," but misses **Silent Systemic Corruption**: an auto-patched script that passes syntactic tests but alters file locations or deletes context before the household notices weeks later.

---

## 2. What to CUT and Why

| Component / Feature | Reason for Cutting |
| :--- | :--- |
| **SQLite Proposal Queue (Arch 1)** | Unnecessary database bloat for a household system. Flat files or standard OS signals are sufficient. |
| **Agent "Rubber-Stamp" Approvals (Arch 1)** | If a script forms a complete proposal without requiring ambiguity resolution, calling an LLM just to get an `APPROVED` signal wastes tokens. |
| **LLM Micro-Retries for Syntax Errors (Arch 2)** | LLMs should not be invoked to fix linter/formatting failures that deterministic CLI tools (`prettier`, `black`, `sed`) can fix for free. |
| **"Zero-Clock" Operational Dogma (Arch 3)** | Household systems require timeouts and time-bound triggers. Eliminating clocks breaks negative-event monitoring (detecting when expected data *fails* to arrive). |
| **Counterfactual Token Accounting Engine (Arch 4)** | Entire architecture must be purged. It is a vanity monitoring subsystem that adds maintenance overhead to track hypothetical numbers. |
| **Autonomous Script Self-Healing & Hot-Swapping (Arch 5)** | High risk of silent data corruption, dangerous path executions, and token burn. LLM code modifications must land as human-reviewed PRs/diffs, not auto-overwriting production scripts. |

---

## 3. What SURVIVES and Why

Despite the over-engineering, several core primitive concepts are exceptionally valuable for a metered-agent household and survive scrutiny:

### 1. Mechanical QC Gating Before Memory Persistence (From Arch 2)
* **Why it survives:** Passing agent outputs through zero-cost AST parsers, link-checkers, and schema validators *before* committing them to long-term memory or daily logs prevents memory corruption. If the validation fails natively and cannot be auto-fixed by deterministic tools, the output is rejected *before* it corrupts the household markdown graph.

### 2. Audio/Media Canary Checks via `ffmpeg` (From Arch 2)
* **Why it survives:** This directly reinforces the contextual constraint (the household audio canary). Using simple shell checks (`ffmpeg` signal analysis) to verify audio file generation (detecting zero-volume or clipped audio) before waking an agent or alerting a human is a textbook zero-token validation win.

### 3. State-Graph Event Cascades with Ambiguity Thresholds (From Arch 3)
* **Why it survives:** The core idea of keeping execution in the deterministic layer (Bash/Python) across sequential mechanical steps, and **only** crossing over to an agent when state crosses an explicitly measured *ambiguity threshold*, is the exact correct design pattern. The deterministic layer handles aggregation, file movement, and transcoding; the agent handles judgment.

### 4. Deterministic Error Ticket Generation (Grounded Version of Arch 5)
* **Why it survives (with modifications):** When a local polling script or API watcher fails, the deterministic system *should* package the script source, `stderr`, and recent payload diffs into a clean Markdown maintenance ticket. However, instead of letting an agent auto-patch production code live, the ticket is queued for the agent's scheduled work session or flagged for human review. This captures the diagnostic value without the operational hazard of autonomous self-modifying code.

---

## Final Synthesis Matrix

| Layer | Responsibility | Metered Cost | Example Actions |
| :--- | :--- | :--- | :--- |
| **Deterministic Layer** | Polling, state diffing, event cascades, linters, timeout checks, audio signal checks, error payload packaging. | **$0.00 (Zero Tokens)** | `inotifywait`, `curl`, `ffmpeg`, `jq`, `flake8`, creating micro-cron schedules. |
| **Agent Judgment Layer** | Resolving un-templatized ambiguity, semantic evaluation, content synthesis, targeted triage. | **Metered Tokens** | Collating unstructured bench research, resolving conflicting priority schedules, evaluating semantic intent of complex notes. |
