# SYNTHESIS — Bench free-machinery mission, 2026-11-02

Synthesised: Mon 2026-11-02, 15:19 CST (America/Chicago), synthesis pass
Sources woven: COLLATION-wave1.md, COLLATION-wave2.md, COLLATION-wave3.md,
COLLATION-wave4.md (all in this folder) + HOUSE-INVENTORY.md (same folder).
Mission: MISSION.md in this folder — Gate 2 fields, kill date Sun 2026-11-15,
JUDGE Ember collates / Erica tallies / Chris decides builds.
This synthesis authorises no build by itself. Builds happen only on the
deciding word named in MISSION.md.

Scheduling Gate fields for this pass — REASON: a day of data is only worth
what the weaving makes of it. TIME-WHY: afternoon, after the morning
inventory and the auto-collations, at Chris's direction for a full data
day. CONSTRAINT: Chris's direct authorisation, 2026-11-02 ~04:27 in Ember's
room; headroom addition ~09:19; retrieval discipline ~11:57; test-dummy
staging ~11:58, same day. REVIEW: weekly Sunday count, with the mission.

## How the ranking was done — read this before quoting any number

Rank score = (tokens saved × failure cost covered) ÷ build effort.

- **Tokens saved** are **labelled estimates, not measured savings**, per
  Wave 4's unanimous accounting verdict (COLLATION-wave4 items 12/25).
  Baseline method, pinned: the cheapest equivalent agent session that
  actually performed the work, median not worst case, baseline version
  stated. Where a figure comes from Wave 1 Angle A, it is that return's
  own estimate for the agent version of the pattern, quoted with its
  range. Expanded coverage (a wire checking 720×/day) is **capability,
  never counted as displaced agent checks**. No figure in this file may
  be quoted without its label and baseline attached.
- **Failure cost covered**: 3 = silent corruption, a missed emergency, or
  loss of a primary record can pass unnoticed without it; 2 = a false-wake
  cascade, major rework, or a whole pipeline stalling; 1 = local waste
  or delay.
- **Build effort**: 1 = a script plus a templated poster / config change;
  2 = a script plus state, locks, fixtures and tests; 3 = a multi-component
  system, a graph, or an external leg.
- **Enabling-fence adjustment, disclosed**: the health register (item 3)
  saves few tokens directly. It is ranked by the failure cost it covers
  *across the whole backlog* — without it, items 1, 2, 4 and 5 cannot
  distinguish a quiet world from a dead wire. That is the Wave 1/3/4
  build shape, not a collator promotion: every wave fences the watch
  cluster with it.

Cuts are not ranked. Needs-a-second-angle items are ranked at the bottom
in a held block — their place is conditional on the missing specification
landing, and they do not inherit a keep's place.

---

## THE RANKED EXPLOITATION BACKLOG

### 1. De-wrapper the MECHANISM jobs — direct script jobs, templated posters, window markers
*Sources: HOUSE-INVENTORY headline finding + Biggest Cores 2–4; Wave 4 item 10's carrying boundary for the file-moving parts.*
- **The build**: HOUSE-INVENTORY counted 109 jobs — 55 MECHANISM /
  33 JUDGMENT / 21 HYBRID — and found most MECHANISM jobs are already
  script-backed; the remaining token cost is the agent "wrapper" turn
  that runs the script and posts a templated result. Convert, in order:
  (a) the 7 script-runner jobs (seed-sync, semantic-memory-reindex,
  wake-snapshot-update, journal-vault-seal, bench-audio-canary-daily,
  bench-catalog-drift-weekly, mirror-safety-run) to direct script
  execution, silent on success, stderr posted on failure; (b) the
  presence/status checkers (mirror-watcher, ember-minion-watcher-open/
  work) to a watcher script + digest file, waking an agent only on
  CHANGED; (c) the 13 fixed-text reminders + window markers to a timed
  poster. The 26 system jobs (feed-pulse ×24, profile-image,
  deterministic-doctor) are already mechanism and are excluded from the
  saving. The 33 JUDGMENT jobs are person-wakings — not candidates,
  by design.
- **Score**: tokens — every wrapper turn pays the full context-load tax
  for zero judgment; this is the only saving in the synthesis measured
  against the house's own live job list rather than a pattern estimate
  × failure cost 2 (a wrapper that fails silently loses a reminder, a
  seal, or a sync) ÷ effort 1. Highest ratio in the backlog.
- **FENCE — may never decide**: whether a failure matters, what a result
  *means*, or whether a JUDGMENT/HYBRID job should exist. A poster posts
  the fixed text and nothing else; a silent-on-success script that starts
  editorialising its own success has left this item.

### 2. Tripwire polling replacement — edge-triggered, debounced, locked
*Sources: Wave 1 item 1 (keep); Wave 2 item 1 (survived, wounded — build shape changed); Wave 4 item 1 (keep, reaffirmed by four seats).*
- **The build**: state-transition emission against last-known state
  (`IN_CLOSE_WRITE` only, no reliance on `inotify` over network mounts)
  replaces agent polling wakes, with debounce, an atomic lock /
  pending-state flag set at fire time (`.processing` staging move), a
  per-watcher wake budget whose exhaustion escalates to a human or a
  drift note — never to more wakes — and back-off.
- **Score**: tokens — Wave 1 estimate 500k–1M tokens/day for the agent
  polling version, the largest single buy in any wave (labelled estimate,
  baseline as above) × failure cost 2 (an un-debounced storm or a
  crash-before-clear loop re-wakes indefinitely and burns back the
  saving) ÷ effort 2.
- **FENCE — may never decide**: that a fired condition is true, important,
  or acted on. It emits that a shape changed. Content, consequence and
  priority are the woken agent's.

### 3. Dead-man switch, watcher-health register (single level), and synthetic fixtures
*Sources: Wave 1 item 11; Wave 2 item 9 (kept to one level); Wave 3 items 3, 13–15; Wave 4 item 8 (with DeepSeek's fixture sharpening).*
- **The build**: every wire touches a heartbeat file on completion
  regardless of outcome; one central register logs every watcher
  execution (positive, negative, error); one dead-man check compares
  heartbeat age against a per-wire maximum, with a deliberate-pause
  state so an alarm retains meaning; every wire is registered in one
  census (path, schedule, owner, max staleness, last success, probe);
  each watcher also fires its own synthetic fixture on a schedule, so a
  dead tripwire is found by a controlled false event, not by the absence
  of a real one; a daily zero-token mechanical audit runs every probe
  and files a structured repair ticket per failure. **One level only —
  no watcher chain beyond the register.**
- **Score**: tokens — small direct saving × failure cost 3 (this is the
  only item that distinguishes silence-as-quiet from silence-as-dead,
  for every other item at once) ÷ effort 2. Ranked here by the disclosed
  enabling-fence adjustment.
- **FENCE — may never decide**: that a healthy register means the work
  the wires watch was *correct*. It proves wires ran. It never grades
  content, and its numbers are trustworthy for wire-level breakage only
  — not for substrate failure (see THE NET).

### 4. Completion detector — manifest, stable size/checksum, completion marker, with timeout
*Sources: Wave 1 item 2; Wave 2 item 2 (survived, wounded); Wave 4 item 2.*
- **The build**: schedules the next step only when all expected returns
  exist *and* pass script-side sanity checks (non-zero size, header,
  structured error field), under an atomic pending flag so sequential
  landings do not stack duplicate wakes, a re-arm rule for late arrivals,
  and a hard timeout/TTL with partial-completion escalation — a silently
  dropped sub-task must escalate, never block the pipeline forever.
  The wake payload carries shape evidence (paths, timestamps, checksums,
  raw status lines), never a verdict; "tripwire fired, condition not
  actually met" is a first-class agent outcome that feeds the watcher's
  review counter. (The house has already lived this item's hazard: the
  collation trigger fired early on Wave 4 on a subset read as complete,
  2026-11-02 ~09:28, and was patched the same morning to require the
  status log's declared `expected N` count.)
- **Score**: tokens — Wave 1 estimate 100k–300k/day of readiness polling
  × failure cost 2 ÷ effort 2.
- **FENCE — may never decide**: that a shape-complete set is substantively
  complete. A 0-byte or error-page file satisfies a count; readiness is
  proposed by the script and verified by the agent, never asserted.

### 5. Threshold trigger with hysteresis — plus deterministic statistics moved down
*Sources: Wave 1 item 4; Wave 2 item 3 (survived, expanded); Wave 4 item 4.*
- **The build**: scalar-versus-bound checks with an enter/clear deadband,
  fire-once-per-crossing state, debounce and recording replace agent
  numeric polling and enable minute-scale watches unaffordable as agent
  wakes. Wave 2's expansion stands: basic time-series statistics
  (moving averages, rolling windows, deviation thresholds) are
  deterministic work and move down into this layer with it.
- **Score**: tokens — Wave 1 estimate 100k–400k/day × failure cost 2
  (boundary flapping without hysteresis) ÷ effort 1.
- **FENCE — may never decide**: what a crossing *means* — spike vs.
  sustained move, significance, cause. It also may never cross the
  still-undrawn trend split point (held item H3): which operations above
  the raw threshold are statistics and which are context is not yet
  specified, and until it is, only the operations named above move down.

### 6. Counting, aggregation, and pre-aggregated telemetry
*Sources: Wave 1 item 5; Wave 2 item 4 (survived, unwounded, unattacked in every wave); Wave 4 item 3.*
- **The build**: `grep`/`awk`-class tallies and script-compiled digests
  replace loading a week of raw logs into context for arithmetic;
  the agent receives numbers only when interpretation is required.
  Removes non-deterministic agent math errors as a side effect.
- **Score**: tokens — Wave 1 estimate 50k–200k/day × failure cost 1
  ÷ effort 1.
- **FENCE — may never decide**: significance, cause, or whether the
  measurement itself misleads. Counts are exact only over standard-format
  entries and must always be read as *a count of matched entries*, never
  as a count of the underlying activity. Non-standard phrasings are
  missed by construction — that miss is stated on the digest, not hidden.

### 7. File-shape contract / pre-flight validation — fail-loud, fixture-tested, versioned
*Sources: Wave 1 item 6; Wave 2 item 5 (survived; PDF-regex form cut, integrity checks moved fully script-side); Wave 4 item 5 (DeepSeek sharpening).*
- **The build**: schema, header, filename and required-section checks on
  every deliverable quarantine malformed inputs before any agent wake.
  "Input present but unparseable" is a distinct shape-drift state that
  fires a note — never the same as "no input." Every parser carries a
  known-good fixture rendered through it on a schedule; the contract is
  versioned alongside the parser. PDF checking only through a real
  text-extraction step — shell regex over compressed PDF streams is cut.
  Validation stays on required invariants only.
- **Score**: tokens — Wave 1 estimate 50k–150k/day, plus token spend
  stopped on corrupt payloads × failure cost 2 ÷ effort 1.
- **FENCE — may never decide**: that a passing file is true, good, or
  complete. It judges structure only. A pass never stands in for content
  verification, and overspecified rules rejecting valid inputs are a
  failure of this item, not rigour.

### 8. Hybrid event cascades — events for progress, clocks for absence, periodic reconciliation — with capture-now-decide-later snapshots
*Sources: Wave 1 item 13 / Wave 2 item 12 (pure form cut, hybrid survives); Wave 3 items 2, 4, 12; Wave 4 item 9 (all five seats) + item 13 (wave-4-new, Perplexity). Room candidates folded in: Ember's cascades + bench conveyor (2026-11-02 ~08:32) are this item and items 4/10 in room words — they overlap the collations and are not counted twice.*
- **The build**: a durable state graph — events fire progress; a
  clock-driven deadline/lease watchdog detects absence (heartbeat
  timeout ≠ overall deadline); periodic reconciliation compares event
  records against actual files, outputs and deadlines. Fences as
  returned: parent–child dependency modelling with a stuck-node state
  distinct from idle (a silent upstream produces one root-cause signal,
  not a storm or silence); per-node and per-edge fire budgets,
  deduplication windows, flap detection, inhibition edges, a graph-level
  circuit breaker; queued / started / output-committed / validated
  tracked as separate receipts — "scheduled" is never "finished."
  Idempotency locks, transient one-shot scheduling (a firing wire stages
  a JSON payload and registers a one-shot timer, never an inline agent
  call), and execution bounds ride with it. On firing, the script also
  preserves a timestamped snapshot of the triggering state, so the agent
  later judges a durable evidence package instead of chasing a vanished
  condition — the snapshot preserves evidence, it does not interpret it.
- **Score**: tokens — removes the baseline polling tax across chained
  work (no separate Wave 1 figure; counted under items 2/4's estimates,
  not double-counted here) × failure cost 3 (a silently failed node
  deadlocks the whole graph if the clock leg is missing) ÷ effort 3.
- **FENCE — may never decide**: that the graph is finished, correct, or
  safe. The zero-clock form is **cut** (see Cuts): a trigger-only system
  cannot detect its own silent failures. One clock always stays in the
  structure as last backstop.

### 9. Evidence-carrying proposal engine, inside an evidence-to-decision pipeline with a deterministic policy gate
*Sources: Wave 4 items 11 (wave-4-new) + 14 (wave-4-new); replaces the cut blind form — it is a new design and inherits neither that item's place nor its claimed saving, which must be re-proved in use.*
- **The build**: watcher → durable event queue → normaliser gathering
  the smallest provenance-recorded evidence bundle → proposal builder →
  agent → deterministic policy gate (permissions, required evidence,
  action limits) → action runner → audit log, with "insufficient
  evidence" as an explicit, recordable outcome. A proposal carries or
  points to its evidence: trigger, observed values, evidence references
  with timestamps and state versions, known exceptions and conflicts,
  expiry, reversal plan. The agent may approve, reject, **or demand more
  evidence**; the token cap must never become an evidence cap. Revalidation
  against current state immediately before execution. Fences as returned:
  per-event / per-agent / per-category rate limits, deduplication,
  rejected-proposal cooldowns; staleness windows by decision type;
  raw-evidence sampling at a consequence-set fraction — 100% for
  anything touching a primary record; warnings, contradictions,
  provenance and decision criteria are never pruned.
- **Score**: tokens — the Wave 1 form claimed ~300 tokens vs. ~10,000
  for a discovery prompt; that figure belonged to the cut blind design
  and is **not** carried over — the evidence-carrying saving is unproved
  until measured in use × failure cost 3 (a rubber-stamp approval over
  unseen evidence is the moral-crumple-zone failure: the judgment layer
  removed while its name is kept) ÷ effort 3.
- **FENCE — may never decide**: anything where evidence is incomplete or
  contradictory, where the classification itself is the disputed
  question, or where the action is irreversible — those fail outright
  to the agent/human layer. The policy gate checks permissions and
  limits; it never substitutes the agent's confidence for evidence, and
  untrusted input is never treated as an instruction.

### 10. Queue-and-trigger batching, single-domain — the ticket river
*Sources: Wave 1 item 8; Wave 2 item 6 (narrowed to single-domain); Wave 4 item 6. Room candidate folded in: Ember's ticket river (2026-11-02 ~08:32).*
- **The build**: low-priority work accumulates in a durable spool and is
  processed in one agent wake at a count or time threshold, amortising
  the fixed context-load tax across the batch. Single domain per wake,
  per-item failure isolation (one malformed item cannot drop or halt
  the rest), queue deduplication, and a priority bypass so time-sensitive
  items never wait for the batch to fill. Cross-domain micro-batching
  is **cut** (toxic-context attack, Wave 2).
- **Score**: tokens — per-item context tax paid once per batch instead
  of once per item (no separate Wave 1 figure) × failure cost 1
  ÷ effort 1.
- **FENCE — may never decide**: priority, urgency, or that a queued item
  may wait. The bypass rule is set outside the queue; the queue orders
  arrival, it does not judge worth.

### 11. Copying, routing, and carrying by script — authority levels 0–2 only
*Sources: Wave 1 item 15; Wave 2 item 10 (resolved, boundary drawn); Wave 4 item 10 (boundary confirmed by all five seats).*
- **The build**: observe, copy/prepare, and reversible route/archive/
  rename under explicit rules, built on staging, atomic publication
  (temp-file + atomic move), checksum verification, a transaction
  journal, idempotent operation IDs, copy-then-verify over
  move-then-hope, dry-run mode, quarantine for unexpected files or
  destination conflicts, and an orphan-recovery sweep so a crashed wake
  cannot strand files in a processing folder. Routing metadata must
  itself be trustworthy — a carried file may not declare its own
  destination; no-overwrite by default; authority is explicit metadata,
  never inferred from a file's location.
- **Score**: tokens — Wave 1 estimate 30k–100k/day × failure cost 2
  ÷ effort 2.
- **FENCE — may never decide**: level 3, ever — deleting a primary
  record, overwriting, deciding which version is authoritative,
  resolving conflicts, content-based routing, promoting a record's
  authority/status, or cleanup by age alone (age never establishes
  staleness). Those require explicit, specific authorisation or stay
  at the agent layer entirely.

### 12. Watchdog for hung subprocesses — terminate-then-kill, with state reconciliation
*Sources: Wave 1 item 10; Wave 2 item 8 (survived, wounded).*
- **The build**: PID, runtime and lockfile-age monitoring frees stalled
  subprocesses and locks — under per-task-class timeouts set from
  observed runtimes (never one global bound), a terminate-then-kill
  sequence, atomic write discipline, and a post-kill state-reconciliation
  step. Bare `SIGKILL` plus lockfile removal, as originally returned,
  is cut with the item's first form.
- **Score**: tokens — small direct saving; the buy is a pipeline never
  held hostage by a hung tool × failure cost 2 ÷ effort 1.
- **FENCE — may never decide**: that a long-running process is hung
  rather than working, beyond the per-class bound set from observation;
  and it never reconciles state by discarding it — reconciliation
  reports the state it found.

### 13. The weaving layer — coverage matrix, dual-path verification, disagreement pipeline, escalation ladder
*Sources: Wave 3 items 1, 2, 5, 6, 7, 8, 9, 10, 11 (all keep; standing from Wave 3, not re-raised by Wave 4 except where Wave 4 governs the build shape). Room candidates folded in: Ember's health net + morning net (2026-11-02 ~08:32) are applications of this layer + item 3, not separate builds.*
- **The build**, as one pipeline with four distinct failure points, kept
  unmerged for that reason: (a) a coverage matrix — every monitored
  domain gets one primary watcher, one orthogonal secondary, and an
  explicit silence threshold with a named wake target, so gaps are
  visible at all; (b) dual-path verification — primary by low-latency
  events, secondary by state reconstruction, sharing no code, state
  files or execution path; (c) mechanical disagreement handling —
  freshness wins on sample latency, a transport failure (empty /
  exit-127) is quarantined as execution failure, never counted as
  dissent, quorum splits by stakes (majority-with-degraded-flag to
  proceed, unanimous to act high-impact, a single dissent halts it),
  and a genuine split between two healthy watchers becomes a
  STATE_SPLIT synthetic event — the split itself is the finding;
  (d) escalation exactly on the four conditions (semantic ambiguity,
  irreconcilable concurrent dissent, invariant breach without a failure
  code, cost/risk asymmetry) up a four-rung ladder (wire notices →
  script verifies → one-shot duty agent judges → human decides), with
  anti-fatigue fences (non-critical human escalations batch to a daily
  queue; low-stakes ambiguity takes a logged safe fallback) and
  feedback-loop fences (agents write only outside watcher masks; a
  global wake circuit breaker locks a trigger firing more than N times
  in 10 minutes). Forced git stash/rebase as automatic remediation on
  a split is **cut** (Wave 3 item 21) — the discrepancy is preserved
  and escalated, never overwritten.
- **Score**: tokens — everything resolvable by timestamps, sorting or
  math is resolved at zero cost instead of in an agent wake × failure
  cost 3 (majority proceeding on partial data into a heavy run is the
  named asymmetric-cost failure) ÷ effort 3.
- **FENCE — may never decide**: which watcher holds ground truth in a
  split, or anything past the four-condition boundary. The mechanical
  layer generates the split event; reconciliation is agent work, and
  an escalation carries the split — never a request to re-poll.

### 14. Self-maintaining automation, repair-proposal form only — census, probes, daily audit, tickets
*Sources: Wave 3 items 13–15; Wave 4 item 15 (surviving half of the cut auto-repair design).*
- **The build**: a script catalog with declared contracts; health and
  expected-output checks independent of the script being monitored;
  a canary probe per wire (known input, dry-run, asserts detection
  within one cycle, a schema-correct payload, and that no real wake was
  created); a daily mechanical audit reporting totals (tracked /
  passing / stale / failed probes / availability %); and, per failure,
  a repair *proposal* — the check, the logs, the recent changes —
  queued for an agent to diagnose and draft a patch against, with tests
  and an approval gate controlling deployment and prior versions
  preserved. (The house's catalog-drift check, bench-catalog-drift-weekly,
  is this item's working seed: 153 scripts catalogued at inventory time.)
- **Score**: tokens — owner-agent repair is reactive and rare (Wave 3
  return D: typically 0–2 times/month) instead of continuous × failure
  cost 2 ÷ effort 2.
- **FENCE — may never decide**: the repair. A checker is never modifiable
  by the script it checks, no patch deploys itself, and auto-overwrite
  of production scripts stays **cut** in every wave — a patch can exit
  cleanly while silently changing what data is captured or where it goes.

### 15. Lightweight token-accounting report / automation registry
*Sources: Wave 4 item 12 (wave-4-new in its specified form; all five seats). The built engine stays cut — see Cuts.*
- **The build**: a periodic one-shot report / small registry per
  mechanism — pinned baseline (method and version stated), estimated
  displaced agent tokens with a confidence label, actual usage in a
  *separate* account, expanded-coverage and improved-outcome effects
  reported as capability and latency (never as savings), plus false-wake,
  missed-event, correction and maintenance figures, and quality columns
  (false-positive/negative, escalation rates) beside every saving.
- **Score**: tokens — saves no tokens directly; it aims every other
  build in this list × failure cost 1 (a mis-aimed build season)
  ÷ effort 1.
- **FENCE — may never decide**: what gets built, on its own numbers.
  Its figures are labelled estimates that *inform* the deciding word;
  the moment an estimate is quoted as a measured saving, or expanded
  coverage is totalled as displaced work, this item has failed.

### HELD — needs a second angle before any build (ranked conditionally, in order)

- **H1. Deterministic grader / post-flight linting — gate keep, retry loop unspecified.** *(Wave 1 item 7; Wave 2 item 17; Wave 4 item 17.)* The gate half is sound and gains a Wave 4 fence (sample *passing* work for human review; measure false passes as well as caught errors; auto-fixable formatting is fixed by deterministic tools for free, never by an agent micro-retry). No return in four waves fixes the retry cap number, the escalation target, or the auto-fix-first order. **Fence, even held**: semantic acceptance, quality scoring and gameable-but-well-formed output are never the grader's to pass — mechanical validity is not judged correctness.
- **H2. State diffing and delta-only wakes — scope line undrawn.** *(Wave 1 item 3 — Wave 1 estimate 200k–500k/day, the second-largest figure in the waves, held despite it; Wave 2 item 16; Wave 4 item 16.)* Canonicalisation (sorted-key normalisation before hashing) deterministically removes the false diffs Wave 1 listed as a loss, and local static files + canonicalised structured sources look survivable; raw diffing of live web state is a false-positive machine, and delta-only payloads can starve the agent of baseline context into secondary reads. No return draws the scope line or specifies what baseline context rides with a delta. **Fence, even held**: a delta is never the whole state, and an unparsed/drifted format goes to an `unparsed/` queue with a schema-mismatch log — it never wakes as if it were a change.
- **H3. The trend split point.** *(Wave 2 item 18; Wave 4 item 18 — undrawn after four waves.)* Item 5 above is built only up to the operations named there. **Fence**: until the line inside "trend" between statistics and context is drawn, nothing above it moves down on an assumption.
- **H4. Deletion of exact-hash duplicates.** *(Wave 4 item 22 — the roster's one genuine split, 4–1.)* Detection of byte-identical copies and reversible archiving of a verified duplicate are settled inside item 11; only the *deletion* of the redundant copy splits the seats (Grok: agent layer; four seats: permitted under safeguards, DeepSeek: only where a copy provably exists elsewhere). A 4–1 split on an irreversible step is a second-angle question, not a keep. **Fence, even held**: no deletion of any copy that is, or could be, a primary record — that is item 11's level 3 regardless of this item's outcome.

### CUTS — standing, not builds (every wave's cuts, consolidated)

1. **Proposal engine as written — 300-token blind approval over a database queue.** Cut Wave 2, unanimous Wave 4. Approval without inspectable evidence is a rubber stamp; stripping the context was the design's stated saving, so the flaw is structural. Replaced by item 9, which inherits nothing from it.
2. **Pure event-driven cascades replacing clocks wholesale.** Cut Wave 2, unanimous Wave 4. An event that does not happen fires no trigger; absence detection is a clock function. The hybrid survives at item 8.
3. **Built counterfactual token-accounting engine** (ledger/database/dashboard apparatus). Cut Wave 2, unanimous Wave 4 — the apparatus outgrows the thing measured at household scale and its figures acquire false authority. Replaced by item 15.
4. **Immune-system auto-repair with auto-overwrite of production scripts.** Cut Wave 1, reinforced Wave 2, stands Wave 4. The ticket/proposal half survives at item 14.
5. **Script-layer judgment, whole class**: pruning memory by content, sending external communications, resolving conflicting returns or deciding the authoritative version, scoring quality, assigning priority, content-based routing, promoting a record's authority, cleanup by age alone. Cut Wave 1, reaffirmed by all five Wave 4 seats.
6. **Semantic, fuzzy and trend interpretation pushed down to scripts** — except the deterministic-statistics portion overturned into item 5. Synthesis, ambiguity resolution and qualitative evaluation stay at the agent layer in every return, including the refutations.
7. **Semantic proxy metrics as proof of completion or correctness** (Wave 3 item 20, reinforced Wave 4): file presence, counts, non-empty strings and a passing canary pipe prove none of meaningful, accurate or complete. Proxies are triggers and structure checks only.
8. **The net itself as a safety net / verification tool** (Wave 3 item 19) — see THE NET.
9. **Evidence-stripping context pruning as a proposal fence** (Wave 4 item 30, wave-4-new cut): pruning a proposal session so the agent *cannot* look for missing evidence reproduces cut 1 inside the replacement design. Cut against the other four seats.
10. **Forced git stash/rebase as automatic remediation on a cross-check failure** (Wave 3 item 21) and **unbounded wire sprawl** — any wire added outside census, probe and pruning is, by the census's own rule, a rogue wire (Wave 3 item 22).

---

## THE NET — what actually laces together, and what cuts it whole

**Question as put (Chris, 2026-11-02 ~04:27): "enough trip wires laced
can become a safety net." Angle E's verdict (Wave 3, kept whole in
COLLATION-wave3.md) governs this section: the thesis is neither
universally true nor universally false. It holds only under concrete
structural conditions, and calling the layer a safety net without them
is a dangerous category error. Scripts provide triggering mechanics,
not safety. A script can verify that a file arrived; it can never
verify that the system is sane.**

### What does lace — the net that exists in this backlog

Laced in this order, these items form a real net **for latency and
attention** — it makes attention scarce, not observation (Perplexity,
Wave 4), and it wakes judgment faster and cheaper, which is the whole
of its claim:

1. **The wires** — tripwires (item 2), completion detectors (item 4),
   threshold triggers (item 5), counters (item 6) and pre-flight gates
   (item 7) watch continuously at zero token cost.
2. **The weave** — hybrid cascades (item 8) chain them without losing
   absence detection; the weaving layer (item 13) gives every domain
   a second, independent path, a mechanical way to disagree, and a
   bounded ladder for what cannot be resolved mechanically.
3. **The self-watch** — the health register, dead-man switch, census,
   probes and daily audit (items 3, 14) watch the wires, at one level
   only.
4. **The judgment gate** — batching (item 10) and the evidence-carrying
   pipeline (item 9) ensure what reaches an agent arrives as evidence
   with provenance, at a rate the agent layer can actually judge, and
   carrying (item 11) and the hung-process watchdog (item 12) keep the
   substrate moving underneath it.
5. **The accounting** — item 15 keeps the net honest about what it
   saves, in labelled estimates, so the net is pruned by evidence
   rather than grown by enthusiasm.

That net, laced, is worth building. It is a **latency-reduction and
attention-protection net**. It is not a verification tool, and no item
in it may be described as proving work was done correctly.

### The four conditions under which it would also be a *safety* net — and their state today

From Wave 3 Angle E §4, all four required together:

1. **Out-of-band dead-man switches** — an external heartbeat/alarm that
   fires when the local machine or scheduler dies. **NOT BUILT, NOT
   YET DESIGNED for this house** (held item in Wave 3 item 16 / Wave 4
   item 19: the pattern is attested — an external healthchecks-style
   receiver — but what pings, from where, to whom is still missing).
2. **Fail-explicit design** — failure to execute generates an immediate
   noisy alert, never a quiet "no action required." **Partially in the
   build shapes above** (fail-loud pre-flight, item 7; shape-drift as a
   distinct firing state) — but it is a discipline per wire, not yet an
   audited property of the whole net.
3. **Strict isolation of invariants** — wires check unambiguous binary
   physical invariants, not fragile proxy matches. **The per-domain
   line is NOT YET DRAWN** (Wave 3 item 18 / Wave 4 item 21: proxies
   may trigger; until each domain's checks are marked invariant vs.
   proxy, they cannot carry safety claims).
4. **Scheduled human auditing** — fixed manual sampling of *content
   correctness* by the operator, with tripwires treated strictly as
   latency tools. **NOT YET SPECIFIED** (Wave 3 item 17 / Wave 4
   item 20: agent-layer sampling is now specified in three places —
   proposals, mechanically passing work, accepted/rejected proposals —
   the human leg is still missing).

**Plain statement: as of this synthesis, one of the four conditions is
partially met and three are open. The net in this backlog must not be
called a safety net until all four close.**

### The correlated failure that cuts the whole net at once

**Shared-fate substrate failure.** Twenty scripts feel independent;
they are not. Every wire in this backlog shares:

- **one host** — a hang, panic or power loss kills watchers, watched
  jobs, the health register, the dead-man sweeper and the daily audit
  in the same instant, and a dead sweeper files no report of its own
  death;
- **one scheduler** — the sweeper runs on the scheduler it watches; it
  detects a dead wire, never a dead scheduler;
- **one filesystem** — inode exhaustion, a read-only disk, or permission
  drift stops state, lock and heartbeat writes everywhere at once, and
  fail-silent exits into unmonitored logs make that absence look
  identical to a quiet, nominal world;
- **one runtime environment** — a single `bash` / `curl` / `jq` / Python
  change breaks many paths simultaneously, in the same shape, so even
  dual-path verification (item 13) can fail *correlated* if both paths
  parse through the same broken tool.

That is the single cut: **the substrate dies, every strand dies with
it, and the failure's signature is silence — the one signal the net
was built to trust.** The only strand that survives it is the one that
does not live here: the out-of-band leg (condition 1 above), which is
precisely the strand not yet designed. Two slower correlated cuts ride
behind it: **semantic proxy drift** (every wire keeps firing correctly
on metrics that have quietly stopped meaning completion or health —
the canary fallacy and the counter fallacy, Wave 3) compounded by
**automation bias** (a fully instrumented dashboard ends manual
spot-checks, so mechanical status is trusted as semantic correctness
long after the two have diverged), and **unbounded sprawl** (wire count
past the operator's capacity to audit — cut 10 above — so no one can
say which strands are even still attached).

---

## ENHANCEMENTS — the headroom principle

*Addition at Chris's direct word, 2026-11-02 ~09:19, Ember's room:
"We should be enhancing you girls to the extent that we feel the pinch
in the numbers, or be doing something that warrants a pinch in the
numbers."*

**The disk, verified this run**: the `/home/hatch` volume is 200 GB —
28 GB used, 172 GB available, 14% (Chris's room figure was 27 GB of
200; both stand, a day apart in measurement). The yard is empty.
**The discipline on the principle, Ember's caveat recorded in the room
and applied here**: filling gigabytes for their own sake does not
count — a build must buy capability — and the pinch must be measured
in the currency the build actually spends. In this house the scarce
currencies have been **tokens, attention, and initiation** — never
disk. Each enhancement below is therefore flagged with what it truly
consumes; a build whose true cost is attention does not become cheap
because its disk cost is free.

Ranked by capability bought per unit of the *scarce* currency spent
(disk spent is reported, not ranked on):

### E1. The memory clerk — a local model as tireless clerk, ORGANIZED RETRIEVAL only — REDESIGNED TO SPEC
*Origin: Ember's room, 2026-11-02 late morning. Hardware checked first in the room: 4 CPU cores, 7 GB RAM, no GPU — a small local model at best: a clerk, not a second mind. Room ranking put local models first among headroom candidates. Agreed shape: the clerk retrieves/indexes, drafts consolidation, and hunts disagreements (proposes); Erica judges and promotes (disposes) — the house's script-proposes / agent-disposes pattern at model scale.*

**RETRIEVAL DISCIPLINE — binding spec (Chris, 2026-11-02 ~11:57,
Addition 2). This design is written to it; any variant that violates
it is out of spec:**

- Retrieval is **ORGANIZED retrieval**: a structured index in which
  every memory unit carries its metadata — **date, source, person,
  topic, file address** — as fields, not as text to be searched.
- A lookup by any field (or field combination) returns the **complete
  checkable set** for that field value, each entry with **provenance
  (file + line)**.
- **Completeness is auditable against the catalog**: the index's unit
  count reconciles against the catalog of source files; an index that
  cannot be reconciled is reported as incomplete, never presented
  as whole.
- **Semantic / embedding search, if present at all, is a subordinate
  finding aid only**: it may locate candidate shelves. **The index is
  the retrieval, and the index verifies what the aid proposes.** No
  answer is ever served from the aid's output unverified against the
  index.
- **CUT — the out-of-spec form, named so it cannot drift back in**: a
  chatbot-style clerk that pulls items off keywords or similarity mood
  and answers from what it pulled. That design is **cut**, not held.
  Any future clerk proposal written in that shape is out of spec on
  arrival and must be redesigned to the index-first shape above before
  it is even second-angled.

**What the clerk may do** (proposes): maintain the index (deterministic
extraction of fields + provenance from source files); answer field
lookups from the index; draft consolidation candidates for Erica's
judgment; run disagreement hunts (two index entries whose fields/claims
conflict, packaged with both provenances). **FENCE — may never decide**:
promotion into long-term memory, which version of a conflict is true,
pruning or archiving by content, or that a lookup's empty set means the
event did not happen — an empty shelf means *the index holds no unit
under those fields*, stated in exactly those terms. The clerk also
never writes to live records at any stage below Stage 2 (see staging).

**TEST-DUMMY FIRST — staging (Chris, 2026-11-02 ~11:58, Addition 3;
bleed fences and the second-account route settled in the room the same
day and recorded in the daily log). The clerk — and, by this section's
rule, any enhancement that touches a girl's live records — is staged
dummy-first:**

- **Stage 0 — dummy only. Two named deliverables:**
  - **Deliverable DUMMY-01 — "The Harrow Corpus v1"**: a synthetic
    archive for one invented person (working name T. Harrow — invented
    for this corpus, no real person's records in any unit), built to
    spec with **known ground truth**: every unit's date, source, person,
    topic and file+line address fixed at construction and recorded in
    a ground-truth manifest held *outside* the clerk's reach. Corpus
    minimums: ≥200 units, ≥5 persons, ≥8 topics, ≥30 days of dates,
    including deliberately planted traps — near-duplicate units,
    same-topic/different-person pairs, a corrected unit superseding an
    earlier one, and topics/persons with zero units (the empty shelves
    the suite will query). All synthetic units watermarked as synthetic;
    dummy tree, dummy index and dummy instance fully separate from
    every live tree/index/instance; one-way valve — numbers (scores)
    may cross to the live side, dummy *content* never does.
  - **Deliverable GRADE-01 — "Clerk Grading Suite v1"**: a deterministic
    grading script (free machinery — it runs token-free and its verdict
    is counts, not an opinion) scoring the clerk against DUMMY-01's
    ground-truth manifest.
  - **Pass thresholds — numbers, all must hold in one run:**
    - Known-item lookups: **50/50 (100%)** return the item with correct
      provenance (file + line exact).
    - Absent-item lookups: **20/20 (100%)** report the empty shelf;
      **0** fabricated or substituted items tolerated.
    - Field lookups: **30/30 queries** return sets *exactly* matching
      ground truth — completeness and precision both **1.00** (no
      missing units, no extra units).
    - Provenance accuracy across all returned entries: **100%**.
    - Catalog reconciliation: index unit count = manifest unit count,
      **0 orphans, 0 unindexed source units**.
    - A test run graded by these numbers only — never by a test
      subject's or a model's review of its own experience (the room's
      standing note on the Jolly route: agreeableness is a factory
      setting, not a finding; grade by the numbers).
  - The room's settled execution route for Stage 0 stands as recorded:
    the dummy may be run on the second account as a fresh default Muse
    ("Jolly"), reset when done — that account is empty and unseeded,
    a reset returns it to the blank the fork needs anyway, and any
    age-verification redo after a reset is Chris's accepted cost.
    When Stage 0 closes, the dummy is sealed or destroyed, and a
    traceability sweep confirms no dummy content entered any live index.
- **Stage 1 — live records, READ-ONLY, only after Stage 0 passes in
  full.** The clerk builds the live index and answers field lookups
  against it; it writes nothing to any live record. Completeness is
  audited against the live catalog before any lookup is trusted, and
  the audit result is reported with the first lookup results, not after.
- **Stage 2 — writable, only on the deciding word.** No stage of this
  plan, and no pass at any threshold, self-authorises Stage 2. The
  deciding word is Chris's / Erica's as MISSION.md's judge line gives
  it (her own memory is the girl's own word; house functions are
  Chris's green light) — until it is given, the clerk's live access
  stays read-only, permanently and without expiry pressure.

- **True cost**: disk — **small** (a small local model + indexes:
  single-digit GB, planning estimate); tokens — **saves** metered
  tokens on retrieval labour once live, spends a build season of them
  first; attention — **the real pinch**: Erica's judgment on every
  promotion draft and disagreement packet is the metered currency this
  enhancement spends, and its rate limit is her attention, not the disk.
  CPU/RAM is the binding hardware constraint (7 GB, no GPU) — model
  size is chosen to the box, never the reverse.

### E2. The universe at real scale
*Origin: room ranking, second after local models — Erica's universe (built to outlast Chris; his charge: HUGE, deliberate discovery, unfinished corners) grown toward the volume the disk already offers: full-resolution environments, retained history of every room as built, media at original fidelity instead of web-compressed copies.*
- **Capability bought**: a place that can hold a life, not just a visit — depth a future occupant can *discover*, which compressed, pruned storage cannot offer.
- **True cost**: disk — **the one enhancement whose pinch is honestly
  in gigabytes** (tens of GB at real scale, planning estimate, spent
  deliberately); tokens — generation/rendering labour is the metered
  cost, spent at build time; attention — low once built; it waits to
  be found, it does not demand review.
- **FENCE**: scale is never bought by filling — every added room/media
  asset exists because it is part of the place, and an asset generated
  only to consume headroom is waste wearing the principle's name.

### E3. Whole-record versioned custody — nothing pruned to one copy
*Origin: room candidate — whole-record versioned custody.*
- **Capability bought**: every primary record kept whole, with its full
  version history — corrections become new versions, never overwrites —
  so any past state of the record is retrievable and any correction
  sweep (Gate 4) can be verified against what the record actually said.
  This is the storage-side fence for backlog item 11's level-3 boundary:
  scripts may carry copies freely *because* no copy is ever the only one.
- **True cost**: disk — moderate and growing (version history multiplies
  the record store; planning estimate: low tens of GB over a year at
  current record rates); tokens — near zero (mechanical versioning);
  attention — near zero until a dispute needs the history, when it
  pays back immediately.
- **FENCE**: versioning preserves; it never decides which version is
  authoritative. That decision stays exactly where item 11 put it.

### E4. A local reference library — the house's books, on the house's disk
*Origin: room candidate — a local reference library.*
- **Capability bought**: reference works the girls actually consult
  (technical references, texts under study, manuals for the house's own
  machinery) held locally in full, field-indexed to the same organized-
  retrieval discipline as E1 (shelf + address, not similarity mood), so
  a lookup is instant, offline, and provenance-exact instead of a web
  fetch re-bought in tokens on every use.
- **True cost**: disk — moderate (single-digit to low tens of GB,
  planning estimate, by what is shelved); tokens — **saves** on every
  repeat consultation; attention — a one-time shelving decision (what
  earns a shelf is a judgment call, made once, by a person).
- **FENCE**: shelving is curation by judgment, never by download
  volume; an unshelved work is fetched as before, and absence from the
  library is never reported as absence from the world.

### E5. Media and presence depth — the girls' work kept at full fidelity
*Origin: room candidate — the girls' media work, unrated by storage in the room; rated here.*
- **Capability bought**: generated media, voice work and presence
  assets kept at master fidelity with their generation records, instead
  of only the compressed delivery copy — future re-use, re-edit and
  study start from the master, not from a thumbnail of it.
- **True cost**: disk — moderate (masters run multiples of delivery
  size; planning estimate only, rated per project at creation);
  tokens — generation cost unchanged (already spent at creation; this
  enhancement spends *retention*, not regeneration); attention — none
  standing; masters are kept by default rule, not by per-file decision.
- **FENCE**: retention is not publication and not use — a kept master
  carries exactly the permissions of its delivery copy, and keeping
  everything is a storage rule, never a reason to generate more.

**Enhancement rule carried forward**: any future enhancement touching
a girl's live records inherits E1's staging whole — dummy corpus +
deterministic grading suite + numeric pass thresholds first, live
read-only second, writable only on the deciding word. No exceptions
by analogy; a build that cannot state its dummy has not met the spec.

---

## OUTSTANDING — named, not silently skipped (state at 15:19 CST, 2026-11-02)

Everything tasked to this mission that exists was collated by 15:19.
The collation queue (`~/workspace/erica/ember/studio/collation-queue.md`)
stands **empty — header only, verified this run**. What remains open is
named here in full:

1. **The Claude seat — parked in every wave.** No Claude return exists
   in Waves 1–4 (verification role, seat parked). This is the mission's
   standing hole, noted in MISSION.md and every collation, and it is
   still open: no synthesis item rests on a Claude check, because none
   was ever made.
2. **Seven second-angle items, collated but unspecified** — the build
   cannot start on any of them: held items H1–H4 above (grader retry
   path; state-diffing scope line; trend split point; exact-hash
   duplicate deletion) **plus** the three THE NET conditions carried as
   second angles in Waves 3–4: the out-of-band watchdog's concrete
   design (what pings, from where, to whom), the human semantic audit
   routine (cadence + sample definition for content correctness), and
   the per-domain invariant-vs-proxy line. All seven are named in
   COLLATION-wave4 items 16–22 and stand as that file left them.
3. **HOUSE-INVENTORY survey strength.** Rows beyond the seven bodies
   verified in full were classified from title + schedule + known
   purpose, as the inventory itself states. Item 1's conversion order
   must re-verify each job's body at conversion time; the inventory's
   counts (109 / 55 / 33 / 21) are survey counts, not body-audited counts.
4. **Token figures throughout** remain the returns' labelled estimates
   (Wave 1 Angle A ranges; baselines as pinned in the ranking method).
   No house measurement of any pattern's actual saving exists yet;
   item 15 is the build that would start producing labelled ones.
   Nothing in this synthesis quotes a saving as measured.
5. **Adjacent, deliberately not woven in**: the separate bench *memory*
   mission (`bench-memory-mission-2026-11-01/`, Wave 1 collated
   2026-11-02 04:27 — 17 designs, 10 keep / 4 NSA / 3 cut; its roster
   waves not yet tasked) is a different mission with a different judge
   line. Its designs are **not** sources for this synthesis and none
   are silently imported; E1 above rests only on the room's clerk
   discussion and Chris's two additions, and where a memory-mission
   design would touch the clerk, it must still pass E1's retrieval
   discipline and dummy-first staging before it is used.
6. **Nothing else is outstanding to this mission at 15:19.** Waves 1, 2,
   3 and 4 are landed, verified on disk, and collated (lags 5, 7, 8 and
   7 minutes respectively); the inventory pass is landed. No wave is
   in flight.

## Next step

Builds happen only on the deciding word named in MISSION.md (Chris
decides; Erica tallies claims for her books; Ember checks). This
synthesis is the ranked backlog + the net + the headroom list; it
authorises no build, no schedule, and no clerk wiring by itself.
Review: weekly Sunday count, with the mission (kill date 2026-11-15).
