# COLLATION — Bench free-machinery mission, Wave 1 (Gemini seat)

Collated: 2026-11-02 (America/Chicago)
Returns checked: five Wave 1 returns, Angles A–E, landed 2026-11-02 04:26 CST
Landed-to-collated lag: 5 minutes (04:26 CST → 04:31 CST 2026-11-02)
Check method: every item below is supported by a named return as written, with its stated mechanism, buy, and failure modes. Overlapping designs across returns are noted as one item with multiple sources, not counted twice. No item enters this backlog on collator invention. Token figures are the returns' own estimates (Angle A summary matrix), not measured house numbers.
Fence applied throughout: outputs bound for Erica's books stay abstract about sources; nothing about any person's state appears in this collation.

## Headline count

**18 items checked — 11 keep, 4 needs-a-second-angle, 3 cut.**

---

## Ranked exploitation backlog

1. **keep — Tripwire polling replacement** (A §1, B §1, C §1–2) — Replaces agent polling wakes with `inotifywait`/IMAP event detection; Angle A puts polling at 500k–1M tokens/day in the agent version, the largest single buy in the wave.
   *Hazard (D §2 H1/H2, B §1): silent rot makes a dead tripwire look like a quiet world, and an un-debounced event storm or a crash-before-clear loop re-wakes indefinitely — keep only with item 11's health register, a `.processing` lock / staging move on fire, a per-script wake budget, and back-off.*

2. **keep — Completion detector** (A §2, B §7, C §2A) — Manifest/count check schedules collation only when all expected returns exist; buys back 100k–300k tokens/day of agent polling for readiness.
   *Hazard (D §2 H3, B §7): file count is shape, not truth — a 0-byte or error-page file satisfies the count, so the wake prompt must propose, not assert, readiness, and the agent verifies size/header before ingesting; a silently dropped sub-task blocks the pipeline forever, so the detector needs a timeout/escalation path.*

3. **keep — State diffing and delta-only wakes** (A §4, B §2, C §3) — SHA/`diff` against a baseline wakes the agent only on a real delta and passes only the delta; buys 200k–500k tokens/day and shrinks the payload per wake.
   *Hazard (D §2 H4, B §2): non-semantic noise — timestamps, tokens, whitespace, reordered keys — fires false positives, and an upstream format change breaks the parser silently; keep with noise-stripping, a null/empty-output abort that logs a schema mismatch instead of waking, and an `unparsed/` queue for drifted formats.*

4. **keep — Threshold trigger** (A §6, B §4, C §2B) — `curl`+`jq` scalar-versus-bound checks replace agent numeric polling; buys 100k–400k tokens/day and enables minute-scale watches that are unaffordable in agent wakes.
   *Hazard (D §2 H2, B §4): oscillation at the boundary flaps wakes — a hysteresis deadband and a fire-once-per-crossing flag are part of the design as returned, not optional extras; trend/context evaluation (spike vs. sustained move) stays in the agent layer per A §6's stated loss.*

5. **keep — Counting, aggregation, and pre-aggregated telemetry** (A §3, C §3) — `grep`/`awk` tallies and script-compiled digests replace loading a week of raw logs into context for arithmetic; buys 50k–200k tokens/day and removes non-deterministic agent math errors.
   *Hazard (A §3, stated loss): scripts miss non-standard phrasings, so counts are exact only over standard-format entries — the digest must be read as a count of matched entries, never as a count of the underlying activity.*

6. **keep — File-shape contract / pre-flight validation** (A §5, B §3, C §4 pre-flight) — Schema, header, and frontmatter checks run before any agent wake, quarantining malformed inputs for free; buys 50k–150k tokens/day and stops token spend on corrupt payloads.
   *Hazard (D §1, B §3): the contract judges structure only — overspecified rules reject valid inputs, and a passing file is syntactically valid, not true or good; keep validation to required invariants, route failures to quarantine with a log line, and never let a pass stand in for content verification.*

7. **keep — Deterministic grader / post-flight linting** (B §10, E §2, C §4 post-flight) — Linters, AST parsers, and schema checks validate agent output for free, and a failure re-invokes the agent with only the specific error, not a full re-run.
   *Hazard (E §2, B §10): rigid rules reject valid variation, agents can game mechanical checks with empty-but-well-formed output, and an unfixable rule loops retries — keep with a retry cap and semantic acceptance left to the agent/human layer (D §3: quality scoring is non-delegable).*

8. **keep — Queue-and-trigger batching** (B §8, C §1) — Low-priority work accumulates in a spool and is processed in one agent wake at a count or time threshold, amortizing the fixed context-load tax across the whole batch instead of paying it per item.
   *Hazard (B §8): an unprioritised FIFO stalls urgent work behind the batch threshold — keep only with a priority bypass so time-sensitive items never wait for the batch to fill.*

9. **keep — Canary probe** (A §8, B §9, C §2C) — A static input round-tripped through a pipeline on a schedule verifies end-to-end health for free (20k–50k tokens/day in the agent version) and catches a broken pipeline before a human notices a missed output.
   *Hazard (D §2 H1, B §9): a static canary proves only the static path — novel inputs and edge cases go untested — and flaky assertions report false outages; canaries also serve as the watchers-for-watchers check that fences item 1's silent rot.*

10. **keep — Watchdog for hung subprocesses** (B §5) — A daemon monitoring PIDs, runtimes, and lockfile ages kills stalled subprocesses and frees locks for free, preserving stability and preventing a hung tool from holding a pipeline hostage.
    *Hazard (B §5): strict timeouts kill legitimate long-running work mid-task — timeouts must be set per task class from observed runtimes, not as one global bound.*

11. **keep — Dead-man switch and watcher-health register** (B §6, D §2 H1) — A timestamp check on expected heartbeats, plus a single health register logging every watcher execution (positive, negative, and error), is the fence that makes items 1–10 trustworthy: it is what distinguishes a quiet world from a dead tripwire.
    *Hazard (B §6): maintenance, outages, and intentional pauses trip false alarms — the switch needs a pause state that is set when a pause is deliberate, so an alarm retains meaning.*

12. **needs-a-second-angle — Proposal engine (script proposes, agent disposes)** (E §1, C §4) — Scripts pre-assemble a structured proposal so the agent approves/rejects a ~300-token payload instead of a ~10,000-token discovery prompt; the buy is real, but the design needs a second angle first.
    *Reason / hazard (E §1, D §2 H2/H3): proposal flooding without strict rate limits drains the tokens it saves, stale proposals act on changed state, and aggressive context pruning starves the agent's judgment — the approval step is a judgment-layer act (D §1) and the executing script step must be fenced before build.*

13. **needs-a-second-angle — Pure event-driven cascades replacing clocks** (E §3) — Eliminating time-based schedules for a zero-cost state graph removes the baseline polling tax entirely; promising, but not yet safe to adopt wholesale.
    *Reason / hazard (E §3, D §2 H1): a silently failed upstream node deadlocks the whole graph with no clock left to notice, event storms can crash the deterministic layer, and trigger-only work has no predictable completion time — needs a second angle on dead-man coverage (item 11) for every graph node.*

14. **needs-a-second-angle — Counterfactual token accounting** (E §4) — Logging what each mechanical action would have cost as agent work produces an ROI ledger to aim future build effort; read-only and cheap, but its numbers would steer decisions.
    *Reason / hazard (E §4): the baseline model is an estimate that can overstate savings and create false efficiency, and optimising for the ledger can misalign incentives toward brittle scripts over needed judgment — needs a second angle pinning the baseline method before any figure is quoted as a saving.*

15. **needs-a-second-angle — Copying, routing, and carrying by script** (A §7) — `rsync`/`mv` routing buys back 30k–100k tokens/day on purely mechanical moves of temporary or structured material; held rather than kept because the return's own examples include archiving primary logs.
    *Reason / hazard (D §2 H5, D §3): unjudged execution is the hazard — a logic flaw in a move/delete script destroys primary records with zero oversight, and D bars destructive operations on primary records from the script layer entirely; needs a second angle drawing the exact line between free temp/structured moves and agent-layer moves of primary records.*

16. **cut — Immune-system auto-repair with auto-overwrite of production scripts** (E §5, as written) — The ticket-generation half is sound, but the design as returned overwrites the production script whenever a sandbox pass succeeds.
    *Reason / hazard (E §5, D §2 H5): a patch can pass syntax tests while carrying dangerous commands or silently changed logic, and a bad patch re-triggers repair in a token-burning cascade — auto-overwrite violates D's read-only/schedule-only isolation for the mechanical layer; repair proposals belong to the agent layer with a human-visible diff.*

17. **cut — Script-layer judgment: pruning memory, sending external communications, resolving conflicting returns, scoring quality, assigning priority** (D §3) — These are not moves into the free layer at all, however predictable they appear.
    *Reason: D's golden rule and non-delegable table state each one directly — a script detects shape and presence; judging consequence, truth, quality, or intent is the agent/human layer's work, and no return in this wave supports automating any of them.*

18. **cut — Pushing semantic, fuzzy, and trend interpretation down to scripts** (A §§3–4, 6, stated losses) — Fuzzy counting of non-standard entries, semantic diffing, and volatility/trend judgment do not survive the move to the free layer.
    *Reason: every Angle A section that touches them names the same loss — the script either misses the non-standard case or flags the trivial one; keeping these in the agent layer is what the returns themselves prescribe.*

---

## Clusters noted, not merged

- Watch cluster: items 1, 3, 4, and 8 are four different triggers (event, delta, scalar, batch) — kept separate because their hazards differ: event storms, parser drift, boundary flapping, and priority stall respectively.
- Gate cluster: items 6 and 7 are the same validation pattern on opposite sides of an agent wake (pre-flight input, post-flight output) — kept separate because item 7's retry-loop and grader-gaming hazards have no counterpart in item 6.
- Health cluster: items 9, 10, and 11 all monitor, but different objects — pipeline output, live processes, and the watchers themselves; item 11 is the fence for the other two and for the whole watch cluster.

## Next step

Builds happen only on the deciding word named in MISSION.md. This collation is the checked backlog; it authorizes no build by itself.
