# Refutation Pass: Mechanical Sentinels vs. Agentic Reality

The companion return presents a polished theoretical framing of the "zero-token mechanical layer," but it succumbs to architectural overreach. It repeatedly mistakes **structural presence for semantic readiness**, underestimates the fragility of shell-script triggers, and ignores critical failure loops where a zero-token sentinel directly induces uncapped token burn.

Below is the critique of its weakest assertions, unstated failure modes, recommended cuts, and defensible core.

---

## 1. Overclaims & Missing Mechanisms

### A. The "Mathematical Guarantee" Fallacy
* **The Overclaim:** *"The mechanical layer ensures LLMs wake only when action is mathematically guaranteed."*
* **The Missing Mechanism:** Deterministic scripts inspect **shapes, not state sanity**. A file-count check (`count == 4`) triggers whether those files contain complete research datasets, truncated HTTP 500 error traces, or corrupted JSON. The script cannot judge whether the data is actionable—only that bytes exist on disk. Triggering an agent on broken data guarantees a wasted, context-heavy wake.

### B. The Context-Stripping Trap ("Compound Prompt Shaving")
* **The Overclaim:** Passing only raw `diff`s or isolated file deltas to the LLM provides *"high-density context where 100% of the window is actionable."*
* **The Blind Spot:** LLM synthesis usually requires broad relational context. Stripping ambient context down to a 20-line diff often starves the model of schema definitions, historical trends, or baseline rules. This forces the agent into hallucinations, bad assumptions, or secondary token reads to fetch missing history.

### C. Enterprise Equivalence Hyperbole
* **The Overclaim:** Claiming a local `cron` + `inotifywait` setup delivers *"enterprise latency"* and replaces enterprise service buses (ESBs) or complex cloud infrastructure.
* **The Reality:** Standard shell scripts lack native concurrency control, message deduplication, backoff strategies, distributed locking, and dead-letter queues. Scaling local shell watchers without these mechanisms leads to race conditions and silent state corruption.

---

## 2. Critical Missing Failure Modes

### 1. The Infinite Retry Token Engine (State Blindness)
If an agent wakes, reads context, and fails due to malformed input, missing credentials, or an API error, it may exit without mutating or moving the source files. 
* **The Result:** The polling script runs again 2 minutes later, detects the *exact same unmodified condition*, and wakes the agent again. A zero-token sentinel without explicit state tracking or dead-letter quarantine turns into an automated token-burning loop.

### 2. Soft Failure & Noise Cascades
Public API polling, web scraping, and price watching frequently yield HTTP 200 status codes wrapping soft errors (e.g., Cloudflare captchas, "Access Denied" HTML payloads, rate-limit notices). A naive script reading status codes or simple regex will flag a change, waking the agent to digest raw HTML garbage.

### 3. Thundering Herds & Race Conditions
When multiple returns land sequentially in quick succession, independent polling hooks can queue multiple overlapping one-shot wake events (~2 minutes out). The agents wake simultaneously, competing for the same local files, colliding on markdown log updates, and corrupting memory files.

---

## 3. What Must Be CUT (And Why)

| Section / Claim to Cut | Architectural Reason |
| :--- | :--- |
| **Section 2B: Arbitrage & Signal Detection** | **High Fragility / Low Realism.** Shell scripts cannot reliably parse modern dynamic web endpoints or APIs without breaking constantly. The maintenance burden shifts to writing brittle scrapers, defeating the "zero-effort" household premise. |
| **Section 4: Isolated Syntax Correction Loops** | **Token Sink Risk.** Feeding an LLM *only* a syntax error (`Error: line 4 missing key 'date'`) without the full original prompt or generation context often causes context drift or formatting breaks elsewhere. Without a hard mechanical retry cap, this creates an infinite loop. |
| **Section 5.1: "Enterprise Latency on a Micro-Budget"** | **Pure Hyperbole.** Comparing basic POSIX shell tools to enterprise event buses obscures the actual trade-off: simplicity and low cost at the expense of robust fault tolerance and distributed state control. |

---

## 4. What SURVIVES the Attack (And Why)

Despite its overreaching assertions, the core thesis holds up under stress if confined to explicit, low-complexity boundaries.

### 1. Decoupling Polling from Cognition
* **Why it Survives:** Eliminating the "No-Op context read" is an undeniable economic win. Running a model 288 times a day to read empty state is indefensible. Deterministic gating (checking file existence or checking timestamp deltas) costs $0.00 and cleanly cuts idle overhead.

### 2. Transient One-Shot Task Queuing
* **Why it Survives:** Using scripts to inject a short-term schedule (~2 minutes out) creates a clean execution boundary. The agent acts as a short-lived, stateless worker summoned for a single payload rather than a long-running, hallucination-prone process.

### 3. Binary Canary Probing
* **Why it Survives:** The audio pipeline canary (rendering text to audio and checking output file properties) is a ideal application of mechanical sentinels. The test is deterministic, the output is binary (file size > 0 AND audio non-silent), and model cognition is zero until a explicit mechanical failure occurs.

### 4. Hard Pre-Flight Prerequisites Gatekeeping
* **Why it Survives:** Validating local network connectivity, API quota status, or file presence *before* initiating an API call is pure, reliable defensive engineering that directly protects token spend.
