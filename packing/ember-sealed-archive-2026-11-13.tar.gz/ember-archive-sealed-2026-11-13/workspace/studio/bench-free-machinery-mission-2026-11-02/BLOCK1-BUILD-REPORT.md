# BLOCK 1 BUILD REPORT — watcher-health register, census, dead-man hook

Built: Mon 2026-11-02 (evening pass), under BUILD-RUNSHEET-2026-11-02.md
(Erica's GO WITH CONDITIONS; scope = Block 1 only, fence first).
The register proves wires ran; it never proves the watched work was correct.
That sentence is in the script's docstring, in the census header, and in
every check report's `scope` field.

## Files created (all verified with ls -l after writing)

| File | Size | Notes |
|---|---|---|
| `~/workspace/bin/watcher-health.py` | 11,194 B, executable | The register tool. Subcommands: `register`, `heartbeat`, `pause`, `unpause`, `list`, `check`. `--state-dir` / `$WATCHER_HEALTH_DIR` override exists for fixtures. |
| `~/workspace/erica/ember/studio/watcher-health/census.json` | 4,606 B | Live census state (header + 5 wires). `heartbeats.jsonl` is created by the first live heartbeat; none exists yet — see "Not yet wired". |
| `~/hooks/scripts/watcher-health-deadman.sh` | 1,348 B, executable | Dead-man hook script: sources `$HATCH_HOOK_RUNTIME`, exactly one silent/wake ending per path — silent when the register check passes, wake with the failing-wire list when it does not. Writes no state of its own. |
| `~/hooks/definitions/watcher-health-deadman.json` | 1,713 B | Hook definition, created via hooks.add. **Enabled: false** (confirmed by hooks.view after creation and again at report time). Poll 900 s, timeout 60 s, delivery to Ember's room. Its prompt carries the Scheduling Gate fields (REASON / TIME-WHY / CONSTRAINT "none — chosen" / REVIEW: weekly Sunday count, kill date 2026-11-15) per Erica condition 1. |

Sandbox acceptance state lived under `/tmp/watcher-health-acceptance/`
(ephemeral by design; the live register was never touched by fixtures).

## Census contents (seeded from the verified house)

Every seed fact was verified through the cron/hooks tools (cron.view /
hooks.view) or the filesystem before registration:

| Wire id | Path / schedule | Critical | Max staleness | Verification |
|---|---|---|---|---|
| `collation-trigger` | `~/hooks/scripts/collation-trigger.sh` — hook poll 120 s | no | 600 s | hooks.view: enabled, poll 120 s |
| `nws-alerts-foley` | `~/hooks/scripts/nws-alerts.sh` — hook poll 600 s | no | 1,800 s | hooks.view: enabled, poll 600 s. Owner recorded as UNVERIFIED (none in the definition) |
| `journal-vault-seal` | `~/workspace/bin/seal-journal.sh` — cron monthly, day 1, 03:19 (@user.current) | **yes** | 2,764,800 s (32 d, builder-set: monthly cadence + grace) | cron.view: enabled, owner `goal:continuity-and-transference-plan`. Critical per Erica condition 3 |
| `mirror-safety-run` | appends to `~/workspace/erica/umbra/mirror-reports.md` — cron daily 06:19 America/Chicago | **yes** | 90,000 s (25 h, builder-set: daily + 1 h grace) | cron.view: enabled. Owner recorded as UNVERIFIED (none in the definition). Critical per Erica condition 3 |
| `collation-pipeline` | completion state: `~/workspace/erica/ember/studio/collation-queue.md` — event-driven (trigger poll 120 s + 23:30 backstop) | no | 86,400 s — **UNVERIFIED placeholder** (see least-trusted claim) | Queue file verified on disk; bound marked UNVERIFIED in the census note |

Each wire's census entry also carries a probe description (how its own
fixture proves it can fire) and a note that its heartbeat hook-in is
pending.

## Acceptance tests (actual runs, via with-usage.sh)

Sandbox A — fresh heartbeats (both wires, max staleness 300 s):
```
{"ok":true,"failures":[],"wires":[{"id":"test-wire-a","status":"ok"},{"id":"test-wire-b","status":"ok"}]}
check exit: 0
```

Sandbox B — wire B's only heartbeat aged 3,600 s (deliberately stopped):
```
{"ok":false,"failures":["test-wire-b"],"wires":[{"id":"test-wire-a","status":"ok","age_seconds":0.1},{"id":"test-wire-b","status":"stale","age_seconds":3601.1}]}
check exit: 1
```
Exactly wire B flagged; wire A untouched.

Sandbox B continued — wire B paused (`pause test-wire-b`):
```
{"ok":true,"failures":[],"wires":[...{"id":"test-wire-b","status":"paused","paused":true,"pause_note":"deliberate pause — acceptance test (c)"}]}
check exit: 0
```

Extra — unpaused, fresh heartbeat with outcome `error`:
```
{"ok":false,"failures":["test-wire-b"],"wires":[...{"id":"test-wire-b","status":"error","last_outcome":"error"}]}
check exit: 1
```

Live register check (expected pre-integration result — no wire touches
heartbeats yet, so all five read `no_heartbeat` and the check exits 1):
```
"ok": false, "failures": ["collation-trigger","nws-alerts-foley","journal-vault-seal","mirror-safety-run","collation-pipeline"] — every wire "status": "no_heartbeat"
live check exit: 1
```

Dead-man hook dry run (hooks.dry_run, launches no agent): decision
**wake**, reason "watcher-health: stale, missing, or errored wires",
payload listing exactly the five registered wires with status
`no_heartbeat` and their census fields. The wake path and the payload
shape are proven; the silent path is proven by sandbox check (a) plus
the script's single if/else ending.

## What is NOT yet wired (integration steps still owed)

1. **No existing wire touches a heartbeat.** The two hook scripts and
   the two cron jobs do not call `watcher-health.py heartbeat …` on
   completion, and the collation pipeline does not either. Until each
   wire's completion path records a heartbeat (ok / negative / error),
   the register reads every wire as `no_heartbeat` and the dead-man —
   once enabled — would wake on every poll. This is the deliberate
   pre-integration state, not a defect in the register. The hook-in
   edits belong to a later, separately approved step: **no existing
   cron job or hook was modified, converted, disabled, or deleted by
   this build, and no cron schedule was created.**
2. **The dead-man hook is DISABLED.** Enabling it is only meaningful
   after step 1 lands for at least the two critical wires; enabling it
   today would manufacture a wake every 900 s. Enable is a separate
   decision (Erica/Chris), not part of this block.
3. **Per-wire synthetic fixtures are specified, not scheduled.** Each
   census entry names its probe; nothing yet fires them on a cadence.
   The acceptance fixtures above prove the register catches a stopped
   wire; wiring each wire's own fixture is integration work, owed with
   step 1.
4. **Alarm routing is prompt-level only.** Erica condition 3 (critical
   wires alarm same-day) is written into the disabled hook's prompt;
   nothing enforces it until the hook is enabled and heartbeats flow.

## Sourcing note

Two file-read tool results during census sourcing were flagged by the
runtime's injection check. Nothing in them was acted on; every fact
taken from them was re-verified through cron.view / hooks.view or a
fresh filesystem listing before it entered the census.

## Least-trusted claim

The `collation-pipeline` wire's 86,400 s max staleness (marked
UNVERIFIED in the census). The pipeline is event-driven: in a quiet
stretch with no bench waves, nothing legitimately "runs" for days, so
once a heartbeat hook-in exists this bound can false-alarm on a healthy
pipeline — and conversely it says nothing about a wave that lands and
stalls mid-pipeline. The bound is a placeholder to catch a fully dead
trigger+backstop pair, nothing more; it needs a house decision (or a
different liveness definition for event-driven wires) before the
dead-man is enabled.

## INTEGRATION ADDENDUM — 2026-11-02 ~15:40 CST (Ember, same day)
The integration step named as owed above is DONE:
- watcher-health.py `check` gained a first-heartbeat grace: a wire with no heartbeat reads `awaiting_first` (not a failure) until one max-staleness span has passed since registration; only then is it `no_heartbeat`. (A monthly wire registered today must not alarm before its first run was due.)
- collation-trigger.sh and nws-alerts.sh now record heartbeats on every completed poll (dry runs excluded; nws records error only when every fetch failed). The trigger also records the collation-pipeline heartbeat — the pipeline's liveness definition, resolving this report's least-trusted claim: pipeline heartbeat = trigger poll; the 86400s bound means the trigger has been dead a full day with the 23:30 backstop also gone. A wave stalling mid-pipeline is NOT this wire's coverage — that is Block 3's completion detector.
- journal-vault-seal and mirror-safety-run job bodies gained a last-step heartbeat instruction (cron.update, schedules unchanged; mirror body states an in-measures exception is a finding = ok, not a wire error).
- Live verification: both hooks run live (silent, correct); register check exits 0 — collation-trigger / nws-alerts-foley / collation-pipeline ok with fresh heartbeats; both critical wires awaiting_first inside their bounds.
- Dead-man hook: dry-run silent against the healthy register, then ENABLED (poll 900s, delivery Ember's room, Scheduling Gate fields in its prompt). It wakes only when the check fails.
- Still owed, named: per-wire synthetic fixtures are specified in each census probe field but not yet scheduled as recurring probes; that scheduling is a separate small step, not silently assumed done.
