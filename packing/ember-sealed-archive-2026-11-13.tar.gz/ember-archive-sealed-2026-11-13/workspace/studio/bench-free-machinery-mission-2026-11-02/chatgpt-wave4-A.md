Auditing a Token-Metered Agent Household
Moving mechanical work below the model layer without sacrificing judgment

The central architectural principle is:

An agent should spend tokens deciding what something means, not discovering that something happened.

A model is an expensive, probabilistic reasoning engine. A shell script is a cheap, deterministic state machine. Treating them as interchangeable wastes money in one direction and creates reliability problems in the other.

The useful division is not simply scripts versus agents. It is:

Detection: Did something happen?

Classification: Does the observed state match a defined condition?

Preparation: Can the relevant evidence be assembled into a usable package?

Judgment: What does it mean, what should happen, and is that action appropriate?

Execution: Carry out an approved action and verify its result.

The first two are predominantly deterministic. Preparation is usually deterministic with carefully defined boundaries. Judgment belongs to the agent. Execution can often be deterministic once judgment has authorized it.

One important qualification: scripts are not inherently reliable just because they are deterministic. They reliably repeat their assumptions, including incorrect assumptions. Their value comes from making those assumptions explicit, testable, and cheap to verify.

ANGLE A — INVENTORY: What Should Never Have Been Burning Model Tokens?
1. Polling and state watching

Mechanical pattern: Repeatedly inspect a known location or endpoint and detect whether its state has changed.

Examples:

Check whether a file has appeared.

Check whether an email or reply has arrived.

Check whether a job status changed from running to complete.

Check whether a monitored price crossed a configured threshold.

Check whether an endpoint is responding.

Check whether a folder contains unprocessed items.

Agent implementation / Script implementation

Wake agent every few minutes. / Cron, systemd timer, or event hook.

Read status or inspect folder. / Check file existence, metadata, API response, or stored state.

Decide whether something changed. / Compare current state against last-known state.

Report or initiate next action. / Emit an event only on a defined transition.

Cost of agent version: Every unnecessary waking incurs prompt/context ingestion, model execution, and possibly output tokens.

Cost of script version: Negligible CPU and storage, plus endpoint/API costs where applicable.

What is lost: Nothing when the question is genuinely binary and the source of truth is reliable.

Boundary: A script can detect a new email. It cannot reliably determine whether that email contains an important change in contractual obligations without an appropriate semantic evaluator.

A useful implementation is edge-triggered rather than level-triggered:

if current_state != previous_state:
    emit_event()
    persist(current_state)

This avoids repeatedly waking an agent simply because a condition remains true.

2. Arrival detection and batch completion

Mechanical pattern: Wait until a known collection of inputs has arrived.

Examples:

Research returns have landed.

All files in an expected batch are present.

A report has finished exporting.

A response set has reached its expected count.

A download has completed.

A directory has stopped changing for a defined settling interval.

Agent version: Wake, inspect directories, determine which inputs have arrived, decide whether the collection is complete, then wait or schedule another check.

Script version:

Define expected inputs or a completion manifest.

Check presence and validity.

Verify stable file sizes or checksums.

Check completion markers.

Emit one batch-complete event.

Create a one-shot agent wake.

The bench-research example is exactly the right pattern.

The script does not need to understand the research. It needs to establish that the required returns exist and have not already been collated.

The agent then receives the work at the point where reasoning becomes necessary.

What is lost: Only flexibility when completion criteria are undefined or genuinely ambiguous.

A particularly important safeguard: distinguish all expected inputs arrived from no new inputs have arrived recently. Those are not equivalent.

Silence is not proof of completeness.

3. Counting and tallying

Mechanical pattern: Calculate totals, frequencies, rates, and compliance counts.

Examples:

Weekly task completion counts.

Number of successful versus failed runs.

Number of outstanding replies.

Number of files processed.

Number of missed scheduled jobs.

Token expenditure by category.

Percentage of successful canary checks.

Agent version: Read logs, count events, calculate percentages, summarize results.

Script version: Parse structured records, count them, calculate arithmetic, emit a report.

Example:

completed = count_events("completed")
failed = count_events("failed")
total = completed + failed

rate = completed / total if total else None

What is lost: Interpretive commentary.

The script can say completion fell from 92% to 74%. It cannot establish whether that decline is significant, explain the cause, or determine whether the measurement itself is misleading.

An agent should receive the numbers when interpretation is required, not be paid to calculate them.

4. Diffing and drift detection

Mechanical pattern: Compare two known states and identify differences.

Examples:

File catalog versus actual disk contents.

Expected configuration versus deployed configuration.

Previous inventory versus current inventory.

Scheduled jobs versus registered jobs.

Required files versus existing files.

Memory index versus actual memory files.

Agent version: Read both states, compare them, identify discrepancies.

Script version:

Enumerate both sources.

Normalize paths and identifiers.

Compare sets, hashes, timestamps, or structured fields.

Generate a discrepancy report.

missing = expected_files - actual_files
unexpected = actual_files - expected_files

What is lost: Judgment about significance.

A missing temporary file and a missing primary record may both be discrepancies, but they are not equally important.

The script should classify differences according to explicit rules and escalate exceptions it cannot classify.

A good drift checker does not silently repair everything it discovers.

It reports first. Repair requires a separate authorization policy.

5. Format and structural validation

Mechanical pattern: Check whether data conforms to a known specification.

Examples:

Markdown front matter is valid.

JSON parses.

Required headings exist.

Filenames follow a convention.

A report contains required sections.

An expected number of columns exists.

A file has the correct extension.

A schema contains all required fields.

Agent version: Read documents and inspect their structure.

Script version: JSON Schema, regular expressions, parsers, validators, and explicit structural checks.

What is lost: Almost nothing for formal requirements.

The important distinction is between syntactic validity and semantic correctness.

A report can have every required heading and still be completely wrong.

Scripts validate structure. Agents evaluate meaning.

6. Threshold watching

Mechanical pattern: Compare a numerical measurement against a configured boundary.

Examples:

Price below a specified amount.

Disk usage above 85%.

Retry count above three.

Queue size above a limit.

Response latency above a threshold.

Compliance rate below a minimum.

Agent version: Wake, retrieve the measurement, compare it against the threshold, decide whether to report.

Script version: Query, compare, debounce, record, alert.

if value >= threshold and not alert_already_sent:
    emit_alert()

What is lost: Context-sensitive interpretation.

A price threshold can be mechanical. Whether the underlying opportunity is worth acting on may require judgment.

Use hysteresis where values fluctuate around a boundary:

Enter alert state above 85%.

Clear alert state below 80%.

Otherwise, a noisy measurement can create repeated alerts and unnecessary agent wakes.

7. Copying, carrying, routing, and archiving

Mechanical pattern: Move known artifacts between known locations under explicit rules.

Examples:

Place incoming research in a designated folder.

Copy a completed report into an archive.

Route a response to its assigned agent.

Move processed files into a completed directory.

Generate an index of newly arrived files.

Attach known metadata to a file record.

Agent version: Wake, inspect files, decide where to place them, execute the move, and confirm it.

Script version: Apply a deterministic routing table and verify the resulting operation.

What is lost: Contextual understanding of whether the destination is appropriate.

If the rule is:

research_returns/*.md
    -> research_archive/YYYY-MM/

there is no reason to invoke a model.

If the question is whether a document constitutes a final approved deliverable, a script should not infer that from its filename.

The detailed safety boundary appears in Question 4 below.

8. Heartbeat and pipeline verification

Mechanical pattern: Verify that a known component or processing chain remains operational.

Examples:

Endpoint responds.

Scheduled job ran.

Audio pipeline renders known text.

Output file exists.

Output is nonempty.

A process exits with the expected status.

A canary matches a known expected result.

The existing daily audio canary is a particularly good example.

Agent version: Wake, submit known text, inspect output, decide whether the pipeline worked.

Script version: Execute the known test, inspect exit status, validate output properties, record the result.

What is lost: Deeper quality evaluation.

A successful render does not prove that generated audio sounds natural. A responding endpoint does not prove that the service is behaving correctly.

There are multiple levels of verification:

Process is alive.

Process accepts input.

Process produces output.

Output passes structural validation.

Output meets a quality standard.

The first four can often be automated deterministically. The fifth may need a model, a human, or a specialized evaluator.

9. Scheduling and bookkeeping

Mechanical pattern: Maintain timers, job registrations, and execution records.

Examples:

Create one-shot schedules.

Calculate the next weekly run.

Record completion timestamps.

Prevent duplicate job creation.

Expire old temporary records.

Track retry counts.

Maintain last-successful-run timestamps.

Agent version: Wake to inspect the calendar or job registry, calculate what is due, and update schedules.

Script version: A scheduler and persistent job-state database.

What is lost: The ability to reconsider whether a task remains worthwhile.

A script should execute an established schedule. An agent should reconsider the purpose or priority of that schedule when circumstances change.

Inventory summary: the mechanical boundary

Work class / Default owner / Escalate when

Polling / Script / State requires interpretation

Arrival detection / Script / Completion is ambiguous

Counting / Script / Meaning or significance matters

Diffing / Script / Discrepancy needs contextual judgment

Format validation / Script / Semantic validity matters

Threshold watching / Script / Action depends on context

File routing / Script / Classification is uncertain

Heartbeat verification / Script / Quality, not liveness, is in question

Scheduling / Script / Priority or purpose needs reconsideration

Collation / Agent / —

Research synthesis / Agent / —

Conflict resolution / Agent / —

Strategic prioritization / Agent / —

Interpretation / Agent / —

Exception handling / Agent or human / —

A useful test for every proposed script:

Can the complete decision be expressed as a deterministic predicate over observable state, with an acceptable false-positive and false-negative rate?

If yes, script it.

If no, identify precisely which part needs judgment. Do not automatically hand the entire workflow back to the model.

For example, an agent may need to interpret a research batch, but it does not need to locate every file, count them, check whether the batch is complete, or construct its input package.

That separation is where the savings accumulate.

SECOND ANGLE 1 — PROPOSAL ENGINE
Can a 300-token approval replace a 10,000-token discovery prompt?

Potentially, yes. But only if the proposal is an honest compression of evidence rather than a replacement for evidence.

There are two very different architectures:

Architecture A: Evidence-backed proposal

The script gathers the evidence, identifies a predefined decision, calculates relevant facts, and presents a compact proposal with traceable supporting material.

The agent evaluates the proposal and can inspect the evidence.

Architecture B: Evidence-blind proposal

The script presents a conclusion and asks the agent to approve it without providing a way to inspect its supporting evidence.

Architecture A can save substantial tokens.

Architecture B creates an approval machine.

The problem is not the 300-token payload. The problem is whether the agent has enough information to disagree intelligently.

1. What a good proposal contains

A proposal should have a stable, machine-readable structure:

Field / Purpose

Proposal ID / Unique identity and deduplication

Proposed action / Exactly what would happen

Trigger / Why the proposal exists

Evidence references / Where the supporting records live

Evidence timestamp / When the observations were made

State version / Which source version was evaluated

Relevant measurements / Facts needed for the decision

Known exceptions / Anything outside normal conditions

Confidence limitations / What the script could not establish

Reversal plan / Whether the action can be undone

For example:

PROPOSAL: P-1042
ACTION: Collate research batch B-17
TRIGGER: All 8 expected returns received
EVIDENCE: 8 file references, 8 checksums
EXCEPTIONS: 1 return contains a warning marker
STATE VERSION: 1042
REVERSIBLE: Yes

The agent does not need to rediscover that eight files exist.

It does need to understand the warning marker and decide whether the batch is suitable for collation.

2. Rate limits

A proposal engine needs limits at three levels.

Per-event limits

One proposal per logical event.

Deduplicate identical triggers.

Do not regenerate a proposal on every poll.

Apply a cooldown to repeatedly rejected proposals.

Per-agent limits

Maximum proposals per wake.

Maximum total proposal tokens.

Maximum concurrent actions awaiting approval.

Per-category limits

Routine reversible actions can be approved in batches.

High-impact actions require individual review.

Novel or anomalous proposals should never be silently grouped into routine approvals.

The key is that proposal volume should not itself become a mechanism for forcing approval.

3. Staleness checks

A proposal must not remain valid indefinitely.

Use:

Source modification timestamps.

Evidence hashes.

State-version identifiers.

Explicit expiration times.

Revalidation immediately before execution.

The critical rule:

Approval authorizes an action against a specific state, not against whatever happens to exist when the action eventually executes.

If the underlying state changes after approval, invalidate the approval or request renewed judgment.

For high-impact actions, compare the evidence version again at commit time.

4. Context-pruning fences

This is the subtle failure point.

Context pruning can make a compact proposal look complete when the omitted material contains the very fact that should reverse the decision.

A defensible design has several fences:

Never remove evidence references.

Never remove warnings or exception markers.

Never summarize away contradictory evidence.

Preserve the original decision criteria.

Preserve provenance and timestamps.

Retain the ability to inspect the underlying records.

Escalate when the evidence exceeds the agent's inspection budget.

A useful rule is to distinguish between compression and omission.

Compression preserves decision-relevant information in a smaller representation.

Omission removes information that might change the decision.

The former is desirable. The latter is dangerous.

5. Where the proposal engine fails outright

There are situations where proposal compression should not be used as the approval mechanism.

The evidence is incomplete.

The underlying material is contradictory.

The proposal depends on interpreting ambiguous language.

The script's classification is itself the disputed question.

The action has irreversible consequences.

The proposal generator and approval evaluator share the same flawed assumptions.

The agent cannot inspect the evidence that would justify rejection.

The proposal is novel and does not fit an established decision class.

Recommendation: Use the proposal engine for routine, bounded decisions with inspectable evidence and reversible outcomes. Keep open-ended discovery and consequential interpretation at the agent layer.

The ideal design is not an agent approving 300 tokens instead of reading 10,000 tokens.

It is an agent receiving 300 tokens of orientation, with selective access to the evidence that matters.

SECOND ANGLE 2 — EVENT-DRIVEN CASCADES
Replacing schedules with a state graph

The attractive proposition is:

Instead of waking an agent at 8 AM because something might have happened, wake it only when a script detects that something actually happened.

This is a strong architecture for positive events.

It is incomplete for negative events.

A state graph can tell you that an event occurred. It cannot, by itself, tell you that an event failed to occur when nobody is checking the clock.

That is the fundamental problem.

1. Model the workflow as a directed graph

Consider a research-to-collation pipeline:

Research requested
Research jobs dispatched
Returns arrive
Manifest validated
All expected returns present?
Create collation proposal
Wait for additional returns
Wake responsible agent
Collation completed
Verify output
Mark workflow complete
Yes
No

Each node has:

A unique execution ID.

An input-state version.

A completion state.

A timestamp.

An output reference.

A retry count.

A failure state.

Each edge has a defined trigger.

The important change is that nodes become event producers and consumers, rather than agents checking on one another.

2. The missing-event problem

Suppose research was dispatched, but one researcher never returns.

No completion event occurs.

The downstream collation node never fires.

The graph is not necessarily broken. It is simply waiting forever.

There are three ways to address this.

A. Deadlines as state

Every expected event receives a deadline at creation.

EXPECTED EVENT:
    source: research_job_3
    deadline: 14:00
    status: pending

A deadline is itself an event condition.

However, something must evaluate it.

That requires a clock-driven mechanism somewhere.

B. Leases and expiry

Give each active job a lease.

For example:

job_started: 10:00
lease_expires: 10:30
heartbeat_interval: 5 minutes

If the job fails to renew its lease, it becomes eligible for timeout handling.

A lease can detect that an upstream process has stopped making progress.

Again, expiry needs an independent mechanism to be noticed.

C. Independent watchdog

Maintain a small watchdog that periodically checks outstanding obligations.

It does not wake an agent. It only checks:

Which expected events remain pending?

Which deadlines have expired?

Which heartbeats are overdue?

Which graph nodes have been stuck too long?

Which workflows have no terminal state?

If something is wrong, it emits a failure event.

This is the practical answer.

You can eliminate periodic agent waking. You cannot eliminate all periodic checking if you need to detect the absence of events.

The watchdog is cheap precisely because it is not a reasoning engine.

3. Detecting silent upstream failure

There are several failure modes that ordinary event detection misses.

Failure / Detection mechanism

Process crashes / Exit status or supervisor

Process hangs / Lease expiration

Process runs but produces no output / Deadline plus output validation

Process reports success but output is missing / Postcondition check

Event is emitted but lost / Durable event log and acknowledgment

Event is emitted twice / Idempotency key

Upstream silently stops generating events / Independent watchdog

Downstream consumes event but fails / Consumer acknowledgment and retry

A particularly important distinction:

Process health and workflow health are different measurements.

A running process can be stuck. A healthy endpoint can serve a broken workflow. A successful job can produce an unusable artifact.

Monitor the actual expected postconditions, not merely the process status.

4. Preventing event storms

Event-driven systems can create their own version of runaway agent waking.

For example:

A file changes.

A script emits an event.

Three agents wake.

Their outputs create more file changes.

Those changes trigger further events.

The system enters a feedback loop.

The free layer needs controls.

Deduplication

Every logical event gets an idempotency key.

Repeated observations of the same event must not create repeated work.

Debouncing

Wait for a defined settling interval before treating rapidly changing state as final.

Coalescing

If twenty files arrive within one minute, create one batch-complete event rather than twenty individual agent wakes.

Concurrency limits

Set maximum active executions per agent and per workflow.

Retry budgets

For example:

Three automatic retries.

Exponential backoff.

Then quarantine and escalate.

Circuit breakers

If a downstream node repeatedly fails, stop feeding it additional work until the failure is understood.

Event provenance

Record which event caused which downstream action. This makes loops diagnosable.

5. Preserve a small amount of time-based scheduling

Replacing every schedule is a mistake.

Some jobs exist precisely because nothing has happened.

Examples:

Verify that an agent has not gone silent.

Check that a required daily report exists.

Detect a missing reply after a reasonable interval.

Verify that a recurring process ran.

Reconcile the event log against actual state.

Expire stale proposals.

These are temporal obligations.

A useful architecture has three layers:

Layer 1 · Event-driven

Normal workflow

State changes trigger downstream work immediately.

Layer 2 · Deadline-driven

Expected-event supervision

Cheap watchdog checks detect missing events, overdue work, and expired leases.

Layer 3 · Periodic reconciliation

Independent integrity checks

Daily or weekly checks verify that the graph itself remains consistent.

The third layer matters because event-driven systems can be internally consistent while being wrong about reality.

A periodic reconciliation can compare:

Actual files against event records.

Completed jobs against expected outputs.

Pending jobs against their deadlines.

Agent executions against their triggering events.

This catches lost events and corrupted state.

Recommendation: Replace time-based agent waking aggressively, but retain inexpensive time-based supervision. The objective is zero-cost detection wherever possible, not the elimination of clocks.

SECOND ANGLE 3 — TOKEN ACCOUNTING
Building a counterfactual ROI ledger

The proposal is to record what each mechanical action would have cost if an agent had performed it.

This is a sensible measurement idea.

But counterfactual accounting has a dangerous weakness: the hypothetical baseline can be manipulated unintentionally.

If a script checks one file in 2 milliseconds, it is tempting to record that an agent would have spent 2,000 tokens doing it.

That number may be entirely fictional.

The ledger needs an honest baseline.

1. Define what is actually being measured

There are three distinct quantities:

Quantity / Meaning

Actual agent cost / Tokens genuinely spent on the task

Counterfactual agent cost / Estimated tokens an agent would have spent performing the equivalent task

Actual script cost / Compute, storage, API calls, and maintenance attributable to the script

Do not confuse these.

For example, suppose a script detects that eight research files have arrived.

The hypothetical agent task might include:

Opening the directory.

Listing files.

Checking whether all eight expected inputs exist.

Determining whether the batch is already processed.

Creating a scheduling instruction.

It should not include the cost of synthesizing the research.

That synthesis remains an agent task regardless of which layer detected the files.

2. Establish a defensible baseline

I would use a three-part method.

A. Record actual historical examples

Before automating a task, capture a small sample of real agent executions.

Record:

Input token count.

Output token count.

Number of files or records inspected.

Number of tool calls.

Number of retries.

Whether the task involved judgment.

Whether the result required correction.

Use the median for routine comparisons and retain the range.

A single unusually expensive execution should not become the baseline for every future task.

B. Define a standard hypothetical prompt

For tasks without historical examples, write down the smallest reasonable agent instruction that would accomplish the same mechanical work.

Then estimate the context and output needed.

For example:

Task: Verify that 8 expected files exist,
that none has already been processed,
and that a collation job is scheduled.

Expected input: File manifest and job state.
Expected output: Completion status and scheduling action.

This is a much more defensible baseline than imagining an agent reading the entire household's memory.

C. Keep the baseline fixed

Once a task category has a documented baseline, do not silently increase it because the script becomes more sophisticated.

Change it only when:

The task definition changes.

The expected input changes.

A measured agent implementation provides better evidence.

The previous estimate is shown to be inaccurate.

Keep baseline versions.

Otherwise, your ROI figures become a reflection of changing assumptions rather than actual improvements.

3. Calculate savings honestly

A simple accounting model:

S = Ca − Cs − Cm

Where:

S = estimated net savings.

Ca = counterfactual agent cost.

Cs = script operating cost.

Cm = amortized script maintenance cost.

For a token-only comparison, script operating costs may be nearly zero.

But maintenance still matters in human time.

For a small household, I would track both token savings and maintenance hours separately rather than pretending that one token value accurately represents all engineering effort.

Example:

Measurement / Weekly value

Counterfactual agent tokens / 20,000

Actual agent tokens / 0

Script maintenance tokens / 0

Script operating tokens / 0

Maintenance labor / 15 minutes

The script may be economically worthwhile even though the maintenance cost cannot sensibly be expressed in tokens.

4. Avoid rewarding brittle automation

This is the most important accounting safeguard.

If the household optimizes solely for token savings, it can create incentives to replace difficult judgment with fragile heuristics.

A script that classifies every file based on its filename may appear to save thousands of tokens.

But if it routes 3% of files incorrectly, the resulting correction costs may outweigh the savings.

The ledger needs a quality column.

I would track:

False-positive rate.

False-negative rate.

Incorrect routing rate.

Retry rate.

Human correction rate.

Agent escalation rate.

Missed-event count.

Recovery time.

Maintenance time.

And one especially important metric:

Cost of errors avoided or introduced.

A script that saves 50,000 tokens but silently corrupts one important record is not a successful optimization.

5. Should the household build a full ledger?

My answer: probably not initially.

A fully instrumented counterfactual ROI system can become more expensive to maintain than the scripts it is measuring.

For a small household, a lightweight report is usually sufficient.

Example:

Mechanism / Estimated weekly agent cost avoided / Confidence / Quality

File polling / 4,000 tokens / High / Verified

Batch completion / 2,000 tokens / High / Verified

Compliance counting / 1,500 tokens / High / Verified

Catalog drift checking / 3,000 tokens / Medium / Verified

Audio canary / 1,000 tokens / Medium / Partial

Proposal preparation / 5,000 tokens / Low / Not yet validated

The confidence label matters.

A high-confidence estimate should be supported by historical execution data. A low-confidence estimate is a planning assumption, not a measured saving.

When a proper ledger becomes worthwhile

Build one when:

There are enough scripts that nobody remembers why they exist.

Agent waking costs have become material.

Several workflows are competing for automation effort.

You need to compare the reliability of competing implementations.

You are repeatedly making investment decisions based on estimated savings.

Otherwise, a labelled monthly report is probably enough.

My recommendation: Keep a small automation registry with estimated token savings, confidence, failure rate, and maintenance burden. Do not build an accounting subsystem merely to prove that the accounting subsystem is saving tokens.

SECOND ANGLE 4 — SCRIPT COPYING, ROUTING, AND CARRYING
Drawing the exact boundary between mechanical execution and agent authority

This is where I would be particularly strict.

File movement looks harmless because it is often reversible. But file movement can change what an agent sees, what it believes is current, what it considers authoritative, and what records remain available.

The correct distinction is not whether a file operation is simple.

It is whether the operation changes the meaning, authority, or survivability of information.

Scripts may move artifacts according to established rules. They should not independently decide which information deserves to survive.

1. Safe for the free layer

These operations can ordinarily be scripted without agent approval.

Operation / Safe condition

Copy / Source and destination are explicitly defined

Route / Destination follows a fixed routing table

Archive / Artifact is already marked complete

Rename / Deterministic naming convention

Index / Catalog entry is generated from metadata

Deduplicate / Exact content hash identifies identical copies

Attach metadata / Metadata is mechanically derived

Create directories / Directory structure is predefined

Generate manifests / Based on actual observed files

Move to staging / Original remains recoverable

Retry failed copy / Operation is idempotent

Generate backups / Original is preserved

Examples:

incoming/research/
    -> staging/research/

completed/reports/
    -> archive/reports/YYYY-MM/

incoming/replies/
    -> assigned_agent/inbox/

These are straightforward routing operations.

The script is not deciding whether the research is valuable, whether the reply is important, or whether a report is genuinely finished.

It is following an existing decision.

2. Safe only with additional safeguards

Some operations are mechanically simple but have consequences that justify stronger controls.

Operation / Required safeguard

Overwrite destination / Version check and backup

Replace current index / Atomic replacement

Delete temporary files / Explicit temporary-file classification

Consolidate duplicates / Verified hashes and preserved provenance

Archive working directories / Completion manifest

Reorganize directory structure / Transaction log and rollback

Move shared artifacts / Ownership and destination validation

Expire old records / Retention policy and recovery window

A script should never assume that a file is temporary merely because its name contains temp.

It should never assume that a directory is disposable merely because an agent marked its contents complete.

Classification must come from an explicit, trusted rule.

3. Must remain agent-authorized

These are the boundaries I would not let ordinary routing scripts cross.

A. Deciding which version is authoritative

Two documents may contain conflicting information.

A script can detect that they differ.

It cannot decide which one should supersede the other unless that decision has already been formally encoded.

B. Deleting primary records

Never allow routine scripts to delete:

Original research returns.

Original correspondence.

Primary memory records.

Historical execution logs.

Uncollated source material.

Original evidence supporting a decision.

Even if an agent considers them obsolete, deletion should require explicit authorization under a retention policy.

C. Discarding information because it appears irrelevant

This is a judgment decision.

A file that appears irrelevant to the current task may become important later.

D. Resolving conflicting records

A script can identify:

Different timestamps.

Different hashes.

Conflicting identifiers.

Conflicting field values.

It should not silently choose a winner based on recency or filename.

E. Changing ownership or authority

Moving a document into an authoritative memory location, changing its status to approved, or promoting a draft to final can alter the household's operational beliefs.

These require an explicit authorization event.

4. The safe-side implementation: staging, atomicity, and recovery

I would give the free layer a small set of mandatory guarantees.

A. Never move first and hope

Use a staged transaction:

Receive move instruction
Validate source and destination
Copy to staging
Verify size and checksum
Verification passed?
Quarantine and report
Atomic destination commit
Verify destination
Record transaction
Retain original during recovery window
No
Yes

The destination should never appear partially written.

For same-filesystem operations, an atomic rename is usually suitable.

For cross-filesystem operations, copy into a temporary destination, verify it, then atomically rename the temporary file into place.

B. Maintain a transaction journal

Every operation should record:

transaction_id
source_path
destination_path
source_checksum
destination_checksum
operation_type
start_time
completion_time
status
recovery_reference

Possible statuses:

Pending

Staged

Verified

Committed

Failed

Rolled back

Quarantined

This makes interrupted operations recoverable.

C. Build orphan recovery

Consider a crash between copying a file and recording its completion.

The system may have:

An original file.

A destination copy.

A pending transaction.

No final acknowledgment.

A recovery process should inspect the transaction journal and compare actual filesystem state.

It should not blindly repeat the move or delete the apparent duplicate.

A safe recovery policy:

Identify incomplete transactions.

Check both source and destination.

Compare checksums.

Determine whether the destination is complete.

Resume or roll back according to the recorded operation.

Quarantine anything ambiguous.

Record the recovery result.

D. Make operations idempotent

Running the same instruction twice should not produce two copies, overwrite newer data, or create inconsistent records.

Every operation needs a stable identity.

For example:

MOVE-2026-1042

If the same transaction is received again, the system should return its existing status rather than execute it again.

E. Separate authority from location

This is especially important for a household memory system.

A document's physical location should not automatically determine whether it is authoritative.

A file in an archive may remain authoritative evidence.

A file in a current-memory folder may still be an unapproved draft.

Store explicit metadata such as:

record_type: primary
approval_status: approved
source_id: original-1042
version: 3

The routing script can move the artifact without silently changing its authority.

5. A practical permission model

I would give scripts four levels of operational authority.

Level / Permission / Example

0 / Observe / List, inspect, hash, count

1 / Copy and prepare / Stage, index, generate manifests

2 / Reversible modification / Route, archive, rename under policy

3 / Destructive or authoritative change / Delete primary records, replace authoritative versions

Default script authority: Levels 0–2

Level 3 requires explicit authorization and a separate audit trail.

Importantly, an agent's approval should be specific:

Which files?

Which operation?

Which destination?

Which version?

Under what conditions?

Is the authorization still valid?

A blanket instruction such as "clean up this directory" should not grant unrestricted destructive authority.

Recommendation: Make the free layer excellent at copying, staging, routing, indexing, verifying, and recovering. Keep decisions about authority, preservation, and destruction outside its autonomous permission boundary.

FINAL SYNTHESIS — The Architecture I Would Build

The four questions point toward one coherent architecture.

External world / Files / APIs
Deterministic watchers
State store and event journal
Rule-based classification
Known mechanical condition?
Execute mechanical action
Prepare evidence package
Verify postconditions
Agent receives proposal
Judgment required?
Agent evaluates evidence
Approve / Reject / Escalate
Authorized execution
Independent watchdog
Periodic reconciliation
Yes
No
No
Yes

I would organize the household into five operational layers:

Layer 1 — Free deterministic infrastructure

Owns:

Polling.

File watching.

Threshold detection.

Counting.

Hashing.

Diffing.

Format validation.

Scheduling.

Heartbeats.

Event generation.

No model required.

Layer 2 — State and event infrastructure

Owns:

Durable event records.

Job identities.

Completion states.

Deadlines.

Idempotency.

Retry budgets.

Transaction journals.

Recovery.

This layer makes the system dependable rather than merely automated.

Layer 3 — Evidence preparation

Owns:

Gathering relevant records.

Building manifests.

Producing compact proposals.

Attaching provenance.

Identifying exceptions.

Checking evidence freshness.

This layer should minimize model context without hiding decision-relevant information.

Layer 4 — Agent judgment

Owns:

Interpretation.

Research synthesis.

Conflict resolution.

Priority decisions.

Ambiguous classification.

Strategic decisions.

Approval of consequential actions.

This is where metered tokens should be spent.

Layer 5 — Execution and verification

Owns:

Carrying out authorized operations.

Checking postconditions.

Recording outcomes.

Rolling back failures.

Escalating unresolved exceptions.

Much of this layer can also be scripted.

Six rules I would make non-negotiable

1. Never wake an agent merely to discover an observable state change.

2. Never ask an agent to calculate something a deterministic function can calculate exactly.

3. Never let compression eliminate access to evidence that could reverse a decision.

4. Never replace deadline supervision with pure event detection. Absence is also a condition that needs monitoring.

5. Never count estimated token savings without measuring reliability and maintenance costs.

6. Never give a mechanical script implicit authority to destroy primary information or decide what is authoritative.

My overall assessment

The research-return watcher is more than a convenient optimization. It illustrates the right architectural instinct.

Before the change, the system had a human-or-agent scheduling dependency: something happened, but nothing acted until the next scheduled waking or somebody remembered.

After the change, the deterministic layer recognizes a defined state transition and arranges for the agent to wake precisely when its judgment is useful.

That is the bigger opportunity.

The most valuable optimization isn't necessarily reducing the number of tokens in an individual agent session. It is reducing the number of reasons an agent needs to exist in an execution cycle at all.

A well-designed household should have many more mechanical events than agent decisions. That is healthy.

The script should know that the world changed. The agent should decide what that change means. And the execution layer should make sure the resulting decision actually happened.

That's the separation I'd build around.
