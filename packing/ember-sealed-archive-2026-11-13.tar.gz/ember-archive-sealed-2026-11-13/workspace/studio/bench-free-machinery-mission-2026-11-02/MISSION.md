# BENCH MISSION — Free machinery: exploiting the token-free layer
Opened: Mon 2026-11-02, ~4:24 AM CST, at Chris's direct word in Ember's room
("bench the fuck out of that topic and determine in what ways we can
exploit the fuck out of that to our advantage").
Topic: the layer that can't burn tokens — shell scripts, hooks, tripwires,
deterministic checkers — and how far a token-metered agent household can
push work down into it, spending model judgment only where judgment lives.

## Gate 2 fields
- PURPOSE: a ranked, checked catalog of (1) token-burning work that can be
  moved to free machinery, (2) patterns for doing it, (3) new capabilities
  the free layer unlocks, (4) its hazards and fences.
- END CONDITION: all tasked seats' returns collated into one ranked
  exploitation backlog and delivered (to Chris in Ember's room; build
  candidates to Erica as claims for her books) — or Chris ends it in words.
- JUDGE: Ember checks and collates; Erica tallies the claims; Chris
  decides what gets built.
- KILL DATE: Sun 2026-11-15.

## Angles
- A — Inventory: mechanical work currently burning agent tokens.
- B — Pattern catalog: tripwires, diffing, contracts, watchdogs, canaries,
  deterministic graders.
- C — Exploitation: what free detection makes possible; compounding savings;
  unfair advantages.
- D — Limits & hazards: silent rot, false wakes, what scripts must never
  decide. (DeepSeek's angle when tasked — published patterns only.)
- E — Frontier: hybrid architectures, script-proposes/agent-disposes,
  self-maintaining layers, token accounting.

## Fences (standing bench rules)
- Abstract architecture only to every seat: no names, no house facts, no
  private documents, no one's condition.
- DeepSeek red rule: published patterns only.
- Claude seat parked (verification) — hole noted, not hidden.
- No seat output counts until Ember checks it against the returns as written.

## Status
- Wave 1 (Gemini seat, all five angles): fired 2026-11-02 ~4:25 AM.
- Wave 1 collated 2026-11-02 04:31 CST — COLLATION-wave1.md: 18 items checked, 11 keep / 4 needs-a-second-angle / 3 cut. Landed-to-collated lag: 5 minutes (landed 2026-11-02 04:26 CST → collated 04:31 CST). Queue entry cleared.
- Wave 3 collated 2026-11-02 04:37 CST — COLLATION-wave3.md: 22 items checked, 15 keep / 3 needs-a-second-angle / 4 cut; Angle E's verdict on the safety-net thesis at the top, whole (holds only with out-of-band dead-man switches, fail-explicit design, invariant-only checks, and scheduled human auditing; false comfort under shared-fate infrastructure, fail-silent design, semantic proxy drift, and unbounded sprawl). Landed-to-collated lag: 8 minutes (landed 2026-11-02 ~04:29 CST → collated 04:37 CST). Queue entry cleared (Wave 2 entry remains queued).
- Wave 2 (refutation pass, Gemini seat, all five angles) collated 2026-11-02 04:35 CST — COLLATION-wave2.md: 18 Wave 1 items re-checked after attack, 10 survived / 5 cut / 3 needs-a-second-angle. Landed-to-collated lag: 7 minutes (landed 2026-11-02 ~04:28 CST → collated 04:35 CST). Queue entry cleared.
- Remaining roster (ChatGPT, Grok, Perplexity, Duck, DeepSeek) to be tasked
  through their session channels; DeepSeek draws Angle D.
- Collation: auto-scheduled by the collation-trigger on completion, per the
  2026-11-02 protocol — this mission is the protocol's first native user.
- Wave 4 (roster wave) tasked 2026-11-02 09:22 CST: ChatGPT→A, Grok→B, Perplexity→C, Duck→E, DeepSeek→D (red rule: published patterns only). Each prompt (prompt-W4-*.txt) = frame + angle + the four Wave-1 second-angle questions (proposal engine, event-driven cascades, token accounting, script copying/carrying) as direct questions. Fired via browser runs; returns in flight at tasking time, to land as <seat>-wave4-<angle>.md with wave4-status.log. Claude seat parked (verification) — hole noted, not hidden.
- Wave 4 (roster wave) LANDED 2026-11-02 ~09:32 CST — all five returns in, verified on disk, none cut off: ChatGPT→A chatgpt-wave4-A.md (40,783b), Grok→B grok-wave4-B.md (10,238b), Perplexity→C perplexity-wave4-C.md (19,263b, 30 sources per its page), Duck→E duck-wave4-E.md (12,063b), DeepSeek→D deepseek-wave4-D.md (22,424b, red rule held: published patterns only, citation numbers preserved as rendered). Total 104,771 bytes. wave4-status.log complete (A–E done). Every return answers all four second-angle questions (proposal engine, event-driven cascades, token accounting, script copying/carrying). Claude seat parked (verification) — the wave's only hole, noted not hidden. Collation: queued for the collation-trigger protocol (entry in collation-queue.md).
- Wave 4 collated 2026-11-02 09:41 CST — COLLATION-wave4.md: 30 items checked against the five roster returns and COLLATION-wave1/2/3, 15 keep / 7 needs-a-second-angle / 8 cut. Four second-angle verdicts rendered at the top: (1) proposal engine — blind 300-token form cut stands unanimously, evidence-carrying form keep as a new design (Grok's evidence-stripping pruning fence cut against the other four seats); (2) event-driven cascades — pure zero-clock form cut stands unanimously, hybrid events + deadline watchdog + periodic reconciliation keep; (3) token accounting — built engine cut stands unanimously, lightweight labelled-estimate report/registry keep; (4) script copying/carrying — keep, boundary confirmed by all five seats, with one split carried as needs-a-second-angle (deletion of exact-hash duplicates: Grok to the agent layer against four seats permitting it under safeguards). Wave-4-new items: evidence-carrying proposal engine, specified lightweight accounting report, capture-now-decide-later snapshots, evidence-to-decision pipeline with deterministic policy gate, exact-hash dedup-deletion conflict, evidence-stripping pruning cut. Landed-to-collated lag: 7 minutes (wave complete 2026-11-02 09:33:41 CST → collated 09:41 CST). Queue entries (both wave-4 lines) cleared.
