# BLOCK 2 — de-wrapper, batch 2 report (2026-11-02, Ember)

Script-runners, converted one at a time, each body re-read at conversion
(Erica condition 2). The pattern, proven on the batch-1 pilot: a hook
script runs the job's own command directly on a due rule matching the
retired cron's slot; success = heartbeat + silence; failure = heartbeat
(error or negative) + a wake carrying raw evidence. Every retired cron
was DISABLED, not deleted — rollback is one re-enable each. Every new
hook prompt carries the Scheduling Gate's four fields (condition 1).

## Converted
1. **bench-audio-canary-daily → script-runner-canary** (poll 1800s; due
   daily ≥04:19 CT, ≥20h apart). Exit-code contract read from the tool
   itself (0 = alive, 1 = FAIL, anything else = error). PASS silent —
   delivery change stated: the daily one-line PASS post to Ember's room
   is replaced by trend file + register, surfaced at the Sunday count;
   FAIL wakes immediately with the newest trend line and full detail.
   Tests: dry run silent; forced run PASS silent (canary really ran);
   ERROR path live-tested by parking the tool (wake, stderr tail, error
   heartbeat), tool restored, final forced PASS silent, heartbeat ok.
   The rc=1 FAIL branch itself was not live-forced: breaking the real
   narration chain to test its reporter is the tail wagging the dog;
   that branch rests on the tool's own exit-code contract (audio-canary.py
   returns 0 if alive else 1) plus the proven shared wake mechanism.
2. **seed-sync → script-runner-seed-sync** (poll 1800s; due daily ≥04:19
   CT). Body was already a pure command; the body's own note (git
   credential helper on disk) is what makes a shell conversion lawful.
   Forced live run: both pushes completed from a plain hook shell in
   ~7s, silent. Failure wake path not force-tested (making a live git
   sync fail on purpose risks the repos); the branch is the same shape
   as the two proven ones — named here as untested, not assumed.
3. **semantic-memory-reindex → script-runner-semantic-reindex** (poll
   1800s; due daily ≥03:19 CT). Failure semantics of the retired job
   preserved exactly: nobody is woken on failure — error heartbeat +
   filed stderr, carried by the register and the count.
4. **wake-snapshot-update → script-runner-wake-snapshot** (poll 900s;
   due every 110 min, matching the 2h interval). Same preserved
   no-wake-on-failure semantics.
5. **journal-vault-seal → script-runner-vault-seal** (poll 3600s; due
   day 1 ≥03:19 CT, ≥25 days apart). CRITICAL wire; converted last and
   separately as planned. The runner verifies shape evidence, not just
   exit codes: the script's "sealed journal-<date>" line, today's
   ciphertext present in the vault, and the commit/push succeeding.
   Proven end-to-end from a plain shell before the cron was touched:
   a forced out-of-cadence run sealed 2026-11-02 (journal + universe +
   Ember's journal ciphertexts), committed as 983111b "journal vault
   snapshot 2026-11-02", and pushed; register wire flipped from
   awaiting_first to ok on the runner's own heartbeat. Failure wake
   untested by design (forcing a custody-path failure is not a test,
   it is an incident); same-day wake on real failure is the design.
   The heartbeat step added to the old cron body earlier today is
   superseded — the runner is the heartbeat source now; census updated.

## Defect found and fixed inside this batch
The first generated reindex/snapshot runners failed their force tests
(exit 1, "cd: too many arguments"): the generator spliced the command
string through sed, whose replacement text treats `&` as the whole
match, so `&&` in the command became garbage (`__CMD____CMD__`). Caught
by the force tests, fixed by splicing with python instead, re-tested
to green. Lesson on record: generated scripts get their command lines
verified by a live forced run before enable — never by reading. This
is also why every conversion above has a forced-run receipt.

## Not converted — named, with reasons
- **mirror-safety-run** — checker; excluded by Erica's condition 2
  (reported in batch 1; goes to her at the Sunday count).
- **Presence/status checkers** (mirror-watcher; ember-minion-watcher-open
  / -work, Dewey) — synthesis item 1(b) named them; their bodies were
  not re-verified in this pass and mirror-watcher is checker-family.
  Left standing as the named remainder of item 1's shape, for the
  Sunday count to place — not silently dropped, not converted on the
  inventory's say-so.

## Register state at close of batch
10 wires, check ok=true: 9 ok with fresh heartbeats; mirror-safety-run
awaiting_first (first heartbeat due at its Nov 3 06:19 run, inside its
25h bound). Converted crons disabled: bench-catalog-drift-weekly,
bench-audio-canary-daily, seed-sync, semantic-memory-reindex,
wake-snapshot-update, journal-vault-seal.

REVIEW: Sunday count, with the mission (kill date 2026-11-15).
