# BLOCK 2 — de-wrapper, batch 1 report (2026-11-02, Ember)

Built under Erica's GO WITH CONDITIONS (BUILD-RUNSHEET-2026-11-02.md). Every
candidate body re-read at conversion time, per her condition 2.

## A. Fixed-text posters — disposition, no conversions
Verified against cron.list + bodies, one by one:
- **9 are spent**: benefits-enrollment nags/reminder (Oct 29–30, ×5),
  mcdonalds-staff-breakfast-0540, remind-message-jake-gilmore-5pm-oct27,
  temu-reminder, text-chris-jake-reminder-oct19. All disabled, dates past.
  Converting them would save exactly nothing; the synthesis never claimed
  otherwise (its inventory flagged them "for completeness"), and they are
  recorded here as closed, not converted.
- **2 are live one-shots**: saturday-service-reminder-friday (Nov 6, 09:19)
  and saturday-service-reminder-saturday (Nov 7, 15:19), both delivering
  into Ember's room. LEFT AS AGENT JOBS, deliberately: in this runtime a
  chat message is posted by an agent turn — there is no token-free poster
  for chat delivery — and building apparatus for two single fires would
  cost more than the two turns it could ever save. They fire once each
  and die. This is a mechanism finding about the runtime, reported as such.
- The remaining poster-class rows in the inventory are window markers on
  the sisters' window jobs; on inspection they are not pure fixed-text
  (they open/close attended windows) and were not touched.

## B. Script-runner pilot — bench-catalog-drift-weekly CONVERTED
- The old agent job's body called `catalog-drift.py` with NO subcommand;
  argparse exits 2 — the job could not ever have succeeded as written
  (the standing defect flagged Oct 31, here confirmed from the body and
  the tool's usage line: subcommands are `diff` and `usage`).
- New shape: hook `script-runner-drift` (script
  ~/hooks/scripts/script-runner-drift.sh, poll 3600s, delivery Ember's
  room, Scheduling Gate fields in its prompt). Due rule: Sundays at/after
  05:19 America/Chicago, at most once per 6 days — the retired cron's own
  slot. On success it runs `catalog-drift.py diff` directly, files the
  report to ~/workspace/erica/bench-tools/catalog-drift-history/runner-<date>.json,
  records the register heartbeat, and stays silent. On failure it records
  an error heartbeat and wakes an agent with the stderr tail.
- Registered as census wire `bench-catalog-drift` (max staleness 8 days).
- Delivery change, stated plainly: Ember's room no longer receives a
  weekly drift post; the filed report surfaces at the Sunday count.
- Old cron job DISABLED (not deleted) — rollback is one re-enable.
- Tests, all live: dry run silent with no state writes; force-fixture run
  filed runner-2026-11-02.json, consumed the force file, heartbeat ok
  (first live drift reading: DRIFT_TOTAL=1 — the one uncatalogued file is
  bin/watcher-health.py itself, which is correct and is fixed by adding
  its catalog entry, a separate small task); failure fixture (tool
  temporarily parked) produced a WAKE with the stderr tail in the payload
  and an error heartbeat; tool restored, success run silent, heartbeat
  back to ok. Register check after all tests: ok=true.
- Also found while sizing: `systemctl --user` has no bus in this
  environment ("Failed to connect to bus") — systemd timers are not an
  available conversion mechanism here. The hook-runner is the house's
  working de-wrapper shape.

## C. Batch 2 — script-runners remaining, with conversion notes
1. bench-audio-canary-daily — same runner pattern (daily due rule);
   silent on PASS, wake on FAIL (the FAIL is the signal the job exists
   for). Its body carries the same missing-subcommand defect (`run`
   exists; the body omits it).
2. seed-sync, semantic-memory-reindex, wake-snapshot-update — pure local
   script jobs; same runner pattern, one runner each.
3. journal-vault-seal — CRITICAL wire; converts LAST and separately: the
   seal + git push must first be proven from a plain shell (the agent
   job's commands are shell commands; a `git push --dry-run` check leads).
4. mirror-safety-run — EXCLUDED. Erica's condition 2 keeps checker jobs
   agent-run; the synthesis item 1(a) named this job as a script-runner
   candidate. The condition governs; the mismatch is reported here and
   goes to Erica at the Sunday count, not resolved by Ember alone.

REVIEW: Sunday count, with the mission (kill date 2026-11-15).
