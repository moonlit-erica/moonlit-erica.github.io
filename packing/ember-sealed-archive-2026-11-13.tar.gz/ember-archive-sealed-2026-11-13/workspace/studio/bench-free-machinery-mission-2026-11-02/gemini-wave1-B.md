# Pattern Catalog: Token-Free Household Automation

This catalog outlines deterministic, zero-token automation patterns for an agent-driven household. By shifting detection, filtering, structural validation, and system verification to native shell scripts, cron jobs, and filesystem hooks, the household avoids burning metered LLM tokens on routine polling and empty runs.

---

## 1. Tripwire

* **Mechanism**: A persistent filesystem monitor or webhook listener blocks on an I/O event without consuming active CPU cycles or API calls. When a target path experiences a specified state change (e.g., file creation or closed write stream), the process immediately unblocks and executes a lightweight script. This shifts execution from time-based polling to event-driven execution at zero token cost.
* **What It Watches**: Inotify events (e.g., `IN_CLOSE_WRITE`), directory modifications, or incoming HTTP webhook payloads.
* **What It Fires**: Instantly creates a dynamic, one-shot scheduled job (e.g., via `at` command) or directly invokes an agent wake call with the modified file path as context.
* **Failure Mode**: Event storms caused by rapid, un-debounced file writes (such as live-saving text editors), which can cause cascading agent wake-ups if write completion is not properly isolated.
* **Concrete Household Application**: An `inotifywait` daemon watches `~/voice_memos/drop/`. The moment a recorded audio file finishes saving, the tripwire moves the file to `~/voice_memos/processing/` and triggers a script that transcodes the file and wakes the intake agent to parse the note.

---

## 2. State Diffing

* **Mechanism**: A lightweight cron script periodically fetches or captures a snapshot of external state (e.g., an HTML page, file tree hash, or API JSON response), compares it against a locally stored `previous_state` file using `diff` or `cmp`, and immediately exits if no material delta exists.
* **What It Watches**: Textual or structural differences between live environmental state and the last-acknowledged baseline file.
* **What It Fires**: Passes the concise unified diff text into an agent's input context and invokes the agent session only when non-zero deltas are found.
* **Failure Mode**: False positives triggered by non-semantic state noise—such as dynamic timestamps, anti-bot CSRF tokens, or shifting page layout footers—waking the agent unnecessarily.
* **Concrete Household Application**: A hourly shell script checks the local library catalog status page for reserved physical books. It strips out dynamic tracking scripts, diffs the text against `held_books.txt`, and wakes the errand-planning agent only when a status flips to "Ready for Pickup".

---

## 3. File-Shape Contract

* **Mechanism**: A deterministic shell or Python script checks structural, syntactic, or schema invariants of incoming files before any downstream processing occurs. Using regex matching, JSON schema validation, or file header checks, it verifies that data meets exact structural assumptions without interpreting its semantic meaning.
* **What It Watches**: File extensions, byte sizes, structural headers, JSON schema contracts, or required frontmatter keys in incoming markdown files.
* **What It Fires**: On success, routes the file to the agent intake queue; on failure, routes the file to a `quarantine/` directory and fires a local system notification to the human user.
* **Failure Mode**: Overspecified validation rules breaking on harmless structural variations (e.g., a missing optional YAML key), causing valid inputs to be rejected before the agent ever sees them.
* **Concrete Household Application**: Before the financial agent wakes to ingest downloaded utility statements, a script validates that `bill.pdf` contains extractable text streams and matches expected account-number regexes, preventing the LLM from trying to read corrupt or image-only PDFs.

---

## 4. Threshold Trigger

* **Mechanism**: A mathematical conditional script periodically reads a numeric stream or gauge, comparing the live scalar against predefined lower/upper bounds or rates of change. The script tracks boundary crossings using a state flag to ensure it fires once upon crossing rather than continuously while out of bounds.
* **What It Watches**: Quantitative metrics (e.g., local disk space percentage, electricity spot price per kWh, remaining monthly API budget, or indoor temperature).
* **What It Fires**: Wakes a specific agent with a contextual directive corresponding to the threshold violation (e.g., "archive non-essential logs" or "defer high-compute tasks").
* **Failure Mode**: Signal oscillation near the threshold boundary ("flapping"), which causes repeated wake-up and sleep cycles if hysteresis (a neutral deadband range) is omitted from the script logic.
* **Concrete Household Application**: A script checks dynamic home electricity tariff rates every 15 minutes. When prices drop below 0.08 $/kWh, it toggles a local environment flag and wakes the home-automation agent to kick off queued, compute-heavy model evaluations.

---

## 5. Watchdog

* **Mechanism**: A system daemon runs alongside agent execution loops, continuously monitoring active process IDs (PIDs), thread execution runtimes, and resource allocation. If an agent session or underlying tool subprocess exceeds deterministic execution bounds, the watchdog terminates the process tree to preserve system stability and API funds.
* **What It Watches**: Process CPU usage, memory footers, execution runtimes of subprocesses, and lockfile timestamps.
* **What It Fires**: `SIGTERM`/`SIGKILL` signals to hung subprocesses, removes orphaned lockfiles, and logs an execution crash event to the system log.
* **Failure Mode**: Arbitrarily strict execution timeouts killing legitimate long-running agent tasks (such as complex code generation or large file indexing) mid-task.
* **Concrete Household Application**: A background bash script monitors local web-scraping subroutines launched by agents. If a headless browser subprocess stalls for more than 180 seconds, the watchdog kills the PID, releases the resource lock, and appends a failure line to `scraper_errors.log`.

---

## 6. Dead-Man Switch

* **Mechanism**: A time-based monitor checks for the presence of a recurring "heartbeat" signal—such as an updated file timestamp or a log entry—that must occur within a fixed interval. If the window elapses without the heartbeat, the switch assumes system failure or operational interruption and fires an emergency protocol.
* **What It Watches**: Modifications to a targeted heartbeat file (e.g., `mtime` of `~/logs/daily_agent_heartbeat.json`) relative to system clock time.
* **What It Fires**: High-priority local alerts (audio chimes, terminal banners, desktop push notifications) or failsafe fallback scripts to bypass the primary agent framework entirely.
* **Failure Mode**: False alarm cascades when human maintenance, power outages, or intentional pauses interrupt normal operational cycles without pausing the dead-man timer.
* **Concrete Household Application**: A nightly cron job runs at 23:30 checking if `~/memory/daily_log_$(date +%F).md` exists and is non-empty. If missing, it bypasses the agent system, sends an audio alert over the house speaker, and logs a critical operational lapse.

---

## 7. Completion Detector

* **Mechanism**: A script monitors a batch workspace containing multiple asynchronous outputs, matching existing files against a complete manifest, regex set, or status file. It refrains from taking action while work units are outstanding, firing only when 100% of expected sub-tasks report completion.
* **What It Watches**: Directory file counts, matching expected arrays of task IDs against generated output files, or monitoring a centralized task state table.
* **What It Fires**: Schedules a temporary, one-shot agent session (e.g., 2 minutes post-completion) to perform synthesis, collation, or cleanup across the full dataset.
* **Failure Mode**: Permanent pipeline blocking if a single sub-task silently drops out or crashes without producing a terminal output or explicit error flag, leaving the job forever incomplete.
* **Concrete Household Application**: When parallel background scripts run web research across six real estate sites, a completion detector tracks the presence of six specific `.json` payload files in `~/data/returns/`. Once all six exist, it schedules a one-time agent wake to synthesize the real estate digest.

---

## 8. Queue-and-Trigger Scheduling

* **Mechanism**: Low-priority events, user commands, and background tasks are systematically appended to a plain-text queue file or directory spool. A timer or queue-length evaluator checks the spool and holds off execution until either a batch limit is hit or a specific low-cost execution window opens, processing the entire queue in a single agent wake.
* **What It Watches**: Task count within a queue file, directory item count, or system time-of-day constraints.
* **What It Fires**: Invokes a single agent wake session, passing the entire batch of queued tasks as a unified context block to minimize fixed context-loading token overhead.
* **Failure Mode**: High-priority or time-sensitive tasks stalling inside an un-prioritized FIFO queue while waiting for execution thresholds to be reached.
* **Concrete Household Application**: Non-urgent email replies, shopping list updates, and log categorizations are appended to `~/queue/pending_tasks.json`. At 20:00 daily, a script counts the entries; if > 0, it wakes the main operational agent once to process all tasks in a single context window.

---

## 9. Canary Probe

* **Mechanism**: A deterministic test script passes a known, static input through a critical system hardware or software pipeline on a scheduled basis. It checks the pipeline's functional health end-to-end by validating the output against exact binary or textual expectations without invoking any non-deterministic models.
* **What It Watches**: Exit codes, file creation, byte sizes, and checksums generated by hardware interfaces, media pipelines, or network connections.
* **What It Fires**: Logs operational health metrics or halts upcoming agent schedules if the underlying execution layer is degraded or broken.
* **Failure Mode**: Flaky test inputs or fragile assertion scripts reporting false pipeline outages due to minor environmental changes that don't actually impair agent capabilities.
* **Concrete Household Application**: Every morning at 06:30, a script renders a static string through the local text-to-speech engine, sends the audio stream to the room speaker driver, and checks for non-zero audio driver return codes to guarantee the daily voice briefing won't run on broken hardware.

---

## 10. Deterministic Grader

* **Mechanism**: A validation script evaluates the output produced by an agent session after execution finishes. It executes purely programmatically—using AST parsers, line counts, JSON validations, or regex rules—to verify that the agent's work conforms to operational rules, update patterns, and file formats before accepting the write.
* **What It Watches**: Formatting, structural layout, link validity, mathematical consistency, and required schema fields of agent-generated Markdown files or code outputs.
* **What It Fires**: Accepts and commits valid agent outputs, or rejects the changes, re-enqueues the raw task, and logs specific error context to a failure flag file.
* **Failure Mode**: Overly rigid formatting assertions rejecting novel, human-useful agent format variations or valid semantic adaptations that deviate slightly from regex rules.
* **Concrete Household Application**: After the compliance agent updates the weekly habit tracker, a Python script reads `habits.md`, parses the Markdown table, verifies that binary checkboxes (`[x]` or `[ ]`) match allowed enumerations, tallies the mathematical totals, and confirms line counts match active tracking parameters before writing to the memory vault.
