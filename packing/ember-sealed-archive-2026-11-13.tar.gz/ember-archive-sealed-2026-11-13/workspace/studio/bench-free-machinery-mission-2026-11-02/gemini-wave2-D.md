# Refutation Pass: Flaws, Overclaims, and Blind Spots in the Mechanical Layer Red-Team

The companion return presents a neat binary worldview: shell scripts detect structure; LLM agents make decisions. While it identifies real surface-level risks like infinite wake loops and silent script failures, its core framework suffers from **architectural dogmatism, enterprise over-engineering, and misplaced responsibilities**. 

By treating the boundary between scripts and agents as a moral absolute rather than a pragmatic cost/efficiency tradeoff, the return recommends patterns that paradoxically **increase token costs** and **introduce meta-failure modes** worse than the ones it tries to solve.

---

## 1. Weakest Claims & Overclaims

### Overclaim A: The Dogmatic Ban on Script Writing/Deleting (Hazard 5)
> *"The mechanical layer is strictly sandboxed... It has zero write/delete authority over household memory, external communication APIs, or raw research files."*

* **The Flaw:** Forcing the LLM agent to execute mundane file cleanups (`mv incoming/ /archive/`, `rm .tmp_lock`) burns metered tokens on deterministic file operations. If an agent must spend 200 tokens returning a tool call just to move a collated markdown file, the system is wasting money to satisfy architectural dogmatism.
* **Reality:** Deterministic post-processing (e.g., atomic moves upon success, log rotation, cleaning temp directories) belongs in the mechanical layer. Scripts should not perform *unjudged context destruction*, but forbidding them from file system mutations renders them toothless and inflates token burn.

### Weakest Claim: Delegating Byte & Schema Integrity to the Model (Hazard 3)
> *"Agents must run explicit assertion checks (non-zero size, valid header schemas, reasonable file structures)..."*

* **The Flaw:** Asking a probabilistic, token-metered LLM to check if a file is non-zero bytes or if a JSON structure has valid headers is a massive misallocation of resources. LLMs are notoriously sloppy at binary integrity checks and schema validation, and sending raw garbage files into the prompt context burns tokens before the verification even happens.
* **Reality:** Deterministic validation (file size $> 0$, valid JSON via `jq`, non-empty headers) is *precisely* what shell scripts do best at zero cost. Pushing structural validation to the agent layer invalidates the core value proposition of the mechanical layer.

### Overclaim B: The Meta-Monitoring Cascade (Hazard 1)
> *"Watchers for the Watchers (Mechanical Canaries)... Dead-Man Switches... Central monitoring script..."*

* **The Flaw:** Recommending recursive monitoring chains ("scripts watching scripts that watch scripts") for a small household environment creates an infrastructure control plane larger than the workload itself. Who watches the Dead-Man Switch? 
* **Reality:** In a small household setup, heavy telemetry pipelines create maintenance rot. The monitoring layer itself will fail, generating false alerts and administrative overhead.

---

## 2. Missing Failure Modes & Blind Spots

The companion return misses critical execution edge cases unique to polling-script-to-agent architectures:

1. **The Staggered Queue Stacking Race (One-Shot Duplicate Spawning):**
   * *The Gap:* If a polling script runs every 30 seconds and detects an uncollated set of files, it schedules a one-shot wake ~2 minutes out. If the script does not immediately set an atomic pending state, the polling script will run 3 more times before the first scheduled wake occurs, creating **4 duplicate one-shot wake events** for the same event.
2. **Orphaned Quarantine (The Silent Death of Staged Data):**
   * *The Gap:* Hazard 2 suggests moving files to a `.processing` staging folder immediately. If the agent wakes, encounters an unhandled exception, and dies mid-session, those files remain stranded in `.processing` forever. Because they are no longer in `incoming/`, the mechanical watcher will never see them again, and because the agent crashed, no recovery occurs. The data is effectively deleted without alerting anyone.
3. **Prompt Pollution via Error Log Ingestion:**
   * *The Gap:* When a script fails or detects a malformed format, sending raw stack traces or shell errors directly into the agent's wake context wastes token context window on shell syntax errors that the LLM cannot fix.

---

## 3. Assertions Lacking Mechanism

Several countermeasures in the return are asserted as hand-waving abstractions without workable Unix/bash implementation mechanisms:

* **Stateless Wake Budgets (Hazard 2):** The return mandates that *"A single polling script may only schedule $N$ wakes per hour/day,"* but provides no state storage, persistent sliding-window tally, or concurrency lock mechanism for stateless cron executions to track budget state across invocations.
* **Exponential Back-Off in One-Shot Schedulers (Hazard 2):** Recommending "exponential back-off" for shell-triggered one-shot timers (`at` jobs or systemd timers) assumes a persistent daemon process. Pure shell/cron scripts have no native back-off state without building a custom persistent database or state-file key-value store.

---

## 4. What to CUT and Why

| Item to Cut | Reason for Removal |
| :--- | :--- |
| **Strict Read-Only Isolation for Scripts** | **Vastly over-constrained.** Scripts *must* be allowed to perform deterministic cleanup (moving processed files, deleting temporary lockfiles) post-execution to avoid wasting agent tokens on file management. |
| **Agent-Side Structural Integrity Checks** | **Wrong execution layer.** The model should never spend tokens checking file byte-sizes or validating JSON syntax. Mechanics handle syntax; models handle semantics. |
| **Recursive "Watchers for Watchers" Architecture** | **Excessive operational overhead.** Enterprise-grade telemetry cascades (canaries watching monitors watching scripts) create meta-rot in a lean household setup. |

---

## 5. What SURVIVES the Attack and Why

Despite its over-engineering, core pillars of the companion return remain valid and essential:

1. **The Hard Prevention of Token Runaways (Hazard 2):**
   * *Why it survives:* Infinite agent wake loops caused by persistent unhandled state are catastrophic to token budgets. Lock files, atomic state transitions, and rate-limiting breakers are non-negotiable guardrails.
2. **Schema Drift Quiet-Failures (Hazard 4):**
   * *Why it survives:* Suppressing agent wakes when a script parser output is null/empty (`jq` failure) prevents waking an expensive LLM to process an empty state payload.
3. **The Core Semantic Boundary (Section 1 Concept):**
   * *Why it survives:* The fundamental assertion holds: **Scripts trigger on deterministic shape changes; LLMs execute contextual judgment.** A script must never attempt to judge whether a piece of research is "good enough" or if an email reply is "urgent."
