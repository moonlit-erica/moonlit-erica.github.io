# Mechanical Resolution of Multi-Watcher Disagreement

When multiple deterministic watchers (shell scripts, file checkers, status polling hooks) monitor the same underlying state, they will inevitably return conflicting results. Because the mechanical layer operates at zero token cost, it must resolve as much of this conflict as possible using pure logic—timestamps, exit codes, bitwise comparisons, and counting—without invoking an LLM.

Below is an analysis of what the mechanical layer can conclude on its own, how it handles split signals, and the exact boundary where mechanical logic ends and agent escalation must occur.

---

## What the Mechanical Layer Can Conclude Without AI

A shell script cannot read context or infer intent, but it can execute set theory, timestamp comparison, and structural validation. When watchers disagree, the mechanical layer can conclude four things with zero token cost:

### 1. Freshness Superiority (Temporal Resolution)
If Watcher A reports `STATE=IDLE` at `14:00:02` and Watcher B reports `STATE=BUSY` at `14:00:00`, there is no true disagreement—only sample latency. 
* **Conclusion:** The newer timestamp invalidates the older payload.
* **Mechanical Action:** Update the canonical state file to `BUSY` and suppress downstream alerts.

### 2. Quorum and Majority State (K-of-N Consensus)
If three independent endpoints monitor household internet status or external API health, and two report `ONLINE` while one reports `TIMEOUT`:
* **Conclusion:** The service is functionally operational, but one check channel is degraded or misconfigured.
* **Mechanical Action:** Mark the overall system `DEGRADED_OK`, log the failing watcher to a local diagnostic file, and allow downstream scheduled jobs to proceed without waking an agent.

### 3. Structural/Transport Failure vs. State Dissent
If Watcher A outputs valid JSON (`{"status": "complete"}`) and Watcher B outputs an empty string or exit status `127` (command not found):
* **Conclusion:** Watcher B did not observe a conflicting reality; Watcher B suffered execution failure.
* **Mechanical Action:** Quarantine Watcher B's output, rely on Watcher A's valid payload, and flag Watcher B for non-urgent script maintenance.

### 4. Disagreement-as-a-Signal (The Split Vote Event)
When two healthy, synchronous watchers inspect the exact same boundary and yield contradictory valid results (e.g., local disk folder shows 5 research files present, but the remote sync manifest claims only 4 were uploaded), the split itself is a new mechanical fact.
* **Conclusion:** State is indeterminate; an invariant has been violated.
* **Mechanical Action:** Generate a `STATE_SPLIT` synthetic event. The mechanical layer does not try to guess which watcher is "right"; it treats the existence of the split as a trigger condition.

---

## Deterministic Patterns for Zero-Token Disagreement Handling

Before escalating to an agent, the mechanical layer applies three deterministic resolution patterns:

```
                  +-----------------------------------+
                  |   Multiple Watcher Responses      |
                  +-----------------------------------+
                                    |
                    [ Are exit codes all 0/Valid? ]
                                   / \
                                 NO   YES
                                 /     \
    [ Quarantined Script Failure ]     [ Evaluate Timestamps ]
                                                 |
                                     [ Equal / Concurrent? ]
                                                / \
                                              NO   YES
                                             /       \
                        [ Freshness Wins ]       [ Check Quorum / Invariants ]
                                                             |
                                                 [ Unresolved Conflict? ]
                                                            / \
                                                          NO   YES
                                                         /       \
                                        [ Pass to Pipeline ]     [ WAKE AGENT ]
```

### Pattern A: Unanimous Gatekeeper (Strict Safety)
* **Rule:** $N$ out of $N$ watchers must agree before triggering a high-impact auto-action (e.g., wiping temporary bench folders or invoking a costly batch model).
* **Behavior on Dissent:** A single dissenting vote halts execution and logs the split.

### Pattern B: Freshness Supremacy (State Tracking)
* **Rule:** Payloads carry an epoch timestamp. The newest valid observation overwrites older observations regardless of source script priority.
* **Behavior on Dissent:** Older dissent is dropped silently as stale data.

### Pattern C: Majority Quorum with Degraded Flag (Operational Continuity)
* **Rule:** If $\ge M$ of $N$ watchers agree, proceed with the majority state, but append a flag to the daily markdown log.
* **Behavior on Dissent:** Non-blocking disagreement is recorded for the agent to review during its next scheduled nightly cleanup, avoiding an immediate wake event.

---

## The Escalation Boundary: When Disagreement Must Wake an Agent

The mechanical layer reaches its hard limit when conflict resolution requires **semantic interpretation, trade-off evaluation, or intent synthesis**. 

The exact line past which disagreement must be escalated to an AI agent is defined by four boundary conditions:

| Boundary Condition | Mechanical Observation | Why the Shell Layer Fails | Agent Wake Action |
| :--- | :--- | :--- | :--- |
| **1. Semantic Ambiguity** | Watcher A (API): `HTTP 200 "Success"`<br>Watcher B (File): `report.err` exists. | The script sees two valid artifacts. It cannot read `report.err` to know if it's a fatal error or a harmless warning. | Wake Agent: "Investigate return payload vs error log conflict." |
| **2. Irreconcilable Concurrent Dissent** | Watcher A (Local): `State = 5 files`<br>Watcher B (Remote): `State = 4 files`<br>*(Both updated at same second)* | Both watchers are healthy and timely. Mechanical layer cannot judge which data store represents ground truth. | Wake Agent: "Reconcile local vs remote bench research state." |
| **3. Invariant Breach without Failure Code** | Audio Canary renders cleanly, but Audio File Size = 0 bytes. | Canary script returned exit `0` (success), but disk metric watcher flags zero length. Logic says success; physical reality says empty. | Wake Agent: "Audio pipeline passing healthcheck but producing empty buffers." |
| **4. Cost / Risk Asymmetry** | 2 of 3 watchers say "Job Complete" (Ready for 50k-token collation agent), 1 watcher says "Incomplete". | Proceeding based on 2/3 majority risks wasting tokens on partial data. Waiting risks delaying downstream workflow. | Wake Agent: "Assess partial completion risk before initiating heavy run." |

---

## Summary of Architectural Responsibilities

* **The Mechanical Layer's Job:** Filter out execution errors, collapse time-lagged updates, aggregate quorum, and detect when watchers disagree. If the conflict can be solved by timestamps, sorting, or math, solve it silently at zero cost.
* **The Agent's Job:** Wake up when disagreement reflects **semantic confusion or contradictory truths**. The agent does not run the watchers; it acts as the judge called to court only when the mechanical rules detect an insoluble split.
