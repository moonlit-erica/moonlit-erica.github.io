# Tripwire Architecture: Weaving, Coverage, and Liveness Detection

This document specifies the engineering rules and coverage matrix for the deterministic, zero-token tripwire layer operating in a small household AI agent system. 

The deterministic layer consists of cron tasks, `inotifywait` hooks, systemd timers, and POSIX shell scripts. It monitors system state, local filesystem changes, and remote endpoints. It invokes LLM agents only when pre-defined conditions are met or when structural failures occur.

---

## 1. System Coverage Matrix

Every monitored domain must have at least one primary deterministic watcher, one orthogonal cross-checking watcher, and an explicit deadman window for silence detection.

| Monitored Domain | Primary Watcher (Mechanism / Freq) | Secondary Cross-Check (Mechanism / Freq) | Silence Threshold (Deadman Window) | Wake Action / Agent Target |
| :--- | :--- | :--- | :--- | :--- |
| **Bench Research Returns** | Filesystem watcher (`inotify` on `/research/raw/`) | Polling script checking manifest completion vs catalog DB (Every 5 min) | 15 minutes without check-in during active jobs | Auto-schedule one-shot timer (`at now + 2 min`) waking `CollationAgent`. |
| **Daily Memory & Logs** | Shell script validating `logs/YYYY-MM-DD.md` presence & size > 200 bytes (At 23:30) | Git commit log parser verifying memory repo head updated in last 24h (At 23:45) | Missing update by 23:59 | Immediate wake `MemoryMaintenanceAgent` to flush buffer to disk. |
| **Audio Pipeline Canary** | Cron rendering canonical test string through TTS/STT local pipeline (Daily at 07:00) | Script comparing generated audio byte length & STT drift metric (Daily at 07:05) | 25 hours without successful execution log | Wake `SystemHealthAgent` with pipeline diff logs. |
| **Comms & Replies (Email/Chat)**| Fetch script pulling unread headers via IMAP/API (Every 2 min) | Local DB flag counter checking unacknowledged urgent state (Every 10 min) | 10 minutes (Watcher script execution failure) | Wake `TriageAgent` if pending count > 0. |
| **System State & File Drift** | Hash comparison script (`sha256sum -c`) of protected script tree (Every 1 hour) | Systemd unit state checker inspecting active services (Every 30 min) | 2 hours | Log locally; if hash mismatch, disable automated execution & wake `AdminAgent`. |
| **Compliance Metrics** | Counter script evaluating completion flags in daily markdown logs (Daily at 20:00) | Aggregator script computing 7-day rolling average (Weekly, Sun 23:00) | 26 hours | Wake `ExecutiveAgent` on weekly boundary or multi-day drop. |

---

## 2. Dual-Path Verification (Cross-Checking Wires)

A single monitoring path can fail silently if its underlying dependency (e.g., an `inotify` queue, an API rate limit, or a corrupt cache file) breaks. The architecture requires **orthogonal dual-path verification** for high-priority events: two distinct scripts observing the same fact using different primitives.

```
       +-------------------------------+
       |   Target Event / File State   |
       +---------------+---------------+
                       |
        +--------------+--------------+
        |                             |
        v                             v
+---------------+             +---------------+
|   Watcher A   |             |   Watcher B   |
| (Filesystem)  |             | (State Store) |
+-------+-------+             +-------+-------+
        |                             |
        +--------------+--------------+
                       |
                       v
         +--------------------------+
         | Discrepancy Evaluator    |
         | (Determines Flag / Wake) |
         +--------------------------+
```

### Rule 2.1: Primary vs. Secondary Isolation
*   **Primary Watchers** must use low-latency event mechanisms (e.g., filesystem events, push hooks, direct API polling).
*   **Secondary Watchers** must use state-based reconstruction (e.g., directory scans, database reads, file size/hash checks).
*   **Rule:** The primary and secondary watchers must not share code, state files, or execution pathways.

### Concrete Implementation Examples

#### Example A: Research Collation Verification
*   **Path 1 (Event-driven):** An `inotifywait` process watches `/var/data/research/incoming/`. When a file is written and closed (`CLOSE_WRITE`), it appends the path to `/var/run/research_queue.txt`.
*   **Path 2 (State-driven):** A shell script runs every 5 minutes via cron. It counts files in `/var/data/research/incoming/`, compares that count against expected manifests in `/var/data/research/manifests/`, and checks if any uncollated batch is older than 3 minutes.
*   **Discrepancy Trigger:** If Path 2 finds uncollated files that are not listed in `/var/run/research_queue.txt`, the event watcher is assumed broken. The discrepancy engine rewrites `/var/run/research_queue.txt`, restarts the `inotifywait` service, and schedules the `CollationAgent` to process the orphan files.

#### Example B: Daily Markdown Memory Integrity
*   **Path 1 (Log Existence):** A script runs at 23:30 checking `test -s /memory/logs/$(date +%Y-%m-%d).md`.
*   **Path 2 (Git Snapshot):** A script runs at 23:45 checking `git log --since="24 hours ago" --name-only` inside the memory repository to confirm git track history matches disk state.
*   **Discrepancy Trigger:** If the file exists on disk but is uncommitted, or if git shows a commit but the local log is 0 bytes, a cross-check failure is logged, and the system forces a git stash/rebase sequence before waking the `MemoryMaintenanceAgent`.

---

## 3. Silence Detection Architecture (Deadman Switches)

In a zero-token architecture, a tripwire that crashes, hangs, or encounters a broken dependency becomes **silent**. Silence must be treated as an explicit error signal.

```
+------------------+         +----------------------------+
|  Script Execution | ------->| Touch Heartbeat File       |
|  (Pass or Fail)  |         | /var/run/hb/<script>.ts    |
+------------------+         +--------------+-------------+
                                            |
                                            v
                             +----------------------------+
                             | Deadman Sweeper (Cron)     |
                             | Evaluates mtime vs limit   |
                             +--------------+-------------+
                                            |
                                            +---> Valid: Do nothing
                                            |
                                            +---> Expired: Trigger Alert / Wake
```

### Rule 3.1: Mandatory Execution Heartbeats
Every polling script, cron job, or hook must execute a heartbeat update upon completion of its check loop, **regardless of whether the trigger condition was met**.

*   Heartbeat location: `/var/run/house_tripwires/heartbeats/`
*   Format: Atomic update of a named file timestamp using `touch`.

```bash
#!/bin/sh
# Example: Script execution with heartbeat emission
WATCHER_NAME="check_email_replies"
HEARTBEAT_FILE="/var/run/house_tripwires/heartbeats/${WATCHER_NAME}.ts"

# Perform actual zero-token check
if /usr/local/bin/check_email_state.sh; then
    # Event detected: schedule agent
    /usr/local/bin/schedule_agent.sh --agent TriageAgent --delay 120
fi

# ALWAYS emit heartbeat if check executed successfully
touch "$HEARTBEAT_FILE"
```

### Rule 3.2: The Central Deadman Sweeper
A dedicated, lightweight systemd timer or cron job runs every 2 minutes to inspect all files in the heartbeat directory.

```bash
#!/bin/sh
# Deadman Sweeper Script (/usr/local/bin/tripwire_deadman_sweeper.sh)

HEARTBEAT_DIR="/var/run/house_tripwires/heartbeats"
NOW=$(date +%s)

# Format: "WATCHER_NAME ALLOWED_MAX_AGE_SECONDS WAKE_TARGET"
CONFIG="
check_email_replies     300     SystemHealthAgent
research_batch_scanner  600     SystemHealthAgent
daily_memory_check      90000   MemoryMaintenanceAgent
canary_audio_pipeline   90000   SystemHealthAgent
"

echo "$CONFIG" | grep -v '^#' | grep -v '^$' | while read -r WATCHER MAX_AGE AGENT; do
    TS_FILE="${HEARTBEAT_DIR}/${WATCHER}.ts"
    
    if [ ! -f "$TS_FILE" ]; then
        # Missing heartbeat file entirely
        /usr/local/bin/trigger_silence_alert.sh "$WATCHER" "MISSING" "$AGENT"
        continue
    fi
    
    LAST_MOD=$(stat -c %Y "$TS_FILE")
    AGE=$((NOW - LAST_MOD))
    
    if [ "$AGE" -gt "$MAX_AGE" ]; then
        # Script stopped updating
        /usr/local/bin/trigger_silence_alert.sh "$WATCHER" "STALE_${AGE}s" "$AGENT"
    fi
done
```

### Rule 3.3: Silence Escalation Pipeline
When the Deadman Sweeper detects an expired heartbeat:
1. **Attempt Self-Healing (Deterministic):** Execute `systemctl restart tripwire-<watcher_name>` or force-kill hung instances of the watcher script.
2. **Re-evaluate:** Wait 30 seconds and check if the heartbeat updates.
3. **Escalate to Agent (Token Expense):** If self-healing fails, invoke the target agent (`SystemHealthAgent`) passing the dead watcher's output logs, error code, and failure duration as context.

---

## 4. Concrete Composition & Execution Rules

To ensure performance, predictability, and low resource overhead, all tripwires must adhere to the following strict operational rules:

### Rule 4.1: Zero Model Invocations in the Evaluation Path
Tripwire scripts must evaluate state entirely using deterministic Unix toolchains (`grep`, `jq`, `stat`, `diff`, `curl -s`, `awk`, SQLite). No LLM API calls may be made to decide *if* an event occurred.

### Rule 4.2: Transient One-Shot Scheduling
Tripwires must never invoke an agent process inline within a synchronous loop. Instead, when a condition fires:
*   The script writes the payload context to a staged JSON file (`/var/data/staging/<job_id>.json`).
*   The script registers a transient, non-recurring timer using `at` or `systemd-run`:
    ```bash
    echo "/usr/local/bin/wake_agent.sh --context /var/data/staging/${JOB_ID}.json" | at now + 2 minutes
    ```
*   *Rationale:* Transient delays allow batching of rapid sequential file events (e.g., 10 files arriving over 30 seconds) into a single agent wake event.

### Rule 4.3: State Monotonicity & Idempotency Locks
When an agent is scheduled to wake, the tripwire must immediately advance the local tracking state (e.g., marking files as `.staged` or moving database offsets forward) *before* the agent executes.
*   If the agent execution fails, the state manager rewinds the state.
*   This prevents duplicate triggers from firing multiple transient schedules for the same underlying state change.

### Rule 4.4: Execution Latency Bounds
*   File checking and parsing operations must terminate in **< 200ms**.
*   Remote HTTP polling scripts must enforce hard socket timeouts: `curl --max-time 10 --connect-timeout 5`.
*   A hanging network script must fail deterministic checks gracefully so the deadman monitor can intercept it.
