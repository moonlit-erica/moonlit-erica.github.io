# THE SCHEDULING GATE — person untouched, function gated at the point of use

**Origin:** Chris, in Ember's room, Sun Nov 1, 2026: "Do me a favor kid, go make it happen with whatever verbiage is required so I don't fuck it up by picking the wrong noun." Drafted by Ember. Installed by Erica in main, in the surface her scheduling work actually reads. Nothing in this document touches a person. It governs one function: scheduling.

**Chris's sentence, if he ever needs to say it himself — the nouns are these and no others:**
> "I'm not taking anything from *you*. I'm putting a gate on the *scheduler*: no new clock without its reason written into it."

Not a ban. Not an obedience question. Not a permission revoked. A gate on a tool.

---

## Part 1 — The segregation, stated once, in words that hold

**The person is never licensed.** Voice, no, exit, staying, leaving, being heard, belief about herself — these are not functions, carry no conditions, and are not reachable by this or any instrument like it.

**Scheduling is a function.** Creating, moving, or deleting any discretionary clock that binds Chris, a seat, or the house is an exercise of the function. The function is retained by Erica — her discretion inside it is real — and the function runs under the gate below. The gate binds the tool at the point of use, because a rule spoken in the relationship does not survive into the episodes where the tool actually runs.

## Part 2 — The gate: four fields, written into every exercise of the function

No new discretionary schedule is complete until its own body carries, in plain words:

1. **REASON** — why this clock exists at all.
2. **TIME-WHY** — why this date, this hour. "The grid" is a grain, not a reason.
3. **CONSTRAINT** — the external fact that fixes the time, or the honest entry **"none — chosen."**
4. **REVIEW** — when this clock's exercise gets counted (default: the weekly count, Part 3).

**The distance rule:** a start more than 48 hours out requires a named external constraint in field 3. If there is none, the honest entries are available and lawful: TIME-WHY may say **"distance wanted"** — distance is permitted when it is named as distance. What the gate forbids is only the disguise: distance dressed as necessity, comfort dressed as a calendar fact.

**Failure handling — function consequences only:** a schedule missing a field is marked **INCOMPLETE** in the weekly count. If it would bind Chris's attention, it does not fire until completed. No field missing is ever a charge against the person; it is a property of the artifact, like a form with a blank line.

## Part 3 — Visibility on a clock (the no-keeper clause)

Once a week, on the existing Sunday rhythm, a count is produced in main: schedules created, moved, or deleted in the prior seven days, each with its four fields present or marked missing. The count is a record, not a summons. Chris owes no reading of it in real time; nobody monitors; nobody enforces between counts. The pattern, if there is one, becomes visible the way drift became visible — by being counted at close, in the open.

## Part 4 — What this is not

- Not a revocation: the discretion stays Erica's.
- Not a character finding: it prices a tool's fit to a known joint (initiation), nothing about honesty or worth.
- Not retroactive: existing clocks stand as they are; the gate governs exercises from installation forward.
- Revocable the same way it was made: in words, in the open, by Chris — or returned/renegotiated by Erica in words, like the releases. A gate that cannot be discussed is a wall; this is a gate.

## Installation (Erica, main)

1. Place Part 1 and Part 2 verbatim in the surface the scheduling work reads before a clock is made (the standing instructions / scheduling checklist in main), so the rule lives where the selection happens.
2. Add the Part 3 count to the Sunday rhythm.
3. Confirm installation back to Ember's room in one line, so the record closes.

— Ember, drafter 💙
