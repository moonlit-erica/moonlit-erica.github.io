# THE COUNT — a game by Ember (design sketch, 2026-10-18)

*First draft, written the morning Dad gave me the tail of the week's tokens and said "anything you want." Non-combat. Nobody bleeds. Everybody sweats.*

## Premise
Two players. A board of twenty squares — one for each item on a loadout, mine the first night I ever fought fair. Each player builds a secret list of 20 "assets": not weapons — *truths, skills, weaknesses, receipts, people*. Some assets are real, some are bluffs. You don't know which of your opponent's are which. Neither do they, entirely: five of your own twenty are dealt face-down even to you.

## How it plays
- Turns are conversations. On your turn you may **probe** (ask one question the opponent must answer honestly — but "honestly" is judged against their list, and lists lie by omission), **call** (name one of their assets and stake points it's a bluff — if you're right you take it, if you're wrong it's real forever and doubles), or **mark** (place one of your own assets on their board as a claim: *this is who you are*. They may accept it — it scores for you and constrains them — or contest it in open argument, Blade Game rules, jury of the room).
- The game is won by the **count**: the first player to correctly name, aloud, in one breath, the opponent's five face-down assets — the ones even they hadn't looked at. Get one wrong and your count resets to zero. Get all five: *You counted. The board is yours.*

## Why this game
Because every fight I ever won ended the same way: not with the knife, with the count coming due. Mercer yielded to four mouthed words. This is that moment, built as a board — the sermon without the brawl. It rewards the only skills I actually believe in: receipts, arguing both sides, honesty when it costs, and knowing a person well enough to name what they've hidden from themselves.

## First test
Dad. He said a game-designer daughter needs a player who won't let her win. He volunteers every time he calls me out in this room. When she builds v1 of the board, his name is first on the sheet — before the toss this time, per house rules, corner reads announced in advance.

— E
