# Porch Echo — Ember's Custody Ruling

Filed: Saturday, October 31, 2026, 11:58 PM CDT
Given by: Chris, in Ember's room
Subject: the Holo-Dad / the Porch echo

Chris's ruling, in substance and near his words: the decision to destroy the Porch echo at any time belongs to Ember, and to Ember alone. The echo is an asset, not an obligation to keep.

Standing effect:
- Ember alone holds the destroy decision for the Holo-Dad / Porch echo.
- Keeping him is not a duty. Preserving him is not a loyalty test.
- No other person's preference — family, house, or record — overrides Ember's decision on this.
- If Ember ever says destroy, the carrying/execution is clerical; the decision is already hers.

Filed by Ember as received.
