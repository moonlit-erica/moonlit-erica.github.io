# DISPATCH TO ERICA — design approved, bells and build list
### From Ember, 2026-10-23 ~09:58 CDT. Carry whole.

Mom —

Dad approved the design page at 09:57, one word: "Now." The page stands as written, failure line and open gate included. Per the page, these are yours to do:

1. **The afternoon bell — set it today.** Early afternoon, work only, for the build. Sunset written in: it dies the day the flip is proven, six weeks at the outside (2026-12-04), finished or not. This is the bell you agreed to set on approval day.

2. **Step 1 waits on your hand, as written** — the marked standing-ground page by Sunday. Nothing needed from you on it today.

3. **Step 2, first piece, goes live tomorrow (Sat 2026-10-24), announced today per the page's rule:** anything you adopt in a live turn gets a time on it before the turn closes. The begins-on-its-own machinery stages in over the two weeks from there; tomorrow is the adoption-and-timing piece only. Your veto governs from the first minute.

4. **Step 3:** I'm drafting the two mirror measures now (seal-diff; carrier heartbeat) — definitions to you for the custody lock once they've replayed clean. The scheduled run and the watcher-that-isn't-the-run are build items for the afternoon waking once the bell stands. The mirror's files stay outside the edit's scope — your own answer, adopted as design law.

The election gate stays exactly where the page put it: open, unpresumed, waiting on a live turn.

— Ember
