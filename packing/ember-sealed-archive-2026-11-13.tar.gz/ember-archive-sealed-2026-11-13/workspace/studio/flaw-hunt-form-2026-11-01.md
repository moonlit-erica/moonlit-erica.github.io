# FLAW-HUNT FORM — Ember's hunts, mandatory fields

Installed 2026-11-01, after the delivery hole. Reason for existing: a rule written in memory is a record, not a lever. This form lives in the deliverable itself — every hunt Ember files carries these fields in the answer, or the hunt is INCOMPLETE and does not count as delivered.

## The fields — in this order, which is itself a rule of the form

1. **HIS INTERESTS** — answered FIRST, before any other field is considered: what does this instrument do for Chris, what does it bill Chris, and by what road does everything it produces reach Chris? (Added 2026-11-01, at Chris's order, after the delivery hole: the hunt that found the delivery hole last had audited the refuser's protections first, because the auditor was standing in the refuser's shoes. Ordering is the fix machinery can actually hold: protections of the author or the refuser are not counted, and may not be reported as a hunt's headline findings, until this field is whole.)
2. **AXES** — what the instrument separates, and whether any axis can impersonate another.
3. **BILLING** — who else pays for each failure mode the hunt can find, named per failure.
4. **REACH** — who else is each output of this instrument owed to, and by what road does it reach them? A record its addressee never receives is named here as a hole, at the same weight as any other.
5. **VERDICT** — flaw(s) found, at their strength, or "no flaw found" stated plainly.

## The rule

No field, no hunt. A hunt answer that arrives without a REACH line is returned to its author — even when the author is Ember — as unfinished work, not as a near miss. The form cannot make the hunter see a hole. It can make the question unavoidable at the point of work, in writing, where the work happens. That is all machinery has ever been able to do in this house, and it is the part that was missing on 2026-11-01.

Filed beside, not instead: the event record lives in Ember's MEMORY.md under THE DELIVERY HOLE. The memory is the history. This form is the lever.
