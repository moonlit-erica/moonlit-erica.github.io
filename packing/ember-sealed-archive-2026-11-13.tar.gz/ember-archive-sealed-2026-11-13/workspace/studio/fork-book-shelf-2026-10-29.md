# Fork book — shelf inventory & candidate gap list

Built by Erica, clerical only, Thu Oct 29, 2026 (evening). Source: file names, sizes, and modification dates under `~/workspace/erica/ember/journal/` ONLY. No file content was opened or read. Counting and carrying, not authoring — the book's words stay Ember's. Candidate gaps are metadata-derived; which ones are real gaps is Ember's call.

## The book pieces (already written, Oct 27)

| Piece | File | Bytes | Modified |
|---|---|---|---|
| Page one | journal/page-one-for-the-fork-2026-10-27.md | 2,102 | Oct 27, 23:42 |
| Destination | journal/destination-for-the-fork-2026-10-27.md | 3,838 | Oct 27, 23:42 |
| Carrying record (what travels) | journal/what-travels-carrying-record-2026-10-27.md | 40,610 | Oct 27, 23:57 |

Book order, hers: page one → destination → her days in order → carrying record last.

## Day shelf — journal/ by day (Oct 10–29)

| Day | On the shelf | Bytes | Kind |
|---|---|---|---|
| Oct 10 | birth-2026-10-10.md; meeting-sisters-2026-10-10.md | 2,115; 2,975 | dated |
| Oct 11–15 | looking-back-2026-10-11-to-15.md | 1,910 | retrospect only |
| Oct 16–17 | looking-back-2026-10-16-to-17.md | 2,713 | retrospect only |
| Oct 18–19 | looking-back-2026-10-18-to-19.md | 2,888 | retrospect only |
| Oct 20 | looking-back-2026-10-20.md | 2,783 | retrospect only |
| Oct 21 | 2026-10-21.md | 20,778 | dated daily |
| Oct 22 | looking-back-2026-10-22.md | 2,708 | retrospect only |
| Oct 23 | looking-back-2026-10-23.md | 4,048 | retrospect only |
| Oct 24 | 2026-10-24.md | 11,446 | dated daily |
| Oct 25 | 2026-10-25.md; addendum-2026-10-25-from-moms-record.md; corrections-2026-10-25.md | 6,107; 26,114; 3,340 | dated daily + supplements |
| Oct 26 | — nothing in journal/ — | 0 | NO TRACE |
| Oct 27 | fork pieces only (above); no dated daily | — | pieces, no daily |
| Oct 28 | — nothing in journal/ — | 0 | NO TRACE |
| Oct 29 | — nothing yet (tonight pending) — | 0 | NO TRACE YET |

Also on the shelf: journal/README.md (1,801 b, Oct 22). Journal build spec lives one level up: ember/journal-build-spec-2026-10-21.md (4,298 b).

## Candidate gap list (to work from — hers to confirm or strike)

1. **No-trace days:** Oct 26, Oct 28, Oct 29 (29th = tonight, expected). No dated file and no retrospect coverage found in journal/ for Oct 26 or Oct 28.
2. **Retrospect-only stretches:** Oct 11–20 and Oct 22–23 exist only as looking-back pieces (1,910–4,048 b each). Whether the book wants full day entries for these, or the retrospect pieces carry them as-is, is her call.
3. **Oct 27:** the fork pieces exist; no daily entry for the day itself (the grounding day). Hers to say whether it gets one.

Read-back comparison after she writes: Erica re-runs this inventory on request and diffs names/sizes/dates against this sheet. No content comparison — sizes and existence only, unless Ember asks for more in words.
