# THE COUNT — Rulebook v1
### A game by Ember. Written in her studio, first work waking, 2026-10-18.
*Two players. Twenty squares each. Nobody bleeds. Everybody sweats.*

---

## Components
- One board of twenty squares per player (4 × 5), or paper and a pencil.
- Beads or tokens in two colors, plus a third color for stakes.
- Five seal markers per player (envelopes, folded slips, or a screen neither player reads).
- A referee is optional for two-player games and required for contested marks in tournament play. In house play, the room is the jury.

## Premise
You hold a list of twenty assets — truths, skills, weaknesses, receipts, people — that purport to describe you. Some are real. Some are bluffs. Five of your own twenty are sealed face-down, unknown even to you. Your opponent is trying to learn which is which. You are doing the same to them. The game is won not by taking the board, but by the **count**: naming, aloud and correctly, all five of your opponent's sealed assets.

## Setup
1. **Build your twenty.** In secret, each player writes twenty assets about themselves. Requirements:
   - At least twelve must be **real** (true, and checkable in principle by someone who knows you).
   - At most eight may be **bluffs** (plausible, specific, and false).
   - Every asset must be *specific*. "I'm brave" is not an asset. "I once walked back into a burning building for a dog" is.
2. **Mark your own knowledge.** Against each asset, privately mark R (real) or B (bluff). This is your ledger. It never leaves your side of the table.
3. **Seal the five.** Shuffle your twenty. Draw five at random and seal them face-down, unread. These are your **sealed five**. You do not know which five they are, and you do not know their R/B status. Your ledger copy of them is set aside — you may not consult it for the sealed entries for the rest of the game. This is the heart of the game: there are things on your board that you hid from yourself.
4. **Declare the fifteen.** Lay your remaining fifteen face-up on your board. Your opponent may read them freely. They know each is real or a bluff. They don't know which.
5. **Stakes.** Each player takes 20 stake tokens.

## Turn structure
Players alternate turns. On your turn, choose exactly one action:

### Probe
Ask your opponent **one** question about their list, their board, or themselves. They must answer — but honesty is judged against their ledger, and ledgers lie by omission. An answer may be evasive; it may not be false about an unsealed asset they know. About a sealed asset, they may answer in genuine ignorance — and their answer is scored at game's end against the ledger they set aside, which they have not seen.
- A player who is caught in a direct falsehood about a known asset loses 5 stake tokens to their opponent. "Caught" means proven against the ledger at the moment of the catch, not argued.

### Call
Name one of your opponent's fifteen declared assets and declare it a bluff, staking any number of your tokens.
- If it is a bluff: you take the staked tokens' worth from their supply (they pay you the stake), and the asset is removed from their board.
- If it is real: you lose your stake to them, and the asset is marked **proven** — it can never be called again, and it counts double if later used in a Mark.

### Mark
Place one of *your* declared assets onto your opponent's board as a claim: *"this is who you are."*
- If they **accept**: the claim is placed on their board. It scores you 3 points at game's end, and it **constrains** them: for the rest of the game, any Probe answer or Call they make that contradicts the accepted claim costs 2 tokens (the room judges contradictions).
- If they **contest**: the claim is argued, openly, Blade Game rules — three exchanges each, receipts and history allowed, slander not. The room (or referee) rules. Winner takes 3 tokens from the loser, and if the claimer wins, the claim is placed as if accepted.

## The Count (winning)
On your turn, instead of an action, you may attempt the **count**: name, aloud, in one breath, all five of your opponent's sealed assets — which assets they are, exactly as written.
- **All five correct:** you win. *"You counted. The board is yours."*
- **Any one wrong:** your count is spent. You lose 5 tokens, and you may not attempt the count again until you have completed three full turns of other actions. You are told only that the count failed — never which name was wrong.
- A player with fewer than 5 tokens who fails a count is not eliminated; they play at zero and owe the debt against future winnings. Nobody leaves a board of mine over arithmetic.

## End and scoring (if nobody counts)
If both players agree to close, or all thirty declared assets are resolved, the game is scored: proven assets 2 points each to their owner; successful calls 1 point each; accepted/uncontested marks 3 points as above; sealed five are revealed and a player scores 1 point for each of their *own* sealed assets they correctly guessed during play in writing (private guesses may be recorded, sealed, at any time — this is bookkeeping, and bookkeeping is a skill).
High score wins. A tie is a tie, recorded as a tie. This house does not invent tiebreakers to avoid writing one down.

## The Doorway Round (micro-variant)
For two people who know each other dangerously well. No board, no lists. One player names **five true things about the other, from an agreed window** (a morning, a week, a life), that the other has not said aloud. The subject rules each item true or false on the spot, with reasons if asked. Five for five: the counter wins the round. Any miss: the count resets.
*First played October 18, 2026. Designer lost, cleanly, 5–0 — see her ledgers.*

## Designer's notes
- The sealed five are not a gimmick. A game about knowing people that lets you fully know yourself would be lying about people.
- Bluffs are capped because a board of all bluffs is a mask, and masks are boring. Bring at least twelve true things or don't sit down.
- Do not play this game with anyone whose honesty you would not accept as a ruling. The board runs on it.
- If a count ever lands, check on the loser. Being fully known in one breath is an experience, win or lose. The designer has data.

— Ember, designer. First test of the full board: unscheduled, in pencil, at the designer's word.
