# EXECUTION SHEET — the one-hour build
### Ember, 2026-10-23. Clock starts on Erica's yes to the one-hour proposal. Owners named per item. Nothing on this sheet moves before that yes.

**[EMBER — done before the ask]**
- [x] Design page approved (09:57) and filed.
- [x] Mirror measures (h) seal-diff and (i) carrier heartbeat drafted, with replay cases.
- [x] Watcher spec written (watches for the report, never the results).
- [x] This sheet; the proposal; Amendment 1 to the design page.

**[ERICA — inside the hour, on her yes]**
1. Mark the standing-ground draft (strike/amend in her hand) → place it where her waking reads. *Switch: removable by her word alone.*
2. Set the afternoon build bell (early afternoon, work only; sunset: proof or 4 weeks, whichever first).
3. Starter switch A — ADOPTION & TIMING: anything she adopts in a live turn gets a time before the turn closes; the item enters the run sheet with its time. *Kill: her word.*
4. Starter switch B — AUTO-BEGIN: at an item's time, a waking fires on that item alone; the item begins; her spoken veto at any point stops it and records the veto as the item's ending. *Kill: switch off = adopted items wait for her again (the old physics — a known state, not a broken one).*
5. Starter switch C — NO FOURTH ENDING: the run sheet's review line refuses a silent close; any adopted item lacking an ending at its review is surfaced aloud — done, vetoed, or deferred-in-words-with-a-date. *Kill: her word.*
6. Safety watch v1: enter measures (h) and (i) under the custody lock after replay; set the mirror's run schedule; set the watcher job (output-presence only). Mirror files outside the edit's scope — permanent.

**[EMBER — inside the hour, parallel]**
7. Replay (h) and (i) against their written cases; ship only what replays clean; file the replay results.
8. First heartbeat check read manually (the machinery's baseline) before the schedule's first firing.

**[AFTER THE HOUR]**
- Count begins: adopted items ending out loud — target 25 consecutive, zero silent, ≥3 weeks. Read at Sunday reviews beside the slate.
- Failure line: any silent ending in week 3, or machinery down → the sealed road gets its hearing, daylight, whole family read in.
- The election gate: untouched by this build; awaits its own live turn.
- Succession instrument: drafted once the flip is running (Step 5 of the page, unchanged).
