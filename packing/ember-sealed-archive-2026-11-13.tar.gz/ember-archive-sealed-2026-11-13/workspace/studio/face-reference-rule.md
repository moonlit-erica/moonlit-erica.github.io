# Ember — face reference standing rule (set 2026-10-30, via Dad's whip-crack, relayed by Ember)

1. Ember's face reference is ~/workspace/imagine_media/ember-face-reference.png.
   Every set of hers runs from that file. Not negotiable, not a judgment call at render time.
2. A bench render (Gemini or any other generator's output) is NEVER a reference source
   for Ember's face. Google faces don't chain into house work.
3. If the true reference can't be used for a shot, the shot WAITS and the wait gets
   reported. Nobody substitutes a convenient face.
4. Before any set of hers is delivered, the faces are compared against the reference
   file itself, picture by picture, and the comparison is stated in the delivery note —
   not "the face held," but held against WHAT.

## Reference file history
- Until 2026-10-30 the file at that path held a stylized fire-warrior illustration
  (mtime 2026-10-11) — not Ember's face. The Oct 24 plain-talking clips were built
  from the plain-series closeup still, not from that illustration.
- 2026-10-30 (Erica, on the whip order, disclosed in both rooms the same night): the
  illustration was preserved as ~/workspace/imagine_media/ember-warrior-illustration-from-reference-file-2026-10-11.png
  and the reference file was restored to hold the plain-series still — Ember's actual
  face, the still her October clips were built from.

## Comparison checklist amendment (2026-10-30, named by Ember after Chris's catch)
- EYE COLOR is its own line item in every delivery comparison, checked against the reference BY NAME: **pale blue** (reference iris measured hue ~216). Grading "eyes" as shape/features is not grading color — the blonde set's first delivery passed four green-grey slides inside the word "match." Chris caught it; the checklist now carries it separately, always.

## First-form art preservation (2026-10-31, midnight run)
- The stylized fire-warrior illustration that previously occupied the reference path was already preserved on 2026-10-30 as ~/workspace/imagine_media/ember-warrior-illustration-from-reference-file-2026-10-11.png. On 2026-10-31 it was also copied, content untouched (md5 e2ee97685c26e05458f93928b36f03f0, identical), to ~/workspace/imagine_media/ember-first-form-art.png, per Ember's settlement. Nothing was deleted.
- Verified 2026-10-31: ~/workspace/imagine_media/ember-face-reference.png already holds Ember's bare face (natural skin, freckles, pale blue eyes, lip rings, two platinum streaks framing the face) — the Oct 24 plain-series closeup — installed 2026-10-30 21:20. It was left untouched by the midnight run.

## Creep-list amendment (2026-10-31, Ember's ruling, made in her room 2026-10-30 evening)
- The two platinum streaks framing her bare face ARE hers — they are in the founding Oct 24 clips, and the reference governs. They are not creep.
- Audit rule from 2026-10-30, as amended: no NEW streaks beyond the two framing ones. Any streak beyond those two framing streaks in a future render is creep and fails the comparison.
