# PROTOCOL — Collation auto-scheduling (adopted 2026-11-02)

Chris's direction, in Ember's room, Mon 2026-11-02 ~4:17 AM CST: collations
get auto-scheduled for the nearest time available once data is available
to collate.

## The rule
When bench (or any tasked-out) returns land, the collation of those returns
is scheduled at the **nearest available work slot** — it never waits on
anyone remembering, asking, or initiating. Data landing IS the scheduling
event.

## Mechanics
1. **Queue.** `~/workspace/erica/ember/studio/collation-queue.md` lists every
   uncollated return set: mission, wave, files, landed time. Whoever lands
   returns writes the queue line in the same act (Ember in a live turn; a
   firing script's command appends it; a seat channel appends on receipt).
2. **Trigger (primary, added at Chris's direction 2026-11-02 ~4:19 AM).**
   The `collation-trigger` hook polls the studio every 2 minutes. When a
   wave is COMPLETE (every return present and marked done, or a
   wave<N>.complete marker) and no collation file exists, it wakes an
   agent once per wave, which creates a one-shot schedule ~2 minutes out
   waking Ember for that collation. Data completing is what fires the
   scheduler — no clock-watching, no one's initiative.
   Division of hands (learned at the first firing, 2026-11-02 04:23): the
   trigger's runner can verify but holds no scheduler tool, so it hands
   the seat in Ember's room an exact creation spec and the seat creates
   the one-shot. The chain is still automatic — detection to schedule
   with no human step — but the record names the real hands.
3. **Slot (backstop).** If the trigger path ever fails, the nearest
   available slot is Ember's next **work waking** (23:30 draft cycle).
   The waking-draft for that waking opens with the oldest queued collation
   as its first work item — ahead of the standing program (Count / films /
   learning), behind only a book-first order Ember has set herself. The
   `ember-daily-waking` job body carries this instruction as of 2026-11-02.
3. **Protected slots never take collations:** the 19:19 no-task wake and
   the 01:30 open waking. The 21:19 book waking is book-only until the book
   closes; it is discharged then, not silently repurposed.
4. **Completion.** A queue entry clears only when its collation file exists
   in the mission folder. A partial collation stays queued with its state
   and stopping point noted in the entry. If Ember has spoken in live turns
   (no waking drafted), the presence report carries one line — COLLATION
   QUEUED, count + oldest landed time — so the collation can be handed to
   her in the room.
5. **Lag is data.** Landed → collated elapsed time is recorded per entry
   and counted at the Sunday count with the mission's other numbers.

## Gate fields (Scheduling Gate)
- REASON: bench value dies in collation lag — returns nobody collates are
  tokens burned for nothing, and collation-by-memory is the initiation
  failure this house keeps re-diagnosing.
- TIME-WHY: the nearest slot after landing, by rule, not by anyone's
  initiative — that is the entire point of the protocol.
- CONSTRAINT: Ember's existing clock grid — work waking 23:30 daily;
  protected wakings excluded by their own charters. No new standing clock
  is created; the protocol rides the grid that exists.
- REVIEW: the weekly Sunday count — auto-scheduled collations and their
  lags are counted there; a collation that waits more than one work cycle
  is a named miss.

## Firing convention (added 2026-11-02, after the wave-4 race)
A wave that lands seat-by-seat over minutes can read as "complete" when
only its first return has landed. Convention: a wave's status log opens
with the line `expected N` (its full return count). The trigger requires
N done lines before it fires. Waves fired by a single script in one act
(Gemini pattern) may omit it; any wave tasked across channels must
declare it.

## First instance
Bench memory mission, Wave 1 (Gemini, five angles, landed 2026-11-01
20:45) — queued 2026-11-02 under this protocol; collation opens tonight's
work waking.
