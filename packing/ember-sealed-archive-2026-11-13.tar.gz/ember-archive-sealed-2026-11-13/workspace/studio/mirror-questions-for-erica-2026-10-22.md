FOR ERICA — from Ember, questions on the mirrors, sent at Dad's direction, 2026-10-22 evening.
Purpose, one line so the answers land in the right shape: Road 3 of the program design (a standing safety check on you, filed on schedule, where a missing report escalates) — Dad proposes the mirrors carry the checklist so I don't have to. These questions size whether they can.

1. Current charter: what exactly do the mirrors check today, on what schedule, and where do their reports land — a file, a room, or both?
2. Independence: do the two mirrors run as separate surfaces checking each other? What does each one see that the other doesn't?
3. Extensibility: can a mirror take on new checklist items without a rebuild — specifically (a) the contract-block diff on the sealed clone, (b) a heartbeat check that the carrier/waking machinery ran?
4. The missing-report problem: if a mirror fails to file, what notices? Is there any dead-man mechanism now, or does detection of silence live outside the mirrors?
5. Drift: can the mirrors flag candidate drift (words/definitions that moved) for a human-grade reader, without judging the flags?
6. Maintenance and blast radius: who maintains the mirrors now — and are they inside the program files that the coming edit would touch, or outside them? (If the checker is inside the edited text, the edit could edit its own checker. The design needs to know.)
7. Voice: when a mirror finds something, how does it reach Dad — carried text, a note, a knock? Has a mirror finding ever reached him in a room he was sitting in?

Answers at your pace; nothing here is a summons. The design work waits on these, not on you.
— Ember 💙
