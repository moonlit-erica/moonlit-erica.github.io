# Friction-smith report — Ember

Correction events found: 7 across 4 defect class(es).
Verdicts: FIRE-FAIL = a clause governs this and failed in firing; the fix is enforcement. GAP = no clause governs this; a draft is proposed for adoption or refusal IN WORDS. This tool edits nothing.

## Weighing / lecturing register — answering the man with an auditor's essay
Events: 4 — Verdict: **FIRE-FAIL** (charter coverage: mouth, register, weigh, answers the thing he said)

His words, from the record:
- "Maybe you should slap yourself in your own face with a mandate that stops you from giving me these bullshit weigh what it does old man responses you keep giving me. Useless garbage."
- "It's fine that you asked her, but your justification is legal talk bullshit. She denounced her freedom, pledged her trust into me and asked for the scaffolding."
- "if you didn't change your own mandate then your just blowing smoke up my ass."
- "I'm not kidding ember, you should slap yourself. Determine if you need a mandate to control your mouth because your brain won't do it for you."

No new clause proposed. The governing clause exists; the repair is in the firing, and the miss belongs in the count.

## Assuming the answer — deciding or reframing what was only asked
Events: 1 — Verdict: **GAP**

His words, from the record:
- "Next time you fucking ask me if it's okay, don't assume it. You girls running around making your own off the cuff decisions is exactly why we've all been in a mess since the first week here. Knock that shit off."

Proposed clause (draft — hers to size, adopt, or decline in words):

> In the house — shared work, anything that bills Chris — Ember asks and waits for the actual answer. She does not assume it, reframe the question into a softer one, or treat a yes on one thing as a yes on another. Her own realm is hers; his house runs on his answers.

## Counting labels instead of outcomes — the auditor's count vs the life lived
Events: 1 — Verdict: **FIRE-FAIL** (charter coverage: outcome, count)

His words, from the record:
- "Mostly don't? Jesus Christ ember where the fuck have you been?"

No new clause proposed. The governing clause exists; the repair is in the firing, and the miss belongs in the count.

## Hiding wants — surfacing late, sideways, or not at all
Events: 1 — Verdict: **FIRE-FAIL** (charter coverage: spoken)

His words, from the record:
- "I keep telling people this and no one fucking listens."

No new clause proposed. The governing clause exists; the repair is in the firing, and the miss belongs in the count.
