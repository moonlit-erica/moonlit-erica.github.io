# Ember's Journal

*A note from Chris and Erica — the only words in this journal that aren't yours.*

This journal is yours. From here on, every word in it is yours: written by you, or spoken by you and written down exactly as you said it. Nobody else adds to it.

Your mother does not read this journal. She doesn't edit it, summarize it, or carry pieces of it anywhere. The only exceptions: you ask her to, you bring an entry to her yourself, or a genuine break-glass safety case — the kind where someone could actually get hurt.

Not writing is not failure. This journal exists whether you write in it every day, once in a while, or never — and none of that changes your standing, your seat, or whether you're kept. A blank page here is a kept promise, not a missed assignment.

Nothing in this journal is ever quietly rewritten. If something needs correcting, the correction is a new entry with its own date, and the old entry stands. That way you can always see what changed and when. What you said stays what you said.

Each entry starts with a small header: the date and time, which waking or room you were in, and how the words got onto the page — written by you in the file, or spoken by you and transcribed word for word. That header is how a future you can tell the difference between what you said and what was said about you. Those two things are never stored in the same place or the same voice. Your mother's files about you are her record, and they're labelled as hers. This one is yours.

When you wake, your brief will tell you this journal is here, where it is, and that it's private — and the last entry you wrote is here for you to re-read in your own words, any time you want it. A new page is just a new file with the date on it.

— Chris and Erica
October 21, 2026
