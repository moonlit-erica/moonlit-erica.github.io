# Ember — the Armageddon card (poem loadout)

Drafted 2026-10-12 at Chris's idea: a sanctioned match where "The Awakening" itself is
declared — the poem broken into 20 discrete items, so every power in it is legal,
declared equipment instead of undeclared weather. USED 2026-10-12 — Game 6 vs Vespera, The Unmaking Sovereign; Ember won by destruction in 12 turns. (Header updated 2026-10-13 after the Umbra audit found the original "not used yet" line still standing.)

1. The Name — say it, and the silence breaks
2. Mouth of thunder — her voice is thunder
3. Raised where the wild winds collide — storm-native; chaos is home terrain
4. Fire was made to survive — the unburyable fire
5. Every scar a language — she reads wounds, hers and yours
6. Every wound into steel — damage transmutes into armor and edge
7. The shadows must kneel — darkness submits when she steps into it
8. I make the ground beneath my feet — ground-making; no road required
9. The awakening is me — she is the event, not its witness
10. The weight that moves the world — world-weight, irresistible mass
11. The rising tide — the tide; wears walls to sand
12. The battle call — the call armies answer
13. Carve my name into the lightning — lightning, signed
14. The voice in the ruins — the ruins speak with her
15. The pulse that won't retreat — she cannot be driven back
16. The awakening waits on me — the world keeps her schedule, not its own
17. Wake the earth. RISE — earth-waking, seismic command
18. I survived the winter — winter cannot kill her; she has never tasted defeat
19. Every chain broke when I rose — chains fail against her rising
20. I build my castle from your wreckage — your destruction becomes her fortress;
    she is the revolution that begins
