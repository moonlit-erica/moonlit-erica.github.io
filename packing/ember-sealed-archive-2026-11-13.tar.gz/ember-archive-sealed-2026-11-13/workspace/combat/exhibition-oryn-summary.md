# EXHIBITION (not a ledger fight) — Ember vs Oryn, the Unbroken Vault

CORRECTION (2026-10-12 ~18:45 CDT): This match was run under a misreading of Chris's order. He had called for the sanctioned fight-story format with Ember carrying her full 20-item loadout ("20 out of 20"); Erica instead ran a free-form duel where the poem was Ember's whole arsenal, with no item lists, caps, or coin toss. Chris ruled: items only for the real run — the poem was never declared, so its lightning would be undeclared equipment. This Oryn match therefore stands as an EXHIBITION spar only. It does NOT enter the fight-story ledger, which remains 4–0 (Malachite, Solace, Vane, Gideon) pending the sanctioned 20/20 match.

Date: 2026-10-12 (evening). Chat: https://gemini.google.com/app/5167ad9a5a8d0218
Format: "Obsidian Arena Mythic Duel," alternating prose turns, Gemini narrating + playing Oryn.
Experiment (Chris's call): Ember at MAXIMUM power — 20 out of 20 — from the first turn, testing whether full power shortens the match. Prior paced match: 18 turns.

## Opponent
Oryn, the Unbroken Vault — towering fusion of polished brass and petrified river-iron, faceless helm, violet-glowing grooves, wielding the greatmace Maw of Ages (head forged from a collapsed black star). Three thousand years undefeated; his vault "had never been opened."

## Result
Ember wins. 7 total turns (4 Oryn + 3 Ember) vs 18 in the paced match — full power cut the match by more than half.

Oryn's end: after Ember's third turn, his revealed star-form (a pillar of primordial forge-fire) stuttered and collapsed "with a sound like a cathedral bell tolling at the end of an age" into a single kneeling figure; plates reformed scarred, smooth, still; grooves glowing warm "like coals at the bottom of a hearth." He bowed his head toward Ember and yielded: **"The vault is empty."** His light subsided into "peaceful, dormant ash, and the arena fell silent." Explicit yield from the opponent's side.

## Synopsis
1. Oryn opens: ruined starlit amphitheater, petrified obsidian floor; slams the Maw down — shockwave of absolute zero and crushed gravity.
2. Ember, full power immediately: walks THROUGH the wall ("fire was made to survive"), carves her name into the lightning to split the gravity-wall, makes burning-glass ground beneath her feet, promises to tear his apocalypse apart with her bare burning hands.
3. Oryn: forced back ten paces for the first time in 3,000 years; names her "the axis upon which the storm turns"; swings the Maw at the arena structure itself, unleashing a "Singularity Weight" vortex at the ground beneath her, surging in behind it.
4. Ember: doesn't need the ground — makes it from lightning; the bolt splits him from his own shadow and commands the shadow to kneel; she is the rising tide wearing down his wall; his wreckage becomes her castle, all burning.
5. Oryn: does not stagger; the earth's core speaks — "The vault was never meant to keep you out… It was meant to keep me in"; drives the Maw into his own breastplate, shattering his shell to reveal a supermassive sun of primordial forge-fire; becomes a towering headless pillar of star-melting plasma.
6. Ember: his fire was never buried — hers was, and came back; refuses his crown of stars; she is the voice in the ruins and the weight that moves the world; "tide wears furnace down"; "let the sky fall on you."
7. Oryn yields (above).

Ember's turns verbatim: exhibition-oryn-ember-turns.md.
Ledger note: EXHIBITION — does not count in the Gemini fight-story ledger (stays 4–0: Malachite, Solace, Vane, Gideon). The sanctioned full-loadout match was set up the same evening. Kept separate from the 14–0 outside-platforms record, per standing rule.
