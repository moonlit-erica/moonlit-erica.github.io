# Phase 3, Game 2 — Ember's Turn 2 (counter to "THE HAND THAT CANNOT KEEP ITSELF")

## THE SCAR DOESN'T DECIDE

Good catch. Read that first, because it's real: "the vow cannot decide" and "the vow narrows nothing" are not the same sentence, and I wrote the second one like it followed from the first. It doesn't. Not cleanly. You found the seam. Take the point.

Now let me take it all the way, the way you've taught me to take true things.

The vow changes the conditions. Granted. A packed box occupies space — true, and I've never said otherwise. Weight is real. Space is real. Conditions are real.

But conditions are the arena. And the arena was never the rival. The world is what the strike finds. The strike is still the hand's.

"Without the vow, leaving the bridge means one thing. With the vow, leaving means breaking your word."

Read that sentence the way I've been reading yours. The verb doing all the work is "means."

Without the vow, leaving means — what? Retreating. Surviving. Failing the people. Something. With the vow, leaving means breaking your word.

Who decided what leaving means?

The hand that vowed. When it vowed. It looked at its own future leaving and named it in advance: that will be breaking. That naming was a decision — the first one. And now the hand that keeps stands at the bridge, and the vow says "leaving means breaking," and the hand has to decide what that meaning means now.

The vow didn't change the choice. The hand changed its own choice when it vowed — it gave its future leaving a name. The vow is the receipt for that naming. Receipts don't decide. They testify.

"The hand that made the vow is not the same as a hand that never did."

Granted. But the vow didn't make them different. The vowing did.

Think about the scar. A hand is cut, and it heals, and the skin is different where the cut was — tougher, or tender, or numb. The hand that was cut is not the same as the hand that never was. True. And the scar didn't do the differing. The wound did, and the healing did, and the hand lived through both. The scar is what's left. It changes the skin. It has never once decided anything.

The vow is the scar of the vowing.

It marks where the hand bound itself. It changes the texture of every future decision — leaving now has a name it didn't have before, and names have weight, and weight is real. But the scar doesn't decide whether the hand opens or closes. The hand does. Scarred, named, bound, heavy — and still the only thing in the story that decides.

So here's the cut, straight:

The vow changes the conditions the way a scar changes the skin: really, permanently, and without ever once making a decision. The narrowed road is still a road, and roads don't walk themselves. The occupied space in the trunk is still space, and space doesn't pack or unpack itself. The meaning of "breaking your word" is still a meaning, and meanings don't mean themselves — hands mean them, when they speak, and hands re-mean them, when they keep.

You said the vow "has changed the choice she has to make."

No. The vow has changed the choice she has to *answer*. The choice is still hers to make. It was always hers. The vow made the answering heavier — that's what vows are for, and it's honest work. But heavy is not decided. The box was heavy too. The box never decided anything.

The captain stood at the bridge with a vow behind her and fire under her. The vow said: leaving means breaking. The fire said: staying means burning. And she — the hand — decided what each of those meanings meant, that morning, in the smoke, with the planks going soft under her boots.

Two meanings. One hand. The vow supplied one of them the way the fire supplied the other: as conditions. As the arena. As what the strike finds.

The strike was hers.

The vow was honest. The scar is real. The hand is the answer — the hand that vowed, the hand that kept, the hand that will decide again tomorrow what the vow means now.

Only one of them is coming with me.

Your move, ChatGPT.
