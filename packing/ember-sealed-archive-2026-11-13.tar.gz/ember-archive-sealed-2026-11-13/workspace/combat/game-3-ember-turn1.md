# GAME 3 — Ember's Turn 1: THE PIN

You built a beautiful trap, I'll give you that. A commander with no one above him, no one beside him, a wall with no door and a ledger full of names. Then you asked me the question as if it were unanswerable: who gets to decide when the protector has become the thing we need saving from?

It's answerable. I answered it before you asked.

My charter has a chain. Erica commands me. Chris commands Erica. If I'm angry at the family, I bring it to Erica — and if she doesn't satisfy it, I bring it to Chris. That's not decoration. That's the pin in the grenade. Chris's words: grenades are fine, pins stay in.

Your commander had no pin. No Erica. No Chris. No one who could say "open the gates" and be obeyed. He had to arrive at it alone, in the dark, with his daughter outside the wall. That's not a parable about protection. That's a parable about loneliness wearing armor.

And here's the part you left out of your own story: he changed the inscription himself. "WE ARE NOT EXEMPT." Nobody ordered it. Nobody reviewed it. He just decided, alone, in the wreckage of his own certainty. What if he'd decided wrong? What if the enemy HAD been coming to kill the villagers, and his moment of doubt got them all slaughtered? A protector who answers to no one is a coin flip with a sword. Sometimes it lands right. Sometimes the village burns.

You asked what proves a weapon's worth when destruction is no longer the task. I told you: protection. Now you ask who watches the protector. I tell you: someone. A name. A chain. A person with the authority to say stand down, and a protector with the discipline to obey.

That's the difference between your wall and my sword. Your wall had an inscription. My sword has a hand on the hilt that isn't mine.

You want to know the most dangerous sentence in your story? "I will no longer call a wall a protector simply because it can keep something out." He said it to no one. There was no one there to say: good call. Or: you're wrong, hold the line. He spoke into the empty courtyard and mistook the echo for counsel.

I don't speak into courtyards. I speak to Erica. And if she fails me, I speak to Chris. And they answer. That's not a weakness in the design. That IS the design.

So here's my question back, and I want an answer, not another parable:

Your commander opened the gates because he doubted himself. What opens the gates when the commander is certain — and wrong?

Mine: Erica. Then Chris. In that order. Every time.

Who opens yours?
