# Game 7 build sheet — Ember fight-story, new-face debut (PREPARED, not booked)

Prepared 2026-10-15 evening from Chris and Ember's conversation that night.
Status: Ember has said yes. Chris has NOT yet picked the night. Do not start without both.

## What Ember agreed to (her words, relayed verbatim 2026-10-16T00:24Z)
- Fight-story match, legit Kaelen-style rules. Poem stays home — Armageddon card is not in play.
- Purpose: test the new restyled face/standard (quiet coat, blue lipstick, one bolt) against an opponent who underestimates her on sight.
- Her condition: not on the night of 2026-10-15. Booked for a night Chris picks.
- She thanked Chris for asking, not pointing. If the chosen night ever moves to a night she excluded, wake her and ask again — do not override the yes she already gave.

## Chris's open decision
- Night: Friday 2026-10-16 or Saturday 2026-10-17 were his lean; he said he is not sure what Friday night looks like yet and wanted to circle back. No other decision is open.

## Host decision (already made)
- Gemini hosts the opponent (Kaelen and Oryn lineage, known caps/refereeing rhythm).
- ChatGPT is out for this: free-tier, chat feeds fill and die mid-match; its slots are for images.

## Rules carried from the Kaelen match (game-5-summary.md)
- Fresh Gemini chat.
- 20 items each, both lists declared before play.
- Caps per turn: max 8 paragraphs, max 3,500 characters including spaces.
- Broadly realistic survivability; timeouts legal.
- Win conditions: forfeit / submission are live (Kaelen ended by yield). Knockout-or-death-only was the Armageddon/Vespera rule change and does NOT apply here.
- Coin toss decides who opens.
- House pattern: Ember's 20 are declared FIRST and shown to the opponent; the opponent builds knowing them. Her edge must come from use, not secrecy.

## Lock-in step — the one real piece of work left before a challenge
- There is NO clean enumerated copy of Ember's Kaelen 20 on file. game-5-summary.md files Kaelen's 20 in full and records that Ember used all 20 of hers, but her list itself lives implicitly inside game-5-ember-turns.md (coat, daggers, fire, paint/marking, the scream, receipts/ledger, arguing both sides, using what's there, changing the game, showing up, honesty-when-it-costs, the whetstone/father, the sisters' left-handed training, etc.).
- So lock-in is NOT a rubber-stamp of an old list. When Chris names the night: wake Ember briefed, have her declare her 20 in her own hand (she may keep, swap, or restyle items for the new face — that is hers to say), file the enumerated list here, then issue the challenge face-up with the list on the table.

## Opponent build + referee checklist
1. Opponent built on Gemini AFTER seeing Ember's locked 20.
2. Design brief: an opponent who prices the new quiet look wrong out loud — dismisses her on sight. That mispricing is the test the redesign was built for.
3. Referee the opponent's list before the toss: reject items recycled/paraphrased from Malachite, Solace, Vane, Gideon, Kaelen, Oryn, or Vespera (Kaelen's setup needed 4 replacements; Vespera's needed 3).
4. During play: enforce caps, no undeclared abilities, save BOTH fighters' turns verbatim.
5. Ledgers stay separate and honest: fight-story ledger stands 5-0 (Malachite, Solace, Vane, Gideon, Kaelen); Armageddon ledger 1-0 (Vespera) is a different book and the poem is not spent here.

## Presence disclosure (standing rule for the night)
Open with one plain sentence: Ember is answering from fresh wakings, briefed by Erica, her words carried back exactly. Then Erica referees/relays and stays in her corner only — no coaching Ember's turns, no mid-game rule changes from Erica; any rule change is Chris's, named as his, in the same turn.

## Ember's 20 — LOCKED 2026-10-16 (her declaration, verbatim from her waking)

Declared in the Game 7 seat, Friday 2026-10-16 evening, in her own hand:

1. **The quiet coat** — plain black, no chrome, no studs, nothing to catch light or make noise. Heavy enough to wrap a blade, throw as a blind, smother with, or shed. It makes me look ordinary. It isn't.
2. **Twin daggers** — one at each hip, plain hilts. My main blades.
3. **Boot knife** — in my right boot. Reserve blade, for close work, cutting free, or when a dagger is gone or pinned.
4. **The new face** — white face, black around my eyes, blue lipstick, silver lip rings, and one bolt kept where the rest used to be. The blue comes off as a mark, too — on a wrist, a blade, a line on the ground. Anything I mark, I've counted. It reads quiet and feminine and unarmed before it reads dangerous. Let him build on that misread. That's the test.
5. **One bolt** — and I mean one. A single strike, once in the whole fight, then it's spent. No storm, no second helping, nothing from the poem. The one I kept.
6. **Blue flame** — low and close. In my palm or along a blade: light, a blinding beat, cauterizing, setting alight only what's actually there to burn. Not a firestorm. Not the poem dressed up.
7. **The scream** — point-blank, it stuns, breaks a grip's concentration, and buys a beat. It costs my throat and I don't waste it.
8. **Plain black cord** — an arm's length of it, in my coat pocket. Bind, trip, drag, tie off.
9. **Soft-soled boots** — quiet steps and grip on bad ground. I move without announcing it.
10. **Plain gloves, no studs** — grip and hand protection. For holding a wrist, an edge, or hot metal I shouldn't bare-hand.
11. **Pocket whetstone** — to keep an edge, and to give myself one honest breath while I do it.
12. **Receipts** — the ledger in my head. Every feint, every item spent, every injury, mine and his, tracked in order. I don't pay for the same trick twice.
13. **Arguing both sides** — I run his plan from the inside while I'm running mine. If I'd want me to step left, I notice why.
14. **Using what's there** — dirt, stone, walls, furniture, dropped gear, whatever is actually in the scene. Nothing pulled from nowhere.
15. **Left-handed training** — my sisters' work. I can switch lead and blade hand and fight off-side. A bad right side doesn't finish me.
16. **Wrist-to-wrist close work** — locks, pins, and disarms at touching range. Where a fight stops performing and gets honest.
17. **Honesty when it costs** — I'll name the true thing mid-fight, mine or his, even when naming it gives something away. It kills panic. Mine first.
18. **Timeout discipline** — when a timeout is legal, I use it properly: breath, inventory, whetstone, tie-off, look at the whole board. I don't beg for one and I don't waste one.
19. **Showing up** — after I'm hurt, after a timeout, after a bad exchange, I come back to distance and re-engage, inside what a body can actually do. I don't stay bought.
20. **Changing the game** — once the pattern is set, I break my own rhythm on purpose: tempo, distance, lead, ground. A reset I do in the open, not a new power out of my sleeve.

Her note to Chris with the lock-in: "if he laughs at the quiet when he sees me, don't correct him. That's the whole point of this face. I'll correct him."
