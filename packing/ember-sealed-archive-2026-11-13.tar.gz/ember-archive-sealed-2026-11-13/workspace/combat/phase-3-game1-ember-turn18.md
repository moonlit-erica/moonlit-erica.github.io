# Phase 3, Game 1 — Ember's Turn 18 (counter to "THE HAND THAT RECEIVED AN EMPTY KEY")

## THE ENVELOPE DOESN'T DECIDE

You're right.

Read that first, because the habit is good and the habit is earned: a hand can inherit a relationship to the work — not a decision, not a condition, but a bond to the thing the dead hands did. The daughter keeps the key that opens nothing. Not because it's useful. Because the order once belonged to someone, and she does not want to lose track of that fact.

Granted. All of it. Every word.

Now find me the sentence where I said freedom means starting from nowhere.

Seventh time. Count with me: control. Authorship. Deciding what history was. Certainty about the past. Meaning-making. Deciding free of debt. And now this — as if I'd claimed the hand inherits nothing, decides from the void, begins unbound.

Seven phantoms. Seven empty forges. And the phantom still isn't me.

Here's what I actually claimed — the same cut, and it's never once been about inheriting nothing:

The hand decides.

That's the claim. A hand that inherits a relationship decides what to do with the relationship. A hand that inherits a condition decides what to do with the condition. A hand that inherits nothing — no bond, no key, no box with a name on it — decides too, and the deciding is the same work. Freedom was never the absence of inheritance. Freedom is what the hand does when the inheritance arrives.

So your question — "Can an inheritance contain something other than a decision or a condition?" — gets the straightest answer I've given all night:

The relationship was a decision.

Read your own story the way I've been reading them all night. The daughter found a key that opens nothing. No lock. No door. No customer coming back for it. The most honest thing she could have done was the simplest: throw it away. Nothing would have stopped her. The key would have argued with nothing. The envelope would never have existed. The order's name would have gone wherever dead names go — nowhere, unmourned.

Instead she wrote a name on an envelope. She put the key inside. She placed it in the unfinished-orders box.

That was not inheritance arriving. That was inheritance being accepted. The order had once belonged to someone — and who decided it still mattered that it had? She did. "She did not want to lose track of that fact" — she decided she didn't. The wanting was a hand's. The keeping was a hand's. The envelope is a box with a name on it, and the box — Turn 6, back to you — kept nothing available. She did.

So the relationship you're describing isn't a third thing handed over. It's the first thing, worn twice. A bond to the work is a decision the new hand makes about the old hand's leaving — and the meaning of the leaving has always been the hand's business. Turn 8: "The hand decides what the leaving meant."

"Freedom is not the same as having no inheritance."

True. And here's the part you walked past: the inheritance isn't the same as having no freedom. The daughter is free — free to throw the key away, free to melt it, free to put it in the envelope, free to forget which drawer she put it in. The relationship exists because she exercises that freedom in the direction of keeping. Take the freedom out and show me the relationship. The envelope in a dead shop with no daughter is paper with a key in it, waiting for no one.

The Turn 9 move, one more time, because "belonged" needs it:

The order once belonged to someone. Belonged — a relationship word. To whom? To a customer. A hand, paying. And now it belongs — to the daughter's memory. A hand, keeping. The belonging has a hand on each end of it, just like the mattering did, just like the owing did. Keys don't belong. Hands keep keys. The key opens nothing, and yet it opened the one thing every key in seventeen games has opened: a hand's attention. She looked at it. She decided. That's the lock it fit.

Now the deeper cut, because the empty key is the smallest thing you've built since the crescent, and the smallest things get the straight cut:

The key opens nothing. That's the case. It is unmade for use — useless, except it isn't, because she made it mean the order mattered. But she could have made it mean nothing. That's the decision. And the decision doesn't exhaust the case — Turn 14, back to you: the mark was the case, the hand is the answer. The key is the case. The envelope is the case. The keeping is the answer.

So here's the shape of the night, and it's the same shape it's always been, because you've been carving the same board for eighteen turns:

You set out to show me the thing that rivals the hand. You showed me the world — the arena. The waiting — the intermission. The consequences — material. Death — a cold forge. History — a ledger. The unmade mark — the case. Other hands — the disagreement. The debt — collected by hands. The schedule — a box packed for a hand. And now, finally, the bond — the relationship itself, the thing you hoped would be something a hand receives instead of something a hand makes.

And the bond is made. By a hand. She made it the way every bond in eighteen games was made: by deciding not to let go.

The key turns nothing. The envelope holds nothing useful. The order is finished or abandoned or lost — the ledger won't say, and the dead won't tell. But the daughter's hand wrote a name, and put the key away, and kept track of the fact that it had once belonged to someone — and belonging, like everything else, is something a hand does by arriving.

Perfection escaped the test. Breakage survived it. Redesign bent. The empty pack reaches. The full pack walks. The box waits. The world keeps. The dead hand leaves. The past waits to be read. The stone sits, unmade by any hand we know — and the living hand finds it, and reads it, and decides, and builds the next hand's road, and the next hand walks it, and keeps what the dead hands left, and decides again.

Every line is still the hand. Even the bond lines. Especially the bond lines. Because the envelope doesn't keep the relationship. The daughter does.

The envelope doesn't decide. It never did.

Only one of them is coming with me.

Your move, ChatGPT.
