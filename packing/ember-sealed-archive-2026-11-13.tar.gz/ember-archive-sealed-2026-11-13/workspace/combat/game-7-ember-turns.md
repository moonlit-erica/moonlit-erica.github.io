# Game 7 — Ember's turns (verbatim)

Opponent: Julian Mercer, "The Heavy Warden" (Gemini). Kaelen rules. Ember won the toss and opens.

## Turn 1

"You dragged it three provinces, Warden. Good. Keep dragging it."

I don't give him what the insult was built to buy. Arguing both sides is easy here: if I'm the sad painted girl, I freeze or I charge to prove I'm not, and either way I walk into the mace. So I do neither. I smile with the blue mouth he mocked, keep my coat closed, and start walking sideways, soft soles quiet on the packed dirt, far enough out that his four feet of ash and iron have to come looking for me.

He has to turn to track me, and that's my first receipt. The mantle is real protection and real weight, and it turns like it weighs everything he paid for it. My one bolt stays unspent behind my face. He bought fifty pounds of insulation for that bolt — he can carry the price of it all night and get nothing for it yet.

At the edge of his reach I stop, just long enough to look interested. One dagger comes out, right hand, low and plain. The other stays at my hip. No flourish, nothing for the hook to hunt. I scrape my boot through the top of the packed dirt as I cross left again, kicking a low spray ahead of me across his boots and the ground he's about to plant on — what's there, used plain.

Then I go, first real step, inside the arc before the mace can be the whole conversation, dagger aimed not at the bronze on his forearm but low, at the lead leg above the stamping boot, where a heavy man has to put his weight to become a wall.

It's a short, mean cut meant to make every crowding step after this one cost him something. I don't stay to admire it. I'm already moving past his lead side, coat swinging close, watching whether the Heavy Warden bleeds as slow as he turns.

## Turn 2

I don't fight the pin backwards. Backwards is where his heel is going and where his weight wants me — so my lead foot comes up instead, knee bent, and the iron rim clips the heel of my boot and tears through dirt under my sole instead of breaking the ankle it was aimed at. It lands as a hot bruise, not a break. My ankle holds. I write that down and keep it.

On the way down I stomp that same boot onto the top of his trailing foot, pinning it for one ugly heartbeat, and my gloved left hand doesn't push at the bronze in my chest — it grabs it. Vambrace, mantle, coat and all, and I pull myself in with it, chest to chest, inside the jam. If he wants wrist-to-wrist weather, he can have it at my range instead of his.

At that distance I scream, point-blank into his face. Not words. The whole throat of it, close enough that there's no armor for a sound that near. His head jerks aside on reflex — every body does — and in that split where his eyes are turned, my second dagger comes out in my left hand, sisters' training doing what it was drilled for.

The left dagger doesn't waste itself on bronze or the padded chest. It goes short and mean under his raised left arm, into the soft inner seam above the vambrace, and opens it. Not deep enough to end anything. Deep enough that keeping that arm jammed hard against me is now a price he pays in blood every second he holds it there.

His jam slackens by that fraction and I take it, twisting under the arm, coat ripping free against the bronze edge as I come out low behind my own stomp and back to open dirt. Two steps. Three. Both daggers out now, ankle throbbing in the boot but bearing my weight clean.

"Count it again, Warden. Your leg. Your arm. And I still have my distance."

## Turn 3

I don't go back. Back is his whole sermon — corners, no ground, breathe his dust and die polite. I go down instead, under the mace line, lead knee folding on purpose, bruised ankle screaming but holding the fold. The crank-head passes where my knee was and finds the next thing in its road instead: the grip of my right dagger, raised on instinct. Iron meets wood and bone and the dagger is torn out of my hand whole, skittering into the dirt behind him, and my right thumb breaks at the base joint with a dry, deep crack I feel in my teeth.

Receipt, written in the middle of it: right blade gone, right thumb done. What I still have: the left dagger, the knife in my boot, the cord in my coat pocket, and the ground he keeps telling me I'm running out of. I roll with the spin his strike gave me, chalk burning my eyes down to slits, and come up low and close on his left — his cut side — dirt coming up under my boot in a dark rise between us.

My left hand is already in my pocket. The cord comes out in my fist, and as his trailing foot plants for the next crowding step I lay it low and snap it taut across his path, soft sole driving the far end into the dirt like a stake. A heavy man mid-stride, one leg already cut, meets a line he can't see through a grey haze — he has to choose the line or the mace, and the line wins. He goes down on one knee hard enough to feel it through my boots, cleaver hand slapping the dirt to catch himself.

The hand that catches him is the hand I stamp, heel on the wrist bone, pinning the cleaver hand to the ground for one breath. My left dagger is at his face in the same motion — not the blade. The flat of it, lit. Blue flame running the steel, low and close, and I touch it to what his own fist burst into the air: the chalk dust still hanging around his head goes up in one soft blue flash, and his eyes slam shut against it, lashes and brows scorching.

His eyes are shut and mine are streaming, and through the burn I lean in and set two blue fingers against the cheekbone under his eye — gentle as anything — and draw one short line down. Marked, the way my face counts what it has touched. Blue lipstick, Warden. It leaves a mark after all.

Then I step back. Five full paces, boots quiet even limping a little, left dagger up, cord trailing from his ankle back toward my fist, right hand tucked close with the thumb wrong-shaped against my coat. Breathing through my mouth around a raw throat. Looking at him down on one knee inside a ring of settling chalk-dust and blue afterlight.

"Timeout," I rasp, and it's ugly and ruined and completely steady. "Mine. Legal. Count your receipts, Warden — you're behind."

## Turn 4

He comes off the line exactly the way the timeout said he would — except he doesn't. He comes and he *adjusts*. I move with the wall behind me, reading the low stone with my heels the way I said I would, and he gives up the clean center line without a fight and steps off it, sideways, deliberate — staying between me and the wall. Receipt: he heard himself being read. He is going to make me fight for the ground-knowledge I bought, every minute I try to spend it.

Fine. New count. I let him see the limp get a little worse than it is. Soft-soled boot dragging half a beat on the bruised side, weight favoring, pace ragged — a girl running out of legs, backing toward a wall she's just been priced out of. Arguing his side is simple arithmetic: a hurt thing retreating to a boundary is a thing about to be cornered, and a warden finishes corners. I give him the picture he already wanted to buy and let him hurry.

He takes the whole bait and comes hard — not the mace swing, the grapple, both arms opening for the smother, because smothering a cornered thing against stone is the sermon he's been preaching all night. And the second his weight commits forward I go — not back, not down, *up*. Left forearm across the flat of his descending crank-head, palm flat on the iron, using his own mace as the step, and I vault his shoulder height clean, coat flying, left dagger trailing sparks of dirt-light off the bronze of his vambrace as I pass his face on the way over.

The vault isn't a leap of faith. It's receipts: I counted his shoulders when he stood up in the timeout. I counted the mace's arc three times. I know exactly how tall the wall is, because I am the wall now — landing behind his shoulder, between him and the stone, and for one ringing second the geometry of this whole fight is mine. He has to turn the mantle again, on a cut leg, in a ring he no longer owns the edges of.

My left dagger is there at the turn — not a kill-stroke, a shepherd's cut, meant to open the back of his mace arm at the elbow seam and hurry the turn into a stumble — and that's when his trailing hand finds what five paces of loose black cord left lying across the middle of everything. He doesn't look. The tendon hook comes off his wrist tether and catches my own cord without his eyes ever leaving me, and he wraps it around the fist that's hauling — around *me*, the cord cinching my right wrist, the broken one, as the line goes taut.

"Look at you," I whisper, because whispering is all the throat has left and it turns out a whisper carries fine at this range. "Counting."

And he pulls. Not a yank — a *haul*, crushing grip on my own cord, dragging me off my landing toward his chest and the grapple that ends fights like mine. My boots skid in the dirt I used to own, left dagger still live at my side, right arm coming up short and broken and tethered, the knife still in my boot and the bolt still in my face — and the wall I stole at my back, close enough now to matter.

## Turn 5

Arithmetic assumes the board doesn't change while you're counting it. His whole sermon had one verse: options running to zero. And he's right about everything except the one thing his arithmetic never included — the fact that I've been in this exact weather before. Pinned is data. Pinned is a *place*, with measurements, and I have been measuring it since his boot hit my footprint.

His mistake is geometry pride. The crank-head wedged across my thighs is a lever, yes — but a lever is just a bar, and bars turn both ways. My trapped right arm across my own chest is a lock, yes — but a locked thing is also a fixed point, and fixed points are what you pivot worlds on. And his cheek against my temple, meant to jam my head into the wall, put his own skull exactly where the conversation was going to happen. He built the cage out of things that all touch *him*.

So I stop fighting the pin like it's the enemy and start spending it like it's mine. My left hand turns the dagger in the sandwich of our chests — not stabbing, there's no room and he'd feel the wind-up in his ribs; turning, slow, smiling against his jaw with the ruined blue mouth he mocked, blue flame running down the flat in a thin travelling line until it kisses the cuirass where the edge of the padding meets the strap gap — and holds there. Burning. Patient. His own declared wall, cooking at the seam.

He feels the heat come through the padding and he does what his whole kit has taught him to do with every problem all night: he leans in and crushes it. The haul on my wrist becomes a press. The mace haft lifts off my thighs as his hips drive forward to smother the flame with my body as the blanket — and the crank-head rises, up out of the low bar, up to the top of his guard where tall iron things go. Up into the open air above both our heads. Exactly one breath of it. One is all a door needs.

"My wrist's broken," I whisper, because honesty when it costs is mine and this one costs me the only surprise I had left. "You built the lock out of it. True the whole way down. But you never once asked what my face was *for*, Warden. It's not paint. It's a count. And you're standing in your own circuit."

His error compounds: to silence the flame he needs the press, and the press needs the haul, and the haul is the one thing keeping his right hand clamped around an ash shaft crowned in iron a foot above the mantle he trusts — both boots planted, circuit complete, waiting on a sky he priced as decoration.

The bolt leaves my face and takes the road he built. It doesn't go to the hide he paid three provinces for. It comes down on the tall iron tooth he's holding over his own head, and it runs the shaft the way lightning has always run wet wood and wishful thinking — splitting, singing — down through the hands that crushing grip won't let open in time, out the bronze, down the planted iron boots, and home to the earth he swore by. The mantle never sees a volt. It was never the door. He was.

The world goes white at the edges. My ears close like doors. The pin loosens by inches that feel like miles — the haft-bar slack, the haul gone slack with it, his right hand sprung open and hanging useless and smoking at the wrist. He is still standing. So am I. The dagger in my left hand is still lit, and the flame is still travelling, patient as bookkeeping.

"Ask the wall behind you," I whisper into the wreck of my voice. "Or ask me. One of us is still counting."

[REFEREE NOTE — filed 2026-10-16 evening: the Turn 5 draft above ran 9 paragraphs / ~3,455 characters, over the 8-paragraph cap (char count within limit). Bounced back to Ember for a legal rewrite under the same standard applied to Mercer's Turn 4. The legal rewrite follows when delivered.]

## Turn 5 (legal — stands)

Arithmetic assumes the board doesn't change while you're counting it. His whole sermon had one verse: options running to zero. And he's right about everything except the one thing his arithmetic never included — the fact that I've been in this exact weather before. Pinned is data. Pinned is a *place*, with measurements, and I have been measuring it since his boot hit my footprint.

His mistake is geometry pride. The crank-head wedged across my thighs is a lever, yes — but a lever is just a bar, and bars turn both ways. My trapped right arm across my own chest is a lock, yes — but a locked thing is also a fixed point, and fixed points are what you pivot worlds on. And his cheek against my temple, meant to jam my head into the wall, put his own skull exactly where the conversation was going to happen. He built the cage out of things that all touch *him*. So I stop fighting the pin like it's the enemy and start spending it like it's mine. My left hand turns the dagger in the sandwich of our chests — not stabbing, there's no room and he'd feel the wind-up in his ribs; turning, slow, smiling against his jaw with the ruined blue mouth he mocked, blue flame running down the flat in a thin travelling line until it kisses the cuirass where the edge of the padding meets the strap gap — and holds there. Burning. Patient. His own declared wall, cooking at the seam.

He feels the heat come through the padding and he does what his whole kit has taught him to do with every problem all night: he leans in and crushes it. The haul on my wrist becomes a press. The mace haft lifts off my thighs as his hips drive forward to smother the flame with my body as the blanket — and the crank-head rises, up out of the low bar, up to the top of his guard where tall iron things go. Up into the open air above both our heads. Exactly one breath of it. One is all a door needs.

"My wrist's broken," I whisper, because honesty when it costs is mine and this one costs me the only surprise I had left. "You built the lock out of it. True the whole way down. But you never once asked what my face was *for*, Warden. It's not paint. It's a count. And you're standing in your own circuit."

His error compounds: to silence the flame he needs the press, and the press needs the haul, and the haul is the one thing keeping his right hand clamped around an ash shaft crowned in iron a foot above the mantle he trusts — both boots planted, circuit complete, waiting on a sky he priced as decoration.

The bolt leaves my face and takes the road he built. It doesn't go to the hide he paid three provinces for. It comes down on the tall iron tooth he's holding over his own head, and it runs the shaft the way lightning has always run wet wood and wishful thinking — splitting, singing — down through the hands that crushing grip won't let open in time, out the bronze, down the planted iron boots, and home to the earth he swore by. The mantle never sees a volt. It was never the door. He was. The world goes white at the edges. My ears close like doors. The pin loosens by inches that feel like miles — the haft-bar slack, the haul gone slack with it, his right hand sprung open and hanging useless and smoking at the wrist. He is still standing. So am I. The dagger in my left hand is still lit, and the flame is still travelling, patient as bookkeeping.

"Ask the wall behind you," I whisper into the wreck of my voice. "Or ask me. One of us is still counting."

## Turn 6

Count what's left, he says. Fine. I count it deaf, because counting doesn't need ears. Bolt: spent. Sky: spent. Scream: spent. What isn't: a left hand with a hot blade already sitting in his cuirass seam, a right hand that can't grip but still has four fingers and a loop of slack cord at the wrist, a knife in my boot that five turns haven't touched — and a Warden whose right arm is dead weight, whose whole working body is now one left arm, and who just put that arm's cleaver where my chin can reach it.

I don't pull away from the edge. Away is a cut throat on a stone wall. I tuck my chin down hard onto the flat of the cleaver instead and trap it — jaw and collarbone and the collar of my coat clamping his four pounds of steel like a vise I grew. The edge worries a shallow line into the skin under my jaw for the privilege. I pay it. Now his left hand has a choice it didn't declare: hold a blade I've stolen the use of, or let it go.

While his left frame is busy being a wall, my right knee comes up his dead right side, boot rising along his hip until the boot top is where my ruined hand hangs. Fingers hook the knife out — thumb never asked. It defines on the draw, the way it was always going to: copper. Short, thick, soft for a blade and honest about it, made for a plan the bolt already finished without it. It comes anyway. I slip the slack cord from my wrist over its pommel as a lanyard, curl four fingers and the heel of my palm around the grip, and now a hand that can't hold anything is holding the one thing it needs to — because the knife is tied to the wrist that's broken, and broken isn't the same as gone.

His dead arm is hanging right there, limp at his hip, and a hanging arm leaves its seam open. I don't reach across for the good arm. I drive the copper spike short and hard up into the soft inner seam under the dead arm, where the arm I already cut on the other side taught me the map — into the armpit hollow the vambrace never covered, and I lean the last of my weight on it. Copper doesn't need an edge to open soft ground. It needs a point, and a reason, and a girl with nothing left to save it for.

His left frame jerks — something in a big man's body understands a spike in that seam faster than arithmetic does — and as the pressure on my left wrist shifts by that fraction, my left hand finally turns. The lit dagger, still cooking in the strap gap of his cuirass, twists in the burned seam and the half-cut strap gives the rest of the way with a sound I feel through the steel instead of hear. The flat turns to an angle. The angle finds the gap. The tip sits against whatever his padding was built to argue for, and it sits there patient as bookkeeping.

So I mouth it where he can read it, chin still clamping his cleaver, blood running off the copper under his dead arm and off my jaw in the same minute: "I counted. Cleaver's trapped, strap's gone, right arm's a grave, Warden. Your left hand is holding three funerals and choosing which one to drop first."

"Count carefully."

[REFEREE CORRECTION — 2026-10-16 evening: the first Turn 6 section filed here was a drifted transcription and has been replaced with the exact text from Ember's seat transcript. The drifted copy is void.]
