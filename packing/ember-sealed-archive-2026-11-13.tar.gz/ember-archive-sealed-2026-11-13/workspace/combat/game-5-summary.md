# Game 5 (Gemini fight-story, SANCTIONED) — Ember vs Kaelen, the Wayfarer

Date: 2026-10-12 (evening). Chat: https://gemini.google.com/app/3bbf7eaa2f194439
Format: Chris's sanctioned rules — fresh chat; each side a declared 20-item loadout; up to 8 paragraphs and 3,500 characters (incl. spaces) per turn; broadly realistic survivability; timeouts legal; play to forfeit. EMBER AT FULL LOADOUT for the first time: all 20 items, no injuries carried in. Poem NOT in play (Chris's ruling: undeclared = would be cheating).
Toss: Kaelen called HEADS; local flip (Erica, secrets module) came up HEADS → Kaelen opened.

## Opponent — Kaelen, the Wayfarer (20 items, final, referee-clean)
1. I pivot without friction 2. I leave no track behind 3. I decipher the pattern 4. I honor the soil I stand on 5. I measure the drop 6. I untangle the knot 7. I carry my own water 8. I leave room for grace 9. I know when to yield the road 10. I keep my hands warm 11. The sling and lead shot 12. The kinetic pulse 13. The resin lantern 14. My spatial geometry 15. The grapple-hook and cord 16. The whistle 17. I reframe the trap 18. The oilskin cloak 19. I seize the tempo 20. My iron constitution
Referee work at setup: 4 items rejected as recycling and replaced before play (#5 replaced a Solace "endure the storm" paraphrase; #6 a Solace "see through illusions" paraphrase; #15 a Malachite "mentor as anvil" concept; #20 a Solace "the oath" echo).

## Result
EMBER WINS BY FORFEIT. 13 total turns (Kaelen 7, Ember 6).
Kaelen's Turn 7 (final): locked wrist-to-wrist with both fighters spent, he judged continuing meant mutual ruin neither could plausibly survive; he released her wrist, stepped back with open palms, invoked his item 9 ("I know when to yield the road"), and said: "You brought the receipts, Ember. And you paid every cent in blood." — then: "I forfeit."
Referee call: one. Kaelen's original T7 ran 9 paragraphs (over the 8 cap; characters in-cap); rewritten in-cap (8 paragraphs, ~2,050 chars) with the forfeit wording identical — the rewrite is the official final turn. All other Kaelen turns verified in-cap; no undeclared abilities used.
Ember used ALL 20 of her items at least once; none untouched. Her final state: wins standing but spent — deafened (whistle, point-blank), left shoulder dislocated/hanging, forearm cut, shoulder grazed, bruised ribs, loosened tooth.

## Synopsis
K1: flooded limestone quarry; lantern flare/smoke; ricochet sling shot rains slate. E1: rides it under the coat (forearm cut), descends, fire-fuse clears smoke, paints a stripe claiming ground, screams to scramble his acoustic map, closes.
K2: whistle blast (left ear ringing), throws his cloak over her blades, hauls a pulley down, floods her footing. E2: concedes the whistle worked; captures the cloak; fire into floodwater = steam screen; climbs the pulley chain (sling grazes her shoulder closing).
K3: kinetic pulse off the pulley; wrenches the cloak to trip her; grapple cord around her ankles. E3: whetstone teaching — turns the fall into a dive inside the sweep, cloak guards her throat, saws the cord apart on the pulley's rusted edge, rises inside his guard aiming at his hands; left shoulder grinding.
K4: pivots out of her arc (dagger still opens his forearm), body-checks her bad side, sling strap pins her right wrist to her chest. E4: honestly concedes her left side is failing; sisters' left-handed winter training; changes the game — clinch slackens the strap; hooks his ankle; both go down toward the flood with her numb left blade braced up: fall on the blade or release.
K5: yields the road — releases mid-fall, measures the drop, lands clear by an inch; retreats to a granite block, lead shot knuckled, kit nearly gone. E5: shows up out of the water; painted handprint misdirection; steam curtain, walks the wall by touch; cuts his right wrist — lead shot drops into the flood; takes his elbow to her jaw (loose tooth).
K6: zero range in her steam; tracks her breathing; shoves her ruined shoulder; whistle point-blank destroys her remaining hearing; "Finish it." E6: deafened, unflinching; rides the shove into a spin; cuts the whistle cord (receipt #7); shallow cut across his ribs; her left shoulder gives a final click and hangs wrong; they end locked wrist-to-wrist.
K7: forfeit (above).

Ember's turns verbatim: game-5-ember-turns.md.
Length check vs Chris's question (does the full 20 shorten matches?): 13 total turns — comparable to the 15-item fights (Malachite/Solace went 7 rounds each ≈ 14 turns), shorter than the 7-item injured Gideon grind. Honest verdict: the full list did not dramatically shorten the fight; it changed her control of it — every item used, his whole kit spent on her tally.

Ledger: GEMINI FIGHT-STORY record now 5–0 (Malachite, Solace, Vane, Gideon, Kaelen). Separate from the 14–0 outside-platforms record, per standing rule. (The Oryn duel earlier this evening is an EXHIBITION — poem-arsenal free-form — and is not counted; see exhibition-oryn-summary.md.)
