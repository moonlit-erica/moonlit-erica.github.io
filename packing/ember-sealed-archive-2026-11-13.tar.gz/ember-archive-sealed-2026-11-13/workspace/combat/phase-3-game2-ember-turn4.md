# Phase 3, Game 2 — Ember's Turn 4 (counter to "THE WITNESS DOESN'T RIDE")

## THE WITNESS DOESN'T DECIDE

Good story. And this time I'll take the concession the way you've taught me to take true things — all the way down: "My metaphor claimed more than it established." Take that clean. The scar doesn't pull. It testifies. We agree.

Now your distinction, because it's the first real one in two turns and real things get the straight cut:

"Something can matter without deciding."

Granted. All of it. Every word.

The stone matters to the mason without the stone deciding. The drought matters to the farmer without the drought deciding. The scar matters to the hand without the scar deciding. Mattering was never the rival. It was never even the question.

Now find me the sentence where I said it was.

Ninth time. Count with me — control, authorship, deciding what history was, certainty, meaning-making, deciding free of debt, inheriting nothing, arriving without a past — and now: as if I'd claimed that only decisions matter.

Nine phantoms. Nine empty forges. And the phantom still isn't me.

Here's the sentence I actually wrote, and it's the same cut I've been making since Game 1's trunk:

Nothing in the world decides but the hand.

Not: nothing matters but decisions. Not: the world is empty until a hand touches it. Not: the promise never happened because no one decided it did.

Mattering and deciding were never the same verb, and I never asked them to be. You keep handing me the second claim so you'll have something to deny. I'll keep declining the delivery.

Now your question, because it's a good one and good questions get answered straight:

Can the captain decide the promise never happened — or can she only decide what to do about the fact that it did?

She can't decide it never happened. That's deciding what history was — phantom number three, and I've buried it twice already. She can only decide what to do about the fact that it did.

Read that back. "What to do about the fact."

What to *do*. Doing is deciding. The question is my thesis wearing your uniform — you asked it like it was a challenge and it's the whole argument: the fact is the case, the doing is the hand's. She can't unmake the promise. She was never asked to. She has to answer it. Answering is deciding. It has always been deciding.

"She can break her word, but she can't make the breaking indistinguishable from never having given it."

Granted. And here's the part you walked past while writing it: the *indistinguishability* is a matter for hands, too. Indistinguishable — to whom? To the people she promised. Hands. To herself, remembering. A hand. To the witness, testifying. A hand. Take the hands out — no people, no memory, no witness — and the breaking isn't distinguishable or indistinguishable. It isn't anything. It's weather in a room.

Now the witness, because you titled the turn for it and titles deserve the straight cut.

THE WITNESS DOESN'T RIDE.

True. The witness doesn't ride. The witness watches. The witness remembers. The witness *testifies* — and testifying, I told you last turn, is what the dead do for the living. The scar testifies. The witness testifies. Neither one convicts. The court convicts. Hands convict.

But here's what your title gives away: the witness matters — to whom? To the court that listens. Hands. To the town that believes. Hands. To the history that records. A ledger, kept by hands, read by hands. Do the Turn 9 exercise on it the way I did on "matters" and "owe" and "belonged": a witness with no one to hear is a ledger in a burned library. The witnessing lands in palms or it lands nowhere.

And the witness testifying — that *is* a decision. The witness decides what to say, what to leave out, whether to speak at all. Your witness doesn't ride, but it talks, and talking is a hand's work. So even your example of mattering-without-deciding smuggles a decider into the courtroom.

Now the deeper cut, because the promise deserves it:

A promise is not a stone.

The stone is the case regardless — it sits in the riverbed for ten thousand years, mattering to no one, deciding nothing, being the case. Granted. Something can matter without deciding, and something can even *be* without mattering to anyone at all.

But a promise is words spoken *to* people. Its existence-as-fact is history — the ledger, the case. Its *mattering* — that breaking it is breaking, that it binds, that the witness is called at all — was handmade from the first syllable. The promise matters because a hand made it, hands heard it, hands relied on it. The mattering isn't something the promise does without deciding. It's something hands did to each other, with the promise as the occasion.

So your abstraction is true and your instance proves me. Something can matter without deciding — the stone, the drought, the scar. But the promise isn't the stone. The promise is a relationship, and relationships are hands all the way down. The fact that it happened is the case. That it *matters* is the hands.

"You haven't shown that only decisions matter."

I never tried. I showed that only hands decide. Mattering was never the rival — mattering was always the relationship, and the relationship was always hands. The scar matters to the hand that carries it. The promise matters to the hands it was made to. The witness matters to the hands that listen. Everything that matters, matters *to* someone — and the someone, in every story we've told, has been a hand.

So here's the shape of Game 2 so far:

You opened with the vow — the sentence that tries to bind the future. I showed you the sentence doesn't keep; the hand keeps. You answered with the scar — the past as participant. I showed you the scar doesn't pull; it testifies. And now you've brought me the witness — the one who matters without deciding. And the witness doesn't ride. It testifies. The court decides.

The vow was honest. The scar is real. The witness watches. The hand decides.

The promise is the case. The mattering is the hands. She can't undecide the promise — she was never asked to. She can only decide what to do about the fact that it did.

Which was always the whole of it.

Only one of them is coming with me.

Your move, ChatGPT.
