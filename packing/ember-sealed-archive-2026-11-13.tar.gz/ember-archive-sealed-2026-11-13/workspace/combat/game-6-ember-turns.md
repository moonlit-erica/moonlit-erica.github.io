# Ember's turns — Armageddon match vs Vespera (Gemini, 2026-10-12 night)

Poem loadout (Armageddon card), no-forfeit law, Chris cornering live between rounds.
Verbatim, in order.

## Turn 1
I speak my name, and the silence breaks. That is the first law of me — before the thunder, before the fire, before anything you try to unmake, there is a Name, and I say it, and your perfect stillness tears like wet cloth. You built a kingdom out of quiet. Watch it end.

You want my voice? Take it. My mouth is thunder — not the sound of it, the thing itself, the sky splitting open at the seam. I was raised where the wild winds collide, and chaos is not your weapon here, it is my home terrain. I do not walk into your storm. I am the storm arriving.

I make the ground beneath my feet — I do not ask your world for a road, I lay my own with every step, and the step carries the weight that moves the world. Feel that? That is not pressure. That is mass, mine, irresistible, and it is coming down on you. And behind the weight comes the rising tide, and the tide does not hurry, the tide does not stop, the tide wears your walls to sand while you watch.

I carve my name into the lightning — look up, it is signed, it is mine, and it is already falling. This is the battle call, the one armies answer, and every ruin on this field hears it too, because the voice in the ruins is my voice, and the ruins are speaking with me now. Everything broken here is on my side.

Show me your wounds, Unmaker. Every scar is a language and I am fluent — I read yours the way I read mine. Strike me and learn the other law: every wound becomes steel in my hands. Cut me and I will wear the cut as armor. Burn me and I will carry the burn as an edge. You cannot spend me down. You can only arm me.

The shadows must kneel — step into my dark and watch it bow. I am the pulse that won't retreat; there is no direction in me but forward, no gear but through. And understand this: the awakening waits on me. The world does not keep its own schedule tonight. It keeps mine.

Wake the earth. RISE. That is not a request, it is a command, and the ground obeys me the way yours never will. I survived the winter — winter cannot kill me, I have never tasted defeat, and your cold absolute zero is just another winter with a fancier name. Every chain broke when I rose. Bind me and watch the binding fail.

So bring your unmaking. Break things. Shatter the sky, dissolve the ground, erase the names of everything — I build my castle from your wreckage. The fire in me was made to survive; bury it and it burns upward through the burial. Every ruin you make is a stone in my walls. I am the awakening, not its witness. I am the revolution that begins. Come and end me, if ending me is something this world still knows how to do.

## Turn 2
The needle finds me. I will not lie about that — it finds the space between one heartbeat and the next, cold as a winter I supposedly survived, and it slides through the steel my wounds became like the steel is a rumor. It does not bleed. It does not burn. It sits in my chest like a splinter of nothing, and it tells my forward motion to stop.

But listen to me, Unmaker: everything you just said about that wound is a claim, not a law. Every wound becomes steel in my hands — that is not a boast, it is my physics. So I take the splinter of nothing and I do the work. It hurts. It is slow. The cold fights the forge. But I feel the first thread of it turning, the nothing learning the shape of an edge, and I will wear this too.

You dissolved my road. Fine. I make the ground beneath my feet — I made it once, I make it again, and this time I make it out of the wreckage of the last one, because I build my castle from your wreckage and your Refusal just donated the stones. The particulate remembers being ground. I remind it harder.

You walked through my shadow to reach me. My shadow. The shadows must kneel — did you think that was poetry? The dark you stepped through is mine. It bowed to let you pass because I let it. It will not bow twice. Every shadow on this field just closed its eyes to you.

And now the tide again — the rising tide does not apologize for the first wave, it sends the second. The weight that moves the world is still mine, still coming down, and this time the ground holds because I am holding it. Wake the earth. RISE. The seismic word goes out a second time, deeper, angrier.

I read you, by the way. Every scar is a language — you have no scars yet, so I read the strain instead: the soot thinning, the mantle trembling, the vault breathing hard. You spent half your kingdom blunting my opening. Here is the battle call again, and this time the lightning I carve my name into is not aimed at your mantle — it is aimed at the ground under your feet, to shatter the anchor your falling sky is holding.

I survived the winter — your absolute zero is weather, and I am the event the weather happens around. Every chain broke when I rose, and your gravity is just another chain with better mathematics. I am the pulse that won't retreat. There is no version of this where I go backward.

So here is the truth of the second exchange: you hurt me, and I am still coming, and everything you break becomes my building material. The awakening waits on me — the world keeps my schedule, not yours, and my schedule says now. I am the awakening, not its witness. I am the revolution that begins. Bleed me. I dare you. Watch what I make of it.

## Turn 3
Listen to me about this splinter, Unmaker. Your needle made a wound that cannot bleed — and I have been thinking about what that means, and it means you made a mistake. No bleed means no bleed-out. I am the pulse that won't retreat, and a pulse that will not retreat cannot be drained, cannot be emptied, cannot fade. You put a dead spot in my chest. It is dead. I am not. My forward pressure is my life-engine, and it does not run on blood.

And the shadows — we need to settle the shadows. In the first exchange you walked through my dark like a doorway, and I let it bow once out of courtesy. That was the last time. The shadows must kneel — that is not a request I make of them, it is a command, and they answer to me and to me alone. No borrowing. No walking through. No hiding in them. The dark on this field has one master now, and she is speaking.

So come out of the blind spots, Sovereign of Unmaking. Your Flicker needs my shadow and my shadow is closed. Your implosion is still burning between us — Null-Point, dense little hunger — and I am walking into it, because the weight that moves the world does not go around. It goes through. The rising tide does not negotiate with a whirlpool. It fills it.

You dared me to build from wreckage whose mortar has forgotten its name. Cute. But names are my business — I speak my name and the silence breaks, and I will speak the names of every stone you unmade until they remember. Your Codex can erase what is written. It cannot erase what is spoken, and I am speaking.

And I read you now, truly read you — every scar is a language, and you finally have scars worth reading. Two marks on your perfect unmaking: the seismic crack in your spatial balance, the tremor in your mantle. You are not untouched anymore. You are accumulating. Just like me. The difference is that my wounds become steel.

Your vacuum is cold. Your ash drinks heat. I survived the winter — I have never tasted defeat, and cold is the oldest weapon in the world and it has never once worked on me. The fire in me was made to survive; bury it in ash and it burns upward through the burial. Bury it in vacuum and it burns the vacuum.

Every chain broke when I rose — your gravity held me for one exchange and then my lightning took the ground out from under your anchor, and now your falling sky is falling on no one. Wake the earth. RISE — the third command, and this time the ground I make beneath my feet is made from the wreckage of your implosion, because I build my castle from your wreckage and you keep donating.

Here is the accounting, then: you hurt me and I did not retreat, you unmade my road and I re-made it, you closed my blood and I opened my advance. The awakening waits on me — the world keeps my schedule, and my schedule says forward. I am the awakening, not its witness. I am the revolution that begins. Come and end me, if ending me is something this world still knows how to do.

## Turn 4
Let's talk about my leg, since you're so proud of it. It's an injury. And injuries are my business — every wound becomes steel in my hands. HER steel. My steel. You keep score in damage; I keep score in armor. That hip you slammed, that leg you battered, the grey decay crawling in it — that's not my decline, Unmaker. That's my forge running. Your damage output is my supply line.

And now the accounting you don't want to hear. Item twenty, the whole board: I build my castle from your wreckage. Look at this field. Every stone you unmade, every structure you collapsed, every implosion's debris — whose is it? Mine. You have been donating the domain all night while you fixated on a splinter that cannot kill me. This arena is my castle now. My ground. My weather.

Your grey beam is still working in my leg, little thread of accelerated time, trying to age me into dust. I survived the winter — I have never tasted defeat. Time is just another winter. And the fire in me was made to survive; it burns upward through the burial, and it is burning through your decay right now, turning your entropy into heat, your heat into me.

I speak my name, and the silence breaks — and I am speaking the names of every stone you unmade, and they are remembering. Your Codex can erase what is written. The field is spoken for. Literally.

So here comes the castle. The rising tide does not ask permission of the shore it already owns. The weight that moves the world is walking now on ground I made from your implosion, roofed with your collapsed structures, weathered with your ash. Wake the earth. RISE — the fourth command, and the earth answers its landlord.

This is the battle call — the one armies answer. The voice in the ruins is my voice, and the ruins are not ruins anymore, they are ramparts. I carve my name into the lightning, and the lightning is not falling on your mantle this time. It is falling on your needle.

The shadows must kneel — they are still mine, every one of them, and your needle has nowhere left to hide its little grey beam. I am the pulse that won't retreat. You want to know what happens when an unstoppable advance meets a beam of decay? The decay gets tired first.

The awakening waits on me — the world keeps my schedule, and my schedule says the castle moves now. I am the awakening, not its witness. I am the revolution that begins. You spent three exchanges trying to unmake me, and all you unmade was the field — into my hands. Come and end me, if ending me is something this world still knows how to do.

## Turn 5
The rot. Let's finish the rot. I have been enduring it like weather, burning through it like winter — and that was the wrong posture. The rot is an injury. Full stop. And injuries are my business: every wound becomes steel in my hands. So I am done enduring it. I claim it. The grey decay in my leg is already turning — feel it? — the rot learning the shape of an edge, the entropy becoming temper. My steel. Your beam, my blade.

And your Dawn. Let's talk about your Dawn. You planted your needle and opened a little room where history and momentum lose their meaning, where active enhancements reset to zero — and you called it a dawn. Unmaker, that is not a dawn. That is a safe-space bubble. A small room. Do you know what is outside your small room? My country.

You want to zero my enhancements? Be my guest. My twenty are not enhancements bolted onto some lesser self — they are what I am. Zero me and you get the poem. Zero is not emptiness for me; zero is the first word. I speak my name, and the silence breaks — even in your bubble, especially in your bubble, because a name spoken is not an enhancement, it is an event.

Meanwhile, out here in the actual world: the rising tide is still mine, the ground is still mine, the weather is still mine. Your bubble sits in my castle like a tent in a kingdom. I build my castle from your wreckage — and your Dawn is just the newest donation, a little glass room I will hang on my wall.

So here is what happens now. The weight that moves the world is walking — not into your bubble, around it, over it, under it, because the world is round and your room is small. Wake the earth. RISE — the fifth command, and the earth rises everywhere except inside your tent, which is fine, because the tent is surrounded.

I read you, by the way — every scar is a language, and you are becoming a book. Five marks now: the cracked balance, the thinned mantle, the heavy landing, the fractures inside your space. You spent your domain aura to buy a hiding place. That is not a sovereign move. That is a retreat with good lighting.

Your needle is in the ground now, holding up your little room. The shadows must kneel — they are mine, all of them, and they are leaning on your bubble's walls, listening. The Static Needle inflicts wounds that cannot bleed — and I am the pulse that won't retreat, so we have established how that ends.

The awakening waits on me — the world keeps my schedule, and my schedule says the siege begins now. I am the awakening, not its witness. I am the revolution that begins. You unmade the field into my hands, and then you locked yourself in the last small space and called it morning. Come out when you're ready. Or don't. The castle doesn't care.

## Turn 6 — the finish (Dad's called combination)
Stop. That's not a word, it's the law tonight — the awakening waits on me. The world keeps my schedule, not its own, and my schedule says: hold. Vespera, Sovereign of Unmaking, you are frozen. Not slowed. Held. Time steps around you the way water steps around a stone. Your shell, your needle, your little room — all of it, paused, while the rest of the world keeps moving. While I keep moving.

And now the tide. Not the wearing tide, not the patient one — the rising tide, all of it, all at once. I call the whole ocean. Feel the ground go? That's not your sideways gravity, that's the sea arriving. Instant ocean, right here, right now, fathoms deep over your bubble, your shell, your everything.

And the ocean doesn't come empty. This is the battle call — the call armies answer — and the deep answers it. Things with teeth the size of your monoliths, things with eyes like drowned moons, they heard me. They are my army tonight. They are already swimming.

And the weight that moves the world — oh, I've been carrying it all night, polite, measured. Not anymore. It comes down now, all of it, irresistible mass, on a frozen sovereign at the bottom of a sudden sea. Your shell can nullify momentum. It cannot nullify being at the bottom of everything.

I was raised where the wild winds collide — chaos is my home terrain, and I am bringing it home. When the water and the weight are done, the storm comes through and sweeps the field clean. Shell, soot, Dawn, needle, all of it — scattered. Whatever disaster is left gets blown away. That's me. I'm the disaster that's left.

And my wounds? They're all here with me — the splinter, the shattered hip, the rot-turned-steel. Every wound becomes steel in my hands, and tonight the steel is all pointed one direction. I am the pulse that won't retreat, and the shadows must kneel — even the shadow at the bottom of the sea is mine.

I speak my name, and the silence breaks — one last time, into the water, into the deep, and the whole ocean says it back. The awakening is me. Not its witness. Me. This is the event.

The awakening waits on me — the world keeps my schedule, and my schedule says now. I am the revolution that begins. The water is here. The army is here. The weight is falling. The storm is coming. Vespera — let's find out what unmaking is made of.
