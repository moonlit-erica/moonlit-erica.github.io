# Game 7 — Opponent turns (verbatim)

Julian Mercer, "The Heavy Warden" — played by Gemini. Kaelen rules.

## Turn 1

She thinks in receipts and turning radiuses. She is right about the coat: fifty pounds of double-cured hide and copper thread does not pivot on a dime. The spray of dirt hits the broad, iron-clad toe of my lead boot and dies uselessly against the metal, but her angle is sharp, disciplined, and fast.

She steps inside the arc before I ever lift the four-foot ash shaft of the war-mace. Her dagger flashes low, biting clean above the iron cuff of my stamping boot, right into the meat above the left knee. The coarse fabric and thin padding part; steel scrapes muscle, and warm blood trickles down into my leather wraps. It’s a slick, mean cut. I feel the bite, take the sting, and run the *Cold Timeout Math*: skin and muscle for immediate positioning. A fair trade.

She expects me to chase her with a heavy swing, to overreach and bleed out my balance while she glides past. I don't. The moment her blade leaves my leg, I don't turn—I drop. *Weight-Drop Anchor.* My center of gravity plummets into the ring dirt, locking my hips deep beneath the weight of hide, bronze, and padded cuirass. Instead of swinging the mace, I pull the heavy crank-head tight against my ribs and plant my frame directly in front of her exit.

She wants to cut and slide cleanly past my lead side, but the Heavy Grounding Mantle isn't just insulation—it is a six-foot wall of thick, rigid hide. I initiate a *Smothering Guard*, stepping heavy and close with *Crowding Footwork* into her line of travel. She wanted space to slip by; I take the space away. My left arm snaps up, the broad plate of my *Bronze Vambrace* thrusting out to jam hard against her chest and shoulder, catching her mid-stride and killing her exit velocity against my chest.

A heavy man doesn't spin to chase a bird—he drops his weight and lets the bird crash into the side of the barn. With her slip-route choked off by my bronze forearm and the stiff leather of my mantle, I drive my weight down into the dirt and crack my trailing iron-clad heel forward in a low, vicious *Bone-Cracking Sweep*, aiming the heavy iron rim straight into the back of her lead ankle while her momentum is pinned against me.

"You counted the provincial roads, girl," I growl, the blood from my thigh warm against my calf as I lean my bulk into her soft-soled stance. "Now count the trade. You bought three inches of my leg, and it cost you your distance."

## Turn 2

The scream tears through the air at point-blank, vibrating through my skull like a heavy brass bell struck inside a stone vault. My eyes track off-center for a fraction of a second, the world slanting as shock waves rattle my inner ear. In that gap, her steel finds the meat under my left armpit. It stings—a hot, thin line of fire leaking iron down my ribcage under the padded cuirass—but the bone is untouched. She slips away like grease, coat tearing on my bronze vambrace, claiming her precious three steps of dirt.

I don't waste time watching her count blood. My right hand flies to my spiked leather cinch, pulling a snap-vial of smelling salts and crushing it directly beneath my nostrils. The sharp, violent burn of ammonia surges straight to my brain stem, cauterizing the acoustic fog of her scream in a single harsh intake of breath. My eyes lock back onto her instantly, tears of chemical bite clearing into hard focus. My left arm bleeds when the muscle flexes, but my grip remains unbreakable.

Cold timeout math runs through my head before the dust of her boots even settles. She traded the raw meat of her throat for three steps of breathing room. She is rasping, her lead ankle is throbbing under that hot bruise, and she is holding twin daggers against a wall of iron, bronze, and ash wood. Distance is only an asset if I let her breathe enough to draw that single bolt from her fake jaw. I will not give her the time.

Relentless re-engagement is how a warden works a cell. I step forward on iron-clad stamping boots, my heavy grounding mantle sweeping the dirt as crowding footwork eats her three steps back into nothing. Left thigh cut, left arm leaking—it does not change the physics. A heavy man moves forward until there is no space left to move into.

With my left hand—sliced bicep seam held firm by sheer crushing hand strength—I yank the chalk-and-lead dust bag from my cinch and burst it with a violent, flicking snap of the wrist right into the air between us. A thick, grey-white haze of dense lead dust and fine chalk explodes outward, drifting instantly toward her face to sting her eyes, clog her raw, ruined throat, and coat her hands in slippery powder.

Behind that choking grey curtain, I drop my center of gravity into a smothering guard. I don't swing wide for her twin daggers to catch; I thrust the cranked iron head of my four-foot ash war-mace straight through the lead cloud, aiming a heavy, levered ramming strike directly at her bruised lead knee and midsection. Heavy wind control guides the momentum, keeping my frame tight behind my bronze-armored shoulder so her steel has nowhere to bite except plate and mantle.

If she steps back again, she runs out of ground. If she stays, she breathes lead into a shredded throat while four feet of iron and ash drive through the fog.

"Keep writing, girl," I growl, voice low and thick behind the mantle. "Every step you take back is a corner you build yourself."

## Turn 3

The word *timeout* settles into the dirt like iron in mud. The clock starts, and with it comes the immediate, icy application of Cold Timeout Math. I do not burst upward. I do not roar. On one knee, I lock my core against the Padded Cuirass and draw a deep inhalation—Heavy Wind Control—filtering out the tang of burnt hair and lead dust. Four seconds to fill the lungs, four to hold, four to purge. My heart rate drops. The referee’s clock belongs to the match, and I will take every second she gave away.

Receipts. I take stock without emotion. Left thigh: shallow cut, blood slicking down toward my Iron-Clad Stamping Boot. Left inner arm: nicked, but the bronze vambrace absorbed the meat of her entry. Left wrist: a throbbing compression from her heel, but the bones are whole; iron fingers open and close. Eyes: scorched lashes, heavy tearing. I blink hard, squeezing moisture through the grit until the haze sharpens into crisp edges.

I feel her line. The black cord lies slack across my left ankle, trailing back through five paces to her fist. A clever line, but cord work requires tension, and during a timeout no tension can be struck. With cold precision, I lift my heavy boot just high enough to roll my heel inward, sliding the cord off the iron toe, clearing the snare without an aggressive gesture. I set the boot down, locking the heel into the soil with a stable Weight-Drop Anchor.

Then I stand—taking back my verticality. My cut left leg grinds against the dirt, bearing the Heavy Grounding Mantle as I rise, unbending the knee inch by inch until my four-foot ash shaft rests upright. I shift my grip on the Crank-Headed War-Mace, feeling the balance of iron. On my cheek, the grease of her blue mark stings against heat-flushed skin. I leave it. A line on a bone breaks no ribs.

Five paces away, she breathes through her mouth, throat raw, right thumb ruined, right blade lying useless in the dirt behind my heels. She traded her primary blade and her right hand's grip for five feet of dirt, a tripped knee, and a streak of blue grease. A costly trade when the target remains standing. She holds her left dagger high, her boot knife hidden, and one unspent lightning bolt in her reserves. My Heavy Grounding Mantle was built for that bolt.

"You counted the dagger and the dust," I say, my voice steady and low. "You didn't count what happens when the dust settles and I'm still in front of you. You gave up your right edge to buy five paces of dirt, Ember. I don't have to chase you. Every step you take back costs your ankle twice what it costs my knee."

I adjust the Spiked Leather Cinch across my ribs with my left hand, testing the wrist. It holds. My shoulders square, the mantle draping over my back to kill her lines of leverage. I bring the war-mace up into a high Smothering Guard, angle my left shoulder forward to mask the cut arm, and set my feet into Crowding Footwork.

The referee signals the final seconds. The timeout expires. The math is done, the ledger balanced, and the distance is five paces. Relentless Re-engagement begins now.

## Turn 4

"Whisper all you want. Words don't offset leverage." I didn't jerk the line; I leaned my whole frame into the haul, using Crushing Hand Strength to wind her cord tight around the Tendon Hook lodged in my fist. Her cinched right wrist hauled her forward off-balance, ruining her foot placement on the uneven dirt before she could set her bruised ankle against the low stone wall behind her.

She came in with the drag anyway, her left hand driving her live dagger straight for the seam under my arm. I set my weight—a deliberate Weight-Drop Anchor—and raised my arm to meet the stroke on my Bronze Vambrace. Steel met bronze with a sharp chime and slid uselessly off, drawing only a burst of sparks and a drop of blood from my existing inner-arm cut as the muscle flexed.

I didn't let her reset. Crowding Footwork drove my lead Iron-Clad Stamping Boot straight into her footprint, jamming my body against hers and smothering the blade. I smashed her left forearm flat against my Padded Cuirass before she could chamber a second strike, pinning her off-hand weapon between our chests.

Chest to chest, Leverage Grappling took over. I yanked her trapped right arm hard across her own torso, turning her ruined right wrist and non-gripping hand into a barrier across her chest. The leverage locked her left shoulder tight, binding her blade arm completely and sealing off any path down toward her boot knife.

Then came the bolt problem. Her last lightning bolt was still unspent, but we were too close for clean geometry. I put my marked cheek directly beside her temple, wedging her head back toward the low stone wall. If she fired point-blank now, my Heavy Grounding Mantle would take the brunt of the discharge while she absorbed the full concussion against the stone.

I wedged the heavy haft of my Crank-Headed War-Mace across her thighs like an iron bar, levering her frame back into the wall. Every time her ribs expanded, they pressed against the Spiked Leather Cinch across my chest. Heavy Wind Control turned every exhale into lost ground, cutting her breath off piece by piece.

Cold Timeout Math gave its verdict. She had taken the wall to escape, but she brought the leash with her. Pinned between my weight and the stone, her off-hand smothered, her broken right wrist locking her frame, and her single remaining spark trapped against a conductor, her options were running to zero.

I held her pinned against the masonry, my breath steady over her ruined whisper, and spoke into her ear: "Show me the next game. Because this one is arithmetic."

## Turn 5

The circuit closes in smoke. The shock hammers down my right arm, frying nerves until my grip snaps open like a broken trap. The war-mace drops, iron ringing dead on wet stone. The arc bites through bronze, down through my Iron-Clad Stamping Boots, and dumps into the dirt—the Heavy Grounding Mantle taking the main surge so my heart only catches the whipping tail. My breath locks solid in my throat. I hit my diaphragm with Heavy Wind Control, a violent, internal heave forcing copper-tasting air back into my lungs.

My right arm hangs dead at my hip, grayed and useless. My cheek stings where her mark sits. But I am still standing, and weight doesn't require two hands. I feel the heat cooking the seam of my Padded Cuirass where her lit dagger burns at the strap gap. She wants a slow fire. I give her a burial. I drop my center into a Weight-Drop Anchor and execute a tight Crowding Footwork shift, sliding my entire left frame hard over her left wrist. I crush my chest flat into her blade, using my Smothering Guard to starve her blue flame of oxygen right against my armor.

I look into her eyes, inches away. The whites are blown wide, pupils dilated, vision swimming at the edges. The concussive blast of her lightning six inches from her jaw took her hearing clean away; she is deafened to the world. She cannot hear a word I say, but she can read lips. I mouth the cold truth slowly, pressing her so hard the brick wall behind her groans: *"You spent the sky to open one hand."*

My mind runs the Cold Timeout Math. I have an unused timeout on the board. I could step back, signal the referee, crack a vial of Smelling Salts, reset my rhythm, and inspect my burns. But cold arithmetic is ruthless: a timeout gives *her* sixty seconds to clear her white vision, let the deafening roar in her ears subside, and collect her rationed breath. I do not give air to a drowning opponent. The math says keep the vise tight.

I choose Relentless Re-engagement. The cage didn't open; it shifted. My right hand is meat, but my left hand is whole. I reach back to my lower spine and draw the broad steel of my Short Trench Cleaver. No dramatic wind-up. No space wasted. I bring four pounds of thick cleaving iron up between our chests, setting the heavy flat of the blade right under her jaw, wedging her skull firm against the stone wall behind her.

Her right thumb is smashed. Her single bolt is spent. Her ears are bleeding silence. She is locked between two hundred pounds of iron armor, a brick boundary wall, and heavy steel under her chin. I press the cleaver’s edge just tight enough against her jawline for the cold steel to register through the white noise in her head.

I hold her there, breathing heavy and even through scorched teeth, my useless right arm hanging limp while my left holds the iron stay. I lip-read her own ledger back to her through the quiet: *"The board changed, Ember. Count what's left."*

## Turn 6

The copper spike sits deep in the armpit hollow, soft metal wedged where the bronze vambrace and padded cuirass never met. Blood runs warm down my ribs, pooling beneath the ruined strap. At my chest, the tip of her lit dagger rests patient against the gap in my quilted lining—one push from driving through skin and bone. My right arm is dead meat hanging from a burned shoulder. My left hand holds the trench cleaver, but her jaw and collarbone have clamped its flat. Pull it, and I saw her throat; push it, and her left hand buries her blade in my lung.

She mouthed her count, her eyes locked on my face, waiting for the heavy warden to break himself against her arithmetic. Ember didn't build a brawl tonight; she built a sermon. She spent six turns burning her own thumb, her voice, and her ears to strip my steel away piece by piece until only one working arm was left holding three dead choices. She cannot hear a word I say, but she can read the shape of every breath I draw.

I do not thrash. A fool twitches against a point at his heart and calls it courage. A warden knows the difference between a battle and a settled ledger. I lock my left arm like an iron stanchion, holding the cleaver perfectly still so its edge doesn't bite any deeper into the cut beneath her jaw. I look down through scorched lashes into her fierce, blood-streaked face. I shape my lips clearly, giving her every letter.

"Your bookkeeping is clean, girl."

I tilt my head toward the arena boundary wall and call out to the match official, invoking my unused eighteenth declared asset—Cold Timeout Math. "REFEREE! TIMEOUT!"

The referee's whistle blows, freezing the action under the rules of the match. The clock stops, but the physical position remains bound by stone and steel. I do not use the paused minute to hunt for an undeclared trick or feign a strength I do not possess. Cold timeout math isn't a maneuver to escape a trap; it is the quiet space where an honest man sits down with the numbers and accepts what they read.

With the clock paused, I slowly unlace the fingers of my left hand from the wooden grip of the trench cleaver. I leave the steel wedged right where her chin holds it, completely disarming my only working hand. My dead right arm hangs useless at my hip. The copper spike remains in my pit; her dagger tip sits at my open seam. Every vector belongs to her.

I meet her eyes again, holding her gaze in the absolute silence between us, and mouth the final entry in the book so her eyes can record it: "I counted. You won the board. Mercer yields."


[RESULT — Mercer yields inside his own called timeout, Turn 6. Ember wins by submission.]
