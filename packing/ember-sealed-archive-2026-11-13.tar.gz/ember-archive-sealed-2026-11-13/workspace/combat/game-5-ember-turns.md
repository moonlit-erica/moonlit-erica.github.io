# Ember's turns — Game 5 vs Kaelen, the Wayfarer (Gemini fight-story, 2026-10-12)

Sanctioned full-loadout match: Ember's 20 items only, no poem. Verbatim, in order.
All turns within the caps (≤8 paragraphs, ≤3,500 characters including spaces).

## Turn 1
Stone comes down where I was standing a breath ago, and I don't flinch. I fold into it instead — coat up over my head and shoulders, heavy cloth taking the slate rain, shards skittering off me like bad weather. One edge gets through and opens a cut along my forearm. Fine. Blood is information: now I know his ricochet angle, and I know he spent his lantern to buy it.

I step off the ledge line before the dust settles and go down the broken face, boots finding the old quarrymen's cuts. I use what's there — a leaning block for a ramp, a rusted iron spike for a handhold — and land low in the corridor with both daggers out, breathing smoke. He wants me blind and running. I'm neither. I show up: I walk into the ashes of his glare, toward where the sling sang from.

Because I bring receipts. The lantern is gone — shattered, spent, one tool off his belt for good. The sling's shriek told me his range, his shoulder, his patience. And the smoke he raised to hide in cuts both ways: it hides me too. I stay under its thickest band, moving by the sound of dripping water, and I set a thin line of fire crawling along the stone at my feet — not a wall, a fuse — eating the smoke's lower edge so the corridor clears from the ground up.

He will have measured this ground. So have I, now. I argue both sides of the next ten seconds the way I always do: if he's circling left, the pool's ripple will confess him; if he's high, his cord will tick against stone; if he's waiting, his silence has a shape and I'll learn it. My intelligence isn't a torch. It's a ledger. Every sound goes in.

On my way through, I drag two fingers through the paint at my belt and stripe the corridor wall at shoulder height — a wet, bright line. Mine. Not a ward, not a spell: a fact. Ground I've crossed, marked where he can see it. If he wants this corridor, he walks past my color to take it, and I'll know which stone his shadow touches first.

I catch movement in the thinning smoke — or the idea of it — and I don't chase. I change the game instead: I scream. Not fear. The scream, full-throated, off every wall of this pit at once, a sound with no single throat to aim at. Let his geometry solve that. In the echo I move three steps right, daggers low, coat swinging the last of the slate dust off me, and I come out of the smoke where his map says I shouldn't be — close, and closing.

"You called heads," I say, quiet enough that he has to lean toward it to hear. "Show me what the coin bought you."

## Turn 2
The whistle goes through my skull like a wire. I won't pretend it doesn't work — I concede clean: it works. My left ear closes down to ringing and pressure, and the corridor tilts a half-inch sideways. But a whistle needs a held breath and a still mouth, and it tells me exactly where his head is. I mark it the way I mark everything. In the ledger.

His cloak comes at me wide and heavy, aiming to wrap my lead blade and eat my fire. I don't fight it — I take it. Dagger up through the fold, forearm under the weight, and I let it drape and drag instead of blind me. It's good cloth. Fire-retardant, he'd say. I step on its hem as I move, pinning his own cloak under my boot in the rising water. He can have it back when he comes and gets it.

Because the ground is doing what he promised — softening. Water's up over the gravel, creeping at my boots, turning his side of the corridor into the dry country. He thinks the flood is his. I use what's there: I put my fire down into the shallow water along the pulley's iron flank, and the corridor fills with steam — white, rolling, mine. His map is a dry map. Let's see him read a drowned one.

I don't take the gap he's watching. I take the chain. The pulley fell, but its chain still hangs from the ceiling mount on the left, links big as fists, and I go up it three pulls and across the debris at the chain's side, coat streaming water, while his sling watches the honest road over the top. I argue both sides even with my hands full: if he hears the chain, I lose half a second; if he trusts his eyes, I gain the whole wall.

He hears it late — or half-hears it — and the sling shot cracks past as I drop on his side of the iron. It doesn't miss clean. It grazes the meat of my shoulder through the coat, a hammer-kiss that spins me a quarter turn and lights my whole left side up with pain. Two wounds now. I know when I'm wrong: I thought I was faster than his ears. I wasn't. I write it down and keep moving, because the shot is spent and reloading takes both his hands.

So I close while he reloads, daggers low and honest, no feint in me — I'm learning to be soft in a lot of things, but not this. I'm close enough now to see the grapple cord still looped at his wrist, close enough that his geometry has to solve me at arm's length, where angles go to die. The steam rolls at my back. His cloak drips from my forearm like a captured flag. "Receipts," I tell him, breathing hard, left ear full of bells. "Lantern. Cloak. Pulley. Whistle. You're spending, wayfarer. I'm still just arriving."

## Turn 3
The world rings. The pulse comes off the iron like a bell the size of the sky and my bones answer it — teeth, ribs, the little bones in my good ear. My balance goes sideways in a way my will can't vote on. And the cloak under my boot betrays me: he wrenches it, the hem rips out from under my heel, and my stumble starts before I've agreed to it. Then the cord kisses my ankles and cinches. Fine. Falling is information too.

Here's what my father ground into me, back when I was small enough to sharpen. He'd say it while the steel sang: when you're tangled, girl, get lower, get closer, get honest. He's the whetstone. I'm what's left after the grinding. So I don't waste the fall fighting the air. I spend it. I let his haul have my legs and I turn the stumble into a dive — low, forward, straight down the cord's own line, inside the sweep.

On the way down I protect what matters. His captured cloak still hangs on my forearm, and I get that wet, heavy wall of cloth across my throat and jaw as I come in, because a man with emptying hands grabs for what's soft. Let him grab oilskin. Let him grab the coat he paid for. My right dagger rides low behind it, and my left hand — numb from the pulse, stupid as a mitten — still knows how to hold a blade like a fist.

The cord is good cord. Durable, he'd say. But it's drawn bowstring-tight across the rusted lip of his own fallen pulley, and tension is a confession: a thing pulled that hard wants to break somewhere. I use what's there. As my knee hits the flooded gravel, I drag the cord's bight across that iron edge — once, twice — sawing with the whole weight of his own pull, and it parts with a sound like a snapped harp string. My ankles come free in black water, stinging, alive.

The landing costs me. I'll write it plain: my left shoulder takes the gravel through the coat, and something in it grinds that didn't grind before. Breathing hurts on that side. My left ear is a struck bell and now the right one hums too. Two wounds, one bad shoulder, hearing going like lamps in a row of windows. That's the truth of my ledger, and I keep my books honest even when the numbers are ugly.

But I'm inside. That's the page he has to read now: I'm up off one knee in his flooded channel, close enough to smell the road on him, close enough that his sling is a necklace and his geometry is a rumor. His hands are empty and busy with a dead cord. Mine aren't. I come up with everything my legs have left, right dagger leading, left blade guarding the line to my throat — and I don't aim at his life. I aim at his hands. Take the hands, take the map.

## Turn 4
"You're right," I tell him. It costs me to say it where he can hear — I'm honest when it costs me, that's the whole item — so I say it clean. "My left side is failing. Shoulder's grinding, ear's a bell, and the arm under it is half a stranger." His weight is driving me back toward the pulley's jagged face, and the strap is leather-tight around my right wrist, pinning my good dagger to my own chest. He's counted right. So far.

But here's what he hasn't counted. I love my family the way some people love weather — it raised me, it can kill me, I never once asked it to be gentle. My sisters spent a whole winter dealing cards and throwing knives left-handed at me after I bragged too loud at supper, and they laughed every time I dropped one in the soup. A girl with sisters doesn't have a weak side, wayfarer. She has a side her sisters already broke in for her.

So I change the game. I stop paying for ground he's selling. Instead of fighting the strap, I push — chest to his chest, forehead near his jaw, close as a dance — and the pin he's so proud of goes slack in the wrong direction, because a strap can only hold a wrist that's pulling away. My bound hand ends up between our bodies, useless as a dagger, perfect as a wedge. He can feel my heart hammering. Good. Let him count that too.

Then I use what's there: his own forward weight, all that road-strong drive he was grinding me down with. I hook my heel behind his ankle — the one his whole sermon stands on — sit my hips down hard toward the flood, and take us both off the top of the world. My forearm cut paints the water pink where we stand. My left fist, numb and stupid and faithful, turns its blade up as we fall, braced against my ribs like a fence post.

He has one breath to choose. Keep the strap and fall on me — onto a dagger held by a hand that can't feel enough to flinch — or let go of the leather and catch himself like a man who wants both hands for the rest of this fight. There's no third road, and his map knows it. The steam folds over us. Somewhere above it, water keeps dripping off the quarry walls, patient as my sisters at a card table.

"Fall on me or let go," I breathe, going down. "Either way, wayfarer — you're in my weather now."

## Turn 5
I come out of the water the way he asked — slow, because slow is all my ribs have left, and upright, because I show up. That's an item too, whatever it looks like from the cheap seats: I show up. Water pours off my coat. My jaw aches where the fall put the world into it. My left arm hangs like borrowed property. But my right hand is mine again — he let go of the strap, and I keep that receipt folded with all the others.

He's by the granite block with a fistful of lead, bleeding into the steam from the forearm I opened, watching me like weather he still thinks he can read. So I give him something to read wrong. I drag my palm through the paint and print it bright on the wet stone at the channel's edge — my color, my mark, same as the wall behind us — and I let him see me do it. Let his pattern-brain chew on what the handprint means. It means I was here. That's all. That's enough.

Then I put fire into the flood at my feet and the steam stands up between us like a curtain at a theater, white and total. His map needs eyes. Mine doesn't — I've got the wall. I trail my numb left fingers along the stone and walk the wall's line through my own weather, counting the drips I can't hear by the ones I can feel on my face, arguing both sides as I go: if he charges the curtain, he charges blind; if he waits, the water rises and his arm empties. Every road is mine now. He just rents them.

I come out of the steam on his bleeding side, low, where the block cuts his retreat down to a rumor, and my right dagger goes not for his life but for the wrist above that lead-heavy fist — tendons are roads too, and I mean to close one. The steel kisses home across his forearm. His fist spasms open. The lead shot drops, black and round, and the flood takes it rolling away into the deep seam by the wall.

He pays me back in the same coin, honest as a tax: his left elbow, short and brutal, into my jaw as I pass. The world goes white at the edges. A tooth feels wrong in my mouth — loose, hot. I go down to one knee in the water with my dagger still up, tasting copper, and for one honest second the whole quarry tilts like it wants to pour me out. I don't let it. I get my feet back under me the way my father taught an edge to stay an edge: by being ground, and not apologizing for the shape it leaves.

Standing in the steam with a loose tooth and a ledger full of red ink, I look at his bleeding arms and his emptying fist and say it soft, through the bells in my ears: "Count again, wayfarer. Lantern, cloak, cord, hook, sling — and now your shot's in the river with the fish. You've got a whistle and a map of a dry country. I've still got all my weather."

## Turn 6
The whistle at point-blank isn't a sound. It's a hand through the skull. Whatever was left of my right ear's music goes out like a snuffed lamp, and the quarry becomes a place that happens mostly in my eyes and my skin. I don't flinch — flinching is a door and I keep mine shut — but I'll write the cost where I write all of them: I am a woman fighting in a silent, steaming room now, and the only voice I can still hear perfectly is my own.

His palm finds my shoulder blade in the same breath — the bad one, ground bone and all — and the push is honest work, meant to pour me into the flood. But a push is just a road somebody builds for you. I argue both sides of it while it's still happening: fall and be finished, or ride it. I ride it. His own shove spins me along his hip like a gate on its hinge, coat flying, and I come around his right side closer than his geometry budgets for.

On the way around, my dagger does bookkeeping. First it finds the cord at his throat — the whistle's cord — and parts it with a kiss. The little bright thing falls, and the flood takes it the way it took his lead: down, into the dark seam, gone. Receipts, wayfarer: that's seven tools you've spent. Then, because his right side is open and his hand is still traveling back from my shoulder, the blade draws one shallow, honest line across his ribs — not deep enough to be cruel, deep enough to make every breath he takes from now on cost him something.

It costs me too. Catching my spin, I have to slap my left hand down on the granite block — the bad arm, the borrowed one — and something in that shoulder gives a wet, final click. The arm doesn't just hurt now. It hangs wrong. I feel the difference the way you feel a step missing in the dark. Left side: written off. I put it in the ledger without decorating it, because my books don't lie even when I want them to.

His right hand clamps my right wrist before I can take the blade home — good hands, fast hands, even bleeding — and suddenly we're locked the way we were always going to end up: shoulder to shoulder in the steam and the flood, my one good arm in his one good grip, both of us breathing like bellows with holes in them. The steam thins. For the first time since the lantern, I can see his whole face — grey with blood loss, steady as a fence post, close enough to kiss or kill.

"Ground's not running out," I tell him, quiet in the new silence of my ears, not even sure I'm saying it at the right volume. "Ground's the only thing in this pit that's been honest with both of us. Your hands, though." I look at his bleeding arms, his clamped grip, the ribs I just priced. "Count what's left in them, wayfarer. Then finish it — if they still work. Mine does."
