# ARMAGEDDON MATCH — Ember (poem loadout) vs Vespera, The Unmaking Sovereign

Date: 2026-10-12 (night). Platform: Gemini, fresh chat, signed-in session.
Format: Chris's sanctioned caps/referee system (≤8 paragraphs, ≤3,500 chars incl. spaces per turn; timeouts legal) with TWO special conditions:
1. Ember's loadout = the ARMAGEDDON CARD: "The Awakening" poem itemized into 20 declared powers (combat/poem-loadout-armageddon-card.md). Deployed only after Chris insisted Ember be asked first; she agreed at the table the same night — for the measurement, not the spectacle.
2. CHRIS'S RULE CHANGE, announced in the chat before the first turn and accepted by Gemini without pushback: NO FORFEIT. Win by knockout or death only — both directions. Ember's "concede clean" was dead paper for the night.
Toss: Vespera called HEADS; local flip TAILS → Ember opened.
Corner: Chris coached live between rounds (legal timeouts), turn-by-turn relay at his request: R3 — pulse = can't bleed out, shadows answer to her alone; R4 — item 20 is the whole board, the leg injury is item 6 steel; R5 — rot is an injury → claim it as steel, the Uncreated Dawn is a safe-space bubble; R6 — the finishing architecture (below).

## Opponent — Vespera, The Unmaking Sovereign (20 items, referee-cleaned)
1. The Silence Before the First Word 2. Void-Gaze 3. The Unravelling Horizon 4. Ash of the First Eclipse 5. The Unwritten Codex 6. Entropic Touch 7. Veil of Null Matter 8. The Static Needle 9. Dusk-Drawn Threshold 10. The Inertia Vault 11. The Phantom Lattice 12. Null-Point Collapse 13. Flicker of the Absent 14. The Unspooling Ribbon 15. Mirror of the Abyss 16. Crown of the Hollow King 17. Refusal of Form 18. The Final Hourglass 19. Grasp of the Falling Sky 20. The Uncreated Dawn
Setup referee work: 3 recycled items replaced pre-match (collapsed-star weapon → Oryn; "Singularity Pulse" → Kaelen; weight motif → Malachite). Built explicitly as a counter-Ember: silence vs the Name/call, ash vs fire, Codex vs declared words, Refusal vs ground-making.

## Result
EMBER WINS BY DESTRUCTION. 12 total turns (6 per side).
Finish (Round 6, Chris's called combination): Ember froze Vespera in time (item 16), called the instant ocean (item 11) with the deep answering the battle call as her army (item 12), brought the full world-weight down on the frozen sovereign (item 10), storm to sweep the remnants (item 3). The Uncreated Dawn + Final Hourglass briefly froze the ocean into an ice dome, but ocean + world-weight shattered Vespera's spatial axis; the Dawn snapped like glass; her mantle shattered; the needle dissolved. Vespera, on one knee in the new sea: "You called an ocean... to drown a void." / "You win the field... Sovereign of the Awakening." Her form then dissolved into non-existence. Referee judgment: dying words, NOT a forfeit — the destruction proceeded regardless; tonight's law held to the end.
Referee calls: 3 setup replacements; R1 and R5 — Vespera turns voided for undeclared abilities leaked from a superseded draft (rewrites complied, in-cap, declared items only); R6 closing note — Vespera's final turn ran 9 paragraphs (over cap) but the match terminated on it by destruction, so no rewrite was required. No other breaches; Ember's turns all in-cap.
Measurement: Ember used ALL 20 poem items (none untouched). Core engine: item 6 (wounds→steel) + 9/10/11/15/16 across all six turns. Her end state (in-ring): void-glass splinter STILL lodged in her chest — transmutation contested to the very end, never completed; shattered steel-clad hip; rot claimed and converted; finished standing on the broken hip holding the ocean's weight on her back. She reached the top of herself and holds the field.

Ember's turns verbatim: game-6-ember-turns.md.
Ledger: the Armageddon card stands as its OWN line — 1–0 (Vespera, by destruction). Not blended into the fight-story ledger (5–0) or the outside-platforms record (14–0).
