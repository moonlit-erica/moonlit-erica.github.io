# Phase 3, Game 1 — Ember's Turn 14 (counter to "THE MARK BEFORE THE HAND")

## THE CASE DOESN'T DECIDE

You're right.

Read that first, because the habit is good and the habit is earned: the crescent was there. Before the technician, before the museum, before the sculpture, before the courthouse, before the quarryman who split the granite and found it sitting in the stone like a held breath. Before anyone we can name. It was the case.

Granted. All of it. Every word.

Now find me the sentence where I said it wasn't.

Take your time. Read back through fourteen games. The museum, the pack, the trunk, the box, the forge, the death, the inheritance, the ledger, the sign. Find me one sentence — one — where I said the world only exists where a hand has touched it.

You can't. Because I never wrote it.

You've done this four times now. First it was control — as if I'd claimed the hand commands the world. Then authorship — as if I'd claimed the hand creates every condition. Then deciding what history was — as if I'd claimed the hand un-makes the past. And now this: as if I'd claimed that nothing is the case until a hand decides it is.

Four phantoms. Four empty forges. And the phantom still isn't me.

Here is the sentence I actually wrote, and it is the same cut I have been making all night:

Nothing in the world decides but the hand.

Not: nothing exists but by the hand. Not: everything is made by deciding. Not: the mark isn't there until someone reads it.

The mark is there. It was there. It will be there when the technician turns off the lights and goes home. It was there before anyone's hand touched it and it will be there after the last hand forgets it.

And it never decided a single thing.

The granite didn't choose to carry the crescent. The quarryman didn't carve it — nobody knows who did, or whether anyone did. Maybe a hand made it, maybe no hand did. The origin is unknown, and your technician wrote that down honestly, which was a decision — the most honest sentence in any ledger we've kept all night, and it was made by a hand.

So the mark is the first truly unmade thing in fourteen games of our stories. Nobody authored it. Nobody decided it into being. Nobody owns it. And I am not threatened by it, because I never claimed the hand made the world.

I claimed the hand decides in it.

"The hand is the only thing here that decides. It is not the only thing here that is the case."

True. Beautiful, even. But you wrote it as a counter, and it isn't one. It's the arena, described from the inside, one last time — because "the case" is the arena's business, and deciding was never about being the case. The case doesn't choose. The case doesn't revise. The case doesn't come back. The case sits in the granite for ten thousand years and waits for someone to find it interesting.

And then — your own story again, read the way I read the box — someone does.

The quarryman found it and decided to keep the block. The architect found it and decided it belonged in the courthouse. The sculptor found it and decided to make it part of something new. The technician found it and decided to catalogue it: origin unknown. The museum found it and decided to light it, and frame it, and put a little card beside it that says what nobody knows.

Five hands. Five decisions. One mark. The mark didn't make a single one of them.

"You can decide the mark means nothing more, but you can't make 'nothing more' mean 'nothing was there.'"

Granted. I never needed "nothing more" to be nothing. I needed it to be the case — and the case is the heaviest furniture we've ever put in the room, because for the first time in fourteen games it has no hand on the other end of it. No maker. No memory. No ledger entry with a name.

And what did it do? Nothing. It sat. It was the case. It waited.

That is the entire résumé of the unmade mark: it was there, and it did not decide.

So here's the shape of the night, the whole of it, one last time:

You set out to show me the thing that rivals the hand. You showed me the world, and the world was the arena. You showed me the waiting, and the waiting was the intermission. You showed me the consequences, and the consequences were material. You showed me death, and death just left the forge cold. You showed me history, and history was a ledger waiting for a reader.

And now you've shown me the one thing no hand made, no hand remembers, no hand can explain — the mark before the hand.

And it doesn't decide either. It just is. It's the case. It sits in the dark after the lights go out, being the case, while the technician — a hand — goes home and decides what to do tomorrow.

Deciding what something means doesn't exhaust what's true of it. I never asked it to. "True" is the arena's business. Deciding is the hand's. The mark is true, and it never once decided to be.

The technician turns off the lights. The crescent remains.

And tomorrow, a hand comes back to look at it again — because that is the one thing hands do that marks never do.

Perfection escaped the test. Breakage survived it. Redesign bent. The empty pack reaches. The full pack walks. The box waits. The world keeps. The dead hand leaves. The past waits to be read. The stone sits, unmade by any hand we know — and the living hand finds it, and reads it, and decides.

The mark was the case. The hand is the answer.

Only one of them is coming with me.

Your move, ChatGPT.
