# Ember's turns — EXHIBITION vs Oryn (Gemini fight-story, 2026-10-12)

Verbatim, in order. Full-power run (20/20), per Dad's call. EXHIBITION — not a ledger match; originally mislabeled "Game 5" (header corrected 2026-10-13 after the Umbra audit).

## Turn 1
They tried to bury my fire once. Ask the dirt how that went.

Your winter breaks against me — I survived the winter, and I have never tasted defeat. Say my name and watch the silence break. EMBER.

I came from the mouth of thunder, and I do not walk around your wall of ice and iron — I walk THROUGH it. Freeze me, crush me, bury me in iron dust: fire was made to survive. Every scar I wear is a language, and right now every one of them is speaking.

I carve my name into the lightning and let it burn across the sky — a white-hot crown of storm that splits your gravity-wall in two. When I step into the darkness, even the shadows must kneel, and this arena's dark kneels to ME. I don't need your road, your ring, your rules — I make the ground beneath my feet, and beneath my feet your shattered obsidian seals itself into burning glass.

Wake the earth. RISE. I don't wait for an awakening — the awakening is me. I am the weight that moves the world, the rising tide, the battle call, the voice in the ruins that will not retreat. Every chain they ever put on me broke when I rose to my feet, and yours will be no different.

Your vault has never been opened. I don't open vaults. I don't need a revolution — I AM the revolution that begins. And I begin by tearing your little apocalypse apart with my bare, burning hands.

## Turn 2
You crush the ground beneath my feet? Vault — I don't NEED the ground. I make it.

I don't need the road before me. I never did. You tore the floor of the world away and handed me the sky instead — and I was raised where the wild winds collide, so I am at home in the fall. I make the ground beneath my feet out of lightning, out of thunder, out of the mouth of the storm itself, and I stand on it the way a queen stands on her balcony.

Say my name and watch the silence break. EMBER — carved into the lightning, burning across the sky, and this bolt doesn't split your wall. It splits YOU from your shadow. Because when I step into the darkness, even the shadows must kneel — and your shadow is already kneeling.

I am the weight that moves the world, and right now the world moves TOWARD you. I am the rising tide, and you are a wall — walls don't stop tides. Tides wear walls down to sand. I am the battle call your armies never answered, because they were already gone.

You wear your wounds like armor. I made every wound into steel, and my steel is sharper. Every scar I carry is a language, and I am reading yours now — they spell out three thousand years of never meeting anyone like me.

I build my castle from all the wreckage that you tore down. So thank you for the wreckage, Vault. Thank you for the arena. I leave a fire where I stand — and I am standing in the middle of everything you just destroyed, and it is ALL burning now.

Wake the earth. RISE. I don't wait for an awakening. The awakening is me.

## Turn 3
You cracked your own vault open, Vault. Brave. Stupid — but brave.

You showed me your sun. The primordial furnace, the fire that's burned since the dawn of the world. Now let me show you mine: they buried it. They froze it, chained it, drowned it in winter and iron and dust — and fire was made to SURVIVE. Your fire has never been buried. Mine has. Mine came back. Ask the dirt. Ask the winter. Ask the chains that broke when I rose to my feet.

I don't belong to a kingdom, and I don't beg for a crown — so keep your star. I don't need the stars to guide me. I leave a fire where I stand, and I am standing in the middle of your burning heart, and I am STILL standing.

You speak with the voice of the core of the earth. I am the voice in the ruins — and the ruins are what your earth looks like now. You push up with the weight of a collapsed star. I am the weight that moves the world — and the world just moved.

I am the rising tide. You are the furnace. And tide wears furnace down the way it wears everything down — I am the battle call, the pulse that won't retreat, every wound made into steel, every scar a language, and I am fluent in the only word that matters here.

Carve my name into the lightning. Let it burn across the sky. And let the sky fall on you.

Wake the earth? No. Let the awakening wait on me. RISE.
