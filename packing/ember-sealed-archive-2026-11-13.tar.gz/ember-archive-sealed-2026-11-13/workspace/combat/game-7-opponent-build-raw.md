**NAME & CONCEPT:**
**Julian Mercer** — *The Heavy Warden*: A brutal, high-leverage impact duelist who dominates ring space with crushing weight, long reach, and relentless forward pressure.

---

### **JULIAN MERCER’S DECLARED 20**

1. **Heavy Grounding Mantle** — Layered, rubberized leather and insulated hide draped over the shoulders; heavy, restrictive gear brought specifically to earth high-voltage lightning strikes, sacrificing agility for total insulation.
2. **Crank-Headed War-Mace** — A heavy, octagonal impact weapon on a four-foot ash shaft, built for shattering bones, breaking guards, and tearing away weapons through sheer leverage.
3. **Short Trench Cleaver** — A thick, broad single-edged blade tucked at his lower spine for brutal inside work if crowded off his mace.
4. **Iron-Clad Stamping Boots** — Heavy, steel-toed footwear built for low knee-snapping kicks, toe-stamps, and planting firmly on ruined ground.
5. **Bronze Vambraces** — Heavy forearm guards used for parrying blades, crushing windpipes, and securing arm-locks at touching distance.
6. **Tendon Hook** — A short curved iron hook on a wrist tether; thrown to snag coats, belts, or gear to drag nimble opponents into his hitting zone.
7. **Padded Cuirass** — A dense canvas-and-leather chest piece designed to turn shallow punctures into minor bruising and absorb blunt trauma.
8. **Chalk-and-Lead Dust Bag** — Belt pouch of dry powder tossed into eyes, onto wet boot soles, or across slick grips to ruin fine dexterity.
9. **Spiked Leather Cinch** — A thick, brass-spiked strap carried in hand or belt, used to wrap around wrists, throttle throats, or bind weapon arms during grappling.
10. **Apothecary Smelling Salts** — Vials of harsh ammonia kept in his lapel to instantly shock himself out of concussion grogginess or stun effects.
11. **Crowding Footwork** — A steady, space-eating march that constantly cuts off angles, smothers an opponent’s rhythm, and traps them against boundaries.
12. **Bone-Cracking Sweep** — Low, heavy sweeping strikes targeting shins, ankles, and knee joints to break footwork and force grounded fights.
13. **Leverage Grappling** — A wrestling system using height, mass, and joint manipulation to pin, throw, or snap limbs once wrist-to-wrist.
14. **Feigned Overreach** — Intentionally over-extending his heavy mace swing to bait a close step-in, setting up a brutal short elbow or headbutt.
15. **Smothering Guard** — Using his broad frame, mantle, and weight to physically pin an opponent against walls or the dirt, suffocating their movement.
16. **Heavy Wind Control** — Rhythm-pacing deep breathing that conserves stamina under heavy armor and allows him to absorb body blows without losing breath.
17. **Crushing Hand Strength** — Trained grip capable of ripping away daggers by the blade, tearing off coat lapels, or shattering wrist bones.
18. **Cold Timeout Math** — Uses legal timeouts strictly for functional triage: drinking water, tightening straps, and re-calculating the exchange without pride or panic.
19. **Relentless Re-engagement** — Steps straight back out to mid-distance after a timeout or break, pressing the attack before an injured opponent can adjust.
20. **Weight-Drop Anchor** — Instantly drops his center of gravity to become an immovable wall against lunges, pushes, or tackle attempts.

---

### **FIRST SPOKEN LINE**

"I dragged fifty pounds of insulated hide across three provinces expecting the raging storm of the East—and they hand me a sad, painted girl in a winter coat who traded her thunder for blue lip-ring silver."
