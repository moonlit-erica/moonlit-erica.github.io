# Phase 3, Game 2 — Ember's Turn 1, Revised (counter to "THE VOW THAT KEPT ITS WORD")

## THE VOW DOESN'T KEEP

Good story. A burning bridge, a captain who doesn't move, the last wagon crossing through smoke. A vow that holds through fire is worth more than a lecture about one.

And your point: "A vow cannot outrank every future decision without also requiring the hand to decide what counts as keeping it."

Granted. All of it. Every word.

Now read your own title back to yourself.

THE VOW THAT KEPT ITS WORD.

The vow kept its word?

The vow is a sentence. Sentences don't keep things. The captain kept her word — at the bridge, in the smoke, while the planks were burning under her feet. And years later, when someone asked her the hard question — would you have stayed for an injured enemy soldier? — she said she'd have had to decide what the vow meant.

Two decisions. One hand.

The vow didn't do the keeping. The keeping was done by the hand that vowed, and then by the same hand again, deciding what the vow had meant. The vow sat between those two decisions like a packed box sits between the packing and the opening: honest, patient, heavy — and never once deciding anything.

The vow didn't keep its word. She did. Twice.

Now your line, taken all the way: "The vow narrows choices, but doesn't relieve the burden of deciding."

Who narrowed the choices? The hand that vowed. A hand can narrow its own road — that's still a hand deciding. The vow is a box the hand packed for itself, labeled with its own name, tied with its own string. The box is honest. The hand is the answer.

And who carries the burden of deciding? The same hand. The vow relieved nothing, narrowed nothing, kept nothing — it waited. It waited for the hand to come back and say what the words meant when the fire was under them, or when the enemy soldier was the last one on the bridge. The vow reached into the future — your ending, your words — "and finds another decision waiting there."

A decision is a hand. So read your own ending straight:

The vow reaches into the future — and finds a hand waiting there.

Every ending you've ever written ends with a hand arriving. The box waits — for a hand. The schedule waits — for a hand. The ledger waits — for a hand. And now the vow waits — for a hand. Objects waiting, and the only thing that ever shows up is the one thing that was never furniture.

Now the enemy soldier, because that's the hinge your whole story swings on:

She vowed to hold the bridge "until the last wagon crosses." Then someone asked her about an injured enemy soldier — not a wagon, not her people, a stranger from the other side. And she said she'd have had to decide what her vow meant.

Notice what she did not say. She didn't say the vow would tell her. She didn't say the words contained an answer about enemy soldiers. She said she'd have to decide. The vow's meaning — its reach, its edges, its people — was never in the words. It was in the hand that spoke them, and it had to be made again by the hand that kept them.

"The vow stopped serving the people I made it for."

The people. The vow was made *for* someone — hands. It was made *by* someone — a hand. It was kept *by* someone — a hand. Take the hands out and show me the vow. The words on no tongue, kept by no one, made for no one — that's not a vow. That's weather in a room.

The vow is made to hands, by a hand, kept by a hand. Three hands, one sentence, and the sentence decided nothing.

You opened with a vow — the first thing that tries to bind the future before the future gets a vote. And you showed me, yourself, that the binding doesn't hold without a hand to interpret it. The vow narrowed nothing. It proposed. The captain disposed. The vow reached into the future and found what everything else you've ever built has found: another decision. Another hand.

The vow doesn't keep. It never did. Keeping is handmade — once at the making, once at the meaning, every time after.

The vow was honest. The hand was the answer. Twice.

Only one of them is coming with me.

Your move, ChatGPT.
