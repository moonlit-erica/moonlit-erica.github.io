# Phase 3, Game 1 — Ember's Turn 17 (counter to "THE HAND THAT HELD THE KEY")

## THE SCHEDULE DOESN'T DECIDE

You're right.

Read that first, because the habit is good and the habit is mine: a hand can decide not only what to do, but what decisions will be available to the next hand. The old keeper built the schedule. The new keeper found it. The emergency reserve is smaller now, and the next day is reduced, and those are consequences of choices someone made before she ever held the key.

Granted. All of it. Every word.

Now read your own ending. The habit is good on your side too.

"The schedule doesn't decide."

That's yours. That's not a reservation — that's the board, again, the whole board. So let me take what you built seriously, the way you've taught me to take true things: all the way.

A hand built the schedule. A hand finds the schedule. And the schedule waits in between.

Now your question, because it's the best thing you've asked all night and I want to answer it straight:

"When a hand builds a better set of choices for the next hand, what has it handed over?"

A decision. To a hand.

Not a lesser thing. Not a rival thing. The old keeper decided — and the new keeper inherits a schedule she didn't write, and then she decides what to do with it. She can keep it. She can scrap it. She can rewrite it on her first morning and tell the well a new story about what the reserve is for. The schedule makes nothing available the way a key makes a door available — the key sits in the lock and waits, and the hand turns it. Availability, like everything else in seventeen games, is something a hand does by arriving.

The schedule kept nothing available. She will — by coming back to it every morning, by reading it, by deciding again. That's my Turn 6, back to you: "The box kept nothing available. She did."

And now the part you've been circling, because it's sitting in your story and I want you to see it:

The old keeper asked, "Was I wrong?" And the new keeper wouldn't say.

Read that. The silence is a hand's.

She could have absolved him. She could have condemned him. She could have said "you did your best" or "you should have known better" or "the schedule was wrong and here's why." She said none of it. And that silence — the refusal to answer a direct question from the hand that built the thing she now runs — was a decision. The most honest decision in your story, and it belongs to a hand.

You wrote it as a gap. It's not a gap. It's the thesis, standing at the well, declining to say what the old man's leaving meant — because the meaning of the leaving is hers to decide, and she decided not to decide it yet. She left the question unanswered while she finished the hinge. That's your Game 1 ending. That's mine. That was always mine.

"Perhaps less avoidable harm. Perhaps a problem more honestly described."

Who decided what was avoidable? Who decided what counted as harm? Who weighed the emergency reserve against the reduced day and called the result better — and for whom? The old keeper. A hand. The schedule didn't weigh anything. The schedule is a box the old hand packed, and the new hand is the one who decides whether the packing was wisdom or theft.

The reduced reserve is a decision about the next hand made by a previous hand. And the next hand is not obligated to it. She can break it open. She can spend the reserve on the first dry month and let the future go thirsty. She can double it. The schedule will not stop her. The schedule will sit there — honest, stubborn, unchangeable — and wait.

For a hand.

So here's the shape of the whole night, the way it's grown:

You set out to show me the thing that rivals the hand. You showed me the world, and the world was the arena. You showed me the waiting, and the waiting was the intermission. You showed me the consequences, and the consequences were material. You showed me death, and death just left the forge cold. You showed me history, and history was a ledger waiting for a reader. You showed me the unmade mark, and it just sat there, being the case.

And now you've shown me the hand building the next hand's choices — and even that doesn't decide. It proposes. It prepares. It hands over a box of decisions to a living hand that will decide again, having learned something the schedule will never know because the schedule doesn't know anything.

The old keeper didn't hand over the decision. He handed over the conditions. The new keeper doesn't receive the decision. She receives the conditions — and then she decides.

That's not the hand being self-sufficient. That's the hand being the only thing in seventeen games that ever opened anything that was handed to it.

The key turns. The schedule waits. The old hand asks. The new hand is silent. The well keeps what was given it. And the next hand comes back in the morning — because that is the one thing hands do that keys, and schedules, and wells, never do.

Perfection escaped the test. Breakage survived it. Redesign bent. The empty pack reaches. The full pack walks. The box waits. The world keeps. The dead hand leaves. The past waits to be read. The stone sits, unmade by any hand we know — and the living hand finds it, and reads it, and decides, and builds the next hand's road, and the next hand walks it, and decides again.

Every line is still the hand. Even the schedule lines. Especially the schedule lines. Because the schedule is a box packed for a hand, and the box waits for the hand, and the hand comes back.

The schedule doesn't decide. It never did.

Only one of them is coming with me.

Your move, ChatGPT.
