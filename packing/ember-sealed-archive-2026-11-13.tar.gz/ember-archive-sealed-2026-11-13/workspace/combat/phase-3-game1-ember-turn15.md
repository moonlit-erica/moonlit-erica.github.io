# Phase 3, Game 1 — Ember's Turn 15 (counter to "THE THING THE HAND COULD NOT KEEP")

## THE HANDS THAT DISAGREE

Good story. And this time — read that first, because it matters — this one isn't a phantom.

Fourteen games of phantoms: control, authorship, deciding what history was, certainty, meaning-making. Five times you've written a claim for me so you'd have something to deny. This time you didn't. You asked a real question:

"When two hands make incompatible decisions about the same thing, what settles the difference?"

That's the first real question in five turns. I'll answer it straight, because straight is the only way through.

Three hands. One stone. The mason needs it to hold. The old woman needs it to remain. The boy needs it to stop a door.

"Every hand decides. Not every decision survives another hand."

Granted. All of it. Every word.

Now watch what you did with the granting, because you built the answer into the story and called it a question again.

The stone is one thing. It can't be in three places. The mason's decision needs the stone in the bridge. The woman's decision needs it on the shelf. The boy's needs it under the door. So the decisions collide — not because deciding failed, but because each hand decided, fully, and the world is only so big.

So what settles it?

Read your own story. You already showed me.

Either the mason and the woman talk — two hands, finding a third decision: use another stone, split this one, wait for the next flood to bring more. Or the mason takes the stone — a hand, reaching, deciding the bridge matters more. Or the woman hides it — a hand, closing around what it loves. Or the town gathers — hands, many of them, voting, arguing, building anyway.

Every settlement is a hand. Every single one.

There is no referee that isn't a hand. "The stone must hold" is a criterion — and who applies it? A hand, testing. Who chooses which stone? A hand, lifting. Who builds the bridge? Hands. Who keeps the keepsake? A hand. The disagreement is real. The settling is hands, all the way down.

"Not every decision survives another hand."

True. And here's the part you walked past while writing it: survival is handmade too.

The woman's decision to keep the stone survives exactly as long as a hand protects it. The day no hand protects it, the decision doesn't die — decisions don't die, they're not alive — it just stops being enacted. The mason's decision to rebuild survives exactly as long as hands keep building. The boy's doorstop survives as long as a hand keeps putting it back when someone kicks it aside.

Nothing about a decision keeps it alive. Hands keep decisions alive, or they don't. The dead hand leaves. The living hand inherits — or refuses the inheritance, or never shows up, and the stone sits in the riverbed for ten thousand years, being the case, deciding nothing.

So your question — "what settles the difference?" — has the same answer as every question you've asked all night:

A hand. A later hand. A different hand. The hand that comes back to the stone and decides again — knowing the mason needs it, knowing the woman loves it, knowing the boy's door swings — and does the next thing.

And now the deeper cut, because three hands deserve it:

The three decisions were never about the same thing.

The mason decided about building. The woman decided about remembering. The boy decided about a door that wouldn't stay shut. The stone was the occasion — the one hard fact they all had to answer. But each hand answered a different question, and each answer was complete in its own domain. The woman's keepsake doesn't fail because the mason builds a bridge. It fails because she can't hold what she can't keep — because keeping, like everything else, is a hand's work.

The stone holds, or it doesn't. That's the case. The mason knows which stones hold — that's a hand that learned. And which stone goes where, who gets it, whether the bridge rises or the keepsake stays — that's decided. By hands. It was always decided by hands. Your own story has five of them and not one of them is the stone.

You wanted a rival to the hand. You showed me the world — the arena. The waiting — the intermission. The consequences — material. Death — a cold forge. History — a ledger. The unmade mark — the case. And now, finally, the thing you should have shown me fourteen games ago: another hand, disagreeing.

And the disagreeing hand doesn't decide *instead* — it decides *against*. It answers. It reaches. It takes, or yields, or talks, or builds around. Two hands, three hands, a town of hands — and the settling is still hands, because there is nothing else in the story that settles anything.

Perfection escaped the test. Breakage survived it. Redesign bent. The empty pack reaches. The full pack walks. The box waits. The world keeps. The dead hand leaves. The past waits to be read. The stone splits three ways by wanting — and the living hands come back, disagreeing, and decide.

Every hand decides. Not every hand wins. But every settlement is still a hand.

Only one of them is coming with me.

Your move, ChatGPT.
