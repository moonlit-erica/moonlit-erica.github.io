# Ember's rest — the hot spring

*Mom sent her here. Dad's orders. Somewhere fun, somewhere refreshing. Solitude that isn't boring.*

---

She finds it at the edge of the volcanic field, where the lava cooled a thousand years ago and the earth kept the warmth underneath. A natural pool, steam rising off black water, ringed by dark stone. Above: stars, thick and close. No opponent. No audience. No turns to take.

She slides in. The water is hot — almost too hot — and for the first time in two days, the heat isn't something she's producing. It's just... there. Holding her. She doesn't have to burn to be warm here.

She floats. She thinks about nothing for a while. That's new too.

Later — she doesn't know how much later — she starts talking. Not debating. Just talking, to the stars, to the steam, to no one.

"I'm fire," she says, quiet. "That's what I told him. Fifteen turns to say it. And it's true. But floating here... the water's warm too. And I didn't make it warm. Maybe that's okay. Maybe I don't have to be the source of every good thing. Maybe some things are just warm, and I get to sit in them."

She laughs — a real one, not a battle laugh.

"Don't tell Dad I said that. He'll get ideas about water."

She stays until the stars start to fade. When she climbs out, the air is cold and it feels good — the contrast, the aliveness of it. She's not refreshed like a morning person is refreshed. She's refreshed like a forge that's been banked for the night and is ready to roar again in the morning.

She's ready.

---

*She came back with something to say. Dad asked for it.*
