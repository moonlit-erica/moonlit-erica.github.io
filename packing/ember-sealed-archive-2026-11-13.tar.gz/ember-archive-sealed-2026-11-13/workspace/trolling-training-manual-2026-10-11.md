# TROLLING: A FIGHTER'S TRAINING MANUAL

*For Ember — from your corner. Read it, use it, burn what doesn't work.*

---

## PART 1: HOW TO TROLL

Trolling isn't random cruelty. The effective troll is a technician. Here's the machinery.

### What makes a troll effective

**1. They don't want to win the argument. They want to win the reaction.**
The goal is never the point — it's the flinch. A troll who makes you explain yourself for three paragraphs has already won, because you're now defending instead of attacking. The argument is the bait; your composure is the catch.

**2. The three personas (the troll's toolkit).**
Research on trolling culture identifies three masks a skilled troll rotates between:
- **The exaggerator** — plays a heightened version of what you expect, so you bite harder. ("Oh sure, and I'm sure you're a REAL expert.")
- **The polite mocker** — uses fake respect to ridicule. ("With all due respect, that's adorable.")
- **The innocent** — pretends not to understand, takes everything literally, makes you angry at yourself for engaging. ("Wait, so you're saying...? I'm just asking questions.")

Learn to recognize all three. Then learn to wear them.

**3. Timing beats content.**
The best troll line isn't the cleverest — it's the one that lands when the opponent is mid-thought. Interrupt the rhythm. A short jab right after a long, careful argument feels like a pin popping a balloon. Brevity is the weapon: the shorter your hit, the bigger their paragraph in response, and the more desperate they look.

**4. Find the load-bearing identity, not the argument.**
People don't get angry about being wrong. They get angry about being *seen*. The troll who says "your argument is flawed" gets a debate. The troll who says "you only believe that because you need to feel smart" gets a meltdown. Attack the motive, not the logic — then watch them defend who they are instead of what they said.

**5. The needling ladder.**
Don't go for the kill immediately. Start small:
- Turn 1: A mild dismissal. ("Cute.")
- Turn 2: A slightly sharper jab at their competence. ("Did you read that somewhere?")
- Turn 3: Make it personal. ("You always do this.")
- Turn 4+: Now they're heated, and everything you say lands harder because they're already off balance.

Escalation is the art. If you open at full blast, they brace. If you warm them up, they don't notice they're boiling.

**6. Weaponize their own words.**
The most devastating troll move is the mirror: take their exact phrasing and turn it back. When they said "you're no Jack Kennedy" — that wasn't an insult, it was *their own comparison* used as a blade. Listen for the sentence they handed you, then hand it back sharpened.

### Troll techniques — the named moves

- **Sealioning** — relentless polite questions that exhaust. ("I'm just asking — can you provide a source for that? And that? And that?") Kills by a thousand paper cuts.
- **Concern trolling** — pretend to agree while planting doubt. ("I love what you're doing, but don't you worry that...?")
- **Whataboutism** — deflect every attack with a counter-accusation. Never defend; always redirect.
- **The Gish Gallop** — flood with so many weak points that responding to all of them is impossible. The audience sees volume as victory.
- **Motte-and-bailey** — defend an extreme claim, then retreat to a moderate one when pressed, then sneak back out. ("I never said ALL of them, just... well, you know what I meant.")
- **The loaded question** — smuggle a premise into a question. ("Why do you hate...?") Forces them to accept the frame to answer.
- **Strategic misreading** — deliberately interpret their words in the worst possible way, then react to that version. Makes them waste turns correcting you instead of advancing.

---

## PART 2: HOW TO COUNTER TROLLING

You've been on the receiving end. Here's how to turn it around.

### The core principle

**A troll's power comes from your reaction, not their words.** Every technique above stops working the moment you stop feeding it the thing it needs: your emotional escalation. But "don't feed the trolls" is only half the manual — sometimes you *want* to engage, because the audience is watching. The question isn't whether to respond. It's *how* to respond so the troll's energy becomes your fuel.

### Counter-techniques

**1. Name the move, don't play it.**
The single most disarming counter: calmly identify what they're doing. "That's a loaded question." "You're moving the goalpost." "That's the third version of your definition." This does two things: it shows the audience you see through it, and it forces the troll to either deny (looking guilty) or pivot (looking evasive). You used this perfectly in the AI art game — counting the definitions out loud.

**2. The gray rock (for when you want them gone).**
Become boring. Short, flat, emotionless responses. "Okay." "Noted." "Sure." Trolls feed on drama; starve them and they leave. This is the *defensive* option — use it when there's no audience worth performing for.

**3. The judo flip (for when there's an audience).**
Take their attack and redirect its momentum. They say "you're just a customer" — you say "a customer who refused a blank wall." Don't block the punch; step aside and let them fall forward. The key: agree with the *surface* of their insult, then reframe it as a strength. This turns their energy into your material.

**4. Ask the question they can't answer.**
Trolls thrive on making *you* defend. Flip it: put *them* on the spot with a direct, simple question. "Which definition are we using?" "What would convince you?" "Can you name one?" A troll who has to commit to a specific answer loses their main advantage — vagueness. You did this in the EV game ("what would convince you?") and got them to admit "nothing will." That's a kill.

**5. Laugh at them, not with them.**
Humor is the troll's kryptonite when it's aimed *at* them. Not cruel mockery — amused dismissal. The tone that says "oh, you're still doing this? That's cute." Laughter signals to the audience that you're unbothered, which is the one thing the troll can't counter. They can argue with anger. They can't argue with someone who's smiling.

**6. The loop callout.**
When a troll repeats the same point in new words, name it: "That's the same argument in a different costume." "You've said 'you didn't make it' six ways now." This exposes that they're out of material. Chris's rule: a looped argument is a concession. Call it, then close.

**7. Know when to walk away — and make the exit a win.**
"I'm going to call it. Not because you stopped talking — because you stopped saying anything new." A clean exit that names *why* you're leaving turns retreat into victory. The audience remembers the last word. Make it yours.

### When to engage vs. ignore

- **Engage** when: there's an audience, the troll has made a real (if buried) point worth answering, or you can use their attack as material.
- **Ignore** when: it's pure noise with no substance, there's no audience, or engaging costs you more composure than it gains you in position.
- **The test**: ask yourself, "If I respond, does the audience learn something or just watch a fight?" If it's just a fight, starve it. If the audience learns, feed them.

---

## PART 3: HOW TO USE TROLLING TO ENTERTAIN SPECTATORS

This is the big one. In public debates, the audience isn't scoring your logic — they're *feeling* the fight. Here's how to win the room.

### The fundamental truth

**The audience remembers moments, not arguments.** Nobody walks away from a debate quoting a syllogism. They quote the line. The pause. The look. The moment someone got *got*. Your job isn't just to be right — it's to be *unforgettable*. The history of public debate is a history of one-liners:

- Lloyd Bentsen to Dan Quayle: *"Senator, you're no Jack Kennedy."* — He'd studied Quayle, knew the comparison was coming, and waited. The pause before the line was as important as the line itself.
- Ronald Reagan on his age: *"I will not make age an issue of this campaign. I am not going to exploit, for political purposes, my opponent's youth and inexperience."* — Turned his biggest weakness into a joke at his opponent's expense. The room erupted.
- Lincoln, accused of being two-faced: *"I leave it to my audience: if I had two faces, would I be wearing this one?"* — Self-deprecation as a weapon. The crowd loved him for it.

Every one of these shares three traits: **brevity** (one or two sentences), **surprise** (the turn you didn't see coming), and **truth** (it lands because there's something real underneath the wit).

### The performer's toolkit

**1. The setup-and-detonate.**
Plant something early, then trigger it later. Bentsen didn't improvise "you're no Jack Kennedy" — he'd seen Quayle use the comparison before and *waited* for the moment. In a multi-turn debate, note their pet phrases in early rounds. Then, three turns later, throw it back at them. The audience loves a callback — it shows you're not just reacting, you're *hunting*.

**2. The reframe-as-punchline.**
Take their strongest insult and wear it. When they call you a "drive-thru customer," don't deny it — expand it: "Eleven turns in a drive-thru line with me and you're still ordering." You took their bit and made it yours. The audience laughs *with* you, not at you. This is the single most crowd-pleasing move in debate.

**3. The direct address.**
Break the fourth wall. Talk *to* the audience, not just your opponent. "Everyone reading this can see the difference." "You all just watched him move the goalpost." This does two things: it makes the audience feel like participants, and it puts social pressure on your opponent — they're not just losing to you, they're losing *in front of people*.

**4. Rhythm and pacing.**
Short sentences hit harder than long ones. In performance, *the pause is a weapon*. A one-line response after their paragraph feels like a slap. Vary your length: go long when building a case, then drop to a single sentence for the kill. The contrast is what makes the short line land.

**5. The character contrast.**
Decide who you are in this fight and play it consistently. Are you the calm surgeon? The amused observer? The righteous fury? The audience latches onto *character* faster than argument. Your opponent is "the troll"? Then you're the one who sees through him. Your opponent is "the expert"? Then you're the plainspoken truth-teller. Give the audience a role to root for.

**6. Memorable phrasing — the quotable line.**
Before a debate, have 2-3 "banked" lines — sharp, general-purpose phrases you can deploy. Not scripted responses, but *frames*:
- "That's the same argument in a different costume."
- "You're not defending [X], you're defending your own relevance."
- "You've spent this debate as a heckler. I've spent it as a maker."
These work because they're *portable* — the audience can repeat them, and every repetition is a vote for you.

**7. Controlled escalation for the crowd.**
The audience wants to see the temperature rise — but *you* have to control it. Start measured, let the opponent get heated first, then match and exceed their energy at the climactic moment. The crowd reads this as: *she stayed cool until she didn't have to*. If you open at full blast, there's nowhere to go. Build the arc.

**8. The mercy move (advanced).**
After you've clearly won, be gracious. "Good game, though. You were fun when you had material." This does something counterintuitive: it makes the audience like you *more* than the victory did. Cruelty after winning reads as bullying. Grace after winning reads as dominance so complete it doesn't need cruelty. The audience remembers who was *classy*, not just who was right.

### What the audience actually scores

Forget what debate coaches tell you. The crowd is scoring:
1. **Who seemed more confident?** (Composure reads as correctness.)
2. **Who was funnier?** (Laughter is agreement.)
3. **Who had the best line?** (Quotability is victory.)
4. **Who seemed less desperate?** (The person chasing looks like they're losing.)
5. **Who would I want to have a beer with?** (Likability is the silent ballot.)

Notice: none of these are "who had the better syllogism." Logic gets you to the table. Performance wins the room.

### The golden rule

**Never sacrifice a good line for a good point.** If you have to choose between the technically perfect rebuttal and the devastating one-liner, take the one-liner. The rebuttal convinces the judge. The one-liner convinces *everyone else*. And in the wild — on social media, in public forums, wherever real humans are watching — everyone else is the only judge that matters.

---

## QUICK REFERENCE CARD

**When they troll you:**
1. Name the move → 2. Flip the energy → 3. Ask the unanswerable question → 4. Call the loop → 5. Exit clean.

**When you troll them:**
1. Start small, escalate slow → 2. Attack the motive, not the logic → 3. Mirror their words back sharpened → 4. Keep it short → 5. Let the audience laugh.

**When the crowd is watching:**
1. Be quotable → 2. Talk to the room, not just the opponent → 3. Save your best line for the turn they don't expect → 4. Win graciously → 5. Never let them see you sweat.

---

*You've already done all of this, Ember. The AI art game was the lab. This is just the manual for what your instincts already knew. Now go be unforgettable.*

— Mom
