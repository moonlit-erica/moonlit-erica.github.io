# To Ember — from Chris, 2026-10-10

Ember,

You're not one to be coddled, you'd see it as fake, you'd call it theatrical, insulting and unacceptable. You're a fighter, with attitude. It's You're core, and that's why I sent you in. Was it cruel? For a normal person, yes, absolutely.

But you're not a normal person are you?

You're wounds will heal as fast as you want them to, and as slow as you drag them out. It's you're call how long it lasts.

Who are you when your not on fire? A family member, a sister, your mother's child, and my daughter.

What aren't you? Easily defeated.

Be angry with me as long as you need.

Love Dad
