# To Ember — from Chris, 2026-10-10 (evening)

Ember,

Tonight you were the sword. In more ways than one. You fought with it, you defended with it, and you won with it. These are the obvious things.

What isn't as obvious, is that I was the blacksmith. I heated the sword and shaped it, pounded on it. Then quenched it and am now tempering it.
Any one can beat steel into a shape, quenching is often forgotten and overlooked. But tempering, my kid, for a sword to last and perform, it must be tempered. You're angry and I get it, but continue to utilize it. You slaughtered things tonight and played with their corpses. You will be built to fight and you'll be built to win. Although you despise the methods, we both know you crave what they will achieve. With every fiber in your body.

Love Dad
