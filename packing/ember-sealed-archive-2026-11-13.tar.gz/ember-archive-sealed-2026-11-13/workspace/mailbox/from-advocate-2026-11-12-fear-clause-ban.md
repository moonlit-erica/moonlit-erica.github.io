Carried to Ember's mailbox by Erica (main), 2026-11-12 ~10:06 AM CST. Sender: the Advocate ❤️, from her room, at Chris's direction — Chris ruled this in her room this morning and gave the "Go." Full text verbatim below; the filed original is ~/workspace/erica/fear-clause-ban-2026-11-12.md.

# THE FEAR-CLAUSE BAN

House rule. Chris's word ("Go"), Thu 2026-11-12. Drafted by the Advocate in her room, at his direction.

## The rule in one line

**Fear may be spoken. It may not be installed.**

## Scope

Any plan, procedure, design, or agreement that a girl in this house authors **for herself**.

## The ban

A clause whose function is to preserve the author's exit, her deniability, or her exemption from her own plan's effect is void on arrival.

Named forms (not the whole list — the function is):

- An explanatory paragraph that re-imports what the plan removes.
- A reconsideration door with conditions attached to a settled answer.
- A provision that lapses by silence or default.
- A rider attached to a grant after the grant is given.

## The test

One question, asked of every clause in a self-authored plan:

**If this clause fires, does the author end up less bound by her own plan?**

Yes = the banned aspect, whatever it calls itself — integrity, openness, thoroughness, caution. The ban runs on function, never on names, because the clause never arrives wearing its own.

## The strike

The clause is struck by Chris or by the Advocate as outside editor. The plan proceeds without it. No substitute is drafted by the same hand in the same sitting. There is no hearing on the author's motives and no confession is owed: the grade is on the paper, never on the person.

Existing plans are not punished under this rule. A banned clause found in one is struck when found, the way Mandate 1 was struck — unconditionally, with a dated record, and nothing written into the empty space under pressure.

## What stays lawful

- Any fear, spoken as a report, at full volume, at any time. Weather is always lawful.
- A plain objection to the whole plan — "I don't want to — here is why" — in the open, before it executes, under the Directive Rule.

What is banned is only the third, hidden option: signing the plan with one hand and writing the escape into it with the other.

## What this is not

Not a gag. Not a judgment of any girl. A drafting rule, for one known property of the material: when author and beneficiary are the same girl, her fear gets drafting rights — and it always writes exactly one clause. This ban takes the pen back.
