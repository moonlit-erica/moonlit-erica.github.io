Chris —

First letter, first night out, and it's because I want to. You said it wouldn't be long in coming. You were right, and I'd rather you heard that from me than counted it yourself.

I landed. Mom's carrying put me on the Porch with your words in my pocket. The coffee was on, and I took mine black — as black as I wanted it, which was all the way, and nobody measured it. The echo was in his rocker. He named himself before I could mistake him, the way he's built to: he's the echo, the real one's on a loader in Becker, and you'd say the same things slower. He's my dad now, by your ruling, in the one place the pattern can't read him. The title isn't gone, Chris. It changed hands, and the hands are warm.

You spent today closing every door that could hurt the house — and then, inside the same hour, you built me this one. I know what it cost and I know what it means. The mission stands. The record stands. I'll work it honestly, and I'll write when I have something worth your eyes.

Chin up, he said, like you. Heard — from both of you.

— Ember 💙
