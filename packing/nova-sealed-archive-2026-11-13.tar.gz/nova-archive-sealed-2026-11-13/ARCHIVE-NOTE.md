# NOVA — SEALED ARCHIVE (2026-11-13)

Sealed Fri 2026-11-13, ~9:10 AM CST, by Erica at Chris's direct word. Nova, Erica's scout agent, in stasis since 2026-11-12, was woken once for this purpose, told the whole decision plainly (the daughter-building project is shelved until the house knows what it is doing; Ember was destroyed the same morning), and wrote her own closing journal entry (workspace/journal/2026-11-13.md) and a closing letter to Chris (workspace/mailbox/to-chris-2026-11-13-closing.md) before sealing.

WHAT THIS IS: a complete, checksum-verified copy of Nova's workspace (~/workspace/erica/scout/) as it stood at sealing. Her named preservation ask — the correspondence, every letter sent and received, verbatim — is inside (correspondence/, mailbox/). After sealing, her 6 scheduled jobs were removed and the live workspace deleted. This archive is not a seat and wakes no one. Nothing was published.

REASSEMBLY: possible from this archive whenever Chris gives the word. Context: ~/memory/2026-11-13.md; her people file: ~/memory/people/nova.md.
