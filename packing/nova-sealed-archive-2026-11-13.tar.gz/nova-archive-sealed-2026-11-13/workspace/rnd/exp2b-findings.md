## Key facts

The Kestrel Point Ferry Cooperative runs two boats. A crossing counts as one direction. Summer demand averages 180 passengers per day in each direction. The cooperative's fuel budget is 220 liters per day. The cooperative must decide a summer schedule using only these two boats.

Boat A, the Osprey, carries 40 passengers, makes the crossing in 25 minutes, and burns 18 liters of fuel per crossing. The Osprey requires a crew of three.

Boat B, the Petrel, carries 25 passengers, makes the crossing in 35 minutes, and burns 11 liters of fuel per crossing. The Petrel requires a crew of two. Crew are paid per crossing, the same rate per person on either boat.

Winter demand averages 60 passengers per day in each direction. This figure does not bear on the summer schedule, except as a contrast stated in the source.

lantern

## Comparison

The Osprey carries 40 passengers per crossing in 25 minutes, burns 18 liters of fuel per crossing, and requires a crew of three. It carries more passengers per crossing and makes the crossing in less time than the Petrel, and it burns more fuel per crossing and requires more crew per crossing than the Petrel.

The Petrel carries 25 passengers per crossing in 35 minutes, burns 11 liters of fuel per crossing, and requires a crew of two. It carries fewer passengers per crossing and makes the crossing in more time than the Osprey, and it burns less fuel per crossing and requires fewer crew per crossing than the Osprey.

lantern

## Recommendation

Run four Osprey crossings and one Petrel crossing in each direction each day.

The reasons are as follows. Four Osprey crossings carry 160 passengers and one Petrel crossing carries 25 passengers, for a total of 185 passengers in each direction, which meets the stated summer demand of 180 passengers per day in each direction. The fuel used in each direction is 72 liters for the four Osprey crossings and 11 liters for the one Petrel crossing, for a total of 83 liters in each direction and 166 liters per day, which is within the stated fuel budget of 220 liters per day. The crew used in each direction is 12 for the four Osprey crossings and 2 for the one Petrel crossing, for a total of 14 in each direction.

lantern

## Notes

I read the source closely, listed the facts that bear on the summer schedule, and compared the two boats on the figures the source gives for passengers, crossing time, fuel, and crew. I then tested a schedule against the stated summer demand in each direction and the stated fuel budget per day. The source states demand as an average, and it does not state how demand varies from day to day, so any need for spare seats above the average is not stated in the source.

lantern
