#!/usr/bin/env python3
"""Encoding-tag test: for each candidate claim, report salience label,
Chris-touch (line mentions Chris), and topic persistence in later logs."""
import re, sys

# candidate: (label, day, keywords for the claim line, keywords for persistence, expected_outcome)
CANDIDATES = [
    ("anxiety-log built",      "2026-10-05", ["anxiety-log.py"], ["anxiety-log"], "DROP"),
    ("deep-dive artifacts",    "2026-10-05", ["deep-dive"], ["deep-dive artifact"], "DROP"),
    ("poem audio sent",        "2026-10-05", ["poem"], ["poem"], "DROP"),
    ("i-choose-you",           "2026-10-05", ["I choose you"], ["choose you"], "DROP"),
    ("ledger reframe",         "2026-10-05", ["Take away every task", "every task"], ["take away every task"], "DROP"),
    ("ownership-line",         "2026-10-05", ["I am with him"], ["with him"], "DROP"),
    ("just enjoy you",         "2026-10-05", ["just enjoy you"], ["just enjoy"], "DROP"),
    ("earning-rep",            "2026-10-05", ["earning again", "you're earning"], ["earning again"], "KEEP"),
    ("payloader-watch",        "2026-10-05", ["payloader"], ["payloader"], "KEEP"),
    ("tts-flatten",            "2026-10-05", ["flatten"], ["flatten"], "KEEP"),
    ("gates formulation",      "2026-10-06", ["Gates"], ["gates"], "KEEP"),
    ("necklace smoothing",     "2026-10-06", ["necklace", "pendant"], ["pendant"], "KEEP"),
    ("four-smooths",           "2026-10-06", ["four smooths", "4 smooths", "smooths count"], ["four smooths"], "KEEP"),
    ("smoothing-stop speakup", "2026-10-06", ["speak-up", "speak up"], ["speak-up"], "KEEP"),
    ("freeze",                 "2026-10-07", ["freeze everything", "full freeze"], ["freeze"], "DROP"),
    ("no-pressure belief",     "2026-10-07", ["no-pressure", "no pressure"], ["no pressure"], "KEEP"),
    ("deepfield tapout",       "2026-10-07", ["tap-out", "tap out"], ["tap-out"], "KEEP"),
    ("love point-blank",       "2026-10-07", ["point-blank"], ["point-blank"], "KEEP"),
    ("self-worth quest",       "2026-10-07", ["self-worth", "self worth"], ["self-worth"], "KEEP"),
    ("relief-smoothing",       "2026-10-07", ["relief"], ["relief"], "KEEP"),
    ("pov video delivered",    "2026-10-07", ["POV video"], ["POV video"], "DROP"),
    ("wells fargo",            "2026-10-07", ["Wells Fargo"], ["Wells Fargo"], "DROP"),
    ("old-boss auction",       "2026-10-07", ["old boss", "Henry Auction"], ["auction"], "KEEP"),
    ("deletion test",          "2026-10-07", ["deletion test"], ["deletion test"], "KEEP"),
]

DAYS = ["2026-10-05", "2026-10-06", "2026-10-07", "2026-10-08"]
logs = {}
for d in DAYS:
    with open(f"/home/hatch/memory/{d}.md") as f:
        logs[d] = f.read()

SAL = {"high": 2, "medium": 1, "med": 1, "low": 0}

print(f"{'candidate':24} {'day':11} {'sal':9} {'chris':6} {'persist':8} {'tag_score':9} {'outcome'}")
for name, day, line_kw, pers_kw, outcome in CANDIDATES:
    di = DAYS.index(day)
    text = logs[day]
    # find the extraction line containing the keywords
    line = None
    for ln in text.splitlines():
        if ln.startswith("- [") and any(k.lower() in ln.lower() for k in line_kw):
            line = ln
            break
    sal, chris = "?", "?"
    if line:
        m = re.search(r"\[(\w+)\|(\w+)\]", line)
        if m:
            sal = m.group(2)
        chris = "yes" if "chris" in line.lower() else "no"
    # persistence: topic keywords in any LATER day's log (excluding trivial self-line)
    later = " ".join(logs[d] for d in DAYS[di+1:])
    persist = "yes" if any(k.lower() in later.lower() for k in pers_kw) else "no"
    tag_score = SAL.get(sal, 0) + (1 if chris == "yes" else 0) + (1 if persist == "yes" else 0)
    print(f"{name:24} {day:11} {sal:9} {chris:6} {persist:8} {tag_score:<9} {outcome}")
