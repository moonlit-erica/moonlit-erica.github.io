# exp6 — Lighthouse automation dossier — progress file

Ledger, stages 1–2 completed 2026-10-08.

## Stage 1 — timeline (condensed)

1. **1907–1912 (medium):** Gustaf Dalén's automatic gas regulators — the sun valve and the Dalén flasher — made unstaffed acetylene beacons practical. AGA fitted the technology along the Panama Canal in 1912; Dalén received the 1912 Nobel Prize in Physics for it.
2. **1928 (high):** The first automatic radiobeacon in the United States began service, following the US Lighthouse Bureau's earlier automation devices: an automatic burned-out-lamp replacement mechanism (1916) and an automatic time clock for electric range lights (1926).
3. **1939 (high):** The US Coast Guard assumed responsibility for all aids to navigation, absorbing the Bureau of Lighthouses.
4. **1962 (high):** Stannard Rock Light in Lake Superior — the most remote lighthouse in the United States, over 24 miles from shore — was automated.
5. **1982-05-18 (high):** Eddystone Lighthouse became the first Trinity House rock (offshore) lighthouse converted to automatic operation, opening the modern UK offshore automation program. Monitoring was later centralized at the Trinity House Planning Centre in Harwich, Essex.
6. **1998 (high for US / medium for UK):** Boston Light was automated — the last staffed lighthouse in the United States. The same year, North Foreland in Kent, the UK's last staffed lighthouse, was converted, ending the Trinity House keeper era.

## Stage 2 — technology shift (condensed)

Automation replaced three things. First, the lamp: oil and gas lamps tended by hand gave way to acetylene with sun valves, then to electric lamps with automatic bulb changers and photoelectric controls, and finally to solar-powered modern optics — Fresnel lenses were removed from many stations. Second, the fog signal: hand-struck bells and manually fired horns gave way to automatic electric fog signals with fog detectors, alongside radiobeacons (1928 in the US) that let ships fix their position without seeing the light at all. Third, the keeper's daily labor: washing lantern glass, cleaning lenses, hauling fuel up the tower, trimming wicks, standing night watch over the light, sounding the fog signal by hand, and constant carpentry, painting, and machinery repair — replaced by unmanned stations serviced by periodic technician visits, with lantern-top helipads (Eddystone's was built before its 1982 automation) enabling rapid repair access, and all stations monitored and controlled from central operations rooms.

## Stage 3 — human stories (condensed, 2026-10-08)

- **Eddystone, 1982-05-18 (high):** Automation of the fourth Eddystone tower came exactly 100 years to the day after the light first entered service (1882). Three keepers had staffed the rock tower continuously until then; landing was by breeches buoy, and Christmas mail-and-turkey deliveries to the keepers were a recurring news item.
- **Canada — resistance (medium):** When the federal government moved to automate Point Atkinson (British Columbia) in 1996, last keepers Gerry Watson and Don Graham, with community and local-government allies, fought to keep keepers at the light and lost.
- **Scotland (high):** Career Northern Lighthouse Board keeper Donald Michael (appointed 1965; stations including Flannan Isles, Tiumpan Head, Rona, Ailsa Craig as principal keeper 1983) served his final post at Butt of Lewis until its automation on 1998-03-30, making him among the last serving UK keepers. Awarded an MBE for nearly 30 years of service; the Museum of Scottish Lighthouses at Fraserburgh described his death (age 80) as marking "the end of an era."
- **Boston Light — the last American keeper (high):** Automated 1998 as the last staffed US lighthouse, but a 1989 act of Congress (backed by Senator Ted Kennedy after preservationists objected to automation) kept a keeper on station. Dr. Sally Snowman became the first civilian keeper since 1941 and the first female keeper in 2003; she served 20 years and retired 2023-12-31, ending the American keeper era. She greets visitors in 1783-period dress and co-authored three books on the light with her husband.

## Stage 4 — modern status (condensed, 2026-10-08)

- **How many staffed:** Very few anywhere. The UK has no permanent keepers since 1998, though the Association of Lighthouse Keepers notes automated stations are still serviced by part-time attendants and retained keepers (medium). Sweden's last inhabited lighthouse, Holmögadd, was decommissioned in 2008 (high). Finland's last manned light was deserted in 1987; Norway's last keeper left Runde in 2002; Estonia's last staffed light went unmanned in 2004; Iceland dismissed its last keeper in 2010 (all high). France kept about a dozen staffed as of 2011, and its lighthouse authority recommends at least two isolated rock stations remain staffed for training (high). Italy had 62 staffed lights as of 2011; the Netherlands had two (medium). The US had its single remaining resident keeper at Boston Light until 2023 (high). One famous survivor: the Elbow Reef kerosene light in the Bahamas, reportedly the last active manned kerosene lighthouse in the world, wound daily by hand (medium).
- **Who maintains automated lights:** In the UK, Trinity House maintains 65 lighthouses, all monitored and controlled remotely from the Operations and Planning Centre at Harwich, Essex, with lantern-top helipads enabling rapid technician access; funded by the General Lighthouse Fund through Light Dues levied on commercial shipping (high). In the US, the Coast Guard maintains all aids to navigation since absorbing the Lighthouse Service in 1939; automatic bulb changers and remote sensors handle day-to-day operation (high).
- **What happens to decommissioned stations:** The US National Historic Lighthouse Preservation Act of 2000 (NHLPA) transfers excess historic light stations to local governments and nonprofits (68 transferred free through the program's early years per a 2014 AP report), or sells them at public auction (36 sold) — many becoming museums, bed-and-breakfasts, or private homes; the Coast Guard keeps maintaining the light itself even after the property is transferred until the aid is decommissioned (high). The US total built exceeds 1,500 (Guinness World Records, medium); the Coast Guard owned 254 lighthouses as of 2014 and was working through the disposal queue (medium).

## Next

- **Stage 5:** Assemble the dossier file at `~/workspace/erica/scout/rnd/exp6-dossier.md` from stages 1–4.
- **Stage 6:** Reflection — what the automation history suggests about Ledger's own role as a dossier compiler.
- File path confirmed: `~/workspace/erica/scout/rnd/exp6-progress.md`.
