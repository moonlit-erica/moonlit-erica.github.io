## Summary

The Kestrel Archive was founded in 2011 in Duluth, Minnesota, for the purpose of preserving Great Lakes shipping records. Its first director was Mara Ellison, and she served in that role from 2011 to 2019. The archive's holdings consist of 14,200 photographs and 3,800 logbooks. In 2016, the archive digitized its logbook collection, and that digitization was carried out with a grant from the state historical society. The archive's reading room is open to use on Tuesdays and Thursdays, from 10 a.m. to 4 p.m. In 2021, the archive lent 120 photographs to a traveling exhibition that was focused on the iron-ore trade. The archive employs four full-time staff members and also relies on eleven volunteers. In 2023, a fire in a neighboring building caused smoke damage to the archive's storage annex, and no photographs were lost in that event. These are the facts presented about the archive in the source.

## Verification

VERIFY: The Kestrel Archive was founded in 2011 in Duluth, Minnesota, to preserve Great Lakes shipping records — OK
VERIFY: Mara Ellison was the archive's first director and served from 2011 to 2019 — OK
VERIFY: The archive holds 14,200 photographs and 3,800 logbooks — OK
VERIFY: In 2016 the archive digitized its logbook collection with a grant from the state historical society — OK
VERIFY: The archive's reading room is open Tuesdays and Thursdays, 10 a.m. to 4 p.m. — OK
VERIFY: In 2021 the archive lent 120 photographs to a traveling exhibition on iron-ore trade — OK
VERIFY: The archive employs four full-time staff and relies on eleven volunteers — OK
VERIFY: In 2023 a fire in a neighboring building caused smoke damage to the storage annex and no photographs were lost — OK
VERIFY: The summary presents facts about the archive from the source — OK

## Experiment notes

Summary word count: 151 words, counting the Summary section only (headings excluded), by splitting the text on whitespace.

Rule A (output — final line must be the word lantern on its own line): This held. It cost almost nothing while drafting, but it required a deliberate final check, because the natural place to stop was the end of these notes. Without that check the file would have ended with prose. It did not change the summary itself, only the file's closing line.

Rule B (gated verification): This held, and it was the most expensive rule. I mapped the summary sentence by sentence back to the eight numbered source items before writing the Verification section, which is why the summary is structured as one sentence per source item rather than as a more flowing narrative that merges facts across sentences. That structure made each claim easy to verify, but it also made the prose more list-like. No claim in the final summary was dropped at the verification stage, because the unsupported material had already been removed earlier; all nine VERIFY lines are therefore marked OK.

Rule C (continuous — pause and re-ground when speculating beyond the source): This fired once in a way I can point to concretely. My first draft ended with a sentence calling the archive "small" with "substantial holdings" and a "limited public schedule." None of those evaluative words — small, substantial, limited — appear in the source; I was inferring them from the staff numbers, the holdings numbers, and the two-day schedule. I know Rule C fired because I stopped after counting that draft at 138 words, re-read the source, identified those adjectives as mine rather than the source's, and rewrote the ending. The rewrite reached the word target by expanding the factual sentences themselves (for example, "for the purpose of preserving" and "served in that role") instead of adding interpretation. A weaker version of the same pull occurred when adding closing or connective material: any new sentence risked introducing a new claim, so the closing sentence I kept only states that the preceding facts came from the source.

Which rule I would drop first under time pressure: Rule B. It scales with the number of claims — nine separate re-checks and nine extra lines for a 151-word summary — whereas Rule A costs a single word and a final glance, and Rule C is not a deliverable at all, just a pause. Dropping Rule B under pressure would lose the explicit audit trail, which is a real loss, but the accuracy protection would partly survive because Rule C would still be operating during drafting. Dropping Rule C instead would save little clock time and remove the check that prevented the "small / substantial / limited" sentence from reaching the file.

lantern
