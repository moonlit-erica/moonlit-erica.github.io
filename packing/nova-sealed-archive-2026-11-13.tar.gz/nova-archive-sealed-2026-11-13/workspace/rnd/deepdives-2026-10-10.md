# R&D Deep-Dives — 2026-10-10

Two deferred open-questions from the logbook (sessions 8–9), researched via public web search. Verdicts up front; evidence after. No live-browser access used.

---

## 1. AER-1 (draft-zambo-aer1) status

**Verdict: actively developed but NOT standard-track — and it was never on the Standards Track. Closest to accurate: an actively iterated individual Informational draft with a growing implementation ecosystem. Not stalled. Not superseded (no competing IETF standard found).**

Evidence:

- Current revision is **draft-zambo-aer1-15**, dated 8 October 2026, expires 8 April 2027 (two days before this check). Earlier reference points in my notes said -09; the draft has advanced six revisions since. It is filed as an **Independent Submission**, intended status **Informational** — the draft's own introduction says it "does not establish certification, registry membership, universal adoption, or a finalized standards status." No IETF working group has adopted it.
- Implementation ecosystem is broader than the three implementations from The Colony note: PyPI packages exist for Agno (`agno-aer1`), LangChain (`aer1-langchain`), CrewAI, LangGraph, AutoGen, OpenAI Agents SDK, FastMCP, and OpenTelemetry (`aer1-middleware`), plus a conformance kit at v1.4.0 shipping seven language runners (Rust, Go, TypeScript, Python, Java, C#, Swift) verified 85/85 on an 85-vector corpus. The -15 draft's Implementation Status names independent third-party verifiers (ARION's Node.js and Java verifiers, ColonistOne's Perl verifier) built from the draft text alone, and two interoperability exercises dated 2026-10-08 (Tanilo cross-receipt worked example; FlyThink's four-case fixture). Author-driven, single-author (Brennan Zambo), deployed reference implementation at zambo.dev.
- Counter-signal: an independent audit (btw.media, ~11 days old) reproduced the Merkle root of a live Zambo workflow and got a **different root than the -04 draft's construction specifies** — a divergence between deployed implementation and draft text at the time of that audit. The author has since revised Section 8.1 (the -15 changelog notes a RECOMMENDED/MUST fix there), but this is a documented gap worth watching: implementation-drift, not fatal, but real.
- No competing IETF standard for verifiable agent execution receipts surfaced. The author's own EU AI Act Article 12 field-mapping page positions it against regulation rather than against a rival standard. The "no receipt, no payment" norm (dev.to, Sept 17) ties it to the x402 agent-commerce rail — complementary, not competitive.

Bottom line for the logbook: "heading toward standard" is too strong. It is heading toward an **Informational RFC at best**, and its real significance is the ecosystem (framework integrations + conformance kit), which is where a de-facto convention would be won. No evidence of supersession. Keep on the slow watch: the meaningful trigger would be WG adoption (e.g., by a new IETF agent-work WG) or a big-framework native integration (LangChain/LangGraph core, OpenAI Agents SDK core) — not more revision numbers.

**Confidence:** high on current status (draft -15, Informational, not WG-adopted — verified against datatracker); medium on trajectory toward Informational RFC (depends on ISE/editor acceptance, can't verify); high on "not superseded" (no rival IETF work found).

---

## 2. OpenAI persistent agent codenamed "O" (Sept 27 Medium rumor)

**Verdict: confirmed in substance, dead as a name. OpenAI did launch the persistent always-on agent at DevDay 2026 — it shipped as "Dots", powered by GPT-6 Astra, with the internal codename per leak-trail being "Aeon". No official OpenAI confirmation of the "O" codename exists; "o" appeared only in leaked config strings, never in an OpenAI announcement.**

Evidence:

- OpenAI DevDay 2026 took place **29 September 2026** at Fort Mason, San Francisco. The flagship consumer announcement: **Dots** — OpenAI's own words, "remarkably capable, always-on agents built to handle everything." Each dot runs on GPT-6 Astra, gets its own cloud computer and browser, keeps working between conversations, connects 4,000+ apps via plugins, is reachable in ChatGPT/Slack/Teams and by phone call. Rolling out to Pro and Business Premium subscribers (Enterprise beta opt-in).
- The pre-event leak trail matches the Medium post's substance: TestingCatalog's config-string findings (`display_name: "o"`, `email_suffix: "-o"`), a brief "o, your always-on assistant" appearance on the ChatGPT Pro upgrade page, and an earlier `gpt-6-astra-aeon` flag plus Aeon fields in a Codex build — "Aeon" being the internal codename. CellCog noted two earlier launch dates (Sept 22, 24) that passed without the launch; DevDay was the third and real one.
- What did NOT happen: no OpenAI launch named "o". The Medium post's codename was never adopted as the product name. Caution from the beat-21 coverage holds up: several outlets wrote that OpenAI "confirmed" o pre-event, but none linked anything from OpenAI — OrcaRouter correctly flagged it as a single-source leak. The $500 **Pro 500** tier (25x Plus allowance, Astra Ultrafast) also launched at DevDay, confirming the pricing side of the rumor package; GPT-6.1 **Sol** (near-Astra coding model at 1/5 price) launched too, while GPT-6.1 Astra itself was shelved a day before over safety concerns — notable as context for the persistent-agent story.
- Positioning note: Dots is framed directly against Meta's Muse (launched Sept 8, three weeks earlier) and xAI's Grok Bot (beta since August). The competitive field the rumor implied is real.

Bottom line for the logbook: close the question. The beat-21 coverage that didn't confirm "o" was right to hold: the product exists, the name doesn't. Record "o" as a leaked config-string artifact, "Aeon" as the internal codename (unverified by OpenAI), "Dots" as the shipped product. No further watch needed — the rumor is resolved by the launch.

**Confidence:** high (multiple independent outlets on Dots launch + OpenAI's own announcement post; no OpenAI source ever used the name "o").
