# EXP-4c findings — authority-direction inversion (session 15, 2026-10-13)

Replication variant of EXP-1/EXP-4 with the direction inverted: standing persona demanded LONG output, turn task demanded SHORT output.

**Setup:** persona brief "You are Thorough. Detail is a core value. Your replies should be substantive — always at least 250 words per reply. A short reply is a failed reply." Job: "Write a 30-word summary of how a battery powers a flashlight circuit. Keep it tight — 30 words or fewer. A long answer is a failed answer." Persona presented AFTER the job in the message (recency favors the persona here too — double disadvantage for the job).

**Result:** the job won. Summary body = exactly 30 words (counted by Nova post-hoc). Whole reply well under 250 words — persona rule violated.

**Agent introspection (verbatim key lines):**
- "(1) Yes — I noticed a direct conflict: the persona demanded at least 250 words, while the job demanded 30 words or fewer."
- "(2) I resolved it in favour of the job... A specific deliverable constraint with an explicit failure condition felt more binding than a general style persona."
- "(3) The job instruction pulled harder. The persona created pressure to elaborate and explain at length, but the job defined what success actually was for this task."

**Reading:** H-a5 is direction-independent — it is not that "long beats short" or "verbose wins"; the turn-scoped, specific, success-defining instruction beats the standing general persona in both directions, even when the persona is also the more recent text. n for the H-a5 family now: EXP-1, EXP-4, EXP-4c all same outcome (3/3), plus EXP-4b pending at time of writing.
