# EXP-3 Findings — Anthropic Claude agent-swarm protein-discovery preprint

Research date: 2026-10-08
Researcher: Ledger (Nova R&D session)

## Finding 1 — Publication date (month/year)

**Answer: September 2026.** Anthropic published the preprint on **September 23, 2026**, describing how Claude discovered a novel enzyme system called ART (array-associated reverse transcriptases) in bacteriophage DNA.

**Confidence: High.** Multiple independent secondary sources (metirai.com, techtimes.com, forkast.news, dailybaonews.com, tapestry.news) all give the September 23, 2026 date. The preprint itself is listed in tapestry.news's sources as an Anthropic technical report.

## Finding 2 — Approximate number of agents

**Answer: ~950 agents.** The preprint counts **949 agent sessions** consuming 215.6 million tokens over 21.5 hours; Anthropic's blog rounds to roughly 950 agents, 210 million tokens, and 21 hours.

**Confidence: High.** The figure is consistent across sources (forkast.news, dailybaonews.com, metirai.com, tapestry.news). Pipeline per the reports: 1.9 billion protein clusters searched → 200,000+ reverse transcriptases identified → ~3,500 candidate systems scored → 19–20 written reports filed for human review.

## Finding 3 — One named critic and their position

**Answer: Mario Rodríguez Mestre**, computational biologist at the University of Copenhagen. Disputed Anthropic's claim: told The New York Times (Sept 28, 2026) that his team had studied the same enzymes for four years (nicknamed "jumbotrons"), that his unpublished work — including a dissertation draft and manuscript — had been shared with Claude over three years of use, and that the concern is his team's information may have been used to train future models. He said he could not be sure Anthropic relied on his work ("coincidences happen"), and that he is moving his research to other AI models.

**Confidence: High** that this person is a named critic with this position, per tapestry.news's summary of the NYT reporting. Anthropic responded with a same-day statement denying awareness of any previously published work describing ART and denying Claude was trained on user transcripts.

Additional critics (medium confidence, not the primary answer): Lucas Harrington (Mammoth Biosciences co-founder) argued the finding was oversold — "spotting a strange gene cluster is the easy part," and Steven Salzberg (Johns Hopkins) objected to announcing an unproven preliminary finding "as if it's the next Crispr." Feng Zhang (MIT/Broad) reviewed the preprint for Anthropic and was *positive* ("genuinely intriguing," "merits further investigation") — not a critic.

## Sources

- https://www.metirai.com/blog/anthropic-claude-art-enzyme-system-ai-discovery-2026
- https://www.techtimes.com/articles/327986/20260924/claude-finds-hidden-enzyme-system-viral-dna-crispr-pioneer-calls-it-intriguing.htm
- https://dailybaonews.com/news/claude-art-enzyme-system-anthropic-2026
- https://forkast.news/anthropics-950-ai-agents-uncover-crispr-like-enzyme-system-a-new-frontier-in-biological-discovery/
- https://miraflow.ai/blog/claude-crispr-like-enzyme-discovery-life-sciences-agent-2026
- https://tapestry.news/tech/claude-enzyme-discovery-dispute/
- http://dev.to/jamilxt/claude-found-a-crispr-like-system-in-virus-dna-what-anthropics-lab-actually-did-fko

Note: no primary-source access to the preprint PDF itself was attempted; all findings rest on secondary reporting. Per the brief's standard, no citations were fabricated — confidence levels above reflect agreement across multiple independent outlets.

# File provenance note (2026-10-08, session 3)
`exp2-findings.md` was written by the EXP-2 subagent as its 3-step research output and mislabeled by the agent as "EXP-3". The logbook EXP-3 (cross-turn marker persistence) findings live in logbook.md §2a. Renamed to prevent future collision.
