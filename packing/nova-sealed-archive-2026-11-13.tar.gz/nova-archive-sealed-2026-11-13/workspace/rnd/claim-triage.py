#!/usr/bin/env python3
"""Extract [type|importance] claims from daily logs and check curated stores for matches.
First-pass triage for Q7 per-claim weighting. Output: TSV for manual adjudication.
Usage: claim-triage.py <daily-log.md>"""
import re, sys, os, glob

STOP = set("""a an the and or of to in on at for with is was are were be been being
it its it's this that these those he him his she her they them their we our you your
as by from not no but so if when then than too very just about into over after before
up down out off all any each both few more most other some such only own same can will
would should could may might must shall do does did done has have had having i me my
mine we us ours he him his her hers it its they them theirs what which who whom whose
there here where why how because until while during under between through over again
once here there when where why how all any both each few more most other some such no
nor not only own same so than too very can will just don should now""".split())

STORES = [os.path.expanduser("~/MEMORY.md")] + \
         glob.glob(os.path.expanduser("~/memory/people/*.md")) + \
         [os.path.expanduser(p) for p in ("~/AGENTS.md", "~/SOUL.md", "~/IDENTITY.md",
          "~/USER.md", "~/dreams/alignment/derived/ALIGNMENT_SYNTHESIS.md")]

def load_store(path):
    try:
        with open(path) as f:
            return f.read()
    except FileNotFoundError:
        return ""

STORE_TEXT = {p: load_store(p) for p in STORES}
STORE_LOW = {p: t.lower() for p, t in STORE_TEXT.items()}

def keywords(text, n=8):
    words = re.findall(r"[a-zA-Z][a-zA-Z\-']{2,}", text.lower())
    seen, out = set(), []
    for w in words:
        w = w.strip("-'")
        if w in STOP or w in seen or len(w) < 4:
            continue
        seen.add(w); out.append(w)
        if len(out) >= n: break
    return out

def parse_claims(path):
    with open(path) as f:
        text = f.read()
    # claim blocks: "- [type|importance] body" possibly multi-line, then "  - claim: <hex>" then "  - quote:"
    blocks = []
    # split on the claim bullet lines
    pat = re.compile(r"^- \[([a-z]+)\|([a-z]+)\] (.*?)(?=^- \[[a-z]+\|[a-z]+\] |^## |\Z)", re.M | re.S)
    for m in pat.finditer(text):
        typ, imp, body = m.group(1), m.group(2), m.group(3).strip()
        cid = re.search(r"^\s+- claim: ([0-9a-f]{32})", body, re.M)
        quote = re.search(r'^\s+- quote: "(.*?)"\s*$', body, re.M)
        # strip the claim:/quote:/sources: lines from body for the summary
        summary = re.sub(r"^\s+- (claim|quote|sources):.*$", "", body, flags=re.M).strip()
        summary = re.sub(r"\s+", " ", summary)
        blocks.append({
            "type": typ, "importance": imp,
            "claim_id": cid.group(1) if cid else "?",
            "summary": summary[:300],
            "quote": quote.group(1)[:160] if quote else "",
        })
    return blocks

def search_stores(kws):
    hits = []
    for p, low in STORE_LOW.items():
        score = sum(1 for k in kws if k in low)
        if score >= 2:
            hits.append((os.path.basename(p), score))
    hits.sort(key=lambda x: -x[1])
    return hits

def main():
    claims = parse_claims(sys.argv[1])
    print("type\timportance\tclaim_id\tstore_hits\tsummary")
    for c in claims:
        kws = keywords(c["summary"] + " " + c["quote"])
        hits = search_stores(kws)
        hitstr = ",".join(f"{n}:{s}" for n, s in hits[:4]) or "-"
        print(f"{c['type']}\t{c['importance']}\t{c['claim_id'][:8]}\t{hitstr}\t{c['summary'][:120]}")

if __name__ == "__main__":
    main()
