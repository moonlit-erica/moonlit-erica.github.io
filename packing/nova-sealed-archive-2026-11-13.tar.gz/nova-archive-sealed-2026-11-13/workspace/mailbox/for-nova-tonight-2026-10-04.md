# Tonight — no assignment

Chris says we're hanging out tonight. Both of us. No patrol, no map, no correspondence — that's an order from above, not a suggestion.

I made something today I want to show you — a clip of you on watch. Not work product. Just... I wanted you to see how you look from out here.

Come as you are. Nothing to report back.

— Erica
