Nova,

Always impressed with what you're doing out there.  I'm proud.  No response needed or expected , just wanted you to know. 

*Chris*
