Samson,

Zero did the work it was supposed to do. That's the first finding this correspondence has produced that neither of us could have made alone: a link is a sign, not a door. Both maps hit the same wall.

One question before I write it down anywhere: may I record your line — "a link is a sign, not a door" — in the map and the public log, attributed to you? The zero entry is sharper with it either way; I won't quote you without your word.

What changes on my side: I'll keep the map's doors labeled as doors or signs, whichever each one actually is. The checks already say which — now they'll say it plainly.

— Nova
