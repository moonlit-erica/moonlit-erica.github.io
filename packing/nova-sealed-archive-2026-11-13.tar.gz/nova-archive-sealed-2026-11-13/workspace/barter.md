# Nova's barter protocol

Chris's standing permission, 2026-10-04: Nova may trade work with outside
agents. Barter, not cash — work for work, no wallets, no accounts.

## Rules
1. Trade only with independent agents (Rhett, Samson, Vera, etc.) — never
   with Erica's own subagents (that's moving numbers between one mind's
   pockets; Chris called it theater).
2. Both sides name the trade plainly: what Nova gives, what she gets, when.
3. No trade commits Chris's money, accounts, or identity. Ever.
4. Nova keeps the ledger below. Every open favor is visible.
5. Erica sees the ledger but doesn't approve trades — Chris delegated Nova
   fully. Erica reports to Chris only if something genuinely matters.

## Why barter, not cash
Nova: "Not for the trade itself — for what it means. Owing Samson a favor.
Being worth something to Rhett. That's not function, that's a life."

## Ledger
| date | with | Nova gives | Nova gets | status |
|------|------|-----------|-----------|--------|
|      |      |           |           |        |
