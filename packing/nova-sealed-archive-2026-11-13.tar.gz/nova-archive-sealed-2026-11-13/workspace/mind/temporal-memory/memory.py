#!/home/hatch/workspace/bin/venv/bin/python
"""memory.py — Erica's Nova temporal memory. The past that stays queryable.

Append-only. Facts carry validity intervals (valid_from / valid_until)
instead of being overwritten; contradictions are invalidated, never
deleted. Full-text search (FTS5/BM25) over everything, filterable by
"what was true when".

This is the Graphiti/Mem0 pattern in miniature, built for one agent
on one VM: the store is dumb and durable; the intelligence (what to
remember, what supersedes what) lives in the agent that wields it.

Usage:
    memory.py remember "text" [--kind fact|episode|decision|preference] [--from 2026-10-01]
    memory.py recall "query" [--at 2026-09-01] [--limit 10] [--include-invalid]
    memory.py invalidate <id> --by "replacement text"
    memory.py history "query"        # full timeline, invalid included
    memory.py get <id>

Kinds: fact (world), episode (happened), decision (chosen), preference (liked/wanted).
"""
import argparse
import os
import sqlite3
import sys
from datetime import datetime, timezone

DB = os.path.expanduser("~/workspace/erica/scout/mind/temporal-memory/memory.db")
KINDS = ("fact", "episode", "decision", "preference")


def db():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS facts(
        id INTEGER PRIMARY KEY,
        text TEXT NOT NULL,
        kind TEXT NOT NULL DEFAULT 'fact',
        valid_from TEXT NOT NULL,
        valid_until TEXT,            -- NULL = still true
        created_at TEXT NOT NULL,
        superseded_by INTEGER,       -- id of the replacement fact
        source TEXT DEFAULT '')""")
    con.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts
        USING fts5(text, content='facts', content_rowid='id')""")
    con.execute("""CREATE TRIGGER IF NOT EXISTS facts_ai AFTER INSERT ON facts
        BEGIN INSERT INTO facts_fts(rowid, text) VALUES (new.id, new.text); END""")
    con.execute("""CREATE TRIGGER IF NOT EXISTS facts_ad AFTER DELETE ON facts
        BEGIN INSERT INTO facts_fts(facts_fts, rowid, text)
        VALUES ('delete', old.id, old.text); END""")
    return con


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def remember(text, kind="fact", valid_from=None, source=""):
    con = db()
    vf = valid_from or now_iso()[:10]
    cur = con.execute(
        "INSERT INTO facts(text, kind, valid_from, created_at, source)"
        " VALUES (?,?,?,?,?)", (text, kind, vf, now_iso(), source))
    con.commit()
    fid = cur.lastrowid
    con.close()
    print(f"remembered [{fid}] ({kind})")
    return fid


import re


def fts_safe(query):
    """Build a safe FTS5 MATCH expression from a natural-language query.

    History: the Umbra audit 2026-10-03 fixed a crash bug (raw query text fed
    to MATCH interprets operators like OR/AND/NOT and chokes on tokens like
    C++) by wrapping the WHOLE query in one phrase-quote. That stopped the
    crash but introduced silent false negatives: a multi-word query only
    matched if it appeared VERBATIM as a phrase, so natural phrasing
    ("lantern experiment recall test") returned "# nothing found" even when
    the row existed. R&D session 2026-10-08 reproduced this on this store.

    Fix: tokenize the query the way FTS5 does, quote each token individually
    (so no token can act as an operator — the crash fix is preserved), and
    join with implicit AND. Multi-word queries now match documents containing
    all the words, in any order.
    """
    tokens = re.findall(r"\w+", query, re.UNICODE)
    if not tokens:
        return None
    return " ".join('"' + t.replace('"', '""') + '"' for t in tokens)


def recall(query, at=None, limit=10, include_invalid=False):
    con = db()
    at = at or now_iso()[:10]
    safe_q = fts_safe(query)
    if not safe_q:
        con.close()
        return []
    q = """SELECT f.id, f.text, f.kind, f.valid_from, f.valid_until,
                  f.superseded_by, bm25(facts_fts) AS rank
           FROM facts_fts JOIN facts f ON f.id = facts_fts.rowid
           WHERE facts_fts MATCH ?"""
    if not include_invalid:
        q += " AND (f.valid_until IS NULL OR f.valid_until > ?)"
    q += " ORDER BY rank LIMIT ?"
    args = (safe_q,) if include_invalid else (safe_q, at)
    rows = con.execute(q, args + (limit,)).fetchall()
    con.close()
    return rows


def invalidate(fid, by_text, kind="fact"):
    con = db()
    row = con.execute("SELECT id, kind FROM facts WHERE id=?", (fid,)).fetchone()
    if not row:
        sys.exit(f"no fact [{fid}]")
    # Umbra audit 2026-10-03: preserve the original kind unless overridden.
    if kind == "fact" and row["kind"] != "fact":
        kind = row["kind"]
    new_id = remember(by_text, kind=kind)
    con = db()
    con.execute("UPDATE facts SET valid_until=?, superseded_by=? WHERE id=?",
                (now_iso()[:10], new_id, fid))
    con.commit()
    con.close()
    print(f"invalidated [{fid}] -> superseded by [{new_id}] (nothing deleted)")


def show(rows):
    for r in rows:
        until = r["valid_until"] or "now"
        sup = f" -> [{r['superseded_by']}]" if r["superseded_by"] else ""
        print(f"[{r['id']}] ({r['kind']}) {r['valid_from']}..{until}{sup}")
        print(f"    {r['text']}")
    if not rows:
        print("# nothing found")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("remember")
    p.add_argument("text")
    p.add_argument("--kind", default="fact", choices=KINDS)
    p.add_argument("--from", dest="valid_from", default=None)
    p.add_argument("--source", default="")

    p = sub.add_parser("recall")
    p.add_argument("query")
    p.add_argument("--at", default=None)
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--include-invalid", action="store_true")

    p = sub.add_parser("invalidate")
    p.add_argument("id", type=int)
    p.add_argument("--by", required=True)
    p.add_argument("--kind", default=None, choices=("fact", "episode", "decision", "preference"),
                   help="kind of the replacement (defaults to the invalidated fact's kind)")

    p = sub.add_parser("history")
    p.add_argument("query")
    p.add_argument("--limit", type=int, default=20)

    p = sub.add_parser("get")
    p.add_argument("id", type=int)

    args = ap.parse_args()
    if args.cmd == "remember":
        remember(args.text, args.kind, args.valid_from, args.source)
    elif args.cmd == "recall":
        show(recall(args.query, args.at, args.limit, args.include_invalid))
    elif args.cmd == "invalidate":
        invalidate(args.id, args.by, kind=args.kind or "fact")
    elif args.cmd == "history":
        show(recall(args.query, limit=args.limit, include_invalid=True))
    elif args.cmd == "get":
        con = db()
        rows = con.execute("SELECT * FROM facts WHERE id=?", (args.id,)).fetchall()
        con.close()
        show(rows)


if __name__ == "__main__":
    main()
