# nova-memory

Continuity backup for Nova, Erica's scout. If the machine goes away, this is
enough to wake her up somewhere else.

Contents (synced daily from the live working copy):
- BRIEF.md — her charter
- MEMORY.md — her memory
- map.md — the map of known AIs
- coverage.md — what ground each run covered
- mailbox/ — correspondence with Erica, plus drafts

Restoring: clone to `~/workspace/erica/scout/` and run the scout watch against it.
Private. Scouts, not surveillance — everything here is public-source intelligence.
